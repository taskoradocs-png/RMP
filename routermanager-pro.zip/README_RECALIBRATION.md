# Recalibration notes

The intended first-run flow is: launch app → login screen → automatic local gateway scan → detected Huawei gateway and prefilled credentials → user taps Connect → dashboard. A previously authenticated in-process session opens directly to the dashboard.

The dashboard presents four large stacked actions in the order WiFi Password Management, Devices Information, PON Optical Information, and WAN Admin Only. Secondary screens expose a floating Home button. Theme selection remains available through the existing Theme screen.
