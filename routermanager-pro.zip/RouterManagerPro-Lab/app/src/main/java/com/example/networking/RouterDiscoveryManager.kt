package com.example.networking

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.models.DiscoveredAdminInterface
import com.example.models.DiscoveredRouter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket

data class LocalNetworkSnapshot(
    val isWifiActive: Boolean,
    val isEthernetActive: Boolean,
    val interfaceName: String?,
    val localIpv4Address: String?,
    val subnetPrefixLength: Int?,
    val defaultGatewayIp: String?,
    val errorDetail: String? = null
)

interface NetworkEnvironmentInspector {
    suspend fun inspectActiveNetwork(): LocalNetworkSnapshot
}

interface GatewayEndpointProber {
    suspend fun checkReachability(hostIp: String, probePorts: List<Int>, timeoutMs: Int): Pair<Boolean, Long?>
    suspend fun probeAdminInterface(hostIp: String, scheme: String, port: Int, timeoutMs: Int): DiscoveredAdminInterface?
}

class AndroidNetworkEnvironmentInspector(
    private val context: Context
) : NetworkEnvironmentInspector {

    override suspend fun inspectActiveNetwork(): LocalNetworkSnapshot = withContext(Dispatchers.IO) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return@withContext LocalNetworkSnapshot(
                isWifiActive = false,
                isEthernetActive = false,
                interfaceName = null,
                localIpv4Address = findFallbackLocalIpv4(),
                subnetPrefixLength = null,
                defaultGatewayIp = null,
                errorDetail = "Android ConnectivityManager is unavailable on this device."
            )

        val activeNetwork = cm.activeNetwork
            ?: return@withContext LocalNetworkSnapshot(
                isWifiActive = false,
                isEthernetActive = false,
                interfaceName = null,
                localIpv4Address = null,
                subnetPrefixLength = null,
                defaultGatewayIp = null,
                errorDetail = "No active Wi-Fi or Ethernet connection detected."
            )

        val caps = cm.getNetworkCapabilities(activeNetwork)
        val isWifi = caps?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        val isEthernet = caps?.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) == true

        if (!isWifi && !isEthernet) {
            return@withContext LocalNetworkSnapshot(
                isWifiActive = false,
                isEthernetActive = false,
                interfaceName = null,
                localIpv4Address = null,
                subnetPrefixLength = null,
                defaultGatewayIp = null,
                errorDetail = "Active network is not Wi-Fi or Ethernet. Connect to your router's Wi-Fi network first."
            )
        }

        val linkProperties = cm.getLinkProperties(activeNetwork)
        val ipv4LinkAddr = linkProperties?.linkAddresses
            ?.firstOrNull { it.address is Inet4Address && !it.address.isLoopbackAddress }

        val localIpv4 = ipv4LinkAddr?.address?.hostAddress ?: findFallbackLocalIpv4()
        val prefixLen = ipv4LinkAddr?.prefixLength

        val gatewayIp = linkProperties?.routes
            ?.firstOrNull { it.isDefaultRoute && it.gateway is Inet4Address }
            ?.gateway
            ?.hostAddress
            ?: linkProperties?.dhcpServerAddress?.hostAddress

        LocalNetworkSnapshot(
            isWifiActive = isWifi,
            isEthernetActive = isEthernet,
            interfaceName = linkProperties?.interfaceName,
            localIpv4Address = localIpv4,
            subnetPrefixLength = prefixLen,
            defaultGatewayIp = gatewayIp,
            errorDetail = if (gatewayIp.isNullOrBlank()) {
                "Connected to ${if (isWifi) "Wi-Fi" else "Ethernet"}, but default IPv4 gateway could not be resolved."
            } else null
        )
    }

    private fun findFallbackLocalIpv4(): String? {
        return runCatching {
            NetworkInterface.getNetworkInterfaces()?.toList()
                ?.filter { it.isUp && !it.isLoopback }
                ?.flatMap { it.inetAddresses.toList() }
                ?.firstOrNull { it is Inet4Address && !it.isLoopbackAddress }
                ?.hostAddress
        }.getOrNull()
    }
}

class OkHttpGatewayEndpointProber : GatewayEndpointProber {
    private val json = Json { ignoreUnknownKeys = true; isLenient = true }
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    override suspend fun checkReachability(
        hostIp: String,
        probePorts: List<Int>,
        timeoutMs: Int
    ): Pair<Boolean, Long?> = withContext(Dispatchers.IO) {
        val startNs = System.nanoTime()
        for (port in probePorts) {
            val ok = tryTcpConnect(hostIp, port, timeoutMs)
            if (ok) {
                val elapsedMs = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
                return@withContext true to elapsedMs
            }
        }
        val icmpReachable = runCatching { InetAddress.getByName(hostIp).isReachable(timeoutMs) }.getOrDefault(false)
        if (icmpReachable) {
            val elapsedMs = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
            true to elapsedMs
        } else {
            false to null
        }
    }

    override suspend fun probeAdminInterface(
        hostIp: String,
        scheme: String,
        port: Int,
        timeoutMs: Int
    ): DiscoveredAdminInterface? = withContext(Dispatchers.IO) {
        val connectStartNs = System.nanoTime()
        if (!tryTcpConnect(hostIp, port, timeoutMs)) {
            return@withContext null
        }
        val connectLatencyMs = ((System.nanoTime() - connectStartNs) / 1_000_000L).coerceAtLeast(1L)

        val timeoutSec = ((timeoutMs + 999) / 1000).coerceAtLeast(2).toLong()
        val client = RouterEndpointClient.createClient(
            allowPrivateLanSelfSignedTls = scheme.equals("https", ignoreCase = true),
            targetHost = hostIp,
            connectTimeoutSeconds = timeoutSec,
            readTimeoutSeconds = timeoutSec
        )

        val baseUrl = "$scheme://$hostIp:$port"

        // 1. Safe conservative probe for OpenWrt /ubus JSON-RPC endpoint
        val ubusProbePayload = """{"jsonrpc":"2.0","id":1,"method":"call","params":["00000000000000000000000000000000","system","board",{}]}"""
        val ubusCheck = runCatching {
            val req = Request.Builder()
                .url("$baseUrl/ubus")
                .post(ubusProbePayload.toRequestBody(jsonMediaType))
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty().take(4096)
                val isJsonRpc = body.contains("\"jsonrpc\"") &&
                    runCatching {
                        val obj = json.parseToJsonElement(body).jsonObject
                        obj["jsonrpc"]?.jsonPrimitive?.content == "2.0" &&
                            (obj.containsKey("result") || obj.containsKey("error"))
                    }.getOrDefault(false)
                Triple(resp.code, isJsonRpc, resp.header("Server"))
            }
        }.getOrNull()

        if (ubusCheck != null && ubusCheck.second) {
            return@withContext DiscoveredAdminInterface(
                scheme = scheme.lowercase(),
                port = port,
                isReachable = true,
                latencyMs = connectLatencyMs,
                statusCode = ubusCheck.first,
                fingerprintHint = "OpenWrt ubus JSON-RPC API detected",
                detectedAdapterId = "openwrt_luci"
            )
        }

        // 2. Probe LuCI /cgi-bin/luci or root web admin metadata without assuming compatibility
        val luciCheck = runCatching {
            val req = Request.Builder()
                .url("$baseUrl/cgi-bin/luci")
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty().take(4096)
                val serverHeader = resp.header("Server")
                val hasLuciMarker = body.contains("luci", ignoreCase = true) ||
                    body.contains("openwrt", ignoreCase = true) ||
                    resp.header("Set-Cookie").orEmpty().contains("sysauth", ignoreCase = true)
                Triple(resp.code, hasLuciMarker, serverHeader)
            }
        }.getOrNull()

        if (luciCheck != null && luciCheck.second && luciCheck.first in 200..403) {
            return@withContext DiscoveredAdminInterface(
                scheme = scheme.lowercase(),
                port = port,
                isReachable = true,
                latencyMs = connectLatencyMs,
                statusCode = luciCheck.first,
                fingerprintHint = "OpenWrt LuCI web interface detected",
                detectedAdapterId = "openwrt_luci"
            )
        }

        // 3. Fallback root HTTP status check (never assume gateway is a compatible router API)
        val rootCheck = runCatching {
            val req = Request.Builder()
                .url("$baseUrl/")
                .get()
                .build()
            client.newCall(req).execute().use { resp ->
                val server = resp.header("Server")
                resp.code to server
            }
        }.getOrNull()

        val statusCode = rootCheck?.first ?: ubusCheck?.first
        val server = rootCheck?.second ?: ubusCheck?.third
        val serverNote = server?.let { " ($it)" } ?: ""
        DiscoveredAdminInterface(
            scheme = scheme.lowercase(),
            port = port,
            isReachable = true,
            latencyMs = connectLatencyMs,
            statusCode = statusCode,
            fingerprintHint = "Web endpoint HTTP ${statusCode ?: "?"}$serverNote — API not identified",
            detectedAdapterId = null
        )
    }

    private fun tryTcpConnect(hostIp: String, port: Int, timeoutMs: Int): Boolean {
        return runCatching {
            Socket().use { socket ->
                socket.connect(InetSocketAddress(hostIp, port), timeoutMs)
            }
            true
        }.getOrDefault(false)
    }
}

/**
 * Discovers active Wi-Fi/Ethernet link details, local IPv4, default gateway,
 * gateway reachability, and available HTTP/HTTPS administration ports without
 * assuming an unidentified gateway exposes a compatible router API.
 */
class RouterDiscoveryManager(
    private val networkInspector: NetworkEnvironmentInspector,
    private val endpointProber: GatewayEndpointProber = OkHttpGatewayEndpointProber(),
    private val candidateAdminPorts: List<Pair<String, Int>> = DEFAULT_ADMIN_ENDPOINTS,
    private val probeTimeoutMs: Int = 1500
) : GatewayDiscoveryService {

    constructor(context: Context) : this(
        networkInspector = AndroidNetworkEnvironmentInspector(context),
        endpointProber = OkHttpGatewayEndpointProber()
    )

    override suspend fun inspectLocalNetwork(): DiscoveryScanResult = withContext(Dispatchers.IO) {
        val snapshot = networkInspector.inspectActiveNetwork()
        val gatewayIp = snapshot.defaultGatewayIp

        if (gatewayIp.isNullOrBlank()) {
            return@withContext DiscoveryScanResult(
                routers = emptyList(),
                localGatewayIp = null,
                localIpv4Address = snapshot.localIpv4Address,
                isWifiActive = snapshot.isWifiActive,
                isEthernetActive = snapshot.isEthernetActive,
                interfaceName = snapshot.interfaceName,
                gatewayReachable = false,
                statusMessage = snapshot.errorDetail
                    ?: "No active Wi-Fi/Ethernet gateway detected."
            )
        }

        val uniquePorts = candidateAdminPorts.map { it.second }.distinct()
        val (reachable, baseLatencyMs) = endpointProber.checkReachability(
            hostIp = gatewayIp,
            probePorts = uniquePorts,
            timeoutMs = probeTimeoutMs
        )

        val adminInterfaces = if (reachable) {
            coroutineScope {
                candidateAdminPorts.map { (scheme, port) ->
                    async {
                        endpointProber.probeAdminInterface(
                            hostIp = gatewayIp,
                            scheme = scheme,
                            port = port,
                            timeoutMs = probeTimeoutMs
                        )
                    }
                }.awaitAll().filterNotNull()
            }
        } else {
            emptyList()
        }

        val identifiedInterface = adminInterfaces.firstOrNull { it.detectedAdapterId != null }
        val preferredInterface = identifiedInterface
            ?: adminInterfaces.firstOrNull { it.scheme == "https" }
            ?: adminInterfaces.firstOrNull()

        val matchedAdapterId = if (gatewayIp == "192.168.100.1") {
            "huawei_hs8346r"
        } else {
            identifiedInterface?.detectedAdapterId
        }
        val manufacturerHint = when (matchedAdapterId) {
            "openwrt_luci" -> "OpenWrt Router (Detected)"
            "huawei_hs8346r" -> "Huawei HS8346R (Gateway Match)"
            else -> if (!reachable) "Unreachable Gateway" else "Unidentified Gateway"
        }
        val modelHint = when {
            !reachable -> "Gateway $gatewayIp did not respond to TCP/ICMP probes."
            gatewayIp == "192.168.100.1" -> "Known Huawei HS8346R gateway address; confirm the login interface before authentication."
            identifiedInterface != null -> identifiedInterface.fingerprintHint
                ?: "Detected compatible OpenWrt endpoint on ${identifiedInterface.scheme.uppercase()}:${identifiedInterface.port}."
            adminInterfaces.isNotEmpty() -> "Admin interface open (${adminInterfaces.joinToString { "${it.scheme.uppercase()}:${it.port}" }}), but router API was not automatically identified. Verify adapter manually."
            else -> "Gateway responds to ping, but no HTTP/HTTPS admin port (${uniquePorts.joinToString()}) is open."
        }

        val sourceLabel = buildString {
            append(if (snapshot.isWifiActive) "Wi-Fi" else if (snapshot.isEthernetActive) "Ethernet" else "LAN")
            if (!snapshot.interfaceName.isNullOrBlank()) append(" (${snapshot.interfaceName})")
            append(" Default Route")
        }

        val discovered = DiscoveredRouter(
            hostIp = gatewayIp,
            port = preferredInterface?.port ?: 443,
            supportsHttps = adminInterfaces.any { it.scheme == "https" },
            manufacturerHint = manufacturerHint,
            modelHint = modelHint,
            discoverySource = sourceLabel,
            matchedAdapterId = matchedAdapterId,
            isReachable = reachable,
            reachabilityLatencyMs = preferredInterface?.latencyMs ?: baseLatencyMs,
            adminInterfaces = adminInterfaces
        )

        val statusMsg = buildString {
            val netLabel = if (snapshot.isWifiActive) "Wi-Fi" else if (snapshot.isEthernetActive) "Ethernet" else "LAN"
            append("$netLabel active")
            snapshot.localIpv4Address?.let { append(" · Local IP $it") }
            append(" · Gateway $gatewayIp")
            if (reachable) {
                append(" (Reachable")
                discovered.reachabilityLatencyMs?.let { append(", ${it}ms") }
                append(")")
                if (adminInterfaces.isEmpty()) {
                    append(". No HTTP/HTTPS admin ports answered.")
                } else {
                    append(". Interfaces: ${adminInterfaces.joinToString { "${it.scheme.uppercase()}:${it.port}" }}.")
                }
            } else {
                append(" (Unreachable).")
            }
        }

        DiscoveryScanResult(
            routers = listOf(discovered),
            localGatewayIp = gatewayIp,
            localIpv4Address = snapshot.localIpv4Address,
            isWifiActive = snapshot.isWifiActive,
            isEthernetActive = snapshot.isEthernetActive,
            interfaceName = snapshot.interfaceName,
            gatewayReachable = reachable,
            statusMessage = statusMsg
        )
    }

    companion object {
        val DEFAULT_ADMIN_ENDPOINTS = listOf(
            "https" to 443,
            "http" to 80,
            "https" to 8443,
            "http" to 8080
        )
    }
}

/**
 * Legacy wrapper preserved for compatibility; delegates to RouterDiscoveryManager.
 */
class AndroidGatewayDiscoveryService(
    context: Context
) : GatewayDiscoveryService {
    private val delegate = RouterDiscoveryManager(context)
    override suspend fun inspectLocalNetwork(): DiscoveryScanResult = delegate.inspectLocalNetwork()
}
