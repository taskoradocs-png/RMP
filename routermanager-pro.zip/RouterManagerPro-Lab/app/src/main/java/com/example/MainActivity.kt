package com.example

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.AppContainer
import com.example.core.ThemePreference
import com.example.database.AppSecurityPreferences
import com.example.designsystem.RouterManagerTheme
import com.example.navigation.RouterNavShell

class MainActivity : ComponentActivity() {
    private lateinit var appContainer: AppContainer

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        appContainer = AppContainer.getInstance(applicationContext)

        setContent {
            val prefs by appContainer.preferencesStore.preferencesFlow.collectAsStateWithLifecycle(
                initialValue = AppSecurityPreferences()
            )
            val useDarkBars = when (prefs.themePreference) {
                ThemePreference.DARK -> true
                ThemePreference.LIGHT -> false
                ThemePreference.SYSTEM -> isSystemInDarkTheme()
            }

            DisposableEffect(useDarkBars) {
                enableEdgeToEdge(
                    statusBarStyle = if (useDarkBars) {
                        SystemBarStyle.dark(Color.TRANSPARENT)
                    } else {
                        SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                    },
                    navigationBarStyle = if (useDarkBars) {
                        SystemBarStyle.dark(Color.TRANSPARENT)
                    } else {
                        SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
                    }
                )
                onDispose {}
            }

            LaunchedEffect(Unit) {
                if (!appContainer.hasSyncedInitialMode) {
                    val initialPrefs = appContainer.preferencesStore.preferencesFlow.first()
                    appContainer.settingsRepository.syncModeFromPreferences(initialPrefs.appMode)
                    appContainer.hasSyncedInitialMode = true
                }
            }

            RouterManagerTheme(
                themePreference = prefs.themePreference,
                accentColor = prefs.accentColor,
                themeStyle = prefs.themeStyle,
                cornerStyle = prefs.cornerStyle
            ) {
                RouterNavShell(appContainer = appContainer)
            }
        }
    }

}
