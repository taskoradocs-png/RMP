package com.example.adapters.live

import android.util.Base64
import com.example.core.RouterResult
import com.example.models.*
import com.example.networking.RouterEndpointClient
import com.example.router.huawei.hs8346r.HuaweiHs8346rProfile
import com.example.authentication.RouterSessionManager
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.Request
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Live hardware adapter for Huawei HS8346R ONT.
 *
 * Handles HTTP authentication, router information,
 * optical telemetry and session management.
 */
class HuaweiHs8346rAdapter(
    private val hostIp: String = "192.168.100.1",
    private val port: Int = 80,
    private val sessionManager: RouterSessionManager = RouterSessionManager()
) : BaseLiveRouterAdapter() {

    private val baseUrl = "http://$hostIp:$port"

    private val client = RouterEndpointClient.createClient(
        allowPrivateLanSelfSignedTls = true,
        targetHost = hostIp,
        enableDebugMetadataLogs = false
    ).newBuilder()
        .cookieJar(sessionManager.cookieJar)
        .build()

    private var activeSessionToken: String? = null

    override val capabilities = RouterCapability(
        supportedFeatures = setOf(
            RouterFeature.ROUTER_INFO,
            RouterFeature.WAN_INFO,
            RouterFeature.DEVICE_LIST,
            RouterFeature.OPTICAL_INFO
        ),
        supports5Ghz = true,
        maxGuestNetworks = 0,
        capabilityNotes =
            "Huawei HS8346R HTTP CGI/ASP adapter. Reboot endpoint requires verification."
    )

    override val descriptor = AdapterDescriptor(
        id = "huawei_hs8346r",
        displayName = HuaweiHs8346rProfile.MODEL,
        manufacturer = "Huawei",
        supportedModels = listOf("HS8346R"),
        minFirmwareVersion = HuaweiHs8346rProfile.FIRMWARE_VERSION,
        protocolDescription =
            "Huawei ONT HTTP CGI / ASP session communication",
        capability = capabilities,
        isLiveTransportReady = true
    )

    // ------------------------------------------------
    // AUTHENTICATION
    // ------------------------------------------------

    override suspend fun authenticate(
        credentials: RouterCredentials
    ): RouterResult<RouterSession> = withContext(Dispatchers.IO) {
        try {
                sessionManager.clearSession()
                activeSessionToken = null

                // Fetch router login page.
                val indexRequest = Request.Builder()
                    .url("$baseUrl/")
                    .get()
                    .build()

                val indexHtml = client.newCall(indexRequest)
                    .execute()
                    .use { response ->

                        if (!response.isSuccessful) {
                            return@withContext RouterResult.Failure(
                                "Unable to access Huawei login page. HTTP ${response.code}"
                            )
                        }

                        response.body?.string().orEmpty()
                    }

                // Extract dynamic Huawei token.
                val tokenRegex = Regex(
                    """function\s+GetRandCnt\s*\(\s*\)\s*\{\s*return\s*['"]([a-fA-F0-9]+)['"]"""
                )

                val token = tokenRegex.find(indexHtml)
                    ?.groupValues
                    ?.get(1)
                    ?: return@withContext RouterResult.Failure(
                        "Huawei authentication token was not found."
                    )

                // Encode password according to the observed login protocol.
                val encodedPassword = Base64.encodeToString(
                    credentials.password.toByteArray(Charsets.UTF_8),
                    Base64.NO_WRAP
                )

                val loginBody = FormBody.Builder()
                    .add("UserName", credentials.username)
                    .add("PassWord", encodedPassword)
                    .add("x.X_HW_Token", token)
                    .build()

                val loginRequest = Request.Builder()
                    .url("$baseUrl${HuaweiHs8346rProfile.Paths.LOGIN}")
                    .post(loginBody)
                    .addHeader(
                        "Cookie",
                        "Cookie=body:Language:english:id=-1"
                    )
                    .build()

                val loginSuccess = client.newCall(loginRequest)
                    .execute()
                    .use { response ->

                        val body = response.body?.string().orEmpty()

                        response.isSuccessful &&
                            !body.contains("DivErrPage", ignoreCase = true) &&
                            !body.contains("Login failed", ignoreCase = true)
                    }

                if (!loginSuccess) {
                    sessionManager.clearSession()

                    return@withContext RouterResult.Failure(
                        "Huawei HS8346R authentication rejected. Verify credentials."
                    )
                }

                activeSessionToken = token

                val session = RouterSession(
                    sessionId = "huawei-session-${System.currentTimeMillis()}",
                    profileId = "huawei_hs8346r",
                    routerIp = hostIp,
                    adapterId = descriptor.id,
                    authenticatedUsername = credentials.username,
                    establishedAtEpochMs = System.currentTimeMillis(),
                    isDemoSession = false
                )

                RouterResult.Success(session)

        } catch (e: Exception) {
            sessionManager.clearSession()
            val detail = e.message?.takeIf { it.isNotBlank() }
                ?: e.cause?.message?.takeIf { it.isNotBlank() }
                ?: "no exception message"
            RouterResult.Failure(
                "Huawei authentication failed (${e::class.java.simpleName}): $detail"
            )
        }
    }

    // ------------------------------------------------
    // DISCONNECT
    // ------------------------------------------------

    override suspend fun disconnect(): RouterResult<Unit> {

        return try {

            val request = Request.Builder()
                .url(
                    "$baseUrl${HuaweiHs8346rProfile.Paths.LOGOUT}" +
                        "?RequestFile=html/logout.html"
                )
                .post(FormBody.Builder().build())
                .build()

            client.newCall(request).execute().close()

            activeSessionToken = null
            sessionManager.clearSession()

            RouterResult.Success(Unit)

        } catch (e: Exception) {

            activeSessionToken = null
            sessionManager.clearSession()

            RouterResult.Failure(
                "Huawei logout failed: ${e.localizedMessage}"
            )
        }
    }

    // ------------------------------------------------
    // ROUTER INFORMATION
    // ------------------------------------------------

    override suspend fun getRouterInfo(): RouterResult<RouterInfo> {

        return try {

            val request = Request.Builder()
                .url("$baseUrl${HuaweiHs8346rProfile.Paths.WAN_LIST}")
                .get()
                .build()

            val html = client.newCall(request)
                .execute()
                .use { response ->

                    if (!response.isSuccessful) {
                        return RouterResult.NotConnected(
                            "Router unreachable or session expired."
                        )
                    }

                    response.body?.string().orEmpty()
                }

            val wanRegex = Regex(
                """new\s+WanPPP\s*\(([^)]*)\)"""
            )

            val match = wanRegex.find(html)
                ?: return RouterResult.Failure(
                    "WAN information was not found."
                )

            val args = parseJsArgs(match.groupValues[1])

            val ipAddress = args.getOrNull(12)
                ?.takeIf { it.isNotBlank() }
                ?: "Unknown"

            val uptime = args.getOrNull(38)
                ?.toLongOrNull()
                ?: 0L

            val wanStatus = args.getOrNull(3)
                ?.takeIf { it.isNotBlank() }
                ?: "Unknown"

            RouterResult.Success(
                RouterInfo(
                    manufacturer = "Huawei",
                    model = HuaweiHs8346rProfile.MODEL,
                    firmwareVersion = HuaweiHs8346rProfile.FIRMWARE_VERSION,
                    hardwareRevision = HuaweiHs8346rProfile.HARDWARE_REVISION,
                    routerIp = hostIp,
                    wanIp = ipAddress,
                    internetConnected = wanStatus.equals("Connected", ignoreCase = true) ||
                        wanStatus.equals("Up", ignoreCase = true),
                    uptimeSeconds = uptime,
                    cpuLoadPercent = 0,
                    memoryLoadPercent = 0,
                    serialMasked = "Unknown",
                    connectionState = RouterConnectionState.CONNECTED,
                    adapterId = descriptor.id,
                    adapterName = descriptor.displayName
                )
            )

        } catch (e: Exception) {

            RouterResult.Failure(
                "Router information error: ${e.localizedMessage}"
            )
        }
    }

    // ------------------------------------------------
    // OPTICAL INFORMATION
    // ------------------------------------------------

    override suspend fun getOpticalInfo(): RouterResult<OpticalInfo> =
        withContext(Dispatchers.IO) {
            try {
                if (activeSessionToken == null) {
                    return@withContext RouterResult.NotConnected(
                        "Authenticate before requesting optical information."
                    )
                }

                // Confirmed in the supplied HS8346R HAR capture.
                val request = Request.Builder()
                    .url("$baseUrl/html/amp/opticinfo/opticinfo.asp")
                    .get()
                    .build()

                val html = client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext RouterResult.Failure(
                            "Optical request failed: HTTP ${response.code}."
                        )
                    }
                    response.body?.string().orEmpty()
                }

                val match = Regex(
                    """new\s+stOpticInfo\s*\(([^)]*)\)""",
                    RegexOption.IGNORE_CASE
                ).find(html) ?: return@withContext RouterResult.Failure(
                    "Optical telemetry record was not present in the router response."
                )

                val args = parseJsArgs(match.groupValues[1])
                if (args.size < 15) {
                    return@withContext RouterResult.Failure(
                        "Invalid optical telemetry: expected 15 fields, received ${args.size}."
                    )
                }

                val txPower = args[1].toFloatOrNull()
                    ?: return@withContext RouterResult.Failure("Router returned invalid optical TX power.")
                val rxPower = args[2].toFloatOrNull()
                    ?: return@withContext RouterResult.Failure("Router returned invalid optical RX power.")
                val voltageMv = args[3].toFloatOrNull()
                    ?: return@withContext RouterResult.Failure("Router returned invalid optical voltage.")
                val temperature = args[4].toFloatOrNull()
                    ?: return@withContext RouterResult.Failure("Router returned invalid optical temperature.")
                val bias = args[5].toFloatOrNull()
                    ?: return@withContext RouterResult.Failure("Router returned invalid optical bias current.")

                val ponMode = Regex(
                    """ontPonMode\s*=\s*['"]([^'"]+)['"]""",
                    RegexOption.IGNORE_CASE
                ).find(html)?.groupValues?.get(1) ?: "Unknown"

                val losStatus = args[14]
                RouterResult.Success(
                    OpticalInfo(
                        ponMode = ponMode,
                        linkState = when (losStatus) {
                            "0" -> "No LOS"
                            "1" -> "LOS"
                            else -> "Unknown"
                        },
                        rxPowerDbm = rxPower,
                        txPowerDbm = txPower,
                        temperatureC = temperature,
                        voltageV = voltageMv / 1000.0f,
                        biasCurrentMa = bias
                    )
                )
            } catch (e: Exception) {
                val detail = e.message?.takeIf { it.isNotBlank() }
                    ?: e.cause?.message?.takeIf { it.isNotBlank() }
                    ?: "no exception message (${e::class.java.simpleName})"
                RouterResult.Failure("Optical information error: $detail")
            }
        }

    // ------------------------------------------------
    // CONNECTED DEVICES
    // ------------------------------------------------

    override suspend fun getConnectedDevices(): RouterResult<List<ConnectedDevice>> =
        withContext(Dispatchers.IO) {
            try {
                if (activeSessionToken == null) {
                    return@withContext RouterResult.NotConnected(
                        "Authenticate before discovering connected devices."
                    )
                }

                // HAR confirms this endpoint is requested with POST.
                val request = Request.Builder()
                    .url("$baseUrl/html/bbsp/common/GetLanUserDevInfo.asp")
                    .post(FormBody.Builder().build())
                    .build()

                val html = client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext RouterResult.Failure(
                            "Connected-device request failed: HTTP ${response.code}."
                        )
                    }
                    response.body?.string().orEmpty()
                }

                val deviceRegex = Regex(
                    """new\s+USERDevice\s*\(([^)]*)\)""",
                    RegexOption.IGNORE_CASE
                )

                val devices = deviceRegex.findAll(html).mapNotNull { match ->
                    val args = parseJsArgs(match.groupValues[1])
                    if (args.size < 13) return@mapNotNull null

                    val ip = args[1].takeIf { it.isNotBlank() && it != "--" }
                        ?: return@mapNotNull null
                    val mac = args[2].takeIf {
                        it.matches(Regex("(?i)([0-9a-f]{2}:){5}[0-9a-f]{2}"))
                    } ?: return@mapNotNull null

                    if (!args[10].equals("1", ignoreCase = true)) {
                        return@mapNotNull null
                    }

                    val portType = args[7]
                    val isWifi = portType.equals("WIFI", ignoreCase = true)
                    val connection = if (isWifi) {
                        // Firmware identifies Wi-Fi but this record does not expose its band.
                        ConnectionType.WIFI_2_4_GHZ
                    } else {
                        ConnectionType.ETHERNET
                    }

                    val rawName = args[9].takeIf { it.isNotBlank() && it != "--" }
                        ?: args[5].takeIf { it.isNotBlank() && it != "--" }
                        ?: "Unknown device"

                    val category = when {
                        rawName.contains("android", true) ||
                            rawName.contains("iphone", true) ||
                            rawName.contains("redmi", true) ||
                            rawName.contains("phone", true) -> DeviceCategory.PHONE
                        rawName.contains("desktop", true) ||
                            rawName.contains("windows", true) ||
                            rawName.startsWith("DESKTOP-", true) -> DeviceCategory.DESKTOP
                        rawName.contains("laptop", true) ||
                            rawName.contains("notebook", true) -> DeviceCategory.LAPTOP
                        rawName.contains("tv", true) -> DeviceCategory.TV_MEDIA
                        else -> DeviceCategory.UNKNOWN
                    }

                    ConnectedDevice(
                        macAddress = mac,
                        name = rawName,
                        ipAddress = ip,
                        manufacturer = args[5].takeIf { it.isNotBlank() } ?: "Unknown",
                        connectionType = connection,
                        category = category,
                        isOnline = args[6].equals("Online", ignoreCase = true),
                        isBlocked = false,
                        isInternetBlocked = false,
                        isGuestBlocked = false,
                        isBand24Blocked = false,
                        isBand5Blocked = false,
                        staticIpReserved = args[4].equals("Static", ignoreCase = true),
                        frequencyBandLabel = if (isWifi) "Wi-Fi (band not reported)" else "Ethernet",
                        signalStrengthDbm = null,
                        linkSpeedMbps = null,
                        rxRateMbps = 0f,
                        txRateMbps = 0f,
                        totalDownloadedBytes = 0L,
                        totalUploadedBytes = 0L,
                        connectedDurationSeconds = 0L,
                        dhcpType = args[4].ifBlank { "Unknown" },
                        lastSeenLabel = args[8].takeIf { it.isNotBlank() } ?: "Unknown"
                    )
                }.toList()

                RouterResult.Success(devices)
            } catch (e: Exception) {
                val detail = e.message?.takeIf { it.isNotBlank() }
                    ?: e.cause?.message?.takeIf { it.isNotBlank() }
                    ?: "no exception message (${e::class.java.simpleName})"
                RouterResult.Failure("Connected-device discovery failed: $detail")
            }
        }

    // ------------------------------------------------
    // ROUTER REBOOT
    // ------------------------------------------------

    override suspend fun rebootRouter(): RouterResult<Unit> {

        if (activeSessionToken == null) {
            return RouterResult.NotConnected(
                "Authenticate before attempting router operations."
            )
        }

        // The actual reboot CGI endpoint and parameters have
        // not yet been verified against captured router traffic.

        return RouterResult.Failure(
            "Reboot is not enabled. Verify the Huawei reboot endpoint first."
        )
    }

    // ------------------------------------------------
    // JAVASCRIPT ARGUMENT PARSER
    // ------------------------------------------------

    private fun parseJsArgs(rawArgs: String): List<String> {

        val result = mutableListOf<String>()
        val current = StringBuilder()

        var quote: Char? = null
        var escaped = false

        for (char in rawArgs) {

            if (escaped) {
                current.append(char)
                escaped = false
                continue
            }

            if (char == '\\') {
                current.append(char)
                escaped = true
                continue
            }

            if (quote != null) {

                if (char == quote) {
                    quote = null
                } else {
                    current.append(char)
                }

                continue
            }

            if (char == '"' || char == '\'') {
                quote = char
                continue
            }

            if (char == ',') {
                result.add(decodeJsValue(current.toString()))
                current.clear()
                continue
            }

            current.append(char)
        }

        result.add(decodeJsValue(current.toString()))

        return result
    }

    private fun decodeJsValue(value: String): String {

        val cleaned = value.trim()

        return Regex("""\\x([0-9A-Fa-f]{2})""")
            .replace(cleaned) { match ->

                match.groupValues[1]
                    .toInt(16)
                    .toChar()
                    .toString()
            }
    }
}
