package com.example.features.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.HelpOutline
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.DonutLarge
import androidx.compose.material.icons.outlined.FamilyRestroom
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.PublicOff
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material.icons.outlined.WifiPassword
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.Formatters
import com.example.core.UiState
import com.example.designsystem.AdminCard
import com.example.designsystem.AmberDemo
import com.example.designsystem.ConfirmDestructiveDialog
import com.example.designsystem.CyanAccent
import com.example.designsystem.EmeraldOnline
import com.example.designsystem.InfoBanner
import com.example.designsystem.LiveDisconnectedPanel
import com.example.designsystem.MonoLargeMetricStyle
import com.example.designsystem.MonoValueStyle
import com.example.designsystem.PillTone
import com.example.designsystem.RoseCritical
import com.example.designsystem.StatusPill
import com.example.designsystem.ThroughputChart
import com.example.models.ActivitySeverity
import com.example.models.NetworkActivityEvent
import com.example.models.RouterInfo
import com.example.models.TrafficSnapshot

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onNavigateToWifi: () -> Unit,
    onNavigateToGuestWifi: () -> Unit,
    onNavigateToDevices: () -> Unit,
    onNavigateToNetwork: () -> Unit,
    onNavigateToBlockedDevices: () -> Unit,
    onNavigateToOpticalInfo: () -> Unit,
    onNavigateToEthernetStatus: () -> Unit,
    onNavigateToDeviceInfo: () -> Unit,
    onNavigateToUsageStats: () -> Unit,
    onNavigateToVoipStatus: () -> Unit,
    onNavigateToParentalControl: () -> Unit,
    onNavigateToDnsSettings: () -> Unit,
    onNavigateToFirewall: () -> Unit,
    onNavigateToHelpGuide: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val feedback by viewModel.actionFeedback.collectAsStateWithLifecycle()
    var showRebootDialog by remember { mutableStateOf(false) }
    var showActivitySheet by remember { mutableStateOf(false) }

    if (showRebootDialog) {
        ConfirmDestructiveDialog(
            title = "Reboot Router?",
            message = "Rebooting will temporarily disconnect all Wi-Fi and wired clients for 60–120 seconds.",
            confirmLabel = "Reboot Now",
            isCritical = true,
            onConfirm = {
                showRebootDialog = false
                viewModel.rebootRouter()
            },
            onDismiss = { showRebootDialog = false }
        )
    }

    val readyContent = (uiState as? UiState.Ready)?.data
    if (showActivitySheet && readyContent != null) {
        ModalBottomSheet(onDismissRequest = { showActivitySheet = false }) {
            ActivityLogSheetContent(
                events = readyContent.recentActivity,
                onRebootClick = {
                    showActivitySheet = false
                    showRebootDialog = true
                },
                onRefreshClick = {
                    viewModel.refresh()
                }
            )
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        when (val state = uiState) {
            is UiState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is UiState.Disconnected -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        RouterHeaderBar(
                            title = "RouterManager Pro",
                            subtitle = "Live Mode · Disconnected",
                            statusColor = RoseCritical,
                            onNotifications = { },
                            onToggleTheme = viewModel::toggleTheme,
                            onLogoutOrLogin = onNavigateToLogin
                        )
                    }
                    item {
                        LiveDisconnectedPanel(
                            title = state.title,
                            subtitle = state.message,
                            onConnectClick = onNavigateToLogin,
                            onDiscoverClick = onNavigateToDiscovery,
                            onSwitchToDemoClick = viewModel::switchToDemoMode
                        )
                    }
                }
            }
            is UiState.Error -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        RouterHeaderBar(
                            title = "RouterManager Pro",
                            subtitle = "Connection Error",
                            statusColor = RoseCritical,
                            onNotifications = { },
                            onToggleTheme = viewModel::toggleTheme,
                            onLogoutOrLogin = onNavigateToLogin
                        )
                    }
                    item { InfoBanner(message = state.message) }
                }
            }
            is UiState.Ready -> {
                val content = state.data
                val info = content.routerInfo

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp)
                        .testTag("dashboard_list"),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // 1. Top Header Bar (Model name + IP dot + Bell / Sun / Logout)
                    item {
                        RouterHeaderBar(
                            title = "${info.manufacturer} ${info.model}",
                            subtitle = when {
                                state.isDemoMode -> "${info.routerIp} · DEMO MODE"
                                content.routerInfoWarning != null -> "${info.routerIp} · LIVE MODE"
                                else -> "${info.routerIp} · LIVE MODE"
                            },
                            statusColor = if (state.isDemoMode) AmberDemo else MaterialTheme.colorScheme.primary,
                            onNotifications = { showActivitySheet = true },
                            onToggleTheme = viewModel::toggleTheme,
                            onLogoutOrLogin = onNavigateToLogin
                        )
                    }

                    if (!feedback.isNullOrBlank()) {
                        item { InfoBanner(message = feedback!!) }
                    }
                    if (!content.routerInfoWarning.isNullOrBlank()) {
                        item {
                            InfoBanner(
                                message = "Some router information is unavailable: ${content.routerInfoWarning}. Dashboard sections remain available; unsupported features will explain their status when opened."
                            )
                        }
                    }

                    // 2. 2-Page Swipeable Hero Card (matches screenshots #6 & #7)
                    item {
                        HeroPagerSection(
                            routerInfo = info,
                            routerInfoAvailable = content.routerInfoWarning == null,
                            isDemoMode = state.isDemoMode,
                            connectedDevicesCount = content.connectedDevicesCount,
                            wanConnectionLabel = content.wanConnectionLabel,
                            opticalRxDbm = content.opticalRxDbm,
                            traffic = content.trafficSnapshot
                        )
                    }

                    // 3. STATS & DIAGNOSTICS 2-Column Grid (6 tiles)
                    item {
                        Text(
                            text = "STATS & DIAGNOSTICS",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                DashboardTileCard(
                                    title = "WAN Status",
                                    subtitle = content.wanConnectionLabel,
                                    icon = Icons.Outlined.Public,
                                    iconTint = Color(0xFF8B5CF6),
                                    onClick = onNavigateToNetwork,
                                    modifier = Modifier.weight(1f).testTag("tile_wan_status")
                                )
                                DashboardTileCard(
                                    title = "Devices",
                                    subtitle = "${content.connectedDevicesCount} connected",
                                    icon = Icons.Outlined.Devices,
                                    iconTint = Color(0xFFF59E0B),
                                    onClick = onNavigateToDevices,
                                    modifier = Modifier.weight(1f).testTag("tile_devices")
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                DashboardTileCard(
                                    title = "Optical Info",
                                    subtitle = "Laser power & temp",
                                    icon = Icons.Outlined.WbSunny,
                                    iconTint = Color(0xFF38BDF8),
                                    onClick = onNavigateToOpticalInfo,
                                    modifier = Modifier.weight(1f).testTag("tile_optical_info")
                                )
                                DashboardTileCard(
                                    title = "Ethernet Ports",
                                    subtitle = "Link status & speeds",
                                    icon = Icons.Outlined.Hub,
                                    iconTint = Color(0xFF38BDF8),
                                    onClick = onNavigateToEthernetStatus,
                                    modifier = Modifier.weight(1f).testTag("tile_ethernet_ports")
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                DashboardTileCard(
                                    title = "Device Info",
                                    subtitle = "CPU RAM & Versions",
                                    icon = Icons.Outlined.Memory,
                                    iconTint = Color(0xFFFACC15),
                                    onClick = onNavigateToDeviceInfo,
                                    modifier = Modifier.weight(1f).testTag("tile_device_info")
                                )
                                DashboardTileCard(
                                    title = "Usage",
                                    subtitle = "Traffic statistics",
                                    icon = Icons.Outlined.DonutLarge,
                                    iconTint = Color(0xFF22D3EE),
                                    onClick = onNavigateToUsageStats,
                                    modifier = Modifier.weight(1f).testTag("tile_usage")
                                )
                            }
                        }
                    }

                    // 4. Management 2-Column Grid (6 tiles matching screenshot #6)
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                DashboardTileCard(
                                    title = "VoIP Status",
                                    subtitle = "SIP line status",
                                    icon = Icons.Outlined.Call,
                                    iconTint = Color(0xFF34D399),
                                    onClick = onNavigateToVoipStatus,
                                    modifier = Modifier.weight(1f).testTag("tile_voip_status")
                                )
                                DashboardTileCard(
                                    title = "Wi-Fi Password",
                                    subtitle = "Change SSID & Key",
                                    icon = Icons.Outlined.WifiPassword,
                                    iconTint = Color(0xFF818CF8),
                                    onClick = onNavigateToWifi,
                                    modifier = Modifier.weight(1f).testTag("tile_wifi_password")
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                DashboardTileCard(
                                    title = "Guest",
                                    subtitle = "Guest WiFi & users",
                                    icon = Icons.Outlined.Group,
                                    iconTint = Color(0xFF94A3B8),
                                    onClick = onNavigateToGuestWifi,
                                    modifier = Modifier.weight(1f).testTag("tile_guest_wifi")
                                )
                                DashboardTileCard(
                                    title = "MAC Filter",
                                    subtitle = "Allow/Block devices",
                                    icon = Icons.Outlined.Shield,
                                    iconTint = Color(0xFF14B8A6),
                                    onClick = onNavigateToBlockedDevices,
                                    modifier = Modifier.weight(1f).testTag("tile_mac_filter")
                                )
                            }
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                DashboardTileCard(
                                    title = "Parental Control",
                                    subtitle = "${content.parentalTemplatesCount} templates",
                                    icon = Icons.Outlined.FamilyRestroom,
                                    iconTint = Color(0xFFF43F5E),
                                    onClick = onNavigateToParentalControl,
                                    modifier = Modifier.weight(1f).testTag("tile_parental_control")
                                )
                                DashboardTileCard(
                                    title = "Block Internet",
                                    subtitle = "without disconnect",
                                    icon = Icons.Outlined.Block,
                                    iconTint = Color(0xFFEF4444),
                                    onClick = onNavigateToDevices,
                                    modifier = Modifier.weight(1f).testTag("tile_block_internet")
                                )
                            }
                        }
                    }

                    // 5. MORE Grouped Card (Admin, DNS Settings, Firewall, Help & Guide)
                    item {
                        Text(
                            text = "MORE",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(8.dp))
                        AdminCard {
                            MoreGroupRow(
                                title = "Admin",
                                subtitle = "DHCP, firewall & ports",
                                icon = Icons.Outlined.AdminPanelSettings,
                                onClick = onNavigateToNetwork,
                                testTag = "more_admin_row"
                            )
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 8.dp),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )
                            MoreGroupRow(
                                title = "DNS Settings",
                                subtitle = "DNS policy, custom rules & host entries",
                                icon = Icons.Outlined.Dns,
                                onClick = onNavigateToDnsSettings,
                                testTag = "more_dns_row"
                            )
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 8.dp),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )
                            MoreGroupRow(
                                title = "Firewall",
                                subtitle = "Firewall level (${content.firewallLevelLabel} needed for IP blocking)",
                                icon = Icons.Outlined.Security,
                                onClick = onNavigateToFirewall,
                                testTag = "more_firewall_row"
                            )
                            HorizontalDivider(
                                modifier = Modifier.padding(vertical = 8.dp),
                                color = MaterialTheme.colorScheme.outlineVariant
                            )
                            MoreGroupRow(
                                title = "Help & Guide",
                                subtitle = "How each section works & how to manage safely",
                                icon = Icons.AutoMirrored.Outlined.HelpOutline,
                                onClick = onNavigateToHelpGuide,
                                testTag = "more_help_row"
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RouterHeaderBar(
    title: String,
    subtitle: String,
    statusColor: Color,
    onNotifications: () -> Unit,
    onToggleTheme: () -> Unit,
    onLogoutOrLogin: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(7.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = subtitle,
                    style = MonoValueStyle,
                    color = statusColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                onClick = onNotifications,
                modifier = Modifier.testTag("dashboard_notifications_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Notifications,
                    contentDescription = "Recent network activity and router actions"
                )
            }
            IconButton(
                onClick = onToggleTheme,
                modifier = Modifier.testTag("dashboard_theme_toggle")
            ) {
                Icon(
                    imageVector = Icons.Outlined.WbSunny,
                    contentDescription = "Toggle dark or light theme"
                )
            }
            IconButton(
                onClick = onLogoutOrLogin,
                modifier = Modifier.testTag("dashboard_logout_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Outlined.Logout,
                    contentDescription = "Router login and connection management"
                )
            }
        }
    }
}

@Composable
private fun HeroPagerSection(
    routerInfo: RouterInfo,
    routerInfoAvailable: Boolean,
    isDemoMode: Boolean,
    connectedDevicesCount: Int,
    wanConnectionLabel: String,
    opticalRxDbm: Float?,
    traffic: TrafficSnapshot?
) {
    val pagerState = rememberPagerState(pageCount = { 2 })
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        HorizontalPager(
            state = pagerState,
            pageSpacing = 12.dp,
            modifier = Modifier.fillMaxWidth()
        ) { page ->
            if (page == 0) {
                HeroRouterCard(
                    routerInfo = routerInfo,
                    routerInfoAvailable = routerInfoAvailable,
                    isDemoMode = isDemoMode,
                    connectedDevicesCount = connectedDevicesCount,
                    wanConnectionLabel = wanConnectionLabel,
                    opticalRxDbm = opticalRxDbm
                )
            } else {
                HeroThroughputCard(traffic = traffic, isDemoMode = isDemoMode)
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(2) { idx ->
                val selected = pagerState.currentPage == idx
                Box(
                    modifier = Modifier
                        .height(6.dp)
                        .width(if (selected) 20.dp else 6.dp)
                        .clip(CircleShape)
                        .background(
                            if (selected) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outlineVariant
                        )
                )
            }
        }
    }
}

@Composable
private fun HeroRouterCard(
    routerInfo: RouterInfo,
    routerInfoAvailable: Boolean,
    isDemoMode: Boolean,
    connectedDevicesCount: Int,
    wanConnectionLabel: String,
    opticalRxDbm: Float?
) {
    val accent = MaterialTheme.colorScheme.primary
    val heroGradient = Brush.linearGradient(
        colors = listOf(
            accent.copy(alpha = 0.88f),
            Color(0xFF2858B8)
        )
    )
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("router_status_card"),
        shape = MaterialTheme.shapes.large,
        color = accent,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.22f))
    ) {
        Box(modifier = Modifier.background(heroGradient)) {
            // Subtle top-right radial highlight matching screenshot #7
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .align(Alignment.TopEnd)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.08f))
            )
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = routerInfo.model.removeSuffix(" (Demo)"),
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${routerInfo.routerIp} · ${if (!routerInfoAvailable) "status unavailable" else if (routerInfo.internetConnected) "connected" else "offline"}",
                            style = MonoValueStyle,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Outlined.Wifi,
                                contentDescription = "Optical signal",
                                tint = Color.White.copy(alpha = 0.9f),
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = opticalRxDbm?.let { "$it dBm" } ?: "-36 dBm",
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }
                        Spacer(Modifier.height(6.dp))
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (isDemoMode) AmberDemo.copy(alpha = 0.28f) else Color.White.copy(alpha = 0.16f),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.55f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (isDemoMode) AmberDemo else Color.White)
                                )
                                Text(
                                    text = if (isDemoMode) "DEMO MODE" else "ONLINE",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(92.dp),
                    contentAlignment = Alignment.Center
                ) {
                    RouterGlyphIllustration(accentColor = CyanAccent)
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    HeroStatColumn(
                        label = "Devices",
                        value = connectedDevicesCount.toString(),
                        modifier = Modifier.weight(1f)
                    )
                    HeroStatColumn(
                        label = "Uptime",
                        value = Formatters.formatUptime(routerInfo.uptimeSeconds),
                        modifier = Modifier.weight(1f)
                    )
                    HeroStatColumn(
                        label = "Network",
                        value = wanConnectionLabel,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun HeroThroughputCard(
    traffic: TrafficSnapshot?,
    isDemoMode: Boolean
) {
    val accent = MaterialTheme.colorScheme.primary
    val gradient = Brush.linearGradient(
        colors = listOf(Color(0xFF153166), accent.copy(alpha = 0.72f))
    )
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = Color(0xFF153166),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier
                .background(gradient)
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "WAN Throughput",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )
                StatusPill(
                    label = if (isDemoMode) "DEMO SANDBOX" else "LIVE WAN",
                    tone = if (isDemoMode) PillTone.WARNING else PillTone.ONLINE
                )
            }
            Spacer(Modifier.height(12.dp))
            if (traffic != null) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.ArrowDownward, contentDescription = null, tint = Color.White)
                        Spacer(Modifier.width(6.dp))
                        Column {
                            Text("Download", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.75f))
                            Text(Formatters.formatMbps(traffic.downloadMbps), style = MonoLargeMetricStyle, color = Color.White)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.ArrowUpward, contentDescription = null, tint = CyanAccent)
                        Spacer(Modifier.width(6.dp))
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Upload", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.75f))
                            Text(Formatters.formatMbps(traffic.uploadMbps), style = MonoLargeMetricStyle, color = CyanAccent)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                ThroughputChart(
                    downloadHistoryMbps = traffic.downloadHistoryMbps,
                    uploadHistoryMbps = traffic.uploadHistoryMbps,
                    modifier = Modifier.height(106.dp)
                )
            } else {
                Text(
                    text = "Throughput history unavailable for this adapter.",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = 0.85f)
                )
            }
        }
    }
}

@Composable
private fun HeroStatColumn(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = Color.White.copy(alpha = 0.78f)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun RouterGlyphIllustration(
    accentColor: Color
) {
    Canvas(modifier = Modifier.size(width = 210.dp, height = 88.dp)) {
        val w = size.width
        val h = size.height
        val cx = w / 2f

        // Signal arc above router
        drawArc(
            color = Color.White.copy(alpha = 0.65f),
            startAngle = 220f,
            sweepAngle = 100f,
            useCenter = false,
            topLeft = Offset(cx - 20.dp.toPx(), 4.dp.toPx()),
            size = Size(40.dp.toPx(), 24.dp.toPx()),
            style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round)
        )

        val bodyTop = h * 0.38f
        val bodyHeight = h * 0.34f
        val bodyWidth = 104.dp.toPx()
        val bodyLeft = (w - bodyWidth) / 2f

        // Dual antennas
        drawLine(
            color = Color.White,
            start = Offset(bodyLeft + 16.dp.toPx(), bodyTop),
            end = Offset(bodyLeft + 11.dp.toPx(), bodyTop - 16.dp.toPx()),
            strokeWidth = 3.2.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color.White,
            start = Offset(bodyLeft + bodyWidth - 16.dp.toPx(), bodyTop),
            end = Offset(bodyLeft + bodyWidth - 11.dp.toPx(), bodyTop - 16.dp.toPx()),
            strokeWidth = 3.2.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Chassis
        drawRoundRect(
            color = Color(0xFFF3F6FC),
            topLeft = Offset(bodyLeft, bodyTop),
            size = Size(bodyWidth, bodyHeight),
            cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx())
        )

        // LED dots + power port
        val ledY = bodyTop + bodyHeight / 2f
        drawCircle(color = EmeraldOnline, radius = 2.6.dp.toPx(), center = Offset(bodyLeft + 16.dp.toPx(), ledY))
        drawCircle(color = accentColor, radius = 2.6.dp.toPx(), center = Offset(bodyLeft + 27.dp.toPx(), ledY))
        drawCircle(color = AmberDemo, radius = 2.6.dp.toPx(), center = Offset(bodyLeft + 38.dp.toPx(), ledY))
        drawRoundRect(
            color = Color(0xFF1E293B),
            topLeft = Offset(bodyLeft + bodyWidth - 24.dp.toPx(), ledY - 3.dp.toPx()),
            size = Size(11.dp.toPx(), 6.dp.toPx()),
            cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
        )

        // Dotted telemetry arc underneath matching screenshot #7
        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 8f), 0f)
        drawArc(
            color = Color.White.copy(alpha = 0.5f),
            startAngle = 200f,
            sweepAngle = 140f,
            useCenter = false,
            topLeft = Offset(cx - 88.dp.toPx(), bodyTop + bodyHeight + 6.dp.toPx()),
            size = Size(176.dp.toPx(), 42.dp.toPx()),
            style = Stroke(width = 1.8.dp.toPx(), pathEffect = dashEffect)
        )
        listOf(cx - 50.dp.toPx() to bodyTop + bodyHeight + 11.dp.toPx(), cx to bodyTop + bodyHeight + 6.dp.toPx(), cx + 50.dp.toPx() to bodyTop + bodyHeight + 11.dp.toPx()).forEach { (px, py) ->
            drawCircle(color = Color.White.copy(alpha = 0.35f), radius = 6.dp.toPx(), center = Offset(px, py))
            drawCircle(color = Color.White, radius = 2.5.dp.toPx(), center = Offset(px, py))
        }
    }
}

@Composable
private fun DashboardTileCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    AdminCard(
        onClick = onClick,
        modifier = modifier
    ) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = iconTint.copy(alpha = 0.14f),
            border = BorderStroke(1.dp, iconTint.copy(alpha = 0.25f)),
            modifier = Modifier.size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint,
                    modifier = Modifier.size(19.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold),
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun MoreGroupRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        onClick = onClick,
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth().testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(19.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ActivityLogSheetContent(
    events: List<NetworkActivityEvent>,
    onRebootClick: () -> Unit,
    onRefreshClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Router Activity & Quick Actions", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onRefreshClick) {
                    Text("Refresh")
                }
                OutlinedButton(onClick = onRebootClick) {
                    Icon(Icons.Outlined.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Reboot")
                }
            }
        }
        LazyColumn(
            modifier = Modifier.height(340.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(events, key = { it.id }) { event ->
                AdminCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(event.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusPill(
                            label = event.category.label,
                            tone = when (event.severity) {
                                ActivitySeverity.CRITICAL -> PillTone.CRITICAL
                                ActivitySeverity.WARNING -> PillTone.WARNING
                                ActivitySeverity.INFO -> PillTone.INFO
                            }
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(event.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(2.dp))
                    Text(event.timestampLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}
