package com.example.features.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material.icons.outlined.Router
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.AppMode
import com.example.core.ThemePreference
import com.example.designsystem.AdminCard
import com.example.designsystem.ConfirmDestructiveDialog
import com.example.designsystem.KeyValueRow
import com.example.designsystem.MonoValueStyle
import com.example.designsystem.PillTone
import com.example.designsystem.SectionHeader
import com.example.designsystem.StatusPill
import com.example.models.RouterProfile

@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    onOpenLogin: (String?) -> Unit,
    onOpenDiscovery: () -> Unit,
    onOpenSupportedRouters: () -> Unit,
    onBack: (() -> Unit)? = null
) {
    val preferences by viewModel.preferences.collectAsStateWithLifecycle()
    val savedProfiles by viewModel.savedProfiles.collectAsStateWithLifecycle()
    val appMode by viewModel.appMode.collectAsStateWithLifecycle()
    val session by viewModel.currentSession.collectAsStateWithLifecycle()

    var pendingDeleteProfile by remember { mutableStateOf<RouterProfile?>(null) }
    var pendingClearCredsProfile by remember { mutableStateOf<RouterProfile?>(null) }

    pendingDeleteProfile?.let { profile ->
        ConfirmDestructiveDialog(
            title = "Delete Saved Profile?",
            message = "Remove '${profile.displayName}' (${profile.hostIp}) and any encrypted credentials stored for it?",
            confirmLabel = "Delete Profile",
            isCritical = true,
            onConfirm = {
                pendingDeleteProfile = null
                viewModel.deleteProfile(profile.id)
            },
            onDismiss = { pendingDeleteProfile = null }
        )
    }

    pendingClearCredsProfile?.let { profile ->
        ConfirmDestructiveDialog(
            title = "Erase Stored Credentials?",
            message = "Clear saved encrypted password for '${profile.displayName}'? You will be prompted to enter it next time.",
            confirmLabel = "Erase Password",
            isCritical = true,
            onConfirm = {
                pendingClearCredsProfile = null
                viewModel.clearProfileCredentials(profile.id)
            },
            onDismiss = { pendingClearCredsProfile = null }
        )
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("settings_screen_list"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onBack != null) {
                        IconButton(onClick = onBack, modifier = Modifier.testTag("settings_back_button")) {
                            Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                        }
                        Spacer(Modifier.width(6.dp))
                    }
                    Text("Settings", style = MaterialTheme.typography.headlineMedium)
                }
            }

            // 1. Router Connection Management & Mode Switch
            item {
                AdminCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SectionHeader(
                            title = "Operation Mode",
                            subtitle = "Separate simulated sandbox from live hardware"
                        )
                        StatusPill(
                            label = if (appMode == AppMode.DEMO) "DEMO MODE" else "LIVE MODE",
                            tone = if (appMode == AppMode.DEMO) PillTone.WARNING else PillTone.INFO
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        AppMode.entries.forEachIndexed { idx, mode ->
                            SegmentedButton(
                                selected = appMode == mode,
                                onClick = { viewModel.setAppMode(mode) },
                                shape = SegmentedButtonDefaults.itemShape(idx, AppMode.entries.size),
                                modifier = Modifier.testTag("mode_segment_${mode.name}")
                            ) {
                                Text(if (mode == AppMode.DEMO) "Demo Sandbox" else "Live Router")
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    if (appMode == AppMode.LIVE) {
                        KeyValueRow(
                            "Live Session",
                            session?.let { "Authenticated (${it.routerIp})" } ?: "Disconnected"
                        )
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { onOpenLogin(null) },
                                modifier = Modifier.weight(1f).height(48.dp).testTag("settings_connect_router_button")
                            ) {
                                Text("Connect / Login")
                            }
                            if (session != null) {
                                OutlinedButton(
                                    onClick = viewModel::disconnectLiveSession,
                                    modifier = Modifier.weight(1f).height(48.dp)
                                ) {
                                    Text("Disconnect")
                                }
                            }
                        }
                    } else {
                        Text(
                            text = "Demo Mode displays isolated sandbox data so you can explore every control safely without router hardware.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            // 2. Discovery & Supported Routers Navigation
            item {
                SectionHeader(title = "Router Integration & Discovery")
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AdminCard(
                        onClick = onOpenDiscovery,
                        modifier = Modifier.testTag("settings_discovery_row")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.Radar, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Scan Router", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "Inspect active Android default gateway route",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null)
                        }
                    }
                    AdminCard(
                        onClick = onOpenSupportedRouters,
                        modifier = Modifier.testTag("settings_supported_routers_row")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.VerifiedUser, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Supported Routers & Adapters", style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "${viewModel.supportedAdapters.size} adapter profiles & capability matrix",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null)
                        }
                    }
                }
            }

            // 3. Saved Router Profiles & Credentials
            item {
                SectionHeader(
                    title = "Saved Router Profiles",
                    subtitle = "Credentials encrypted with Android Keystore AES-256-GCM",
                    trailing = {
                        OutlinedButton(
                            onClick = { onOpenLogin(null) },
                            modifier = Modifier.height(40.dp).testTag("add_profile_button")
                        ) {
                            Text("Add Profile")
                        }
                    }
                )
            }
            if (savedProfiles.isEmpty()) {
                item {
                    AdminCard {
                        Text("No Saved Profiles", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Add a router gateway profile to store host settings and optional Keystore-encrypted admin credentials.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(savedProfiles, key = { it.id }) { profile ->
                    AdminCard(onClick = { onOpenLogin(profile.id) }) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Outlined.Router, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(profile.displayName, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    text = "${if (profile.useHttps) "https" else "http"}://${profile.hostIp}:${profile.port} · ${profile.username}",
                                    style = MonoValueStyle,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = if (profile.hasStoredPassword) "Password stored (Keystore encrypted)" else "Password not stored",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (profile.hasStoredPassword) {
                                IconButton(onClick = { pendingClearCredsProfile = profile }) {
                                    Icon(Icons.Outlined.Key, contentDescription = "Erase saved password")
                                }
                            }
                            IconButton(onClick = { pendingDeleteProfile = profile }) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = "Delete profile")
                            }
                        }
                    }
                }
            }

            // 4. App Security
            item {
                SectionHeader(title = "App Security")
            }
            item {
                AdminCard {
                    SecurityToggleRow(
                        title = "Require Confirmation for Destructive Actions",
                        subtitle = "Prompt before router reboot, device blocking, or LAN/Wi-Fi changes",
                        checked = preferences.confirmDestructiveActions,
                        onCheckedChange = viewModel::setConfirmDestructiveActions
                    )
                    Spacer(Modifier.height(8.dp))
                    SecurityToggleRow(
                        title = "Clear Live Session in Background",
                        subtitle = "Require re-authentication when returning to Live Router Mode",
                        checked = preferences.autoClearSessionOnBackground,
                        onCheckedChange = viewModel::setAutoClearSessionOnBackground
                    )
                    Spacer(Modifier.height(8.dp))
                    SecurityToggleRow(
                        title = "App Security Lock Guard",
                        subtitle = "Protect stored router profiles on launch",
                        checked = preferences.appPinLockEnabled,
                        onCheckedChange = viewModel::setAppPinLockEnabled
                    )
                }
            }

            // 5. Theme Settings
            item {
                SectionHeader(title = "Appearance & Theme")
            }
            item {
                AdminCard {
                    Text(
                        text = "Dark-first network console with optional light theme",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        ThemePreference.entries.forEachIndexed { idx, theme ->
                            SegmentedButton(
                                selected = preferences.themePreference == theme,
                                onClick = { viewModel.setThemePreference(theme) },
                                shape = SegmentedButtonDefaults.itemShape(idx, ThemePreference.entries.size),
                                modifier = Modifier.testTag("theme_segment_${theme.name}")
                            ) {
                                Text(
                                    text = when (theme) {
                                        ThemePreference.DARK -> "Dark"
                                        ThemePreference.LIGHT -> "Light"
                                        ThemePreference.SYSTEM -> "System"
                                    }
                                )
                            }
                        }
                    }
                }
            }

            // 6. About Application
            item {
                SectionHeader(title = "About RouterManager Pro")
            }
            item {
                AdminCard {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("RouterManager Pro", style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(8.dp))
                    KeyValueRow("Version", "1.1.0-live-openwrt", isMonospace = true)
                    KeyValueRow("Architecture", "MVVM · Capability Adapter Registry")
                    KeyValueRow("Live Transport", "OpenWrt LuCI JSON-RPC Ready")
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Designed with zero-fabrication integrity: live hardware data is never simulated or mocked in Live Router Mode.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SecurityToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(8.dp))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
