# RouterManager Pro Lab

Independent experimental Android application for router-driver research, beginning with the Huawei HS8346R (HWTC, hardware 1257.A, firmware V3R018C10S108).

## Separation from Stable

- Android application ID: `com.routermanagerpro.lab`
- Display name: `RMP Lab`
- The original `routermanager-pro.zip` was extracted into this separate directory; the original archive was not modified.
- No Stable repository files were edited.
- No `.github/workflows/android-build.yml` was copied or changed.
- This Lab copy has its own project root and can evolve independently.

## Current status

- Existing RMP application scaffold copied as the initial UI baseline.
- Separate Android package identity configured.
- Huawei HS8346R firmware profile and evidence-backed endpoint inventory added.
- HAR research distinguishes observed page JavaScript from actual successful write transactions.
- Live Huawei authentication and configuration operations are not yet claimed as implemented.

## Build

Open this folder as an independent Android Studio project, or build with the included Gradle wrapper if one is added/configured in your environment. The Gradle wrapper is not included in the supplied source archive.

## Safety

Use only a router you own or are authorized to administer. Never commit router credentials, session cookies, tokens, or unredacted HAR captures.
