# RouterManager Pro Lab architecture

RMP Lab is a separate Android application for experimental router-driver development. It is intentionally isolated from the stable RMP project.

## Identity

- Android application ID: `com.routermanagerpro.lab`
- Display name: `RMP Lab`
- Stable app identity remains unchanged.

## Layers

1. `core/networking`: HTTP transport, timeouts, redirect policy, cookie handling.
2. `core/authentication`: router-specific login, token extraction, session lifecycle.
3. `routers/huawei/hs8346r`: firmware-specific endpoints, parsers, commands and capability map.
4. `routers/openwrt`: kept as a separate driver family; no Huawei assumptions leak into it.
5. `research/`: HAR-derived endpoint and form evidence, explicitly distinguishing observed, inferred and verified behavior.
6. `tests/mock-router`: deterministic fixtures for parsing and request construction.

## Development gates

- Gate 1: parse read-only responses from saved fixtures.
- Gate 2: authenticate and retrieve read-only status from the physical router.
- Gate 3: reconstruct and unit-test write form parameters without sending them.
- Gate 4: one reversible write at a time, with confirmation and read-back verification.
- Gate 5: integrate only proven functionality into production RMP after separate review.

No production workflow or Stable source file is a dependency of this project.
