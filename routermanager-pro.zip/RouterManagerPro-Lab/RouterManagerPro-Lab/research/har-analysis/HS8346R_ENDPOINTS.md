# Huawei HS8346R endpoint evidence

Target identified from the supplied captures and user-provided router details:

- Model: Huawei HS8346R
- Hardware: 1257.A
- Firmware: V3R018C10S108
- Vendor ID: HWTC
- Observed management origin: `http://192.168.100.1`

## Read paths observed in HAR

| Purpose | Path | Evidence |
|---|---|---|
| Login | `POST /login.cgi` | Request captured |
| Logout | `POST /logout.cgi` | Request captured |
| Device information | `/html/ssmp/deviceinfo/deviceinfo.asp` | Request captured |
| LAN devices | `/html/bbsp/common/GetLanUserDevInfo.asp` | Request captured |
| DHCP clients | `/html/bbsp/common/GetLanUserDhcpInfo.asp` | Request captured |
| WAN list | `/html/bbsp/common/getwanlist.asp` | Request captured |
| WAN list details | `/html/bbsp/common/wan_list_info.asp` | Request captured |
| Optical diagnostics | `/html/amp/common/getSmartDiagnoseResult.asp` | Request captured |
| WLAN list | `/html/amp/common/wlan_list.asp` | Request captured |
| WLAN basic page | `/html/amp/wlanbasic/WlanBasic.asp` | Request captured; HTML response archived |
| WLAN advanced page | `/html/amp/wlanadv/WlanAdvance.asp` | Request captured |

## Write mechanism evidence from WLAN Basic page source

The captured HTML for `WlanBasic.asp` includes JavaScript that constructs forms and calls `webSubmitForm()`:

- Wireless radio enable uses `set.cgi?x=<radio object path>&RequestFile=html/amp/wlanbasic/WlanBasic.asp`.
- In dual-frequency mode the code targets `InternetGatewayDevice.LANDevice.1.WiFi.Radio.1` or `.Radio.2` and submits `x.Enable`.
- The single-radio branch submits `x.X_HW_WlanEnable` against `InternetGatewayDevice.LANDevice.1`.
- The page adds `x.X_HW_Token` from the page's `onttoken` value before submitting.
- SSID deletion uses `del.cgi?RequestFile=html/amp/wlanbasic/WlanBasic.asp` and a helper `addDeleteDomain(Form)`.
- The HTML contains references to `add.cgi` and `set.cgi`, but each action's exact parameter set must be reconstructed from its complete page function before implementing it.

This is frontend source evidence, not a successful write transaction. The supplied HARs do not show a completed POST to `set.cgi`, `add.cgi`, or `del.cgi`. Therefore no write is considered verified until the exact form fields are reconstructed, sent to the user's own router with explicit confirmation, and the resulting state is read back.

## Authentication notes

The captured page scripts include `safelogin.js`, `RndSecurityFormat.js`, `md5.js`, `util.js`, and references to `x.X_HW_Token`. The login flow and token lifecycle need a dedicated, line-by-line review before authentication is implemented. Do not infer a password hashing scheme from filenames alone.

## Safety constraints

- No credentials, cookies, or tokens in logs, source control, HAR exports, or crash reports.
- Use only the router the user owns/administers.
- Do not send a configuration write without explicit user action.
- After a write, re-fetch the affected setting and compare it with the requested value.
- Never display success merely because an HTTP request returned 200.
