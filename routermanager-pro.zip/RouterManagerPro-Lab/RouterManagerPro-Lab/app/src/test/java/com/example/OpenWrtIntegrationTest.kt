package com.example

import com.example.adapters.RouterCapabilityRegistry
import com.example.adapters.demo.DemoDataProvider
import com.example.adapters.live.OpenWrtAdapter
import com.example.adapters.live.OpenWrtRpcClient
import com.example.authentication.KeystoreCredentialCipher
import com.example.authentication.RouterAuthenticationManager
import com.example.authentication.RouterSessionManager
import com.example.core.AppMode
import com.example.core.RouterResult
import com.example.models.ConnectionType
import com.example.models.DhcpConfig
import com.example.models.PortForwardRule
import com.example.models.ProtocolType
import com.example.models.RouterCredentials
import com.example.models.RouterFeature
import com.example.models.WifiBand
import com.example.models.WifiSecurityMode
import com.example.networking.RouterEndpointClient
import com.example.repositories.DeviceRepository
import com.example.repositories.NetworkRepository
import com.example.repositories.RouterRepository
import com.example.repositories.WifiRepository
import com.example.router.RouterController
import com.sun.net.httpserver.HttpExchange
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.util.concurrent.Executors

class OpenWrtIntegrationTest {

    private val json = Json { ignoreUnknownKeys = true; isLenient = true }

    @Test
    fun openWrtLiveFlow_authenticatesReadsAndMutatesStateOverRealHttp() = runTest {
        var fakeClockMs = 1_000_000L
        val fakeRouter = FakeOpenWrtHttpServer()
        fakeRouter.start()

        try {
            val sessionManager = RouterSessionManager(clockMs = { fakeClockMs })
            val rpcClient = OpenWrtRpcClient(sessionManager)
            val openWrtAdapter = OpenWrtAdapter(sessionManager, rpcClient, clockMs = { fakeClockMs })
            val registry = object : RouterCapabilityRegistry(DemoDataProvider(), sessionManager) {}
            val authManager = RouterAuthenticationManager(
                capabilityRegistry = registry,
                sessionManager = sessionManager,
                credentialCipher = KeystoreCredentialCipher(allowJreAesForTests = true)
            )
            val controller = RouterController(registry, sessionManager, authManager)

            val discoveryStub = object : com.example.networking.GatewayDiscoveryService {
                override suspend fun inspectLocalNetwork() =
                    com.example.networking.DiscoveryScanResult(emptyList(), "127.0.0.1", "Test")
            }
            val routerRepo = RouterRepository(controller, registry, discoveryStub)
            val deviceRepo = DeviceRepository(controller)
            val wifiRepo = WifiRepository(controller)
            val networkRepo = NetworkRepository(controller)

            // 1. Wrong password fails cleanly
            controller.setAppMode(AppMode.LIVE)
            val badLogin = authManager.authenticate(
                OpenWrtAdapter.ADAPTER_ID,
                RouterCredentials("127.0.0.1", fakeRouter.port, false, "root", "wrong-pass"),
                overrideAdapter = openWrtAdapter
            )
            assertTrue(badLogin is RouterResult.Failure)
            assertFalse(sessionManager.isAuthenticated())
            assertTrue(routerRepo.getRouterInfo() is RouterResult.NotConnected)

            // 2. Valid login establishes session with cookies, CSRF token, and runtime ubus capabilities
            val goodLogin = authManager.authenticate(
                OpenWrtAdapter.ADAPTER_ID,
                RouterCredentials("127.0.0.1", fakeRouter.port, false, "root", "openwrt-secret"),
                overrideAdapter = openWrtAdapter
            )
            assertTrue("Expected Success login, got $goodLogin", goodLogin is RouterResult.Success)
            val session = (goodLogin as RouterResult.Success).data
            assertEquals("csrf-openwrt-123", sessionManager.getCsrfToken())
            assertTrue(session.hasCsrfToken)
            assertTrue(session.cookieCount >= 1)
            assertEquals("1", fakeRouter.observedHeaders["Cookie"]?.contains("sysauth=cookie-sid-777")?.let { if (it) "1" else "0" })

            // Deterministic traffic Mbps delta check on openWrtAdapter with fakeClockMs
            val baselineSnap = (openWrtAdapter.getTrafficSnapshot() as RouterResult.Success).data
            assertEquals(0f, baselineSnap.downloadMbps, 0.01f)
            fakeRouter.wanRxBytes += 5_000_000L // +5 MB = 40 Mbits over 2s = 20.0 Mbps
            fakeClockMs += 2_000L
            val deltaSnap = (openWrtAdapter.getTrafficSnapshot() as RouterResult.Success).data
            assertEquals(20.0f, deltaSnap.downloadMbps, 0.1f)

            // Authenticate controller through live adapter for full repository flow
            val ctrlLogin = controller.authenticateLive(
                OpenWrtAdapter.ADAPTER_ID,
                RouterCredentials("127.0.0.1", fakeRouter.port, false, "root", "openwrt-secret")
            )
            assertTrue(ctrlLogin is RouterResult.Success)

            // 3. Router Info (system.board + system.info + network.interface.dump)
            val infoRes = routerRepo.getRouterInfo()
            assertTrue(infoRes is RouterResult.Success)
            val info = (infoRes as RouterResult.Success).data
            assertEquals("OpenWrt", info.manufacturer)
            assertEquals("GL.iNet GL-MT6000", info.model)
            assertTrue(info.firmwareVersion.contains("23.05.3"))
            assertEquals("203.0.113.44", info.wanIp)
            assertTrue(info.internetConnected)

            // 4. Wi-Fi config read & update (uci.get + uci.set + uci.commit)
            val wifiRes = wifiRepo.getWifiConfig()
            assertTrue(wifiRes is RouterResult.Success)
            val wifi = (wifiRes as RouterResult.Success).data
            assertEquals("OpenWrt_2G", wifi.band24.ssid)
            assertEquals("OpenWrt_5G", wifi.band5?.ssid)
            assertEquals(WifiSecurityMode.WPA2_PSK, wifi.band24.securityMode)
            assertNotNull(wifi.guestNetwork)

            val updatedWifiRes = wifiRepo.updateBandConfig(
                WifiBand.BAND_5_GHZ,
                wifi.band5!!.copy(ssid = "Studio_5G_Updated", channel = "44", bandwidthMhz = "80 MHz")
            )
            assertTrue(updatedWifiRes is RouterResult.Success)
            assertEquals("Studio_5G_Updated", (updatedWifiRes as RouterResult.Success).data.band5?.ssid)
            assertTrue(fakeRouter.committedConfigs.contains("wireless"))

            // 5. Connected clients (iwinfo.assoclist + luci-rpc.getDHCPLeases + MAC/WAN blocks)
            val devicesRes = deviceRepo.getDevices()
            assertTrue(devicesRes is RouterResult.Success)
            val devices = (devicesRes as RouterResult.Success).data
            assertEquals(2, devices.size)
            val laptop = devices.first { it.macAddress == "AA:BB:CC:11:22:33" }
            assertEquals("Workstation-Laptop", laptop.name)
            assertEquals("192.168.1.120", laptop.ipAddress)
            assertEquals(-51, laptop.signalStrengthDbm)
            assertEquals(ConnectionType.WIFI_5_GHZ, laptop.connectionType)

            // Block device & block internet
            assertTrue(deviceRepo.blockDevice(laptop.macAddress) is RouterResult.Success)
            assertTrue(deviceRepo.setInternetBlocked(laptop.macAddress, true) is RouterResult.Success)
            assertTrue(fakeRouter.committedConfigs.contains("firewall"))

            val devicesAfterBlock = (deviceRepo.getDevices() as RouterResult.Success).data
            val blockedLaptop = devicesAfterBlock.first { it.macAddress == laptop.macAddress }
            assertTrue(blockedLaptop.isBlocked)
            assertTrue(blockedLaptop.isInternetBlocked)

            // 6. Network settings + DHCP + Port forward
            val netRes = networkRepo.getNetworkSettings()
            assertTrue(netRes is RouterResult.Success)
            val net = (netRes as RouterResult.Success).data
            assertEquals("192.168.1.1", net.lan.routerIp)
            assertEquals("192.168.1.100", net.dhcp.startIp)

            assertTrue(
                networkRepo.updateDhcpConfig(
                    DhcpConfig(true, "192.168.1.50", "192.168.1.200", 720, 2, 0)
                ) is RouterResult.Success
            )
            assertTrue(
                networkRepo.savePortForwardRule(
                    PortForwardRule("pf-new", "WireGuard", 51820, 51820, "192.168.1.10", ProtocolType.UDP, true)
                ) is RouterResult.Success
            )

            // 7. Traffic snapshot & interface stats via controller
            assertTrue(routerRepo.getTrafficSnapshot() is RouterResult.Success)
            assertTrue(networkRepo.getInterfaceStats() is RouterResult.Success)

            // 8. Unsupported ISP optical/VoIP/speedtest never fabricate data
            assertTrue(networkRepo.getOpticalInfo() is RouterResult.Unsupported)
            assertTrue(networkRepo.getVoipStatus() is RouterResult.Unsupported)
            assertTrue(networkRepo.runSpeedTest() is RouterResult.Unsupported)

            // 9. Session expiration triggers AuthRequired and clears session
            fakeRouter.sessionExpired = true
            val afterExpiry = routerRepo.getRouterInfo()
            assertTrue("Expected AuthRequired after server expiry, got $afterExpiry", afterExpiry is RouterResult.AuthRequired)
            assertNull(sessionManager.currentSession.value)
        } finally {
            fakeRouter.stop()
        }
    }

    @Test
    fun openWrtAdapter_handlesStrippedFirmwareAndHttpErrorsWithoutFabricating() = runTest {
        val fakeRouter = FakeOpenWrtHttpServer(strippedCapabilities = true)
        fakeRouter.start()
        try {
            val sessionManager = RouterSessionManager()
            val rpcClient = OpenWrtRpcClient(sessionManager)
            val adapter = OpenWrtAdapter(sessionManager, rpcClient)

            val login = adapter.authenticate(
                RouterCredentials("127.0.0.1", fakeRouter.port, false, "root", "openwrt-secret")
            )
            assertTrue(login is RouterResult.Success)
            // Stripped firmware omitted luci-rpc, iwinfo, network.device -> capabilities updated dynamically!
            assertFalse(adapter.capabilities.supports(RouterFeature.DEVICE_LIST))
            assertFalse(adapter.capabilities.supports(RouterFeature.TRAFFIC_MONITORING))
            assertTrue(adapter.getConnectedDevices() is RouterResult.Unsupported)
            assertTrue(adapter.getTrafficSnapshot() is RouterResult.Unsupported)

            // Simulate HTTP 500 server error
            fakeRouter.forceHttpStatus = 500
            val errRes = adapter.getRouterInfo()
            assertTrue(errRes is RouterResult.Failure)

            // Simulate HTTP 404 missing endpoint
            fakeRouter.forceHttpStatus = 404
            val notFoundRes = adapter.getRouterInfo()
            assertTrue(notFoundRes is RouterResult.Unsupported)
        } finally {
            fakeRouter.stop()
        }
    }

    @Test
    fun openWrtAdapter_supportsLegacyLuciRpcFallbackAndTimeouts() = runTest {
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        val port = server.address.port
        server.executor = Executors.newSingleThreadExecutor()

        // /ubus returns 404 -> legacy OpenWrt without uhttpd-mod-ubus
        server.createContext("/ubus") { ex ->
            ex.sendResponseHeaders(404, 0)
            ex.responseBody.close()
        }
        server.createContext("/cgi-bin/luci/rpc/auth") { ex ->
            val resp = """{"id":1,"result":"legacy-token-555","error":null}"""
            val bytes = resp.toByteArray()
            ex.responseHeaders.add("Set-Cookie", "sysauth=legacycookie; path=/")
            ex.sendResponseHeaders(200, bytes.size.toLong())
            ex.responseBody.use { it.write(bytes) }
        }
        server.createContext("/cgi-bin/luci/rpc/sys") { ex ->
            val resp = """{"id":2,"result":86400,"error":null}"""
            val bytes = resp.toByteArray()
            ex.sendResponseHeaders(200, bytes.size.toLong())
            ex.responseBody.use { it.write(bytes) }
        }
        server.createContext("/cgi-bin/luci/rpc/slow") { ex ->
            Thread.sleep(2500)
            ex.sendResponseHeaders(200, 0)
            ex.responseBody.close()
        }
        server.start()

        try {
            val sessionManager = RouterSessionManager()
            val rpcClient = OpenWrtRpcClient(sessionManager) { target ->
                RouterEndpointClient.createClient(
                    cookieJar = sessionManager.cookieJar,
                    connectTimeoutSeconds = 1,
                    readTimeoutSeconds = 1
                )
            }
            val adapter = OpenWrtAdapter(sessionManager, rpcClient)
            val login = adapter.authenticate(
                RouterCredentials("127.0.0.1", port, false, "root", "pass")
            )
            assertTrue(login is RouterResult.Success)
            val info = adapter.getRouterInfo()
            assertTrue(info is RouterResult.Success)
            assertEquals(86400L, (info as RouterResult.Success).data.uptimeSeconds)

            // Timeout error check
            val timeoutRes = rpcClient.callLegacyLuciRpc(
                com.example.adapters.live.OpenWrtConnectionTarget("127.0.0.1", port, false),
                "slow",
                "hang"
            )
            assertTrue(timeoutRes is RouterResult.Failure)

            // Unreachable closed port check
            val closedPort = ServerSocket(0).use { it.localPort }
            val unreachableRes = adapter.authenticate(
                RouterCredentials("127.0.0.1", closedPort, false, "root", "pass")
            )
            assertTrue(unreachableRes is RouterResult.Failure)
        } finally {
            server.stop(0)
        }
    }

    private class FakeOpenWrtHttpServer(
        private val strippedCapabilities: Boolean = false
    ) {
        private val json = Json { ignoreUnknownKeys = true; isLenient = true }
        private val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        val port: Int get() = server.address.port

        var wanRxBytes: Long = 10_000_000L
        var wanTxBytes: Long = 2_000_000L
        var sessionExpired: Boolean = false
        var forceHttpStatus: Int? = null
        val committedConfigs = mutableListOf<String>()
        val observedHeaders = mutableMapOf<String, String>()

        private var wifi5gSsid = "OpenWrt_5G"
        private var blockedMacs = mutableListOf<String>()
        private var wanBlockedMacs = mutableListOf<String>()
        private var dhcpStart = "100"

        fun start() {
            server.executor = Executors.newSingleThreadExecutor()
            server.createContext("/ubus") { ex -> handleUbus(ex) }
            server.start()
        }

        fun stop() = server.stop(0)

        private fun handleUbus(ex: HttpExchange) {
            forceHttpStatus?.let { code ->
                ex.sendResponseHeaders(code, 0)
                ex.responseBody.close()
                return
            }

            ex.requestHeaders["Cookie"]?.firstOrNull()?.let { observedHeaders["Cookie"] = it }
            ex.requestHeaders["X-CSRF-Token"]?.firstOrNull()?.let { observedHeaders["X-CSRF-Token"] = it }

            val reqText = ex.requestBody.bufferedReader().readText()
            val reqObj = json.parseToJsonElement(reqText).jsonObject
            val id = reqObj["id"] ?: JsonPrimitive(1)
            val method = reqObj["method"]?.jsonPrimitive?.content
            val params = reqObj["params"] as? JsonArray ?: JsonArray(emptyList())

            if (method == "list") {
                val objs = mutableListOf("system", "uci", "network.interface", "session")
                if (!strippedCapabilities) {
                    objs.addAll(listOf("iwinfo", "luci-rpc", "network.device", "dhcp"))
                }
                val resultJson = objs.joinToString(",") { "\"$it\":{}" }
                sendJson(ex, """{"jsonrpc":"2.0","id":$id,"result":{$resultJson}}""")
                return
            }

            val sid = params.getOrNull(0)?.jsonPrimitive?.content.orEmpty()
            val ubusObj = params.getOrNull(1)?.jsonPrimitive?.content.orEmpty()
            val proc = params.getOrNull(2)?.jsonPrimitive?.content.orEmpty()
            val args = params.getOrNull(3) as? JsonObject ?: JsonObject(emptyMap())

            if (ubusObj == "session" && proc == "login") {
                val user = args["username"]?.jsonPrimitive?.content
                val pass = args["password"]?.jsonPrimitive?.content
                if (user == "root" && pass == "openwrt-secret") {
                    ex.responseHeaders.add("Set-Cookie", "sysauth=cookie-sid-777; Path=/; HttpOnly")
                    ex.responseHeaders.add("X-CSRF-Token", "csrf-openwrt-123")
                    sendJson(
                        ex,
                        """{"jsonrpc":"2.0","id":$id,"result":[0,{"ubus_rpc_session":"sid-live-1","timeout":300,"expires":300}]}"""
                    )
                } else {
                    sendJson(ex, """{"jsonrpc":"2.0","id":$id,"result":[6]}""")
                }
                return
            }

            if (sessionExpired || sid != "sid-live-1") {
                sendJson(ex, """{"jsonrpc":"2.0","id":$id,"error":{"code":-32002,"message":"Access denied"}}""")
                return
            }

            if (strippedCapabilities && ubusObj in setOf("iwinfo", "luci-rpc", "network.device", "dhcp")) {
                sendJson(ex, """{"jsonrpc":"2.0","id":$id,"error":{"code":-32000,"message":"Object not found"}}""")
                return
            }

            val response = when ("$ubusObj.$proc") {
                "system.board" -> """{"jsonrpc":"2.0","id":$id,"result":[0,{"kernel":"5.15.150","hostname":"OpenWrt-Lab","system":"ARMv8","model":"GL.iNet GL-MT6000","board_name":"glinet,gl-mt6000","release":{"distribution":"OpenWrt","version":"23.05.3","revision":"r23809"}}]}"""
                "system.info" -> """{"jsonrpc":"2.0","id":$id,"result":[0,{"uptime":14520,"load":[16384,12000,9000],"memory":{"total":1073741824,"free":536870912,"buffered":67108864}}]}"""
                "network.interface.dump" -> """{"jsonrpc":"2.0","id":$id,"result":[0,{"interface":[{"interface":"lan","up":true,"proto":"static","ipv4-address":[{"address":"192.168.1.1","mask":24}]},{"interface":"wan","up":true,"proto":"dhcp","l3_device":"eth1","ipv4-address":[{"address":"203.0.113.44","mask":24}],"dns-server":["1.1.1.1","8.8.8.8"],"route":[{"target":"0.0.0.0","nexthop":"203.0.113.1"}]}]}]}"""
                "network.device.status" -> """{"jsonrpc":"2.0","id":$id,"result":[0,{"wan":{"type":"Network device","up":true,"statistics":{"rx_bytes":$wanRxBytes,"tx_bytes":$wanTxBytes,"rx_packets":12000,"tx_packets":8000,"rx_errors":0,"tx_errors":0,"rx_dropped":0,"tx_dropped":0}}}]}"""
                "uci.get" -> {
                    val cfg = args["config"]?.jsonPrimitive?.content
                    when (cfg) {
                        "wireless" -> {
                            val maclistJson = blockedMacs.joinToString(",") { "\"$it\"" }
                            val macFilter = if (blockedMacs.isNotEmpty()) "deny" else "disable"
                            """{"jsonrpc":"2.0","id":$id,"result":[0,{"values":{"radio0":{".type":"wifi-device","band":"2g","channel":"6","htmode":"HT20"},"radio1":{".type":"wifi-device","band":"5g","channel":"36","htmode":"VHT80"},"default_radio0":{".type":"wifi-iface","device":"radio0","mode":"ap","ssid":"OpenWrt_2G","encryption":"psk2","key":"pass24ghz","macfilter":"$macFilter","maclist":[$maclistJson]},"default_radio1":{".type":"wifi-iface","device":"radio1","mode":"ap","ssid":"$wifi5gSsid","encryption":"psk2","key":"pass5ghz","macfilter":"$macFilter","maclist":[$maclistJson]},"guest_radio":{".type":"wifi-iface","device":"radio0","network":"guest","mode":"ap","ssid":"OpenWrt_Guest","encryption":"psk2","key":"guestpass","disabled":"1"}}}]}"""
                        }
                        "firewall" -> {
                            val wanRuleJson = wanBlockedMacs.joinToString(",") { mac ->
                                val key = "rmpro_wan_${mac.replace(":", "").lowercase()}"
                                """"$key":{".type":"rule","name":"$key","src":"lan","dest":"wan","src_mac":"$mac","target":"DROP","enabled":"1"}"""
                            }
                            val extra = if (wanRuleJson.isNotEmpty()) ",$wanRuleJson" else ""
                            """{"jsonrpc":"2.0","id":$id,"result":[0,{"values":{"cfg01":{".type":"defaults","synflood_protect":"1"},"zone_wan":{".type":"zone","name":"wan","input":"REJECT"}$extra}}]}"""
                        }
                        "dhcp" -> """{"jsonrpc":"2.0","id":$id,"result":[0,{"values":{"lan":{".type":"dhcp","start":"$dhcpStart","limit":"150","leasetime":"12h"},"cfg_dns":{".type":"dnsmasq"}}}]}"""
                        "network" -> """{"jsonrpc":"2.0","id":$id,"result":[0,{"values":{"lan":{".type":"interface","ipaddr":"192.168.1.1","netmask":"255.255.255.0"},"wan":{".type":"interface","proto":"dhcp","mtu":"1500"}}}]}"""
                        "system" -> """{"jsonrpc":"2.0","id":$id,"result":[0,{"values":{"cfg01":{".type":"system","hostname":"OpenWrt-Lab"}}}]}"""
                        else -> """{"jsonrpc":"2.0","id":$id,"result":[0,{"values":{}}]}"""
                    }
                }
                "uci.set" -> {
                    val cfg = args["config"]?.jsonPrimitive?.content
                    val sec = args["section"]?.jsonPrimitive?.content
                    val vals = args["values"] as? JsonObject
                    if (cfg == "wireless" && sec == "default_radio1") {
                        vals?.get("ssid")?.jsonPrimitive?.content?.let { wifi5gSsid = it }
                    }
                    if (cfg == "wireless" && vals?.containsKey("maclist") == true) {
                        blockedMacs = vals["maclist"]!!.jsonArray.map { it.jsonPrimitive.content }.toMutableList()
                    }
                    if (cfg == "dhcp" && sec == "lan") {
                        vals?.get("start")?.jsonPrimitive?.content?.let { dhcpStart = it }
                    }
                    """{"jsonrpc":"2.0","id":$id,"result":[0,{}]}"""
                }
                "uci.add" -> {
                    val cfg = args["config"]?.jsonPrimitive?.content
                    val vals = args["values"] as? JsonObject
                    if (cfg == "firewall") {
                        vals?.get("src_mac")?.jsonPrimitive?.content?.let { wanBlockedMacs.add(it) }
                    }
                    """{"jsonrpc":"2.0","id":$id,"result":[0,{"section":"new_sec"}]}"""
                }
                "uci.delete" -> """{"jsonrpc":"2.0","id":$id,"result":[0,{}]}"""
                "uci.commit" -> {
                    args["config"]?.jsonPrimitive?.content?.let { committedConfigs.add(it) }
                    """{"jsonrpc":"2.0","id":$id,"result":[0,{}]}"""
                }
                "iwinfo.devices" -> """{"jsonrpc":"2.0","id":$id,"result":[0,{"devices":["phy0-ap0","phy1-ap0"]}]}"""
                "iwinfo.info" -> {
                    val dev = args["device"]?.jsonPrimitive?.content
                    val freq = if (dev == "phy1-ap0") 5180 else 2437
                    """{"jsonrpc":"2.0","id":$id,"result":[0,{"ssid":"$wifi5gSsid","frequency":$freq}]}"""
                }
                "iwinfo.assoclist" -> {
                    val dev = args["device"]?.jsonPrimitive?.content
                    if (dev == "phy1-ap0") {
                        """{"jsonrpc":"2.0","id":$id,"result":[0,{"results":[{"mac":"AA:BB:CC:11:22:33","signal":-51,"connected_time":420,"rx":{"rate":866700},"tx":{"rate":780000}}]}]}"""
                    } else {
                        """{"jsonrpc":"2.0","id":$id,"result":[0,{"results":[{"mac":"DD:EE:FF:44:55:66","signal":-64,"connected_time":120,"rx":{"rate":144400},"tx":{"rate":130000}}]}]}"""
                    }
                }
                "luci-rpc.getDHCPLeases" -> """{"jsonrpc":"2.0","id":$id,"result":[0,{"dhcp_leases":[{"macaddr":"AA:BB:CC:11:22:33","ipaddr":"192.168.1.120","hostname":"Workstation-Laptop","expires":3600},{"macaddr":"DD:EE:FF:44:55:66","ipaddr":"192.168.1.145","hostname":"Pixel-Phone","expires":3600}]}]}"""
                "luci-rpc.getHostHints" -> """{"jsonrpc":"2.0","id":$id,"result":[0,{}]}"""
                "system.reboot" -> """{"jsonrpc":"2.0","id":$id,"result":[0,{}]}"""
                else -> """{"jsonrpc":"2.0","id":$id,"error":{"code":-32601,"message":"Method not found"}}"""
            }
            sendJson(ex, response)
        }

        private fun sendJson(ex: HttpExchange, jsonBody: String) {
            val bytes = jsonBody.toByteArray()
            ex.responseHeaders.add("Content-Type", "application/json")
            ex.sendResponseHeaders(200, bytes.size.toLong())
            ex.responseBody.use { it.write(bytes) }
        }
    }
}
