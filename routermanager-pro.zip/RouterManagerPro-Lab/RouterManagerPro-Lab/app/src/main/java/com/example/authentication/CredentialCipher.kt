package com.example.authentication

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import java.security.SecureRandom
import java.security.Security
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

interface CredentialCipher {
    fun encrypt(plaintext: String): String
    fun decrypt(ciphertext: String): String?
}

/**
 * Encrypts router credentials using AndroidKeyStore AES-256-GCM on Android devices.
 *
 * When running in a headless JVM unit test (where AndroidKeyStore is absent), uses a
 * real AES-256-GCM cipher with a process-local ephemeral key if permitted for tests,
 * never downgrading on real Android devices where AndroidKeyStore is registered.
 */
class KeystoreCredentialCipher(
    private val keyAlias: String = "routermanager_pro_cred_v1",
    private val allowJreAesForTests: Boolean = false
) : CredentialCipher {

    @Volatile
    private var jreFallbackKey: SecretKey? = null

    private fun hasAndroidKeyStore(): Boolean = Security.getProvider("AndroidKeyStore") != null

    override fun encrypt(plaintext: String): String {
        if (plaintext.isEmpty()) return ""
        val useAndroidKeyStore = hasAndroidKeyStore()
        if (!useAndroidKeyStore && !allowJreAesForTests) {
            throw IllegalStateException("AndroidKeyStore provider is unavailable on this runtime.")
        }
        val key = if (useAndroidKeyStore) getOrCreateKeystoreKey() else getOrCreateJreTestKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key)
        val iv = cipher.iv
        val encrypted = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))
        val combined = ByteArray(iv.size + encrypted.size)
        System.arraycopy(iv, 0, combined, 0, iv.size)
        System.arraycopy(encrypted, 0, combined, iv.size, encrypted.size)
        val prefix = if (useAndroidKeyStore) "KS1:" else "JREGCM1:"
        return prefix + encodeBase64(combined)
    }

    override fun decrypt(ciphertext: String): String? {
        if (ciphertext.isEmpty()) return ""
        return try {
            when {
                ciphertext.startsWith("KS1:") -> {
                    val raw = decodeBase64(ciphertext.removePrefix("KS1:")) ?: return null
                    if (raw.size <= 12) return null
                    val iv = raw.copyOfRange(0, 12)
                    val payload = raw.copyOfRange(12, raw.size)
                    val key = getOrCreateKeystoreKey()
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
                    String(cipher.doFinal(payload), Charsets.UTF_8)
                }
                ciphertext.startsWith("JREGCM1:") && allowJreAesForTests -> {
                    val raw = decodeBase64(ciphertext.removePrefix("JREGCM1:")) ?: return null
                    if (raw.size <= 12) return null
                    val iv = raw.copyOfRange(0, 12)
                    val payload = raw.copyOfRange(12, raw.size)
                    val key = getOrCreateJreTestKey()
                    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                    cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
                    String(cipher.doFinal(payload), Charsets.UTF_8)
                }
                // Legacy Phase-1 Robolectric migration support only when AndroidKeyStore absent
                ciphertext.startsWith("OBF1:") && !hasAndroidKeyStore() -> {
                    val raw = decodeBase64(ciphertext.removePrefix("OBF1:")) ?: return null
                    String(raw, Charsets.UTF_8)
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun getOrCreateKeystoreKey(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(keyAlias, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            "AndroidKeyStore"
        )
        val spec = KeyGenParameterSpec.Builder(
            keyAlias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private fun getOrCreateJreTestKey(): SecretKey {
        jreFallbackKey?.let { return it }
        synchronized(this) {
            jreFallbackKey?.let { return it }
            val bytes = ByteArray(32).also { SecureRandom().nextBytes(it) }
            val key = SecretKeySpec(bytes, "AES")
            jreFallbackKey = key
            return key
        }
    }

    private fun encodeBase64(bytes: ByteArray): String {
        return try {
            Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (_: Throwable) {
            java.util.Base64.getEncoder().encodeToString(bytes)
        }
    }

    private fun decodeBase64(input: String): ByteArray? {
        return try {
            Base64.decode(input, Base64.NO_WRAP)
        } catch (_: Throwable) {
            runCatching { java.util.Base64.getDecoder().decode(input) }.getOrNull()
        }
    }
}
