package com.example.repositories

import com.example.core.AppMode
import com.example.core.RouterResult
import com.example.models.ConnectedDevice
import com.example.models.RouterFeature
import com.example.models.WifiBand
import com.example.router.RouterController
import kotlinx.coroutines.flow.StateFlow

class DeviceRepository(
    private val controller: RouterController
) {
    val appMode: StateFlow<AppMode> = controller.appMode
    val revision: StateFlow<Long> = controller.revision

    fun supportsBlocking(): Boolean = controller.supportsFeature(RouterFeature.DEVICE_BLOCKING)

    fun supportsInternetBlocking(): Boolean = controller.supportsFeature(RouterFeature.DEVICE_INTERNET_BLOCKING)

    fun supportsBandBlocking(): Boolean = controller.supportsFeature(RouterFeature.DEVICE_BAND_BLOCKING)

    fun supportsGuestBlocking(): Boolean = controller.supportsFeature(RouterFeature.WIFI_GUEST_NETWORK)

    fun supportsStaticIp(): Boolean = controller.supportsFeature(RouterFeature.STATIC_IP_RESERVATION)

    fun supportsRename(): Boolean = controller.supportsFeature(RouterFeature.DEVICE_RENAME)

    suspend fun getDevices(): RouterResult<List<ConnectedDevice>> = controller.getConnectedDevices()

    suspend fun getDeviceByMac(macAddress: String): RouterResult<ConnectedDevice> {
        return when (val result = controller.getConnectedDevices()) {
            is RouterResult.Success -> {
                val found = result.data.firstOrNull {
                    it.macAddress.equals(macAddress, ignoreCase = true)
                }
                if (found != null) {
                    RouterResult.Success(found, isDemoData = result.isDemoData)
                } else {
                    RouterResult.Failure("Device $macAddress is not present in the active client table.")
                }
            }
            is RouterResult.NotConnected -> result
            is RouterResult.Unsupported -> result
            is RouterResult.AuthRequired -> result
            is RouterResult.ValidationError -> result
            is RouterResult.Failure -> result
        }
    }

    suspend fun renameDevice(macAddress: String, newName: String): RouterResult<Unit> =
        controller.renameDevice(macAddress, newName)

    suspend fun blockDevice(macAddress: String): RouterResult<Unit> = controller.blockDevice(macAddress)

    suspend fun unblockDevice(macAddress: String): RouterResult<Unit> = controller.unblockDevice(macAddress)

    suspend fun setInternetBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> =
        controller.setDeviceInternetBlocked(macAddress, blocked)

    suspend fun setGuestBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> =
        controller.setDeviceGuestBlocked(macAddress, blocked)

    suspend fun setBandBlocked(macAddress: String, band: WifiBand, blocked: Boolean): RouterResult<Unit> =
        controller.setDeviceBandBlocked(macAddress, band, blocked)

    suspend fun setStaticIp(macAddress: String, reserved: Boolean): RouterResult<Unit> =
        controller.setDeviceStaticIp(macAddress, reserved)
}
