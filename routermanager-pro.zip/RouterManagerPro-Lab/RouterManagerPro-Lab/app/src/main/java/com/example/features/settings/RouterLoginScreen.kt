package com.example.features.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Login
import androidx.compose.material.icons.outlined.ExpandLess
import androidx.compose.material.icons.outlined.ExpandMore
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material.icons.outlined.Router
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.AppMode
import com.example.designsystem.AdminCard
import com.example.designsystem.HexRouterEmblem
import com.example.designsystem.InfoBanner

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RouterLoginScreen(
    profileId: String?,
    prefillHostIp: String? = null,
    prefillPort: Int? = null,
    prefillUseHttps: Boolean? = null,
    prefillAdapterId: String? = null,
    viewModel: SettingsViewModel,
    onBack: () -> Unit,
    onOpenDiscovery: (() -> Unit)? = null
) {
    val adapters = viewModel.supportedAdapters
    val savedProfiles by viewModel.savedProfiles.collectAsStateWithLifecycle()
    val loginState by viewModel.loginState.collectAsStateWithLifecycle()

    val existingProfile = remember(profileId, savedProfiles) {
        savedProfiles.firstOrNull { it.id == profileId }
    }

    var displayName by remember { mutableStateOf("") }
    var selectedAdapterId by remember {
        mutableStateOf(
            prefillAdapterId?.takeIf { id -> adapters.any { it.id == id } }
                ?: adapters.first().id
        )
    }
    var hostIp by remember { mutableStateOf(prefillHostIp ?: "192.168.1.1") }
    var portText by remember { mutableStateOf((prefillPort ?: 443).toString()) }
    var useHttps by remember { mutableStateOf(prefillUseHttps ?: true) }
    var allowSelfSignedTls by remember { mutableStateOf(true) }
    var username by remember { mutableStateOf("root") }
    var password by remember { mutableStateOf("") }
    var saveEncrypted by remember { mutableStateOf(true) }
    var showPassword by remember { mutableStateOf(false) }
    var showAdvancedOptions by remember { mutableStateOf(false) }
    var adapterMenuExpanded by remember { mutableStateOf(false) }

    LaunchedEffect(existingProfile) {
        viewModel.clearLoginFeedback()
        if (existingProfile != null) {
            displayName = existingProfile.displayName
            hostIp = existingProfile.hostIp
            portText = existingProfile.port.toString()
            useHttps = existingProfile.useHttps
            username = existingProfile.username
            saveEncrypted = existingProfile.hasStoredPassword
            if (existingProfile.hasStoredPassword) {
                password = viewModel.loadSavedPasswordForProfile(existingProfile.id)
            }
            val matched = adapters.firstOrNull {
                it.manufacturer.equals(existingProfile.manufacturer, ignoreCase = true)
            }
            if (matched != null) selectedAdapterId = matched.id
        }
    }

    val selectedAdapter = adapters.firstOrNull { it.id == selectedAdapterId } ?: adapters.first()

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 600.dp)
                .testTag("router_login_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("login_back_button")) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                    TextButton(
                        onClick = {
                            if (onOpenDiscovery != null) onOpenDiscovery()
                            else {
                                viewModel.setAppMode(AppMode.DEMO)
                                onBack()
                            }
                        },
                        modifier = Modifier.testTag("login_discover_quick_button")
                    ) {
                        Text(if (onOpenDiscovery != null) "Discover" else "Demo Mode")
                    }
                }
            }

            item {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    HexRouterEmblem(modifier = Modifier.size(96.dp))
                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = "RouterManager Pro",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Local Wi-Fi / LAN control only",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (!loginState.errorMessage.isNullOrBlank()) {
                item {
                    AdminCard {
                        Text("Connection Result", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.error)
                        Spacer(Modifier.height(4.dp))
                        Text(loginState.errorMessage!!, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            if (!loginState.successMessage.isNullOrBlank()) {
                item { InfoBanner(message = loginState.successMessage!!) }
            }

            item {
                AdminCard {
                    Text(
                        text = "Modem IP / Host",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = hostIp,
                        onValueChange = { hostIp = it },
                        leadingIcon = { Icon(Icons.Outlined.Router, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("login_host_input")
                    )

                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = "Username",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        leadingIcon = { Icon(Icons.Outlined.Person, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth().testTag("login_username_input")
                    )

                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = "Password",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = password,
                        onValueChange = { password = it },
                        leadingIcon = { Icon(Icons.Outlined.Lock, contentDescription = null) },
                        singleLine = true,
                        shape = RoundedCornerShape(14.dp),
                        visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { showPassword = !showPassword }) {
                                Icon(
                                    imageVector = if (showPassword) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                                    contentDescription = "Toggle password visibility"
                                )
                            }
                        },
                        modifier = Modifier.fillMaxWidth().testTag("login_password_input")
                    )

                    Spacer(Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Checkbox(
                            checked = saveEncrypted,
                            onCheckedChange = { saveEncrypted = it },
                            modifier = Modifier.testTag("login_save_credentials_checkbox")
                        )
                        Text(
                            text = "Save credentials for next time",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }

                    // Collapsible adapter, port & HTTPS configuration
                    Surface(
                        onClick = { showAdvancedOptions = !showAdvancedOptions },
                        color = MaterialTheme.colorScheme.surfaceContainerLow,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${selectedAdapter.displayName} · ${if (useHttps) "HTTPS" else "HTTP"}:$portText",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Icon(
                                imageVector = if (showAdvancedOptions) Icons.Outlined.ExpandLess else Icons.Outlined.ExpandMore,
                                contentDescription = "Toggle advanced gateway fields",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    AnimatedVisibility(visible = showAdvancedOptions) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            OutlinedTextField(
                                value = displayName,
                                onValueChange = { displayName = it },
                                label = { Text("Profile Label (optional)") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(8.dp))
                            ExposedDropdownMenuBox(
                                expanded = adapterMenuExpanded,
                                onExpandedChange = { adapterMenuExpanded = !adapterMenuExpanded }
                            ) {
                                OutlinedTextField(
                                    value = selectedAdapter.displayName,
                                    onValueChange = {},
                                    readOnly = true,
                                    label = { Text("Router Adapter") },
                                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = adapterMenuExpanded) },
                                    modifier = Modifier
                                        .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                        .fillMaxWidth()
                                )
                                ExposedDropdownMenu(
                                    expanded = adapterMenuExpanded,
                                    onDismissRequest = { adapterMenuExpanded = false }
                                ) {
                                    adapters.forEach { adapter ->
                                        DropdownMenuItem(
                                            text = { Text("${adapter.displayName} (${adapter.manufacturer})") },
                                            onClick = {
                                                selectedAdapterId = adapter.id
                                                adapterMenuExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                OutlinedTextField(
                                    value = portText,
                                    onValueChange = { portText = it.filter(Char::isDigit) },
                                    label = { Text("Admin Port") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.weight(1f).testTag("login_port_input")
                                )
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f).padding(top = 8.dp)
                                ) {
                                    Text("HTTPS", style = MaterialTheme.typography.bodyMedium)
                                    Spacer(Modifier.width(8.dp))
                                    Switch(
                                        checked = useHttps,
                                        onCheckedChange = {
                                            useHttps = it
                                            if (portText == "80" && it) portText = "443"
                                            if (portText == "443" && !it) portText = "80"
                                        }
                                    )
                                }
                            }
                            if (useHttps) {
                                Spacer(Modifier.height(8.dp))
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Checkbox(
                                        checked = allowSelfSignedTls,
                                        onCheckedChange = { allowSelfSignedTls = it },
                                        modifier = Modifier.testTag("login_self_signed_tls_checkbox")
                                    )
                                    Text(
                                        text = "Trust self-signed certificate on private LAN",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        viewModel.authenticateAndSaveProfile(
                            profileId = existingProfile?.id,
                            displayName = displayName,
                            adapterId = selectedAdapterId,
                            hostIp = hostIp,
                            portText = portText,
                            useHttps = useHttps,
                            username = username,
                            password = password,
                            saveCredentialsEncrypted = saveEncrypted,
                            allowSelfSignedTls = allowSelfSignedTls
                        )
                    },
                    enabled = !loginState.isSubmitting,
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("login_submit_button")
                ) {
                    Icon(Icons.AutoMirrored.Outlined.Login, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (loginState.isSubmitting) "Connecting..." else "Connect",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (onOpenDiscovery != null) {
                        OutlinedButton(
                            onClick = onOpenDiscovery,
                            shape = RoundedCornerShape(50),
                            modifier = Modifier.weight(1f).height(48.dp)
                        ) {
                            Icon(Icons.Outlined.Radar, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Discover Gateway")
                        }
                    }
                    OutlinedButton(
                        onClick = {
                            viewModel.setAppMode(AppMode.DEMO)
                            onBack()
                        },
                        shape = RoundedCornerShape(50),
                        modifier = Modifier.weight(1f).height(48.dp).testTag("login_demo_mode_button")
                    ) {
                        Icon(Icons.Outlined.Science, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Demo Sandbox")
                    }
                }
            }
        }
    }
}
