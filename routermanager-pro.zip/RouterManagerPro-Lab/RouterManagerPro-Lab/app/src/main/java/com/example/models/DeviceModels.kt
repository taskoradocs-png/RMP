package com.example.models

enum class ConnectionType(val label: String) {
    WIFI_5_GHZ("Wi-Fi 5 GHz"),
    WIFI_2_4_GHZ("Wi-Fi 2.4 GHz"),
    ETHERNET("Ethernet"),
    GUEST_WIFI("Guest Wi-Fi")
}

enum class DeviceCategory(val label: String) {
    PHONE("Smartphone"),
    LAPTOP("Laptop"),
    DESKTOP("Workstation"),
    TABLET("Tablet"),
    TV_MEDIA("Media & TV"),
    IOT("IoT / Smart Home"),
    GAMING("Gaming Console"),
    UNKNOWN("Network Device")
}

data class ConnectedDevice(
    val macAddress: String,
    val name: String,
    val ipAddress: String,
    val manufacturer: String,
    val connectionType: ConnectionType,
    val category: DeviceCategory,
    val isOnline: Boolean,
    val isBlocked: Boolean,
    val isInternetBlocked: Boolean = false,
    val isGuestBlocked: Boolean = false,
    val isBand24Blocked: Boolean = false,
    val isBand5Blocked: Boolean = false,
    val staticIpReserved: Boolean = false,
    val frequencyBandLabel: String = connectionType.label,
    val signalStrengthDbm: Int?,
    val linkSpeedMbps: Int?,
    val rxRateMbps: Float,
    val txRateMbps: Float,
    val totalDownloadedBytes: Long,
    val totalUploadedBytes: Long,
    val connectedDurationSeconds: Long,
    val dhcpType: String,
    val lastSeenLabel: String
)
