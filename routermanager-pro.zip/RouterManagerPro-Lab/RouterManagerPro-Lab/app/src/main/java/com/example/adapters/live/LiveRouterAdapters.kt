package com.example.adapters.live

import com.example.core.RouterResult
import com.example.models.AdapterDescriptor
import com.example.models.ConnectedDevice
import com.example.models.DhcpConfig
import com.example.models.DiagnosticResult
import com.example.models.DnsConfig
import com.example.models.EthernetPortInfo
import com.example.models.FirewallConfig
import com.example.models.GuestNetworkConfig
import com.example.models.InterfaceStat
import com.example.models.LanConfig
import com.example.models.NetworkActivityEvent
import com.example.models.NetworkSettings
import com.example.models.OpticalInfo
import com.example.models.ParentalControlTemplate
import com.example.models.PortForwardRule
import com.example.models.RouterCapability
import com.example.models.RouterCredentials
import com.example.models.RouterFeature
import com.example.models.RouterInfo
import com.example.models.RouterSession
import com.example.models.SpeedTestResult
import com.example.models.TrafficSnapshot
import com.example.models.VoipLineInfo
import com.example.models.WanConnectionProfile
import com.example.models.WifiBand
import com.example.models.WifiBandConfig
import com.example.models.WifiConfig
import com.example.router.RouterAdapter

/**
 * Base class for live manufacturer router adapters.
 * Never fabricates connected state, telemetry, or fake success responses.
 */
abstract class BaseLiveRouterAdapter : RouterAdapter {

    protected fun transportNotImplemented(operation: String): RouterResult.Failure {
        return RouterResult.Failure(
            message = "${descriptor.displayName}: Live router communication for \"$operation\" is not implemented in this generation. No request was sent to hardware."
        )
    }

    protected fun unsupported(feature: RouterFeature): RouterResult.Unsupported {
        return RouterResult.Unsupported(
            featureName = feature.displayName,
            reason = "${descriptor.displayName} does not declare support for ${feature.displayName}."
        )
    }

    override suspend fun authenticate(credentials: RouterCredentials): RouterResult<RouterSession> {
        return RouterResult.Failure(
            message = "${descriptor.displayName} live authentication transport (${descriptor.protocolDescription}) is staged for the next implementation phase. Cannot verify credentials against ${credentials.hostIp}:${credentials.port} without a live transport."
        )
    }

    override suspend fun disconnect(): RouterResult<Unit> = RouterResult.Success(Unit)

    override suspend fun getRouterInfo(): RouterResult<RouterInfo> =
        RouterResult.NotConnected("No active live session for ${descriptor.displayName}.")

    override suspend fun getTrafficSnapshot(): RouterResult<TrafficSnapshot> =
        if (!capabilities.supports(RouterFeature.TRAFFIC_MONITORING)) {
            unsupported(RouterFeature.TRAFFIC_MONITORING)
        } else {
            RouterResult.NotConnected("Live traffic telemetry requires an active authenticated router transport.")
        }

    override suspend fun getRecentActivity(): RouterResult<List<NetworkActivityEvent>> =
        RouterResult.NotConnected("No active live session for ${descriptor.displayName}.")

    override suspend fun getWifiConfig(): RouterResult<WifiConfig> =
        RouterResult.NotConnected("No active live session for ${descriptor.displayName}.")

    override suspend fun setWifiEnabled(enabled: Boolean): RouterResult<WifiConfig> =
        transportNotImplemented("setWifiEnabled")

    override suspend fun updateSsid(band: WifiBand, ssid: String): RouterResult<WifiConfig> =
        transportNotImplemented("updateSsid")

    override suspend fun updateWifiPassword(band: WifiBand, password: String): RouterResult<WifiConfig> =
        transportNotImplemented("updateWifiPassword")

    override suspend fun updateWifiBandConfig(band: WifiBand, config: WifiBandConfig): RouterResult<WifiConfig> =
        transportNotImplemented("updateWifiBandConfig")

    override suspend fun updateGuestNetwork(config: GuestNetworkConfig): RouterResult<WifiConfig> =
        if (!capabilities.supports(RouterFeature.WIFI_GUEST_NETWORK)) {
            unsupported(RouterFeature.WIFI_GUEST_NETWORK)
        } else {
            transportNotImplemented("updateGuestNetwork")
        }

    override suspend fun getConnectedDevices(): RouterResult<List<ConnectedDevice>> =
        RouterResult.NotConnected("No active live session for ${descriptor.displayName}.")

    override suspend fun renameDevice(macAddress: String, newName: String): RouterResult<Unit> =
        if (!capabilities.supports(RouterFeature.DEVICE_RENAME)) {
            unsupported(RouterFeature.DEVICE_RENAME)
        } else {
            transportNotImplemented("renameDevice")
        }

    override suspend fun blockDevice(macAddress: String): RouterResult<Unit> =
        if (!capabilities.supports(RouterFeature.DEVICE_BLOCKING)) {
            unsupported(RouterFeature.DEVICE_BLOCKING)
        } else {
            transportNotImplemented("blockDevice")
        }

    override suspend fun unblockDevice(macAddress: String): RouterResult<Unit> =
        if (!capabilities.supports(RouterFeature.DEVICE_BLOCKING)) {
            unsupported(RouterFeature.DEVICE_BLOCKING)
        } else {
            transportNotImplemented("unblockDevice")
        }

    override suspend fun setDeviceInternetBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> =
        if (!capabilities.supports(RouterFeature.DEVICE_INTERNET_BLOCKING)) {
            unsupported(RouterFeature.DEVICE_INTERNET_BLOCKING)
        } else {
            transportNotImplemented("setDeviceInternetBlocked")
        }

    override suspend fun setDeviceGuestBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> =
        if (!capabilities.supports(RouterFeature.WIFI_GUEST_NETWORK)) {
            unsupported(RouterFeature.WIFI_GUEST_NETWORK)
        } else {
            transportNotImplemented("setDeviceGuestBlocked")
        }

    override suspend fun setDeviceBandBlocked(macAddress: String, band: WifiBand, blocked: Boolean): RouterResult<Unit> =
        if (!capabilities.supports(RouterFeature.DEVICE_BAND_BLOCKING)) {
            unsupported(RouterFeature.DEVICE_BAND_BLOCKING)
        } else {
            transportNotImplemented("setDeviceBandBlocked")
        }

    override suspend fun setDeviceStaticIp(macAddress: String, reserved: Boolean): RouterResult<Unit> =
        if (!capabilities.supports(RouterFeature.STATIC_IP_RESERVATION)) {
            unsupported(RouterFeature.STATIC_IP_RESERVATION)
        } else {
            transportNotImplemented("setDeviceStaticIp")
        }

    override suspend fun getNetworkSettings(): RouterResult<NetworkSettings> =
        RouterResult.NotConnected("No active live session for ${descriptor.displayName}.")

    override suspend fun updateLanConfig(lanConfig: LanConfig): RouterResult<NetworkSettings> =
        transportNotImplemented("updateLanConfig")

    override suspend fun updateDhcpConfig(dhcpConfig: DhcpConfig): RouterResult<NetworkSettings> =
        transportNotImplemented("updateDhcpConfig")

    override suspend fun updateDnsConfig(dnsConfig: DnsConfig): RouterResult<NetworkSettings> =
        transportNotImplemented("updateDnsConfig")

    override suspend fun savePortForwardRule(rule: PortForwardRule): RouterResult<NetworkSettings> =
        if (!capabilities.supports(RouterFeature.PORT_FORWARDING)) {
            unsupported(RouterFeature.PORT_FORWARDING)
        } else {
            transportNotImplemented("savePortForwardRule")
        }

    override suspend fun deletePortForwardRule(ruleId: String): RouterResult<NetworkSettings> =
        if (!capabilities.supports(RouterFeature.PORT_FORWARDING)) {
            unsupported(RouterFeature.PORT_FORWARDING)
        } else {
            transportNotImplemented("deletePortForwardRule")
        }

    override suspend fun updateFirewallConfig(firewallConfig: FirewallConfig): RouterResult<NetworkSettings> =
        if (!capabilities.supports(RouterFeature.FIREWALL_CONFIG)) {
            unsupported(RouterFeature.FIREWALL_CONFIG)
        } else {
            transportNotImplemented("updateFirewallConfig")
        }

    override suspend fun setUpnpEnabled(enabled: Boolean): RouterResult<NetworkSettings> =
        if (!capabilities.supports(RouterFeature.UPNP_CONFIG)) {
            unsupported(RouterFeature.UPNP_CONFIG)
        } else {
            transportNotImplemented("setUpnpEnabled")
        }

    override suspend fun saveWanConnection(profile: WanConnectionProfile): RouterResult<NetworkSettings> =
        if (!capabilities.supports(RouterFeature.MULTI_WAN)) {
            unsupported(RouterFeature.MULTI_WAN)
        } else {
            transportNotImplemented("saveWanConnection")
        }

    override suspend fun deleteWanConnection(profileId: String): RouterResult<NetworkSettings> =
        if (!capabilities.supports(RouterFeature.MULTI_WAN)) {
            unsupported(RouterFeature.MULTI_WAN)
        } else {
            transportNotImplemented("deleteWanConnection")
        }

    override suspend fun runNetworkDiagnostics(): RouterResult<List<DiagnosticResult>> =
        if (!capabilities.supports(RouterFeature.NETWORK_DIAGNOSTICS)) {
            unsupported(RouterFeature.NETWORK_DIAGNOSTICS)
        } else {
            transportNotImplemented("runNetworkDiagnostics")
        }

    override suspend fun getOpticalInfo(): RouterResult<OpticalInfo> =
        if (!capabilities.supports(RouterFeature.OPTICAL_INFO)) {
            unsupported(RouterFeature.OPTICAL_INFO)
        } else {
            RouterResult.NotConnected("No active live session for ${descriptor.displayName}.")
        }

    override suspend fun getEthernetPorts(): RouterResult<List<EthernetPortInfo>> =
        if (!capabilities.supports(RouterFeature.ETHERNET_PORT_STATUS)) {
            unsupported(RouterFeature.ETHERNET_PORT_STATUS)
        } else {
            RouterResult.NotConnected("No active live session for ${descriptor.displayName}.")
        }

    override suspend fun getInterfaceStats(): RouterResult<List<InterfaceStat>> =
        if (!capabilities.supports(RouterFeature.INTERFACE_STATS)) {
            unsupported(RouterFeature.INTERFACE_STATS)
        } else {
            RouterResult.NotConnected("No active live session for ${descriptor.displayName}.")
        }

    override suspend fun getVoipStatus(): RouterResult<List<VoipLineInfo>> =
        if (!capabilities.supports(RouterFeature.VOIP_STATUS)) {
            unsupported(RouterFeature.VOIP_STATUS)
        } else {
            RouterResult.NotConnected("No active live session for ${descriptor.displayName}.")
        }

    override suspend fun getParentalTemplates(): RouterResult<List<ParentalControlTemplate>> =
        if (!capabilities.supports(RouterFeature.PARENTAL_CONTROL)) {
            unsupported(RouterFeature.PARENTAL_CONTROL)
        } else {
            RouterResult.NotConnected("No active live session for ${descriptor.displayName}.")
        }

    override suspend fun saveParentalTemplate(template: ParentalControlTemplate): RouterResult<List<ParentalControlTemplate>> =
        if (!capabilities.supports(RouterFeature.PARENTAL_CONTROL)) {
            unsupported(RouterFeature.PARENTAL_CONTROL)
        } else {
            transportNotImplemented("saveParentalTemplate")
        }

    override suspend fun deleteParentalTemplate(templateId: String): RouterResult<List<ParentalControlTemplate>> =
        if (!capabilities.supports(RouterFeature.PARENTAL_CONTROL)) {
            unsupported(RouterFeature.PARENTAL_CONTROL)
        } else {
            transportNotImplemented("deleteParentalTemplate")
        }

    override suspend fun runSpeedTest(): RouterResult<SpeedTestResult> =
        if (!capabilities.supports(RouterFeature.SPEED_TEST)) {
            unsupported(RouterFeature.SPEED_TEST)
        } else {
            transportNotImplemented("runSpeedTest")
        }

    override suspend fun rebootRouter(): RouterResult<Unit> =
        if (!capabilities.supports(RouterFeature.ROUTER_REBOOT)) {
            unsupported(RouterFeature.ROUTER_REBOOT)
        } else {
            transportNotImplemented("rebootRouter")
        }
}

class AsusWrtRouterAdapter : BaseLiveRouterAdapter() {
    override val capabilities = RouterCapability(
        supportedFeatures = setOf(
            RouterFeature.ROUTER_INFO,
            RouterFeature.WIFI_BASIC,
            RouterFeature.WIFI_DUAL_BAND,
            RouterFeature.WIFI_GUEST_NETWORK,
            RouterFeature.WIFI_CHANNEL_CONFIG,
            RouterFeature.WIFI_BANDWIDTH_CONFIG,
            RouterFeature.DEVICE_LIST,
            RouterFeature.DEVICE_BLOCKING,
            RouterFeature.DEVICE_INTERNET_BLOCKING,
            RouterFeature.TRAFFIC_MONITORING,
            RouterFeature.WAN_INFO,
            RouterFeature.LAN_CONFIG,
            RouterFeature.DHCP_CONFIG,
            RouterFeature.DNS_CONFIG,
            RouterFeature.PORT_FORWARDING,
            RouterFeature.FIREWALL_CONFIG,
            RouterFeature.UPNP_CONFIG,
            RouterFeature.NETWORK_DIAGNOSTICS,
            RouterFeature.ROUTER_REBOOT
        ),
        supports5Ghz = true,
        maxGuestNetworks = 3,
        capabilityNotes = "ASUSWRT HTTP/HTTPS session cookie API (Merlin & Stock 386/388)."
    )

    override val descriptor = AdapterDescriptor(
        id = "asuswrt_http",
        displayName = "ASUSWRT / Merlin API",
        manufacturer = "ASUS",
        supportedModels = listOf("RT-AX86U Pro", "RT-AX88U", "GT-AX6000", "ZenWiFi XT8"),
        minFirmwareVersion = "3.0.0.4.386",
        protocolDescription = "HTTPS form/JSON endpoint (/login.cgi, /appGet.cgi)",
        capability = capabilities,
        isLiveTransportReady = false
    )
}

class TpLinkArcherAdapter : BaseLiveRouterAdapter() {
    override val capabilities = RouterCapability(
        supportedFeatures = setOf(
            RouterFeature.ROUTER_INFO,
            RouterFeature.WIFI_BASIC,
            RouterFeature.WIFI_DUAL_BAND,
            RouterFeature.WIFI_GUEST_NETWORK,
            RouterFeature.WIFI_CHANNEL_CONFIG,
            RouterFeature.DEVICE_LIST,
            RouterFeature.DEVICE_BLOCKING,
            RouterFeature.WAN_INFO,
            RouterFeature.LAN_CONFIG,
            RouterFeature.DHCP_CONFIG,
            RouterFeature.DNS_CONFIG,
            RouterFeature.PORT_FORWARDING,
            RouterFeature.ROUTER_REBOOT
            // Intentionally excludes TRAFFIC_MONITORING, WIFI_BANDWIDTH_CONFIG, FIREWALL_CONFIG, UPNP_CONFIG, NETWORK_DIAGNOSTICS
        ),
        supports5Ghz = true,
        maxGuestNetworks = 1,
        capabilityNotes = "TP-Link stock firmware omits live traffic graphs, bandwidth width, UPnP toggle, and SPI firewall APIs."
    )

    override val descriptor = AdapterDescriptor(
        id = "tplink_archer",
        displayName = "TP-Link Archer Encrypted API",
        manufacturer = "TP-Link",
        supportedModels = listOf("Archer AX55", "Archer AX73", "Archer C80", "Deco X50"),
        minFirmwareVersion = "1.0.0",
        protocolDescription = "RSA/AES encrypted HTTP CGI (/cgi-bin/luci)",
        capability = capabilities,
        isLiveTransportReady = false
    )
}

class NetgearNighthawkAdapter : BaseLiveRouterAdapter() {
    override val capabilities = RouterCapability(
        supportedFeatures = setOf(
            RouterFeature.ROUTER_INFO,
            RouterFeature.WIFI_BASIC,
            RouterFeature.WIFI_DUAL_BAND,
            RouterFeature.WIFI_GUEST_NETWORK,
            RouterFeature.DEVICE_LIST,
            RouterFeature.DEVICE_BLOCKING,
            RouterFeature.WAN_INFO,
            RouterFeature.LAN_CONFIG,
            RouterFeature.DHCP_CONFIG,
            RouterFeature.DNS_CONFIG,
            RouterFeature.UPNP_CONFIG,
            RouterFeature.ROUTER_REBOOT
            // Excludes WIFI_CHANNEL_CONFIG, WIFI_BANDWIDTH_CONFIG, PORT_FORWARDING, FIREWALL_CONFIG, TRAFFIC_MONITORING, NETWORK_DIAGNOSTICS
        ),
        supports5Ghz = true,
        maxGuestNetworks = 1,
        capabilityNotes = "Nighthawk SOAP API supports core radio, client ACL, and UPnP controls; advanced diagnostics require web UI."
    )

    override val descriptor = AdapterDescriptor(
        id = "netgear_nighthawk",
        displayName = "Netgear Nighthawk SOAP",
        manufacturer = "Netgear",
        supportedModels = listOf("RAX50", "RAX80", "R7000P", "Orbi RBK752"),
        minFirmwareVersion = "1.0.4",
        protocolDescription = "SOAP XML over HTTP/HTTPS (/soap/server_sa/)",
        capability = capabilities,
        isLiveTransportReady = false
    )
}
