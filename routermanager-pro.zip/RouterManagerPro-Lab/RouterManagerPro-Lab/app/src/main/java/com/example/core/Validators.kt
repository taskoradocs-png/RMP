package com.example.core

import com.example.models.WifiSecurityMode

sealed interface ValidationResult {
    data object Valid : ValidationResult
    data class Invalid(val message: String) : ValidationResult

    val isValid: Boolean get() = this is Valid
    val errorOrNull: String? get() = (this as? Invalid)?.message
}

object Validators {
    private val IPV4_REGEX = Regex(
        "^((25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)\\.){3}(25[0-5]|2[0-4]\\d|1\\d\\d|[1-9]?\\d)$"
    )
    private val MAC_REGEX = Regex("^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$")
    private val HOSTNAME_REGEX = Regex(
        "^(?=.{1,253}$)(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\\.)*[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?$"
    )
    private val VALID_SUBNET_MASKS = setOf(
        "255.255.255.0",
        "255.255.255.128",
        "255.255.255.192",
        "255.255.255.224",
        "255.255.254.0",
        "255.255.252.0",
        "255.255.248.0",
        "255.255.240.0",
        "255.255.0.0",
        "255.0.0.0"
    )

    fun validateIpv4(ip: String, fieldLabel: String = "IP address"): ValidationResult {
        val trimmed = ip.trim()
        if (trimmed.isEmpty()) return ValidationResult.Invalid("$fieldLabel is required.")
        return if (IPV4_REGEX.matches(trimmed)) {
            ValidationResult.Valid
        } else {
            ValidationResult.Invalid("Enter a valid IPv4 $fieldLabel (e.g. 192.168.1.1).")
        }
    }

    fun validateHostOrIp(host: String, fieldLabel: String = "Router host"): ValidationResult {
        val trimmed = host.trim()
        if (trimmed.isEmpty()) return ValidationResult.Invalid("$fieldLabel is required.")
        if (IPV4_REGEX.matches(trimmed) || trimmed.equals("localhost", ignoreCase = true) || HOSTNAME_REGEX.matches(trimmed)) {
            return ValidationResult.Valid
        }
        return ValidationResult.Invalid("Enter a valid IPv4 address or LAN hostname (e.g. 192.168.1.1).")
    }

    fun validateSubnetMask(mask: String): ValidationResult {
        val trimmed = mask.trim()
        if (trimmed.isEmpty()) return ValidationResult.Invalid("Subnet mask is required.")
        return if (VALID_SUBNET_MASKS.contains(trimmed)) {
            ValidationResult.Valid
        } else {
            ValidationResult.Invalid("Enter a standard IPv4 subnet mask (e.g. 255.255.255.0).")
        }
    }

    fun validateMacAddress(mac: String): ValidationResult {
        val trimmed = mac.trim()
        return if (MAC_REGEX.matches(trimmed)) {
            ValidationResult.Valid
        } else {
            ValidationResult.Invalid("MAC address must match AA:BB:CC:DD:EE:FF.")
        }
    }

    fun validateSsid(ssid: String): ValidationResult {
        val trimmed = ssid.trim()
        val byteLen = trimmed.toByteArray(Charsets.UTF_8).size
        return when {
            trimmed.isEmpty() -> ValidationResult.Invalid("Network name (SSID) cannot be empty.")
            byteLen > 32 -> ValidationResult.Invalid("SSID cannot exceed 32 bytes.")
            else -> ValidationResult.Valid
        }
    }

    fun validateWifiPassword(
        password: String,
        securityMode: WifiSecurityMode
    ): ValidationResult {
        if (!securityMode.requiresPassphrase) {
            return ValidationResult.Valid
        }
        return when {
            password.isEmpty() ->
                ValidationResult.Invalid("Passphrase is required for ${securityMode.label}.")
            password.length < 8 ->
                ValidationResult.Invalid("Passphrase must be at least 8 characters.")
            password.length > 63 ->
                ValidationResult.Invalid("Passphrase cannot exceed 63 characters.")
            password.any { it.code !in 32..126 } ->
                ValidationResult.Invalid("Passphrase must use standard printable ASCII characters.")
            else -> ValidationResult.Valid
        }
    }

    fun validatePort(portText: String, fieldLabel: String = "Port"): ValidationResult {
        val port = portText.trim().toIntOrNull()
            ?: return ValidationResult.Invalid("$fieldLabel must be a number.")
        return if (port in 1..65535) {
            ValidationResult.Valid
        } else {
            ValidationResult.Invalid("$fieldLabel must be between 1 and 65535.")
        }
    }

    fun validateLeaseTimeMinutes(minutesText: String): ValidationResult {
        val mins = minutesText.trim().toIntOrNull()
            ?: return ValidationResult.Invalid("Lease time must be a number in minutes.")
        return if (mins in 5..43200) {
            ValidationResult.Valid
        } else {
            ValidationResult.Invalid("Lease time must be between 5 and 43,200 minutes.")
        }
    }

    fun validateDhcpRange(startIp: String, endIp: String, routerIp: String): ValidationResult {
        val startCheck = validateIpv4(startIp, "DHCP start IP")
        if (!startCheck.isValid) return startCheck
        val endCheck = validateIpv4(endIp, "DHCP end IP")
        if (!endCheck.isValid) return endCheck

        val startLong = ipv4ToLong(startIp.trim())
        val endLong = ipv4ToLong(endIp.trim())
        val routerLong = if (IPV4_REGEX.matches(routerIp.trim())) ipv4ToLong(routerIp.trim()) else null

        if (startLong >= endLong) {
            return ValidationResult.Invalid("DHCP start IP must be lower than DHCP end IP.")
        }
        if (routerLong != null && routerLong in startLong..endLong) {
            return ValidationResult.Invalid("DHCP pool should not overlap router gateway IP ($routerIp).")
        }
        val startPrefix = startIp.trim().substringBeforeLast('.')
        val endPrefix = endIp.trim().substringBeforeLast('.')
        if (startPrefix != endPrefix) {
            return ValidationResult.Invalid("DHCP start and end must share the same /24 subnet prefix.")
        }
        return ValidationResult.Valid
    }

    fun validateNonBlank(value: String, fieldLabel: String): ValidationResult {
        return if (value.trim().isEmpty()) {
            ValidationResult.Invalid("$fieldLabel is required.")
        } else {
            ValidationResult.Valid
        }
    }

    private fun ipv4ToLong(ip: String): Long {
        val parts = ip.split('.').map { it.toLong() }
        return (parts[0] shl 24) or (parts[1] shl 16) or (parts[2] shl 8) or parts[3]
    }
}
