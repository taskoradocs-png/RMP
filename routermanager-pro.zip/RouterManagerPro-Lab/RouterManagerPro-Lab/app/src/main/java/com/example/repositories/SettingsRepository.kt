package com.example.repositories

import com.example.authentication.CredentialCipher
import com.example.core.AccentColorOption
import com.example.core.AppMode
import com.example.core.CornerStyleOption
import com.example.core.ThemePreference
import com.example.core.ThemeStyleOption
import com.example.database.AppPreferencesStore
import com.example.database.AppSecurityPreferences
import com.example.database.RouterProfileDao
import com.example.database.RouterProfileEntity
import com.example.models.RouterProfile
import com.example.router.RouterController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

class SettingsRepository(
    private val preferencesStore: AppPreferencesStore,
    private val profileDao: RouterProfileDao,
    private val credentialCipher: CredentialCipher,
    private val controller: RouterController
) {
    val preferencesFlow: Flow<AppSecurityPreferences> = preferencesStore.preferencesFlow
    val appMode: StateFlow<AppMode> = controller.appMode

    val savedProfilesFlow: Flow<List<RouterProfile>> = profileDao.observeProfiles().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun setAppMode(mode: AppMode) {
        preferencesStore.setAppMode(mode)
        controller.setAppMode(mode)
    }

    suspend fun syncModeFromPreferences(mode: AppMode) {
        controller.setAppMode(mode)
    }

    suspend fun setThemePreference(theme: ThemePreference) {
        preferencesStore.setThemePreference(theme)
    }

    suspend fun setAccentColor(accent: AccentColorOption) {
        preferencesStore.setAccentColor(accent)
    }

    suspend fun setThemeStyle(style: ThemeStyleOption) {
        preferencesStore.setThemeStyle(style)
    }

    suspend fun setCornerStyle(corner: CornerStyleOption) {
        preferencesStore.setCornerStyle(corner)
    }

    suspend fun setAppPinLockEnabled(enabled: Boolean) {
        preferencesStore.setAppPinLockEnabled(enabled)
    }

    suspend fun setConfirmDestructiveActions(enabled: Boolean) {
        preferencesStore.setConfirmDestructiveActions(enabled)
    }

    suspend fun setAutoClearSessionOnBackground(enabled: Boolean) {
        preferencesStore.setAutoClearSessionOnBackground(enabled)
    }

    suspend fun saveRouterProfile(
        profile: RouterProfile,
        plainPasswordToStore: String?
    ) {
        val existing = profileDao.getProfileById(profile.id)
        val encrypted = when {
            !plainPasswordToStore.isNullOrEmpty() -> withContext(Dispatchers.Default) {
                credentialCipher.encrypt(plainPasswordToStore)
            }
            profile.hasStoredPassword -> existing?.encryptedPassword
            else -> null
        }
        profileDao.upsertProfile(
            RouterProfileEntity(
                id = profile.id,
                displayName = profile.displayName,
                manufacturer = profile.manufacturer,
                model = profile.model,
                hostIp = profile.hostIp,
                port = profile.port,
                useHttps = profile.useHttps,
                username = profile.username,
                encryptedPassword = encrypted,
                firmwareVersion = profile.firmwareVersion,
                lastConnectedEpochMs = profile.lastConnectedEpochMs
            )
        )
    }

    suspend fun loadDecryptedPassword(profileId: String): String? {
        val entity = profileDao.getProfileById(profileId) ?: return null
        val encrypted = entity.encryptedPassword ?: return null
        return withContext(Dispatchers.Default) {
            credentialCipher.decrypt(encrypted)
        }
    }

    suspend fun clearStoredPassword(profileId: String) {
        profileDao.clearCredentialsForProfile(profileId)
    }

    suspend fun deleteProfile(profileId: String) {
        profileDao.deleteProfileById(profileId)
    }

    private fun RouterProfileEntity.toDomain(): RouterProfile = RouterProfile(
        id = id,
        displayName = displayName,
        manufacturer = manufacturer,
        model = model,
        hostIp = hostIp,
        port = port,
        useHttps = useHttps,
        username = username,
        hasStoredPassword = !encryptedPassword.isNullOrBlank(),
        firmwareVersion = firmwareVersion,
        lastConnectedEpochMs = lastConnectedEpochMs
    )
}
