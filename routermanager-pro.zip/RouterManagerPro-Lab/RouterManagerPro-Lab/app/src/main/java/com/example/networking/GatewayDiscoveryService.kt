package com.example.networking

import com.example.models.DiscoveredRouter

data class DiscoveryScanResult(
    val routers: List<DiscoveredRouter>,
    val localGatewayIp: String?,
    val statusMessage: String,
    val localIpv4Address: String? = null,
    val isWifiActive: Boolean = false,
    val isEthernetActive: Boolean = false,
    val interfaceName: String? = null,
    val gatewayReachable: Boolean = false
)

interface GatewayDiscoveryService {
    suspend fun inspectLocalNetwork(): DiscoveryScanResult
}
