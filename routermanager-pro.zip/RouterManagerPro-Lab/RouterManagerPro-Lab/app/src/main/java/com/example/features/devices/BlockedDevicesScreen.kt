package com.example.features.devices

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.UiState
import com.example.designsystem.AdminCard
import com.example.designsystem.ConfirmDestructiveDialog
import com.example.designsystem.InfoBanner
import com.example.designsystem.MonoValueStyle
import com.example.designsystem.PillTone
import com.example.designsystem.StatusPill
import com.example.models.ConnectedDevice

@Composable
fun BlockedDevicesScreen(
    viewModel: DevicesViewModel,
    onBack: () -> Unit,
    onOpenDeviceDetail: (String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()
    var pendingUnblockDevice by remember { mutableStateOf<ConnectedDevice?>(null) }

    pendingUnblockDevice?.let { device ->
        ConfirmDestructiveDialog(
            title = "Unblock ${device.name}?",
            message = "Restore Wi-Fi and LAN connectivity for MAC ${device.macAddress}?",
            confirmLabel = "Unblock",
            isCritical = false,
            onConfirm = {
                pendingUnblockDevice = null
                viewModel.unblockDevice(device.macAddress)
            },
            onDismiss = { pendingUnblockDevice = null }
        )
    }

    val blockedDevices = (uiState as? UiState.Ready)?.data?.devices?.filter { it.isBlocked }.orEmpty()

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("blocked_devices_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("blocked_devices_back")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("Blocked Devices", style = MaterialTheme.typography.headlineMedium)
                        Text(
                            text = "${blockedDevices.size} MAC rules active",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            if (!actionMessage.isNullOrBlank()) {
                item { InfoBanner(message = actionMessage!!) }
            }

            if (blockedDevices.isEmpty()) {
                item {
                    AdminCard {
                        Text("No Blocked Clients", style = MaterialTheme.typography.titleMedium)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = "Devices blocked from the client detail view will appear here for management.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(blockedDevices, key = { it.macAddress }) { device ->
                    AdminCard(
                        onClick = { onOpenDeviceDetail(device.macAddress) },
                        modifier = Modifier.testTag("blocked_card_${device.macAddress}")
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(device.name, style = MaterialTheme.typography.titleMedium)
                                Text(device.macAddress, style = MonoValueStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = "${device.manufacturer} · ${device.lastSeenLabel}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            StatusPill(label = "Blocked", tone = PillTone.CRITICAL)
                        }
                        Spacer(Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = { pendingUnblockDevice = device },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                                .testTag("unblock_button_${device.macAddress}")
                        ) {
                            Text("Unblock Device")
                        }
                    }
                }
            }
        }
    }
}
