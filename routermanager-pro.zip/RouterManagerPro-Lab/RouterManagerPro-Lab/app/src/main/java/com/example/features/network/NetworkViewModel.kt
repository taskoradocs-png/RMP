package com.example.features.network

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.AppMode
import com.example.core.RouterResult
import com.example.core.UiState
import com.example.core.Validators
import com.example.models.DhcpConfig
import com.example.models.DiagnosticResult
import com.example.models.DnsConfig
import com.example.models.DnsHostEntry
import com.example.models.DnsMode
import com.example.models.EthernetPortInfo
import com.example.models.FirewallConfig
import com.example.models.InterfaceStat
import com.example.models.LanConfig
import com.example.models.NetworkSettings
import com.example.models.OpticalInfo
import com.example.models.ParentalControlTemplate
import com.example.models.PortForwardRule
import com.example.models.ProtocolType
import com.example.models.RouterFeature
import com.example.models.RouterInfo
import com.example.models.SpeedTestResult
import com.example.models.TrafficSnapshot
import com.example.models.VoipLineInfo
import com.example.models.WanConnectionProfile
import com.example.models.WanConnectionType
import com.example.repositories.NetworkRepository
import com.example.repositories.RouterRepository
import com.example.repositories.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.util.UUID

enum class NetworkSectionTab(val label: String) {
    INTERFACES("WAN & LAN"),
    SERVICES("DHCP & DNS"),
    SECURITY("Ports & Firewall"),
    DIAGNOSTICS("Diagnostics")
}

data class NetworkScreenContent(
    val settings: NetworkSettings,
    val supportsLanConfig: Boolean,
    val supportsDhcpConfig: Boolean,
    val supportsDnsConfig: Boolean,
    val supportsPortForwarding: Boolean,
    val supportsFirewall: Boolean,
    val supportsUpnp: Boolean,
    val supportsDiagnostics: Boolean,
    val supportsMultiWan: Boolean,
    val supportsOpticalInfo: Boolean,
    val supportsEthernetPorts: Boolean,
    val supportsInterfaceStats: Boolean,
    val supportsVoip: Boolean,
    val supportsParentalControl: Boolean,
    val supportsSpeedTest: Boolean
)

data class LanDraft(
    val routerIp: String,
    val subnetMask: String,
    val hostname: String,
    val igmpSnoopingEnabled: Boolean,
    val ipError: String? = null,
    val maskError: String? = null
)

data class DhcpDraft(
    val enabled: Boolean,
    val startIp: String,
    val endIp: String,
    val leaseTimeMinutes: String,
    val rangeError: String? = null,
    val leaseError: String? = null
)

data class DnsDraft(
    val mode: DnsMode,
    val primaryDns: String,
    val secondaryDns: String,
    val dnsOverHttpsEnabled: Boolean,
    val primaryError: String? = null,
    val secondaryError: String? = null
)

class NetworkViewModel(
    private val networkRepository: NetworkRepository,
    private val routerRepository: RouterRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<UiState<NetworkScreenContent>>(UiState.Loading)
    val uiState: StateFlow<UiState<NetworkScreenContent>> = _uiState.asStateFlow()

    private val _selectedTab = MutableStateFlow(NetworkSectionTab.INTERFACES)
    val selectedTab: StateFlow<NetworkSectionTab> = _selectedTab.asStateFlow()

    private val _lanDraft = MutableStateFlow<LanDraft?>(null)
    val lanDraft: StateFlow<LanDraft?> = _lanDraft.asStateFlow()

    private val _dhcpDraft = MutableStateFlow<DhcpDraft?>(null)
    val dhcpDraft: StateFlow<DhcpDraft?> = _dhcpDraft.asStateFlow()

    private val _dnsDraft = MutableStateFlow<DnsDraft?>(null)
    val dnsDraft: StateFlow<DnsDraft?> = _dnsDraft.asStateFlow()

    private val _diagnostics = MutableStateFlow<List<DiagnosticResult>>(emptyList())
    val diagnostics: StateFlow<List<DiagnosticResult>> = _diagnostics.asStateFlow()

    private val _isRunningDiagnostics = MutableStateFlow(false)
    val isRunningDiagnostics: StateFlow<Boolean> = _isRunningDiagnostics.asStateFlow()

    private val _opticalInfo = MutableStateFlow<RouterResult<OpticalInfo>?>(null)
    val opticalInfo: StateFlow<RouterResult<OpticalInfo>?> = _opticalInfo.asStateFlow()

    private val _ethernetPorts = MutableStateFlow<RouterResult<List<EthernetPortInfo>>?>(null)
    val ethernetPorts: StateFlow<RouterResult<List<EthernetPortInfo>>?> = _ethernetPorts.asStateFlow()

    private val _interfaceStats = MutableStateFlow<RouterResult<List<InterfaceStat>>?>(null)
    val interfaceStats: StateFlow<RouterResult<List<InterfaceStat>>?> = _interfaceStats.asStateFlow()

    private val _voipLines = MutableStateFlow<RouterResult<List<VoipLineInfo>>?>(null)
    val voipLines: StateFlow<RouterResult<List<VoipLineInfo>>?> = _voipLines.asStateFlow()

    private val _parentalTemplates = MutableStateFlow<RouterResult<List<ParentalControlTemplate>>?>(null)
    val parentalTemplates: StateFlow<RouterResult<List<ParentalControlTemplate>>?> = _parentalTemplates.asStateFlow()

    private val _routerInfo = MutableStateFlow<RouterInfo?>(null)
    val routerInfo: StateFlow<RouterInfo?> = _routerInfo.asStateFlow()

    private val _trafficSnapshot = MutableStateFlow<TrafficSnapshot?>(null)
    val trafficSnapshot: StateFlow<TrafficSnapshot?> = _trafficSnapshot.asStateFlow()

    private val _speedTestResult = MutableStateFlow<RouterResult<SpeedTestResult>?>(null)
    val speedTestResult: StateFlow<RouterResult<SpeedTestResult>?> = _speedTestResult.asStateFlow()

    private val _isRunningSpeedTest = MutableStateFlow(false)
    val isRunningSpeedTest: StateFlow<Boolean> = _isRunningSpeedTest.asStateFlow()

    private val _feedback = MutableStateFlow<String?>(null)
    val feedback: StateFlow<String?> = _feedback.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                networkRepository.appMode,
                networkRepository.revision
            ) { mode, rev -> mode to rev }
                .collect { (mode, _) ->
                    loadNetworkSettings(mode)
                }
        }
    }

    fun selectTab(tab: NetworkSectionTab) {
        _selectedTab.value = tab
    }

    fun switchToDemoMode() {
        viewModelScope.launch {
            settingsRepository.setAppMode(AppMode.DEMO)
        }
    }

    fun updateLanDraft(transform: (LanDraft) -> LanDraft) {
        _lanDraft.value = _lanDraft.value?.let(transform)
    }

    fun updateDhcpDraft(transform: (DhcpDraft) -> DhcpDraft) {
        _dhcpDraft.value = _dhcpDraft.value?.let(transform)
    }

    fun updateDnsDraft(transform: (DnsDraft) -> DnsDraft) {
        _dnsDraft.value = _dnsDraft.value?.let(transform)
    }

    fun validateLanDraft(): Boolean {
        val draft = _lanDraft.value ?: return false
        val ipErr = Validators.validateIpv4(draft.routerIp, "Gateway IP").errorOrNull
        val maskErr = Validators.validateSubnetMask(draft.subnetMask).errorOrNull
        updateLanDraft { it.copy(ipError = ipErr, maskError = maskErr) }
        return ipErr == null && maskErr == null
    }

    fun commitLanSave() {
        val draft = _lanDraft.value ?: return
        viewModelScope.launch {
            val updated = LanConfig(
                routerIp = draft.routerIp.trim(),
                subnetMask = draft.subnetMask.trim(),
                hostname = draft.hostname.trim(),
                igmpSnoopingEnabled = draft.igmpSnoopingEnabled
            )
            handleUpdateResult(networkRepository.updateLanConfig(updated), "LAN configuration saved.")
        }
    }

    fun validateDhcpDraft(): Boolean {
        val draft = _dhcpDraft.value ?: return false
        val routerIp = _lanDraft.value?.routerIp ?: ""
        val rangeErr = Validators.validateDhcpRange(draft.startIp, draft.endIp, routerIp).errorOrNull
        val leaseErr = Validators.validateLeaseTimeMinutes(draft.leaseTimeMinutes).errorOrNull
        updateDhcpDraft { it.copy(rangeError = rangeErr, leaseError = leaseErr) }
        return rangeErr == null && leaseErr == null
    }

    fun commitDhcpSave() {
        val ready = (uiState.value as? UiState.Ready)?.data ?: return
        val draft = _dhcpDraft.value ?: return
        viewModelScope.launch {
            val updated = ready.settings.dhcp.copy(
                enabled = draft.enabled,
                startIp = draft.startIp.trim(),
                endIp = draft.endIp.trim(),
                leaseTimeMinutes = draft.leaseTimeMinutes.trim().toIntOrNull() ?: 1440
            )
            handleUpdateResult(networkRepository.updateDhcpConfig(updated), "DHCP server configuration saved.")
        }
    }

    fun validateDnsDraft(): Boolean {
        val draft = _dnsDraft.value ?: return false
        if (draft.mode == DnsMode.ISP_AUTO) {
            updateDnsDraft { it.copy(primaryError = null, secondaryError = null) }
            return true
        }
        val pErr = Validators.validateIpv4(draft.primaryDns, "Primary DNS").errorOrNull
        val sErr = if (draft.secondaryDns.isBlank()) null else Validators.validateIpv4(draft.secondaryDns, "Secondary DNS").errorOrNull
        updateDnsDraft { it.copy(primaryError = pErr, secondaryError = sErr) }
        return pErr == null && sErr == null
    }

    fun commitDnsSave() {
        val draft = _dnsDraft.value ?: return
        val existingHosts = (uiState.value as? UiState.Ready)?.data?.settings?.dns?.hostEntries.orEmpty()
        viewModelScope.launch {
            val updated = DnsConfig(
                mode = draft.mode,
                primaryDns = draft.primaryDns.trim(),
                secondaryDns = draft.secondaryDns.trim(),
                dnsOverHttpsEnabled = draft.dnsOverHttpsEnabled,
                hostEntries = existingHosts
            )
            handleUpdateResult(networkRepository.updateDnsConfig(updated), "DNS settings saved.")
        }
    }

    fun addDnsHostEntry(hostname: String, ipAddress: String): String? {
        if (hostname.isBlank()) return "Hostname is required."
        Validators.validateIpv4(ipAddress, "Target IP").errorOrNull?.let { return it }
        val currentDns = (uiState.value as? UiState.Ready)?.data?.settings?.dns ?: return "DNS config unavailable."
        val updatedHosts = currentDns.hostEntries + DnsHostEntry(
            id = "host-${UUID.randomUUID().toString().take(6)}",
            hostname = hostname.trim(),
            ipAddress = ipAddress.trim()
        )
        viewModelScope.launch {
            handleUpdateResult(networkRepository.updateDnsConfig(currentDns.copy(hostEntries = updatedHosts)), "Host entry added.")
        }
        return null
    }

    fun deleteDnsHostEntry(entryId: String) {
        val currentDns = (uiState.value as? UiState.Ready)?.data?.settings?.dns ?: return
        val updatedHosts = currentDns.hostEntries.filterNot { it.id == entryId }
        viewModelScope.launch {
            handleUpdateResult(networkRepository.updateDnsConfig(currentDns.copy(hostEntries = updatedHosts)), "Host entry removed.")
        }
    }

    fun addPortForwardRule(
        name: String,
        externalPortText: String,
        internalPortText: String,
        internalIp: String,
        protocol: ProtocolType
    ): String? {
        if (name.isBlank()) return "Rule name is required."
        Validators.validatePort(externalPortText, "External port").errorOrNull?.let { return it }
        Validators.validatePort(internalPortText, "Internal port").errorOrNull?.let { return it }
        Validators.validateIpv4(internalIp, "Internal IP").errorOrNull?.let { return it }

        val rule = PortForwardRule(
            id = "pf-${UUID.randomUUID().toString().take(6)}",
            name = name.trim(),
            externalPort = externalPortText.trim().toInt(),
            internalPort = internalPortText.trim().toInt(),
            internalIp = internalIp.trim(),
            protocol = protocol,
            enabled = true
        )
        viewModelScope.launch {
            handleUpdateResult(networkRepository.savePortForwardRule(rule), "Port forwarding rule added.")
        }
        return null
    }

    fun togglePortForwardRule(rule: PortForwardRule) {
        viewModelScope.launch {
            handleUpdateResult(
                networkRepository.savePortForwardRule(rule.copy(enabled = !rule.enabled)),
                "Port rule updated."
            )
        }
    }

    fun deletePortForwardRule(ruleId: String) {
        viewModelScope.launch {
            handleUpdateResult(networkRepository.deletePortForwardRule(ruleId), "Port forwarding rule removed.")
        }
    }

    fun updateFirewall(firewallConfig: FirewallConfig) {
        viewModelScope.launch {
            handleUpdateResult(networkRepository.updateFirewallConfig(firewallConfig), "Firewall policy updated.")
        }
    }

    fun setUpnpEnabled(enabled: Boolean) {
        viewModelScope.launch {
            handleUpdateResult(networkRepository.setUpnpEnabled(enabled), "UPnP state updated.")
        }
    }

    fun saveWanConnection(
        name: String,
        serviceType: String,
        connectionType: WanConnectionType,
        vlanText: String
    ): String? {
        if (name.isBlank()) return "Connection profile name is required."
        val vlanId = if (vlanText.isBlank()) null else vlanText.toIntOrNull()?.takeIf { it in 1..4094 }
            ?: return "VLAN ID must be 1–4094."
        val profile = WanConnectionProfile(
            id = "wan-${UUID.randomUUID().toString().take(6)}",
            name = name.trim(),
            serviceType = serviceType.ifBlank { "INTERNET" },
            connectionType = connectionType,
            vlanId = vlanId,
            isDefaultRoute = false,
            statusLabel = "Ready",
            ipAddress = if (connectionType == WanConnectionType.BRIDGE) "Bridge L2" else "Pending DHCP",
            enabled = true
        )
        viewModelScope.launch {
            handleUpdateResult(networkRepository.saveWanConnection(profile), "WAN connection profile saved.")
        }
        return null
    }

    fun toggleWanConnection(profile: WanConnectionProfile) {
        viewModelScope.launch {
            handleUpdateResult(
                networkRepository.saveWanConnection(profile.copy(enabled = !profile.enabled)),
                "WAN connection state updated."
            )
        }
    }

    fun deleteWanConnection(profileId: String) {
        viewModelScope.launch {
            handleUpdateResult(networkRepository.deleteWanConnection(profileId), "WAN connection deleted.")
        }
    }

    fun saveParentalTemplate(name: String, scheduleWindow: String, keywordsCountText: String): String? {
        if (name.isBlank()) return "Template name is required."
        if (scheduleWindow.isBlank()) return "Schedule window is required."
        val kwCount = keywordsCountText.toIntOrNull() ?: 8
        val template = ParentalControlTemplate(
            id = "pc-${UUID.randomUUID().toString().take(6)}",
            name = name.trim(),
            scheduleWindow = scheduleWindow.trim(),
            blockedKeywordsCount = kwCount,
            assignedDeviceMacs = emptyList(),
            enabled = true
        )
        viewModelScope.launch {
            when (val res = networkRepository.saveParentalTemplate(template)) {
                is RouterResult.Success -> {
                    _parentalTemplates.value = res
                    _feedback.value = "Parental control template saved."
                }
                is RouterResult.Unsupported -> _feedback.value = res.reason
                is RouterResult.NotConnected -> _feedback.value = res.reason
                is RouterResult.AuthRequired -> _feedback.value = res.reason
                is RouterResult.ValidationError -> _feedback.value = res.message
                is RouterResult.Failure -> _feedback.value = res.message
            }
        }
        return null
    }

    fun toggleParentalTemplate(template: ParentalControlTemplate) {
        viewModelScope.launch {
            when (val res = networkRepository.saveParentalTemplate(template.copy(enabled = !template.enabled))) {
                is RouterResult.Success -> _parentalTemplates.value = res
                is RouterResult.Unsupported -> _feedback.value = res.reason
                is RouterResult.NotConnected -> _feedback.value = res.reason
                is RouterResult.AuthRequired -> _feedback.value = res.reason
                is RouterResult.ValidationError -> _feedback.value = res.message
                is RouterResult.Failure -> _feedback.value = res.message
            }
        }
    }

    fun deleteParentalTemplate(templateId: String) {
        viewModelScope.launch {
            when (val res = networkRepository.deleteParentalTemplate(templateId)) {
                is RouterResult.Success -> _parentalTemplates.value = res
                is RouterResult.Unsupported -> _feedback.value = res.reason
                is RouterResult.NotConnected -> _feedback.value = res.reason
                is RouterResult.AuthRequired -> _feedback.value = res.reason
                is RouterResult.ValidationError -> _feedback.value = res.message
                is RouterResult.Failure -> _feedback.value = res.message
            }
        }
    }

    fun runSpeedTest() {
        viewModelScope.launch {
            _isRunningSpeedTest.value = true
            _speedTestResult.value = networkRepository.runSpeedTest()
            _isRunningSpeedTest.value = false
        }
    }

    fun refreshDiagnosticsModules() {
        viewModelScope.launch {
            loadDiagnosticsModules()
        }
    }

    fun runDiagnostics() {
        viewModelScope.launch {
            _isRunningDiagnostics.value = true
            when (val res = networkRepository.runDiagnostics()) {
                is RouterResult.Success -> {
                    _diagnostics.value = res.data
                    _feedback.value = if (res.isDemoData) {
                        "Completed simulated diagnostics in Demo Sandbox."
                    } else {
                        "Diagnostics completed."
                    }
                }
                is RouterResult.Unsupported -> _feedback.value = res.reason
                is RouterResult.NotConnected -> _feedback.value = res.reason
                is RouterResult.AuthRequired -> _feedback.value = res.reason
                is RouterResult.ValidationError -> _feedback.value = res.message
                is RouterResult.Failure -> _feedback.value = res.message
            }
            _isRunningDiagnostics.value = false
        }
    }

    private fun handleUpdateResult(result: RouterResult<NetworkSettings>, successLabel: String) {
        when (result) {
            is RouterResult.Success -> {
                _feedback.value = if (result.isDemoData) "$successLabel (Demo Sandbox)" else successLabel
            }
            is RouterResult.Unsupported -> _feedback.value = result.reason
            is RouterResult.NotConnected -> _feedback.value = result.reason
            is RouterResult.AuthRequired -> _feedback.value = result.reason
            is RouterResult.ValidationError -> _feedback.value = result.message
            is RouterResult.Failure -> _feedback.value = result.message
        }
    }

    private suspend fun loadDiagnosticsModules() {
        _opticalInfo.value = networkRepository.getOpticalInfo()
        _ethernetPorts.value = networkRepository.getEthernetPorts()
        _interfaceStats.value = networkRepository.getInterfaceStats()
        _voipLines.value = networkRepository.getVoipStatus()
        _parentalTemplates.value = networkRepository.getParentalTemplates()
        _routerInfo.value = (routerRepository.getRouterInfo() as? RouterResult.Success)?.data
        _trafficSnapshot.value = (routerRepository.getTrafficSnapshot() as? RouterResult.Success)?.data
    }

    private suspend fun loadNetworkSettings(mode: AppMode) {
        loadDiagnosticsModules()
        when (val result = networkRepository.getNetworkSettings()) {
            is RouterResult.NotConnected -> {
                _uiState.value = UiState.Disconnected(
                    title = "No Live Router Connected",
                    message = "Connect and authenticate with a supported router to inspect WAN status, DHCP pools, firewall policies, and diagnostics."
                )
            }
            is RouterResult.AuthRequired -> {
                _uiState.value = UiState.Disconnected(
                    title = "Authentication Required",
                    message = result.reason
                )
            }
            is RouterResult.Unsupported -> _uiState.value = UiState.Error(result.reason)
            is RouterResult.ValidationError -> _uiState.value = UiState.Error(result.message)
            is RouterResult.Failure -> _uiState.value = UiState.Error(result.message)
            is RouterResult.Success -> {
                val s = result.data
                val caps = networkRepository.getCapabilities()
                _lanDraft.value = LanDraft(
                    routerIp = s.lan.routerIp,
                    subnetMask = s.lan.subnetMask,
                    hostname = s.lan.hostname,
                    igmpSnoopingEnabled = s.lan.igmpSnoopingEnabled
                )
                _dhcpDraft.value = DhcpDraft(
                    enabled = s.dhcp.enabled,
                    startIp = s.dhcp.startIp,
                    endIp = s.dhcp.endIp,
                    leaseTimeMinutes = s.dhcp.leaseTimeMinutes.toString()
                )
                _dnsDraft.value = DnsDraft(
                    mode = s.dns.mode,
                    primaryDns = s.dns.primaryDns,
                    secondaryDns = s.dns.secondaryDns,
                    dnsOverHttpsEnabled = s.dns.dnsOverHttpsEnabled
                )
                _uiState.value = UiState.Ready(
                    data = NetworkScreenContent(
                        settings = s,
                        supportsLanConfig = caps?.supports(RouterFeature.LAN_CONFIG) ?: false,
                        supportsDhcpConfig = caps?.supports(RouterFeature.DHCP_CONFIG) ?: false,
                        supportsDnsConfig = caps?.supports(RouterFeature.DNS_CONFIG) ?: false,
                        supportsPortForwarding = caps?.supports(RouterFeature.PORT_FORWARDING) ?: false,
                        supportsFirewall = caps?.supports(RouterFeature.FIREWALL_CONFIG) ?: false,
                        supportsUpnp = caps?.supports(RouterFeature.UPNP_CONFIG) ?: false,
                        supportsDiagnostics = caps?.supports(RouterFeature.NETWORK_DIAGNOSTICS) ?: false,
                        supportsMultiWan = caps?.supports(RouterFeature.MULTI_WAN) ?: false,
                        supportsOpticalInfo = caps?.supports(RouterFeature.OPTICAL_INFO) ?: false,
                        supportsEthernetPorts = caps?.supports(RouterFeature.ETHERNET_PORT_STATUS) ?: false,
                        supportsInterfaceStats = caps?.supports(RouterFeature.INTERFACE_STATS) ?: false,
                        supportsVoip = caps?.supports(RouterFeature.VOIP_STATUS) ?: false,
                        supportsParentalControl = caps?.supports(RouterFeature.PARENTAL_CONTROL) ?: false,
                        supportsSpeedTest = caps?.supports(RouterFeature.SPEED_TEST) ?: false
                    ),
                    isDemoMode = mode == AppMode.DEMO
                )
            }
        }
    }
}
