package com.example.models

enum class WifiBand(val label: String) {
    BAND_2_4_GHZ("2.4 GHz"),
    BAND_5_GHZ("5 GHz")
}

enum class WifiSecurityMode(val label: String, val requiresPassphrase: Boolean) {
    OPEN("Open (Unencrypted)", false),
    WPA2_PSK("WPA2-Personal (AES)", true),
    WPA2_WPA3_TRANSITION("WPA2 / WPA3 Transition", true),
    WPA3_SAE("WPA3-Personal (SAE)", true)
}

data class WifiBandConfig(
    val band: WifiBand,
    val enabled: Boolean,
    val ssid: String,
    val securityMode: WifiSecurityMode,
    val password: String,
    val hiddenSsid: Boolean,
    val channel: String,
    val availableChannels: List<String>,
    val bandwidthMhz: String,
    val availableBandwidthsMhz: List<String>,
    val txPowerPercent: Int,
    val connectedClientsCount: Int
) {
    override fun toString(): String {
        return "WifiBandConfig(band=$band, enabled=$enabled, ssid='$ssid', securityMode=$securityMode, password='****')"
    }
}

data class GuestNetworkConfig(
    val enabled: Boolean,
    val ssid: String,
    val securityMode: WifiSecurityMode,
    val password: String,
    val isolateClients: Boolean,
    val bandwidthLimitMbps: Int?,
    val bandLabel: String
) {
    override fun toString(): String {
        return "GuestNetworkConfig(enabled=$enabled, ssid='$ssid', password='****')"
    }
}

data class WifiConfig(
    val masterWifiEnabled: Boolean,
    val band24: WifiBandConfig,
    val band5: WifiBandConfig?,
    val guestNetwork: GuestNetworkConfig?
)
