package com.example.adapters.live

import com.example.authentication.RouterSessionManager
import com.example.core.RouterResult
import com.example.networking.RouterEndpointClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.ConnectException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.concurrent.atomic.AtomicInteger
import javax.net.ssl.SSLException

enum class OpenWrtTransportProtocol(val label: String) {
    UBUS_JSON_RPC("ubus JSON-RPC (/ubus)"),
    LUCI_MOD_RPC("LuCI JSON-RPC (/cgi-bin/luci/rpc)")
}

data class OpenWrtConnectionTarget(
    val hostIp: String,
    val port: Int,
    val useHttps: Boolean,
    val allowSelfSignedTls: Boolean = false
) {
    val baseUrl: String
        get() = "${if (useHttps) "https" else "http"}://$hostIp:$port"
}

data class OpenWrtLoginOutcome(
    val protocol: OpenWrtTransportProtocol,
    val sessionToken: String,
    val csrfToken: String?,
    val timeoutSeconds: Long,
    val cookieCount: Int
)

/**
 * Real HTTP/HTTPS JSON-RPC client for OpenWrt (/ubus primary, /cgi-bin/luci/rpc fallback).
 * Handles cookies, CSRF tokens, session expiration, and exhaustive network/HTTP/RPC error mapping.
 */
class OpenWrtRpcClient(
    private val sessionManager: RouterSessionManager,
    private val clientBuilder: (OpenWrtConnectionTarget) -> OkHttpClient = { target ->
        RouterEndpointClient.createClient(
            cookieJar = sessionManager.cookieJar,
            allowPrivateLanSelfSignedTls = target.allowSelfSignedTls,
            targetHost = target.hostIp
        )
    }
) {
    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
        encodeDefaults = true
    }
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val requestId = AtomicInteger(1)

    @Volatile
    private var cachedTarget: OpenWrtConnectionTarget? = null

    @Volatile
    private var cachedClient: OkHttpClient? = null

    private fun clientFor(target: OpenWrtConnectionTarget): OkHttpClient {
        val current = cachedClient
        if (current != null && cachedTarget == target) return current
        val created = clientBuilder(target)
        cachedTarget = target
        cachedClient = created
        return created
    }

    suspend fun login(
        target: OpenWrtConnectionTarget,
        username: String,
        password: String
    ): RouterResult<OpenWrtLoginOutcome> = withContext(Dispatchers.IO) {
        val payload = buildJsonObject {
            put("jsonrpc", JsonPrimitive("2.0"))
            put("id", JsonPrimitive(requestId.getAndIncrement()))
            put("method", JsonPrimitive("call"))
            put(
                "params",
                buildJsonArray {
                    add(JsonPrimitive(ZERO_SESSION_ID))
                    add(JsonPrimitive("session"))
                    add(JsonPrimitive("login"))
                    add(
                        buildJsonObject {
                            put("username", JsonPrimitive(username))
                            put("password", JsonPrimitive(password))
                            put("timeout", JsonPrimitive(300))
                        }
                    )
                }
            )
        }.toString()

        val httpResult = executePost(target, "/ubus", payload)
        when (httpResult) {
            is HttpOutcome.TransportError -> return@withContext httpResult.failure
            is HttpOutcome.HttpStatus -> {
                if (httpResult.code == 404 || httpResult.code == 405) {
                    // Fallback to classic LuCI RPC (/cgi-bin/luci/rpc/auth) for older OpenWrt versions without uhttpd-mod-ubus
                    return@withContext loginViaLegacyLuciRpc(target, username, password)
                }
                if (httpResult.code == 401 || httpResult.code == 403) {
                    return@withContext RouterResult.Failure(
                        "Authentication failed at ${target.baseUrl}/ubus (HTTP ${httpResult.code}). Verify administrator username and password."
                    )
                }
                if (httpResult.code !in 200..299) {
                    return@withContext RouterResult.Failure(
                        "OpenWrt /ubus login returned HTTP ${httpResult.code}."
                    )
                }

                val rootObj = parseJsonObject(httpResult.body)
                    ?: return@withContext RouterResult.Failure(
                        "Gateway at ${target.baseUrl}/ubus did not return valid JSON-RPC."
                    )

                val rpcError = rootObj["error"] as? JsonObject
                if (rpcError != null) {
                    val code = rpcError["code"]?.jsonPrimitive?.intOrNull
                    val msg = rpcError["message"]?.jsonPrimitive?.content ?: "RPC error"
                    return@withContext if (code == -32002) {
                        RouterResult.Failure("Authentication rejected by OpenWrt ubus: $msg")
                    } else {
                        RouterResult.Failure("OpenWrt ubus login error ($code): $msg")
                    }
                }

                val resultArr = rootObj["result"] as? JsonArray
                    ?: return@withContext RouterResult.Failure("Unexpected OpenWrt /ubus login response format.")
                val ubusCode = resultArr.getOrNull(0)?.jsonPrimitive?.intOrNull ?: -1
                if (ubusCode != 0) {
                    val reason = if (ubusCode == UBUS_STATUS_PERMISSION_DENIED) {
                        "Invalid OpenWrt username or password."
                    } else {
                        "OpenWrt session.login failed with ubus status code $ubusCode."
                    }
                    return@withContext RouterResult.Failure(reason)
                }

                val dataObj = resultArr.getOrNull(1) as? JsonObject
                    ?: return@withContext RouterResult.Failure("OpenWrt login response omitted session data.")
                val sid = dataObj["ubus_rpc_session"]?.jsonPrimitive?.content.orEmpty()
                if (sid.isBlank()) {
                    return@withContext RouterResult.Failure("OpenWrt returned an empty ubus_rpc_session token.")
                }

                val timeoutSec = dataObj["timeout"]?.jsonPrimitive?.longOrNull
                    ?: dataObj["expires"]?.jsonPrimitive?.longOrNull
                    ?: 300L
                val csrf = httpResult.csrfHeader
                    ?: dataObj["csrf_token"]?.jsonPrimitive?.content
                    ?: dataObj["token"]?.jsonPrimitive?.content
                val cookieCount = sessionManager.getCookiesForHost(target.hostIp).size

                return@withContext RouterResult.Success(
                    OpenWrtLoginOutcome(
                        protocol = OpenWrtTransportProtocol.UBUS_JSON_RPC,
                        sessionToken = sid,
                        csrfToken = csrf,
                        timeoutSeconds = timeoutSec,
                        cookieCount = cookieCount
                    )
                )
            }
        }
    }

    private suspend fun loginViaLegacyLuciRpc(
        target: OpenWrtConnectionTarget,
        username: String,
        password: String
    ): RouterResult<OpenWrtLoginOutcome> {
        val payload = buildJsonObject {
            put("id", JsonPrimitive(requestId.getAndIncrement()))
            put("method", JsonPrimitive("login"))
            put(
                "params",
                buildJsonArray {
                    add(JsonPrimitive(username))
                    add(JsonPrimitive(password))
                }
            )
        }.toString()

        return when (val httpResult = executePost(target, "/cgi-bin/luci/rpc/auth", payload)) {
            is HttpOutcome.TransportError -> httpResult.failure
            is HttpOutcome.HttpStatus -> {
                if (httpResult.code == 404 || httpResult.code == 405) {
                    RouterResult.Unsupported(
                        featureName = "OpenWrt JSON-RPC API",
                        reason = "Gateway at ${target.baseUrl} exposes neither /ubus nor /cgi-bin/luci/rpc/auth."
                    )
                } else if (httpResult.code == 401 || httpResult.code == 403) {
                    RouterResult.Failure("Invalid credentials on LuCI RPC (HTTP ${httpResult.code}).")
                } else if (httpResult.code !in 200..299) {
                    RouterResult.Failure("LuCI RPC login returned HTTP ${httpResult.code}.")
                } else {
                    val root = parseJsonObject(httpResult.body)
                        ?: return RouterResult.Failure("LuCI RPC auth did not return valid JSON.")
                    val token = (root["result"] as? JsonPrimitive)?.content
                    if (token.isNullOrBlank() || root["result"] is JsonNull) {
                        RouterResult.Failure("Authentication failed: invalid LuCI username or password.")
                    } else {
                        val csrf = httpResult.csrfHeader ?: root["token"]?.jsonPrimitive?.content
                        RouterResult.Success(
                            OpenWrtLoginOutcome(
                                protocol = OpenWrtTransportProtocol.LUCI_MOD_RPC,
                                sessionToken = token,
                                csrfToken = csrf,
                                timeoutSeconds = 300L,
                                cookieCount = sessionManager.getCookiesForHost(target.hostIp).size
                            )
                        )
                    }
                }
            }
        }
    }

    suspend fun listUbusObjects(target: OpenWrtConnectionTarget): RouterResult<Set<String>> = withContext(Dispatchers.IO) {
        val sid = sessionManager.getRpcSessionToken()
            ?: return@withContext RouterResult.AuthRequired("No active OpenWrt RPC session token.")

        val payload = buildJsonObject {
            put("jsonrpc", JsonPrimitive("2.0"))
            put("id", JsonPrimitive(requestId.getAndIncrement()))
            put("method", JsonPrimitive("list"))
            put("params", buildJsonArray { add(JsonPrimitive("*")) })
        }.toString()

        when (val httpResult = executePost(target, "/ubus", payload, sidHeader = sid)) {
            is HttpOutcome.TransportError -> httpResult.failure
            is HttpOutcome.HttpStatus -> {
                if (httpResult.code == 401 || httpResult.code == 403) {
                    return@withContext RouterResult.AuthRequired("OpenWrt session unauthorized (HTTP ${httpResult.code}).")
                }
                if (httpResult.code !in 200..299) {
                    return@withContext RouterResult.Failure("HTTP ${httpResult.code} listing ubus objects.")
                }
                val root = parseJsonObject(httpResult.body)
                    ?: return@withContext RouterResult.Failure("Invalid JSON from ubus list.")
                val resultObj = root["result"] as? JsonObject
                if (resultObj != null) {
                    return@withContext RouterResult.Success(resultObj.keys.toSet())
                }
                // Fallback: some rpcd configs disable top-level list; probe key namespaces individually via session.access
                val probeNamespaces = listOf(
                    "system",
                    "uci",
                    "network.interface",
                    "network.device",
                    "iwinfo",
                    "luci-rpc",
                    "dhcp",
                    "network.ping"
                )
                val detected = mutableSetOf<String>()
                for (ns in probeNamespaces) {
                    val access = callUbus(
                        target = target,
                        ubusObject = "session",
                        procedure = "access",
                        args = buildJsonObject {
                            put("scope", JsonPrimitive("ubus"))
                            put("object", JsonPrimitive(ns))
                            put("function", JsonPrimitive("*"))
                        },
                        verifySessionOnDeny = false
                    )
                    if (access is RouterResult.Success) {
                        val allowed = access.data["access"]?.jsonPrimitive?.content == "true"
                        if (allowed) detected.add(ns)
                    }
                }
                RouterResult.Success(detected)
            }
        }
    }

    suspend fun callUbus(
        target: OpenWrtConnectionTarget,
        ubusObject: String,
        procedure: String,
        args: JsonObject = buildJsonObject {},
        verifySessionOnDeny: Boolean = true
    ): RouterResult<JsonObject> = withContext(Dispatchers.IO) {
        if (sessionManager.isExpired()) {
            return@withContext RouterResult.AuthRequired("OpenWrt session expired. Please authenticate again.")
        }
        val sid = sessionManager.getRpcSessionToken()
            ?: return@withContext RouterResult.NotConnected("No active OpenWrt session token.")

        val payload = buildJsonObject {
            put("jsonrpc", JsonPrimitive("2.0"))
            put("id", JsonPrimitive(requestId.getAndIncrement()))
            put("method", JsonPrimitive("call"))
            put(
                "params",
                buildJsonArray {
                    add(JsonPrimitive(sid))
                    add(JsonPrimitive(ubusObject))
                    add(JsonPrimitive(procedure))
                    add(args)
                }
            )
        }.toString()

        when (val httpResult = executePost(target, "/ubus", payload, sidHeader = sid)) {
            is HttpOutcome.TransportError -> httpResult.failure
            is HttpOutcome.HttpStatus -> {
                if (httpResult.code == 401 || httpResult.code == 403) {
                    return@withContext RouterResult.AuthRequired("OpenWrt session rejected (HTTP ${httpResult.code}).")
                }
                if (httpResult.code == 404) {
                    return@withContext RouterResult.Unsupported(
                        featureName = "$ubusObject.$procedure",
                        reason = "OpenWrt /ubus endpoint returned HTTP 404."
                    )
                }
                if (httpResult.code !in 200..299) {
                    return@withContext RouterResult.Failure(
                        "OpenWrt HTTP ${httpResult.code} executing $ubusObject.$procedure."
                    )
                }

                httpResult.csrfHeader?.let { newCsrf ->
                    sessionManager.updateTokens(csrfToken = newCsrf)
                }

                val root = parseJsonObject(httpResult.body)
                    ?: return@withContext RouterResult.Failure(
                        "Malformed JSON-RPC response from $ubusObject.$procedure."
                    )

                val rpcError = root["error"] as? JsonObject
                if (rpcError != null) {
                    val code = rpcError["code"]?.jsonPrimitive?.intOrNull ?: -1
                    val message = rpcError["message"]?.jsonPrimitive?.content ?: "RPC error"
                    return@withContext mapRpcError(
                        target = target,
                        ubusObject = ubusObject,
                        procedure = procedure,
                        errorCode = code,
                        errorMessage = message,
                        verifySessionOnDeny = verifySessionOnDeny
                    )
                }

                val resultArray = root["result"] as? JsonArray
                    ?: return@withContext RouterResult.Failure(
                        "OpenWrt response for $ubusObject.$procedure lacked result array."
                    )
                val status = resultArray.getOrNull(0)?.jsonPrimitive?.intOrNull ?: -1
                if (status != 0) {
                    return@withContext mapUbusStatusCode(
                        target = target,
                        ubusObject = ubusObject,
                        procedure = procedure,
                        statusCode = status,
                        verifySessionOnDeny = verifySessionOnDeny
                    )
                }

                val payloadObj = (resultArray.getOrNull(1) as? JsonObject) ?: buildJsonObject {}
                RouterResult.Success(payloadObj)
            }
        }
    }

    suspend fun callLegacyLuciRpc(
        target: OpenWrtConnectionTarget,
        module: String,
        method: String,
        params: JsonArray = buildJsonArray {}
    ): RouterResult<JsonElement> = withContext(Dispatchers.IO) {
        if (sessionManager.isExpired()) {
            return@withContext RouterResult.AuthRequired("LuCI RPC session expired. Please authenticate again.")
        }
        val token = sessionManager.getRpcSessionToken()
            ?: return@withContext RouterResult.NotConnected("No active LuCI RPC session.")

        val payload = buildJsonObject {
            put("id", JsonPrimitive(requestId.getAndIncrement()))
            put("method", JsonPrimitive(method))
            put("params", params)
        }.toString()

        when (val httpResult = executePost(target, "/cgi-bin/luci/rpc/$module?auth=$token", payload)) {
            is HttpOutcome.TransportError -> httpResult.failure
            is HttpOutcome.HttpStatus -> {
                if (httpResult.code == 401 || httpResult.code == 403) {
                    return@withContext RouterResult.AuthRequired("LuCI RPC session expired (HTTP ${httpResult.code}).")
                }
                if (httpResult.code == 404) {
                    return@withContext RouterResult.Unsupported(
                        featureName = "luci-rpc/$module.$method",
                        reason = "LuCI RPC module '$module' is unavailable on this router."
                    )
                }
                if (httpResult.code !in 200..299) {
                    return@withContext RouterResult.Failure("LuCI RPC returned HTTP ${httpResult.code}.")
                }
                val root = parseJsonObject(httpResult.body)
                    ?: return@withContext RouterResult.Failure("Invalid JSON from LuCI RPC $module.$method.")
                val errorEl = root["error"]
                if (errorEl != null && errorEl !is JsonNull) {
                    val errText = errorEl.toString()
                    if (errText.contains("auth", ignoreCase = true) || errText.contains("denied", ignoreCase = true)) {
                        return@withContext RouterResult.AuthRequired("LuCI RPC authentication expired.")
                    }
                    return@withContext RouterResult.Failure("LuCI RPC error: $errText")
                }
                RouterResult.Success(root["result"] ?: JsonNull)
            }
        }
    }

    private suspend fun mapRpcError(
        target: OpenWrtConnectionTarget,
        ubusObject: String,
        procedure: String,
        errorCode: Int,
        errorMessage: String,
        verifySessionOnDeny: Boolean
    ): RouterResult<JsonObject> {
        return when (errorCode) {
            -32002 -> { // JSON-RPC Access denied / expired session
                if (verifySessionOnDeny && ubusObject != "session" && isSessionStillValid(target)) {
                    RouterResult.Unsupported(
                        featureName = "$ubusObject.$procedure",
                        reason = "OpenWrt user lacks ACL permission for $ubusObject.$procedure."
                    )
                } else {
                    RouterResult.AuthRequired("OpenWrt session expired or access denied ($errorMessage).")
                }
            }
            -32000, -32601 -> RouterResult.Unsupported(
                featureName = "$ubusObject.$procedure",
                reason = "OpenWrt firmware does not implement $ubusObject.$procedure ($errorMessage)."
            )
            else -> RouterResult.Failure("OpenWrt ubus RPC error $errorCode on $ubusObject.$procedure: $errorMessage")
        }
    }

    private suspend fun mapUbusStatusCode(
        target: OpenWrtConnectionTarget,
        ubusObject: String,
        procedure: String,
        statusCode: Int,
        verifySessionOnDeny: Boolean
    ): RouterResult<JsonObject> {
        return when (statusCode) {
            UBUS_STATUS_PERMISSION_DENIED -> {
                if (verifySessionOnDeny && ubusObject != "session" && isSessionStillValid(target)) {
                    RouterResult.Unsupported(
                        featureName = "$ubusObject.$procedure",
                        reason = "OpenWrt ACL denies access to $ubusObject.$procedure."
                    )
                } else {
                    RouterResult.AuthRequired("OpenWrt session expired or permission denied.")
                }
            }
            UBUS_STATUS_METHOD_NOT_FOUND,
            UBUS_STATUS_NOT_FOUND,
            UBUS_STATUS_NOT_SUPPORTED -> RouterResult.Unsupported(
                featureName = "$ubusObject.$procedure",
                reason = "This OpenWrt firmware does not expose $ubusObject.$procedure (ubus code $statusCode)."
            )
            else -> RouterResult.Failure("OpenWrt ubus $ubusObject.$procedure failed with status code $statusCode.")
        }
    }

    private suspend fun isSessionStillValid(target: OpenWrtConnectionTarget): Boolean {
        val sid = sessionManager.getRpcSessionToken() ?: return false
        val payload = buildJsonObject {
            put("jsonrpc", JsonPrimitive("2.0"))
            put("id", JsonPrimitive(requestId.getAndIncrement()))
            put("method", JsonPrimitive("call"))
            put(
                "params",
                buildJsonArray {
                    add(JsonPrimitive(sid))
                    add(JsonPrimitive("session"))
                    add(JsonPrimitive("list"))
                    add(buildJsonObject {})
                }
            )
        }.toString()
        val outcome = executePost(target, "/ubus", payload, sidHeader = sid)
        if (outcome !is HttpOutcome.HttpStatus || outcome.code !in 200..299) return false
        val root = parseJsonObject(outcome.body) ?: return false
        if (root["error"] != null && root["error"] !is JsonNull) return false
        val arr = root["result"] as? JsonArray ?: return false
        return arr.getOrNull(0)?.jsonPrimitive?.intOrNull == 0
    }

    private sealed interface HttpOutcome {
        data class HttpStatus(val code: Int, val body: String, val csrfHeader: String?) : HttpOutcome
        data class TransportError(val failure: RouterResult.Failure) : HttpOutcome
    }

    private fun executePost(
        target: OpenWrtConnectionTarget,
        path: String,
        bodyJson: String,
        sidHeader: String? = null
    ): HttpOutcome {
        val client = clientFor(target)
        val reqBuilder = Request.Builder()
            .url("${target.baseUrl}$path")
            .header("Accept", "application/json")
            .post(bodyJson.toRequestBody(jsonMediaType))

        sessionManager.getCsrfToken()?.takeIf { it.isNotBlank() }?.let { csrf ->
            reqBuilder.header("X-CSRF-Token", csrf)
        }
        if (!sidHeader.isNullOrBlank() && sidHeader != ZERO_SESSION_ID) {
            reqBuilder.header("Authorization", "Bearer $sidHeader")
        }

        return try {
            client.newCall(reqBuilder.build()).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                val csrf = resp.header("X-CSRF-Token") ?: resp.header("X-Ubus-Token")
                HttpOutcome.HttpStatus(resp.code, body, csrf)
            }
        } catch (e: SocketTimeoutException) {
            HttpOutcome.TransportError(
                RouterResult.Failure("Connection timed out communicating with router at ${target.baseUrl}.", e)
            )
        } catch (e: UnknownHostException) {
            HttpOutcome.TransportError(
                RouterResult.Failure("Router host '${target.hostIp}' could not be resolved.", e)
            )
        } catch (e: ConnectException) {
            HttpOutcome.TransportError(
                RouterResult.Failure("Router unreachable at ${target.baseUrl} (${e.message ?: "connection refused"}).", e)
            )
        } catch (e: SSLException) {
            HttpOutcome.TransportError(
                RouterResult.Failure(
                    "TLS/HTTPS error connecting to ${target.baseUrl}: ${e.message ?: "certificate rejected"}. Enable local self-signed TLS if your router uses a self-signed certificate.",
                    e
                )
            )
        } catch (e: IOException) {
            HttpOutcome.TransportError(
                RouterResult.Failure("Network I/O error talking to ${target.baseUrl}: ${e.message ?: "unknown"}", e)
            )
        }
    }

    private fun parseJsonObject(raw: String): JsonObject? {
        return runCatching {
            json.parseToJsonElement(raw).jsonObject
        }.getOrNull()
    }

    companion object {
        const val ZERO_SESSION_ID = "00000000000000000000000000000000"
        const val UBUS_STATUS_NOT_FOUND = 4
        const val UBUS_STATUS_METHOD_NOT_FOUND = 3
        const val UBUS_STATUS_PERMISSION_DENIED = 6
        const val UBUS_STATUS_NOT_SUPPORTED = 7
    }
}
