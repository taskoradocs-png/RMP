package com.example.authentication

import com.example.models.RouterSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.HttpUrl
import java.util.concurrent.ConcurrentHashMap

/**
 * Manages authenticated router session state, HTTP cookies, CSRF tokens,
 * RPC session identifiers, and session expiration tracking.
 */
open class RouterSessionManager(
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) {
    private val _currentSession = MutableStateFlow<RouterSession?>(null)
    val currentSession: StateFlow<RouterSession?> = _currentSession.asStateFlow()

    private val _sessionExpiredReason = MutableStateFlow<String?>(null)
    val sessionExpiredReason: StateFlow<String?> = _sessionExpiredReason.asStateFlow()

    @Volatile
    private var rpcSessionToken: String? = null

    @Volatile
    private var csrfToken: String? = null

    @Volatile
    private var expiresAtEpochMs: Long? = null

    private val cookiesByHost = ConcurrentHashMap<String, MutableList<Cookie>>()

    val cookieJar: CookieJar = object : CookieJar {
        override fun saveFromResponse(url: HttpUrl, cookies: List<Cookie>) {
            if (cookies.isEmpty()) return
            val host = url.host.lowercase()
            val list = cookiesByHost.getOrPut(host) { mutableListOf() }
            synchronized(list) {
                for (incoming in cookies) {
                    list.removeAll { existing ->
                        existing.name == incoming.name &&
                            existing.domain == incoming.domain &&
                            existing.path == incoming.path
                    }
                    if (incoming.expiresAt > clockMs()) {
                        list.add(incoming)
                    }
                }
            }
            refreshSessionTokenCounts()
        }

        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            val host = url.host.lowercase()
            val list = cookiesByHost[host] ?: return emptyList()
            val now = clockMs()
            synchronized(list) {
                list.removeAll { it.expiresAt <= now }
                return list.filter { cookie ->
                    cookie.matches(url)
                }
            }
        }
    }

    fun startSession(
        session: RouterSession,
        rpcSessionToken: String? = null,
        csrfToken: String? = null,
        expiresAtEpochMs: Long? = session.expiresAtEpochMs
    ) {
        this.rpcSessionToken = rpcSessionToken
        this.csrfToken = csrfToken
        this.expiresAtEpochMs = expiresAtEpochMs
        _sessionExpiredReason.value = null
        val enriched = session.copy(
            expiresAtEpochMs = expiresAtEpochMs,
            hasCsrfToken = !csrfToken.isNullOrBlank(),
            cookieCount = totalStoredCookieCount()
        )
        _currentSession.value = enriched
    }

    fun startSession(session: RouterSession) {
        startSession(
            session = session,
            rpcSessionToken = this.rpcSessionToken,
            csrfToken = this.csrfToken,
            expiresAtEpochMs = session.expiresAtEpochMs
        )
    }

    fun updateTokens(
        rpcSessionToken: String? = this.rpcSessionToken,
        csrfToken: String? = this.csrfToken,
        expiresAtEpochMs: Long? = this.expiresAtEpochMs
    ) {
        this.rpcSessionToken = rpcSessionToken
        this.csrfToken = csrfToken
        this.expiresAtEpochMs = expiresAtEpochMs
        _currentSession.value = _currentSession.value?.copy(
            expiresAtEpochMs = expiresAtEpochMs,
            hasCsrfToken = !csrfToken.isNullOrBlank(),
            cookieCount = totalStoredCookieCount()
        )
    }

    fun getRpcSessionToken(): String? = rpcSessionToken

    fun getCsrfToken(): String? = csrfToken

    fun getCookiesForHost(host: String): List<Cookie> {
        val list = cookiesByHost[host.lowercase()] ?: return emptyList()
        val now = clockMs()
        synchronized(list) {
            list.removeAll { it.expiresAt <= now }
            return list.toList()
        }
    }

    fun isExpired(): Boolean {
        val session = _currentSession.value ?: return false
        if (session.isDemoSession) return false
        val expiry = expiresAtEpochMs ?: return false
        return clockMs() >= expiry
    }

    fun isAuthenticated(): Boolean {
        val session = _currentSession.value ?: return false
        if (session.isDemoSession) return true
        return !isExpired()
    }

    fun expireSession(reason: String = "Router session expired. Please authenticate again.") {
        clearInternalState()
        _sessionExpiredReason.value = reason
    }

    fun clearSession() {
        clearInternalState()
        _sessionExpiredReason.value = null
    }

    private fun clearInternalState() {
        _currentSession.value = null
        rpcSessionToken = null
        csrfToken = null
        expiresAtEpochMs = null
        cookiesByHost.clear()
    }

    private fun totalStoredCookieCount(): Int =
        cookiesByHost.values.sumOf { synchronized(it) { it.size } }

    private fun refreshSessionTokenCounts() {
        val current = _currentSession.value ?: return
        _currentSession.value = current.copy(
            hasCsrfToken = !csrfToken.isNullOrBlank(),
            cookieCount = totalStoredCookieCount()
        )
    }
}
