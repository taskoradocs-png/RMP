package com.example.core

import java.util.Locale

object Formatters {
    fun formatMbps(mbps: Float): String {
        return when {
            mbps >= 100f -> String.format(Locale.US, "%.0f Mbps", mbps)
            mbps >= 10f -> String.format(Locale.US, "%.1f Mbps", mbps)
            else -> String.format(Locale.US, "%.2f Mbps", mbps)
        }
    }

    fun formatBytes(bytes: Long): String {
        if (bytes < 1024L) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024.0) return String.format(Locale.US, "%.1f MB", mb)
        val gb = mb / 1024.0
        if (gb < 1024.0) return String.format(Locale.US, "%.2f GB", gb)
        val tb = gb / 1024.0
        return String.format(Locale.US, "%.2f TB", tb)
    }

    fun formatUptime(seconds: Long): String {
        if (seconds <= 0L) return "0m"
        val days = seconds / 86400
        val hours = (seconds % 86400) / 3600
        val mins = (seconds % 3600) / 60
        return buildString {
            if (days > 0) append("${days}d ")
            if (hours > 0 || days > 0) append("${hours}h ")
            append("${mins}m")
        }.trim()
    }

    fun formatDurationShort(seconds: Long): String {
        val hours = seconds / 3600
        val mins = (seconds % 3600) / 60
        return if (hours > 0) "${hours}h ${mins}m" else "${mins}m"
    }
}
