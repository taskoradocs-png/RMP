package com.example.features.wifi

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.AppMode
import com.example.core.RouterResult
import com.example.core.UiState
import com.example.core.Validators
import com.example.models.GuestNetworkConfig
import com.example.models.RouterCapability
import com.example.models.RouterFeature
import com.example.models.WifiBand
import com.example.models.WifiBandConfig
import com.example.models.WifiConfig
import com.example.models.WifiSecurityMode
import com.example.repositories.SettingsRepository
import com.example.repositories.WifiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class WifiScreenContent(
    val wifiConfig: WifiConfig,
    val supportsDualBand: Boolean,
    val supportsGuestNetwork: Boolean,
    val supportsChannelConfig: Boolean,
    val supportsBandwidthConfig: Boolean
)

data class WifiBandDraft(
    val enabled: Boolean,
    val ssid: String,
    val password: String,
    val securityMode: WifiSecurityMode,
    val hiddenSsid: Boolean,
    val channel: String,
    val bandwidthMhz: String,
    val ssidError: String? = null,
    val passwordError: String? = null
)

data class GuestNetworkDraft(
    val enabled: Boolean,
    val ssid: String,
    val password: String,
    val securityMode: WifiSecurityMode,
    val isolateClients: Boolean,
    val bandwidthLimitMbps: String,
    val ssidError: String? = null,
    val passwordError: String? = null
)

class WifiViewModel(
    private val wifiRepository: WifiRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<UiState<WifiScreenContent>>(UiState.Loading)
    val uiState: StateFlow<UiState<WifiScreenContent>> = _uiState.asStateFlow()

    private val _selectedBand = MutableStateFlow(WifiBand.BAND_2_4_GHZ)
    val selectedBand: StateFlow<WifiBand> = _selectedBand.asStateFlow()

    private val _band24Draft = MutableStateFlow<WifiBandDraft?>(null)
    val band24Draft: StateFlow<WifiBandDraft?> = _band24Draft.asStateFlow()

    private val _band5Draft = MutableStateFlow<WifiBandDraft?>(null)
    val band5Draft: StateFlow<WifiBandDraft?> = _band5Draft.asStateFlow()

    private val _guestDraft = MutableStateFlow<GuestNetworkDraft?>(null)
    val guestDraft: StateFlow<GuestNetworkDraft?> = _guestDraft.asStateFlow()

    private val _feedbackMessage = MutableStateFlow<String?>(null)
    val feedbackMessage: StateFlow<String?> = _feedbackMessage.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                wifiRepository.appMode,
                wifiRepository.revision
            ) { mode, rev -> mode to rev }
                .collect { (mode, _) ->
                    loadWifi(mode)
                }
        }
    }

    fun selectBand(band: WifiBand) {
        _selectedBand.value = band
    }

    fun switchToDemoMode() {
        viewModelScope.launch {
            settingsRepository.setAppMode(AppMode.DEMO)
        }
    }

    fun updateDraft(band: WifiBand, transform: (WifiBandDraft) -> WifiBandDraft) {
        if (band == WifiBand.BAND_2_4_GHZ) {
            _band24Draft.value = _band24Draft.value?.let(transform)
        } else {
            _band5Draft.value = _band5Draft.value?.let(transform)
        }
    }

    fun updateGuestDraft(transform: (GuestNetworkDraft) -> GuestNetworkDraft) {
        _guestDraft.value = _guestDraft.value?.let(transform)
    }

    fun setMasterWifiEnabled(enabled: Boolean) {
        viewModelScope.launch {
            when (val res = wifiRepository.setMasterWifiEnabled(enabled)) {
                is RouterResult.Success -> {
                    _feedbackMessage.value = if (res.isDemoData) {
                        if (enabled) "Wi-Fi radios enabled in Demo Sandbox." else "Wi-Fi radios disabled in Demo Sandbox."
                    } else {
                        "Wi-Fi radio state updated."
                    }
                }
                is RouterResult.Unsupported -> _feedbackMessage.value = res.reason
                is RouterResult.NotConnected -> _feedbackMessage.value = res.reason
                is RouterResult.AuthRequired -> _feedbackMessage.value = res.reason
                is RouterResult.ValidationError -> _feedbackMessage.value = res.message
                is RouterResult.Failure -> _feedbackMessage.value = res.message
            }
        }
    }

    fun validateAndPrepareBandSave(band: WifiBand): Boolean {
        val draft = if (band == WifiBand.BAND_2_4_GHZ) _band24Draft.value else _band5Draft.value
        if (draft == null) return false

        val ssidError = Validators.validateSsid(draft.ssid).errorOrNull
        val passError = Validators.validateWifiPassword(draft.password, draft.securityMode).errorOrNull
        updateDraft(band) { it.copy(ssidError = ssidError, passwordError = passError) }
        return ssidError == null && passError == null
    }

    fun commitBandSave(band: WifiBand) {
        val ready = (uiState.value as? UiState.Ready)?.data ?: return
        val currentConfig = if (band == WifiBand.BAND_2_4_GHZ) ready.wifiConfig.band24 else ready.wifiConfig.band5
        val draft = if (band == WifiBand.BAND_2_4_GHZ) _band24Draft.value else _band5Draft.value
        if (currentConfig == null || draft == null) return

        viewModelScope.launch {
            val updated = currentConfig.copy(
                enabled = draft.enabled,
                ssid = draft.ssid.trim(),
                password = draft.password,
                securityMode = draft.securityMode,
                hiddenSsid = draft.hiddenSsid,
                channel = draft.channel,
                bandwidthMhz = draft.bandwidthMhz
            )
            when (val res = wifiRepository.updateBandConfig(band, updated)) {
                is RouterResult.Success -> {
                    _feedbackMessage.value = if (res.isDemoData) {
                        "${band.label} configuration saved in Demo Sandbox."
                    } else {
                        "${band.label} configuration applied."
                    }
                }
                is RouterResult.ValidationError -> {
                    _feedbackMessage.value = res.message
                }
                is RouterResult.Unsupported -> _feedbackMessage.value = res.reason
                is RouterResult.NotConnected -> _feedbackMessage.value = res.reason
                is RouterResult.AuthRequired -> _feedbackMessage.value = res.reason
                is RouterResult.Failure -> _feedbackMessage.value = res.message
            }
        }
    }

    fun validateAndPrepareGuestSave(): Boolean {
        val draft = _guestDraft.value ?: return false
        val ssidError = Validators.validateSsid(draft.ssid).errorOrNull
        val passError = Validators.validateWifiPassword(draft.password, draft.securityMode).errorOrNull
        updateGuestDraft { it.copy(ssidError = ssidError, passwordError = passError) }
        return ssidError == null && passError == null
    }

    fun commitGuestSave() {
        val ready = (uiState.value as? UiState.Ready)?.data ?: return
        val existingGuest = ready.wifiConfig.guestNetwork ?: return
        val draft = _guestDraft.value ?: return

        viewModelScope.launch {
            val limit = draft.bandwidthLimitMbps.trim().toIntOrNull()?.takeIf { it > 0 }
            val updated = existingGuest.copy(
                enabled = draft.enabled,
                ssid = draft.ssid.trim(),
                password = draft.password,
                securityMode = draft.securityMode,
                isolateClients = draft.isolateClients,
                bandwidthLimitMbps = limit
            )
            when (val res = wifiRepository.updateGuestNetwork(updated)) {
                is RouterResult.Success -> {
                    _feedbackMessage.value = if (res.isDemoData) {
                        "Guest network saved in Demo Sandbox."
                    } else {
                        "Guest network updated."
                    }
                }
                is RouterResult.ValidationError -> _feedbackMessage.value = res.message
                is RouterResult.Unsupported -> _feedbackMessage.value = res.reason
                is RouterResult.NotConnected -> _feedbackMessage.value = res.reason
                is RouterResult.AuthRequired -> _feedbackMessage.value = res.reason
                is RouterResult.Failure -> _feedbackMessage.value = res.message
            }
        }
    }

    private suspend fun loadWifi(mode: AppMode) {
        when (val result = wifiRepository.getWifiConfig()) {
            is RouterResult.NotConnected -> {
                _uiState.value = UiState.Disconnected(
                    title = "No Live Router Connected",
                    message = "Connect and authenticate with your router to inspect or modify wireless SSIDs, channels, and guest networks."
                )
            }
            is RouterResult.AuthRequired -> {
                _uiState.value = UiState.Disconnected(
                    title = "Authentication Required",
                    message = result.reason
                )
            }
            is RouterResult.Unsupported -> _uiState.value = UiState.Error(result.reason)
            is RouterResult.ValidationError -> _uiState.value = UiState.Error(result.message)
            is RouterResult.Failure -> _uiState.value = UiState.Error(result.message)
            is RouterResult.Success -> {
                val cfg = result.data
                val caps: RouterCapability? = wifiRepository.getCapabilities()
                _band24Draft.value = cfg.band24.toDraft()
                _band5Draft.value = cfg.band5?.toDraft()
                _guestDraft.value = cfg.guestNetwork?.toDraft()

                _uiState.value = UiState.Ready(
                    data = WifiScreenContent(
                        wifiConfig = cfg,
                        supportsDualBand = caps?.supports(RouterFeature.WIFI_DUAL_BAND) ?: (cfg.band5 != null),
                        supportsGuestNetwork = caps?.supports(RouterFeature.WIFI_GUEST_NETWORK) ?: false,
                        supportsChannelConfig = caps?.supports(RouterFeature.WIFI_CHANNEL_CONFIG) ?: false,
                        supportsBandwidthConfig = caps?.supports(RouterFeature.WIFI_BANDWIDTH_CONFIG) ?: false
                    ),
                    isDemoMode = mode == AppMode.DEMO
                )
            }
        }
    }

    private fun WifiBandConfig.toDraft() = WifiBandDraft(
        enabled = enabled,
        ssid = ssid,
        password = password,
        securityMode = securityMode,
        hiddenSsid = hiddenSsid,
        channel = channel,
        bandwidthMhz = bandwidthMhz
    )

    private fun GuestNetworkConfig.toDraft() = GuestNetworkDraft(
        enabled = enabled,
        ssid = ssid,
        password = password,
        securityMode = securityMode,
        isolateClients = isolateClients,
        bandwidthLimitMbps = bandwidthLimitMbps?.toString() ?: ""
    )
}
