package com.example.models

enum class RouterConnectionState(val label: String) {
    DISCONNECTED("Disconnected"),
    AUTHENTICATING("Authenticating"),
    CONNECTED("Connected"),
    AUTH_ERROR("Authentication Failed"),
    UNREACHABLE("Unreachable")
}

data class RouterInfo(
    val manufacturer: String,
    val model: String,
    val firmwareVersion: String,
    val hardwareRevision: String,
    val routerIp: String,
    val wanIp: String?,
    val internetConnected: Boolean,
    val uptimeSeconds: Long,
    val cpuLoadPercent: Int,
    val memoryLoadPercent: Int,
    val serialMasked: String,
    val connectionState: RouterConnectionState,
    val adapterId: String,
    val adapterName: String
)

data class RouterProfile(
    val id: String,
    val displayName: String,
    val manufacturer: String,
    val model: String,
    val hostIp: String,
    val port: Int,
    val useHttps: Boolean,
    val username: String,
    val hasStoredPassword: Boolean,
    val firmwareVersion: String,
    val lastConnectedEpochMs: Long?
)

data class AdapterDescriptor(
    val id: String,
    val displayName: String,
    val manufacturer: String,
    val supportedModels: List<String>,
    val minFirmwareVersion: String,
    val protocolDescription: String,
    val capability: RouterCapability,
    val isLiveTransportReady: Boolean
)

data class DiscoveredAdminInterface(
    val scheme: String,
    val port: Int,
    val isReachable: Boolean,
    val latencyMs: Long?,
    val statusCode: Int?,
    val fingerprintHint: String? = null,
    val detectedAdapterId: String? = null
)

data class DiscoveredRouter(
    val hostIp: String,
    val port: Int,
    val supportsHttps: Boolean,
    val manufacturerHint: String,
    val modelHint: String,
    val discoverySource: String,
    val matchedAdapterId: String?,
    val isReachable: Boolean = false,
    val reachabilityLatencyMs: Long? = null,
    val adminInterfaces: List<DiscoveredAdminInterface> = emptyList()
)

data class RouterCredentials(
    val hostIp: String,
    val port: Int,
    val useHttps: Boolean,
    val username: String,
    val password: String,
    val allowSelfSignedTls: Boolean = false
) {
    override fun toString(): String {
        return "RouterCredentials(hostIp='$hostIp', port=$port, useHttps=$useHttps, allowSelfSignedTls=$allowSelfSignedTls, username='$username', password='****')"
    }
}

data class RouterSession(
    val sessionId: String,
    val profileId: String?,
    val routerIp: String,
    val adapterId: String,
    val authenticatedUsername: String,
    val establishedAtEpochMs: Long,
    val isDemoSession: Boolean,
    val expiresAtEpochMs: Long? = null,
    val hasCsrfToken: Boolean = false,
    val cookieCount: Int = 0,
    val protocolVersionHint: String? = null
)

enum class ActivityCategory(val label: String) {
    SECURITY("Security"),
    WIFI("Wi-Fi"),
    DEVICE("Device"),
    NETWORK("Network"),
    SYSTEM("System")
}

enum class ActivitySeverity {
    INFO,
    WARNING,
    CRITICAL
}

data class NetworkActivityEvent(
    val id: String,
    val timestampLabel: String,
    val title: String,
    val description: String,
    val category: ActivityCategory,
    val severity: ActivitySeverity
)

data class TrafficSnapshot(
    val downloadMbps: Float,
    val uploadMbps: Float,
    val totalDownloadedBytes: Long,
    val totalUploadedBytes: Long,
    val downloadHistoryMbps: List<Float>,
    val uploadHistoryMbps: List<Float>,
    val latencyMs: Int?,
    val packetLossPercent: Float?
)
