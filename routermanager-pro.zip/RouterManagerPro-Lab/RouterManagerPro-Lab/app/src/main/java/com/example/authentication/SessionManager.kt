package com.example.authentication

/**
 * Backwards-compatible alias/subclass for RouterSessionManager.
 */
class SessionManager(
    clockMs: () -> Long = { System.currentTimeMillis() }
) : RouterSessionManager(clockMs)
