package com.example.features.network

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.Cable
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.Formatters
import com.example.core.RouterResult
import com.example.core.UiState
import com.example.designsystem.AdminCard
import com.example.designsystem.AmberDemo
import com.example.designsystem.CyanAccent
import com.example.designsystem.EmeraldOnline
import com.example.designsystem.InfoBanner
import com.example.designsystem.KeyValueRow
import com.example.designsystem.LiveDisconnectedPanel
import com.example.designsystem.MonoLargeMetricStyle
import com.example.designsystem.MonoValueStyle
import com.example.designsystem.PillTone
import com.example.designsystem.RoseCritical
import com.example.designsystem.SectionHeader
import com.example.designsystem.StatusPill
import com.example.designsystem.ThroughputChart
import com.example.designsystem.UnsupportedFeatureNotice
import com.example.models.EthernetPortInfo

@Composable
private fun ToolTopBar(
    title: String,
    onBack: () -> Unit,
    onRefresh: (() -> Unit)? = null
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
            IconButton(onClick = onBack, modifier = Modifier.testTag("tool_back_button")) {
                Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
            }
            Spacer(Modifier.width(6.dp))
            Text(title, style = MaterialTheme.typography.headlineMedium)
        }
        if (onRefresh != null) {
            IconButton(onClick = onRefresh, modifier = Modifier.testTag("tool_refresh_button")) {
                Icon(Icons.Outlined.Refresh, contentDescription = "Refresh telemetry")
            }
        }
    }
}

@Composable
private fun <T> RouterResultHost(
    result: RouterResult<T>?,
    featureName: String,
    onConnect: () -> Unit,
    onDiscover: () -> Unit,
    onDemo: () -> Unit,
    content: @Composable (T) -> Unit
) {
    when (result) {
        null -> {
            AdminCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Text("Querying router telemetry...", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        is RouterResult.NotConnected -> LiveDisconnectedPanel(
            title = "No Live Router Connected",
            subtitle = result.reason,
            onConnectClick = onConnect,
            onDiscoverClick = onDiscover,
            onSwitchToDemoClick = onDemo
        )
        is RouterResult.AuthRequired -> LiveDisconnectedPanel(
            title = "Authentication Required",
            subtitle = result.reason,
            onConnectClick = onConnect,
            onDiscoverClick = onDiscover,
            onSwitchToDemoClick = onDemo
        )
        is RouterResult.Unsupported -> UnsupportedFeatureNotice(featureName = featureName, reason = result.reason)
        is RouterResult.ValidationError -> InfoBanner(message = result.message)
        is RouterResult.Failure -> InfoBanner(message = result.message)
        is RouterResult.Success -> content(result.data)
    }
}

@Composable
fun OpticalInfoScreen(
    viewModel: NetworkViewModel,
    onBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val opticalResult by viewModel.opticalInfo.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { viewModel.refreshDiagnosticsModules() }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("optical_info_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ToolTopBar("Optical Info", onBack = onBack, onRefresh = viewModel::refreshDiagnosticsModules)
            }
            item {
                RouterResultHost(
                    result = opticalResult,
                    featureName = "GPON / Fiber Optical Transceiver",
                    onConnect = onNavigateToLogin,
                    onDiscover = onNavigateToDiscovery,
                    onDemo = viewModel::switchToDemoMode
                ) { info ->
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        AdminCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.Layers, contentDescription = null, tint = Color(0xFF8B5CF6))
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text(info.ponMode, style = MaterialTheme.typography.titleMedium)
                                        Text(info.linkState, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                StatusPill(label = "PON Up", tone = PillTone.ONLINE)
                            }
                        }

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            AdminCard(modifier = Modifier.weight(1f)) {
                                Text("Rx Optical Power", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(6.dp))
                                Text("${info.rxPowerDbm} dBm", style = MonoLargeMetricStyle, color = EmeraldOnline)
                                Text("Nominal (-8 to -27 dBm)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            AdminCard(modifier = Modifier.weight(1f)) {
                                Text("Tx Optical Power", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(6.dp))
                                Text("${info.txPowerDbm} dBm", style = MonoLargeMetricStyle, color = CyanAccent)
                                Text("Nominal (0.5 to 5.0 dBm)", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        AdminCard {
                            SectionHeader(title = "Transceiver Health")
                            Spacer(Modifier.height(8.dp))
                            KeyValueRow("Optics Temperature", "${info.temperatureC} °C", isMonospace = true)
                            KeyValueRow("Supply Voltage", "${info.voltageV} V", isMonospace = true)
                            KeyValueRow("Laser Bias Current", "${info.biasCurrentMa} mA", isMonospace = true)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EthernetStatusScreen(
    viewModel: NetworkViewModel,
    onBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val portsResult by viewModel.ethernetPorts.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { viewModel.refreshDiagnosticsModules() }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("ethernet_status_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ToolTopBar("Ethernet Port Status", onBack = onBack, onRefresh = viewModel::refreshDiagnosticsModules)
            }
            item {
                RouterResultHost(
                    result = portsResult,
                    featureName = "Ethernet Physical Port Status",
                    onConnect = onNavigateToLogin,
                    onDiscover = onNavigateToDiscovery,
                    onDemo = viewModel::switchToDemoMode
                ) { ports ->
                    val connectedCount = ports.count { it.isUp }
                    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        AdminCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                SectionHeader(title = "Switch Ports (${ports.size})")
                                StatusPill(
                                    label = "$connectedCount Connected",
                                    tone = if (connectedCount > 0) PillTone.ONLINE else PillTone.NEUTRAL
                                )
                            }
                            Spacer(Modifier.height(14.dp))
                            val rows = ports.chunked(2)
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                rows.forEach { rowPorts ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        rowPorts.forEach { port ->
                                            EthernetVisualPortTile(
                                                port = port,
                                                modifier = Modifier.weight(1f)
                                            )
                                        }
                                        if (rowPorts.size == 1) {
                                            Spacer(Modifier.weight(1f))
                                        }
                                    }
                                }
                            }
                        }

                        SectionHeader(title = "Detailed Specifications")
                        ports.forEach { port ->
                            AdminCard {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(CircleShape)
                                                .background(if (port.isUp) EmeraldOnline else MaterialTheme.colorScheme.outline)
                                        )
                                        Spacer(Modifier.width(10.dp))
                                        Text("Port ${port.portNumber} (${port.label})", style = MaterialTheme.typography.titleMedium)
                                    }
                                    StatusPill(
                                        label = if (port.isUp) "Up" else "Down",
                                        tone = if (port.isUp) PillTone.ONLINE else PillTone.NEUTRAL
                                    )
                                }
                                Spacer(Modifier.height(10.dp))
                                KeyValueRow(
                                    label = "Link Speed",
                                    value = if (port.isUp) port.speedLabel else "Disconnected",
                                    isMonospace = true
                                )
                                KeyValueRow("Duplex Mode", port.duplexLabel)
                                KeyValueRow("Learned MACs", port.macLearnedCount.toString(), isMonospace = true)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EthernetVisualPortTile(
    port: EthernetPortInfo,
    modifier: Modifier = Modifier
) {
    val activeColor = if (port.isUp) EmeraldOnline else MaterialTheme.colorScheme.outline
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(
            width = 1.dp,
            color = if (port.isUp) EmeraldOnline.copy(alpha = 0.45f) else MaterialTheme.colorScheme.outlineVariant
        )
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(activeColor.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Outlined.Cable,
                    contentDescription = port.label,
                    tint = activeColor
                )
            }
            Spacer(Modifier.height(8.dp))
            Text(port.label, style = MaterialTheme.typography.titleSmall)
            Text(
                text = if (port.isUp) port.speedLabel else "IDLE",
                style = MonoValueStyle,
                color = if (port.isUp) EmeraldOnline else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun InterfaceStatsScreen(
    viewModel: NetworkViewModel,
    onBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val statsResult by viewModel.interfaceStats.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { viewModel.refreshDiagnosticsModules() }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("interface_stats_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ToolTopBar("Interface Stats", onBack = onBack, onRefresh = viewModel::refreshDiagnosticsModules)
            }
            item {
                RouterResultHost(
                    result = statsResult,
                    featureName = "Interface Packet Counters",
                    onConnect = onNavigateToLogin,
                    onDiscover = onNavigateToDiscovery,
                    onDemo = viewModel::switchToDemoMode
                ) { stats ->
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        stats.forEach { iface ->
                            AdminCard {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Outlined.Dns, contentDescription = null, tint = CyanAccent)
                                        Spacer(Modifier.width(10.dp))
                                        Column {
                                            Text(iface.interfaceName, style = MonoValueStyle.copy(fontWeight = FontWeight.SemiBold))
                                            Text(iface.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    StatusPill(
                                        label = if (iface.isUp) "UP" else "DOWN",
                                        tone = if (iface.isUp) PillTone.ONLINE else PillTone.NEUTRAL
                                    )
                                }
                                Spacer(Modifier.height(10.dp))
                                KeyValueRow("Received (Rx)", Formatters.formatBytes(iface.rxBytes), isMonospace = true)
                                KeyValueRow("Transmitted (Tx)", Formatters.formatBytes(iface.txBytes), isMonospace = true)
                                KeyValueRow("Rx / Tx Packets", "${iface.rxPackets} / ${iface.txPackets}", isMonospace = true)
                                KeyValueRow(
                                    "Errors / Drops",
                                    "${iface.rxErrors + iface.txErrors} err · ${iface.droppedPackets} drop",
                                    isMonospace = true,
                                    valueColor = if (iface.rxErrors + iface.txErrors > 0) AmberDemo else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DeviceInfoScreen(
    viewModel: NetworkViewModel,
    onBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val info by viewModel.routerInfo.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { viewModel.refreshDiagnosticsModules() }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("device_info_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ToolTopBar("Device Info", onBack = onBack, onRefresh = viewModel::refreshDiagnosticsModules)
            }
            if (uiState is UiState.Disconnected || info == null) {
                item {
                    LiveDisconnectedPanel(
                        title = "No Live Router Connected",
                        subtitle = "Authenticate with a supported gateway to inspect CPU, RAM, hardware revision, and firmware versions.",
                        onConnectClick = onNavigateToLogin,
                        onDiscoverClick = onNavigateToDiscovery,
                        onSwitchToDemoClick = viewModel::switchToDemoMode
                    )
                }
            } else {
                val r = info!!
                item {
                    AdminCard {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.Memory, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                            Spacer(Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${r.manufacturer} ${r.model}", style = MaterialTheme.typography.titleLarge)
                                Text(r.adapterName, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            StatusPill(label = r.connectionState.label, tone = PillTone.ONLINE)
                        }
                        Spacer(Modifier.height(14.dp))
                        Text("CPU Load (${r.cpuLoadPercent}%)", style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { (r.cpuLoadPercent / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                        )
                        Spacer(Modifier.height(12.dp))
                        Text("Memory Usage (${r.memoryLoadPercent}%)", style = MaterialTheme.typography.labelMedium)
                        Spacer(Modifier.height(4.dp))
                        LinearProgressIndicator(
                            progress = { (r.memoryLoadPercent / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                            color = CyanAccent
                        )
                    }
                }
                item {
                    AdminCard {
                        SectionHeader(title = "Hardware & Firmware")
                        Spacer(Modifier.height(8.dp))
                        KeyValueRow("Firmware Version", r.firmwareVersion, isMonospace = true)
                        KeyValueRow("Hardware Revision", r.hardwareRevision, isMonospace = true)
                        KeyValueRow("Serial Number", r.serialMasked, isMonospace = true)
                        KeyValueRow("Gateway LAN IP", r.routerIp, isMonospace = true)
                        KeyValueRow("WAN IPv4", r.wanIp ?: "Unassigned", isMonospace = true)
                        KeyValueRow("System Uptime", Formatters.formatUptime(r.uptimeSeconds), isMonospace = true)
                    }
                }
            }
        }
    }
}

@Composable
fun UsageStatsScreen(
    viewModel: NetworkViewModel,
    onBack: () -> Unit,
    onOpenSpeedTest: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val traffic by viewModel.trafficSnapshot.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { viewModel.refreshDiagnosticsModules() }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("usage_stats_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ToolTopBar("Traffic Usage", onBack = onBack, onRefresh = viewModel::refreshDiagnosticsModules)
            }
            if (uiState is UiState.Disconnected || traffic == null) {
                item {
                    LiveDisconnectedPanel(
                        title = "Traffic Telemetry Unavailable",
                        subtitle = "Connect to a router to monitor real-time download/upload rates and cumulative WAN counters.",
                        onConnectClick = onNavigateToLogin,
                        onDiscoverClick = onNavigateToDiscovery,
                        onSwitchToDemoClick = viewModel::switchToDemoMode
                    )
                }
            } else {
                val snap = traffic!!
                item {
                    AdminCard {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.ArrowDownward, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(6.dp))
                                Column {
                                    Text("Download", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(Formatters.formatMbps(snap.downloadMbps), style = MonoLargeMetricStyle, color = MaterialTheme.colorScheme.primary)
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.ArrowUpward, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                                Spacer(Modifier.width(6.dp))
                                Column(horizontalAlignment = Alignment.End) {
                                    Text("Upload", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(Formatters.formatMbps(snap.uploadMbps), style = MonoLargeMetricStyle, color = MaterialTheme.colorScheme.secondary)
                                }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                        ThroughputChart(
                            downloadHistoryMbps = snap.downloadHistoryMbps,
                            uploadHistoryMbps = snap.uploadHistoryMbps
                        )
                        Spacer(Modifier.height(10.dp))
                        KeyValueRow("Total Downloaded", Formatters.formatBytes(snap.totalDownloadedBytes), isMonospace = true)
                        KeyValueRow("Total Uploaded", Formatters.formatBytes(snap.totalUploadedBytes), isMonospace = true)
                        KeyValueRow("Gateway Latency", snap.latencyMs?.let { "$it ms" } ?: "N/A", isMonospace = true)
                        KeyValueRow("Packet Loss", snap.packetLossPercent?.let { "$it %" } ?: "N/A", isMonospace = true)
                    }
                }
                item {
                    Button(
                        onClick = onOpenSpeedTest,
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Icon(Icons.Outlined.Speed, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Run WAN Speed Test")
                    }
                }
            }
        }
    }
}

@Composable
fun VoipStatusScreen(
    viewModel: NetworkViewModel,
    onBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val voipResult by viewModel.voipLines.collectAsStateWithLifecycle()
    LaunchedEffect(Unit) { viewModel.refreshDiagnosticsModules() }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("voip_status_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                ToolTopBar("VoIP Status", onBack = onBack, onRefresh = viewModel::refreshDiagnosticsModules)
            }
            item {
                RouterResultHost(
                    result = voipResult,
                    featureName = "SIP / FXS VoIP Status",
                    onConnect = onNavigateToLogin,
                    onDiscover = onNavigateToDiscovery,
                    onDemo = viewModel::switchToDemoMode
                ) { lines ->
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        lines.forEach { line ->
                            AdminCard {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Outlined.Call, contentDescription = null, tint = EmeraldOnline)
                                        Spacer(Modifier.width(10.dp))
                                        Column {
                                            Text("Line ${line.lineNumber} · ${line.numberLabel}", style = MaterialTheme.typography.titleMedium)
                                            Text(line.sipRegistrar, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                    StatusPill(
                                        label = if (line.isRegistered) "Registered" else "Disabled",
                                        tone = if (line.isRegistered) PillTone.ONLINE else PillTone.NEUTRAL
                                    )
                                }
                                Spacer(Modifier.height(10.dp))
                                KeyValueRow("SIP State", line.registrationState)
                                KeyValueRow("Port Activity", line.lastCallStatus)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SpeedTestScreen(
    viewModel: NetworkViewModel,
    onBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val speedResult by viewModel.speedTestResult.collectAsStateWithLifecycle()
    val isRunning by viewModel.isRunningSpeedTest.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) {
        if (speedResult == null) {
            viewModel.runSpeedTest()
        }
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("speed_test_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                ToolTopBar("WAN Speed Test", onBack = onBack)
            }
            if (uiState is UiState.Disconnected) {
                item {
                    LiveDisconnectedPanel(
                        title = "Gateway Not Connected",
                        subtitle = "Authenticate with your router gateway to run a WAN bandwidth probe.",
                        onConnectClick = onNavigateToLogin,
                        onDiscoverClick = onNavigateToDiscovery,
                        onSwitchToDemoClick = viewModel::switchToDemoMode
                    )
                }
            } else {
                item {
                    val data = (speedResult as? RouterResult.Success)?.data
                    val unsupported = (speedResult as? RouterResult.Unsupported)?.reason
                    if (unsupported != null) {
                        UnsupportedFeatureNotice(featureName = "Gateway Speed Test", reason = unsupported)
                    } else {
                        AdminCard {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Box(
                                    modifier = Modifier.size(168.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    val gaugeColor = MaterialTheme.colorScheme.primary
                                    val trackColor = MaterialTheme.colorScheme.outlineVariant
                                    val progress = ((data?.downloadMbps ?: 0f) / 1000f).coerceIn(0.08f, 1f)
                                    Canvas(modifier = Modifier.fillMaxSize()) {
                                        val stroke = 12.dp.toPx()
                                        val pad = stroke / 2f
                                        drawArc(
                                            color = trackColor,
                                            startAngle = 140f,
                                            sweepAngle = 260f,
                                            useCenter = false,
                                            topLeft = Offset(pad, pad),
                                            size = Size(size.width - stroke, size.height - stroke),
                                            style = Stroke(width = stroke, cap = StrokeCap.Round)
                                        )
                                        drawArc(
                                            color = gaugeColor,
                                            startAngle = 140f,
                                            sweepAngle = if (isRunning) 120f else 260f * progress,
                                            useCenter = false,
                                            topLeft = Offset(pad, pad),
                                            size = Size(size.width - stroke, size.height - stroke),
                                            style = Stroke(width = stroke, cap = StrokeCap.Round)
                                        )
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        if (isRunning) {
                                            CircularProgressIndicator(modifier = Modifier.size(28.dp))
                                            Spacer(Modifier.height(6.dp))
                                            Text("Measuring...", style = MaterialTheme.typography.labelMedium)
                                        } else {
                                            Text(
                                                text = data?.let { "%.1f".format(it.downloadMbps) } ?: "--",
                                                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                            Text("Mbps Download", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                                Spacer(Modifier.height(14.dp))
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                Spacer(Modifier.height(12.dp))
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Upload", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(data?.let { Formatters.formatMbps(it.uploadMbps) } ?: "--", style = MonoValueStyle)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Ping", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(data?.let { "${it.pingMs} ms" } ?: "--", style = MonoValueStyle)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Jitter", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text(data?.let { "${it.jitterMs} ms" } ?: "--", style = MonoValueStyle)
                                    }
                                }
                                if (data != null) {
                                    Spacer(Modifier.height(10.dp))
                                    Text(
                                        text = "${data.serverLabel} · ${data.timestampLabel}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(Modifier.height(16.dp))
                                Button(
                                    onClick = viewModel::runSpeedTest,
                                    enabled = !isRunning,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("run_speed_test_button")
                                ) {
                                    Text(if (isRunning) "Testing..." else "Run Speed Test")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
