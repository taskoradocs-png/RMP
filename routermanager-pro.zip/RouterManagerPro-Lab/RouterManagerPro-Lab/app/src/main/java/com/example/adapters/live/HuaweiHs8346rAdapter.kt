package com.example.adapters.live

import android.util.Base64
import com.example.core.RouterResult
import com.example.models.*
import com.example.networking.RouterEndpointClient
import com.example.router.huawei.hs8346r.HuaweiHs8346rProfile
import okhttp3.Cookie
import okhttp3.CookieJar
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.Request

/**
 * Live hardware adapter for Huawei HS8346R ONT.
 *
 * Handles HTTP authentication, router information,
 * optical telemetry and session management.
 */
class HuaweiHs8346rAdapter(
    private val hostIp: String = "192.168.100.1",
    private val port: Int = 80
) : BaseLiveRouterAdapter() {

    private val baseUrl = "http://$hostIp:$port"

    // Preserve cookies between HTTP requests.
    private val sessionCookieJar = object : CookieJar {

        private val cookies = mutableListOf<Cookie>()

        @Synchronized
        override fun saveFromResponse(
            url: HttpUrl,
            newCookies: List<Cookie>
        ) {
            cookies.removeAll { old ->
                newCookies.any {
                    it.name == old.name &&
                    it.domain == old.domain &&
                    it.path == old.path
                }
            }

            cookies.addAll(newCookies.filter { it.expiresAt > System.currentTimeMillis() })
        }

        @Synchronized
        override fun loadForRequest(url: HttpUrl): List<Cookie> {
            cookies.removeAll {
                it.expiresAt <= System.currentTimeMillis()
            }

            return cookies.filter { it.matches(url) }
        }

        @Synchronized
        fun clear() {
            cookies.clear()
        }
    }

    private val client = RouterEndpointClient.createClient(
        allowPrivateLanSelfSignedTls = true,
        targetHost = hostIp,
        enableDebugMetadataLogs = false
    ).newBuilder()
        .cookieJar(sessionCookieJar)
        .build()

    private var activeSessionToken: String? = null

    override val capabilities = RouterCapability(
        supportedFeatures = setOf(
            RouterFeature.ROUTER_INFO,
            RouterFeature.WAN_INFO,
            RouterFeature.OPTICAL_INFO
        ),
        supports5Ghz = true,
        maxGuestNetworks = 0,
        capabilityNotes =
            "Huawei HS8346R HTTP CGI/ASP adapter. Reboot endpoint requires verification."
    )

    override val descriptor = AdapterDescriptor(
        id = "huawei_hs8346r",
        displayName = HuaweiHs8346rProfile.MODEL,
        manufacturer = "Huawei",
        supportedModels = listOf("HS8346R"),
        minFirmwareVersion = HuaweiHs8346rProfile.FIRMWARE_VERSION,
        protocolDescription =
            "Huawei ONT HTTP CGI / ASP session communication",
        capability = capabilities,
        isLiveTransportReady = true
    )

    // ------------------------------------------------
    // AUTHENTICATION
    // ------------------------------------------------

    override suspend fun authenticate(
        credentials: RouterCredentials
    ): RouterResult<RouterSession> {

        return try {

            sessionCookieJar.clear()
            activeSessionToken = null

            // Fetch router login page.
            val indexRequest = Request.Builder()
                .url("$baseUrl/")
                .get()
                .build()

            val indexHtml = client.newCall(indexRequest)
                .execute()
                .use { response ->

                    if (!response.isSuccessful) {
                        return RouterResult.Failure(
                            "Unable to access Huawei login page. HTTP ${response.code}"
                        )
                    }

                    response.body?.string().orEmpty()
                }

            // Extract dynamic Huawei token.
            val tokenRegex = Regex(
                """function\s+GetRandCnt\s*\(\s*\)\s*\{\s*return\s*['"]([a-fA-F0-9]+)['"]"""
            )

            val token = tokenRegex.find(indexHtml)
                ?.groupValues
                ?.get(1)
                ?: return RouterResult.Failure(
                    "Huawei authentication token was not found."
                )

            // Encode password according to the observed login protocol.
            val encodedPassword = Base64.encodeToString(
                credentials.password.toByteArray(Charsets.UTF_8),
                Base64.NO_WRAP
            )

            val loginBody = FormBody.Builder()
                .add("UserName", credentials.username)
                .add("PassWord", encodedPassword)
                .add("x.X_HW_Token", token)
                .build()

            val loginRequest = Request.Builder()
                .url("$baseUrl${HuaweiHs8346rProfile.Paths.LOGIN}")
                .post(loginBody)
                .addHeader(
                    "Cookie",
                    "Cookie=body:Language:english:id=-1"
                )
                .build()

            val loginSuccess = client.newCall(loginRequest)
                .execute()
                .use { response ->

                    val body = response.body?.string().orEmpty()

                    response.isSuccessful &&
                        !body.contains("DivErrPage", ignoreCase = true) &&
                        !body.contains("Login failed", ignoreCase = true)
                }

            if (!loginSuccess) {
                sessionCookieJar.clear()

                return RouterResult.Failure(
                    "Huawei HS8346R authentication rejected. Verify credentials."
                )
            }

            activeSessionToken = token

            val session = RouterSession(
                sessionId = "huawei-session-${System.currentTimeMillis()}",
                profileId = "huawei_hs8346r",
                routerIp = hostIp,
                adapterId = descriptor.id,
                authenticatedUsername = credentials.username,
                establishedAtEpochMs = System.currentTimeMillis(),
                isDemoSession = false
            )

            RouterResult.Success(session)

        } catch (e: Exception) {

            sessionCookieJar.clear()

            RouterResult.Failure(
                "Huawei authentication error: ${e.localizedMessage}"
            )
        }
    }

    // ------------------------------------------------
    // DISCONNECT
    // ------------------------------------------------

    override suspend fun disconnect(): RouterResult<Unit> {

        return try {

            val request = Request.Builder()
                .url(
                    "$baseUrl${HuaweiHs8346rProfile.Paths.LOGOUT}" +
                        "?RequestFile=html/logout.html"
                )
                .post(FormBody.Builder().build())
                .build()

            client.newCall(request).execute().close()

            activeSessionToken = null
            sessionCookieJar.clear()

            RouterResult.Success(Unit)

        } catch (e: Exception) {

            activeSessionToken = null
            sessionCookieJar.clear()

            RouterResult.Failure(
                "Huawei logout failed: ${e.localizedMessage}"
            )
        }
    }

    // ------------------------------------------------
    // ROUTER INFORMATION
    // ------------------------------------------------

    override suspend fun getRouterInfo(): RouterResult<RouterInfo> {

        return try {

            val request = Request.Builder()
                .url("$baseUrl${HuaweiHs8346rProfile.Paths.WAN_LIST}")
                .get()
                .build()

            val html = client.newCall(request)
                .execute()
                .use { response ->

                    if (!response.isSuccessful) {
                        return RouterResult.NotConnected(
                            "Router unreachable or session expired."
                        )
                    }

                    response.body?.string().orEmpty()
                }

            val wanRegex = Regex(
                """new\s+WanPPP\s*\(([^)]*)\)"""
            )

            val match = wanRegex.find(html)
                ?: return RouterResult.Failure(
                    "WAN information was not found."
                )

            val args = parseJsArgs(match.groupValues[1])

            val ipAddress = args.getOrNull(12)
                ?.takeIf { it.isNotBlank() }
                ?: "Unknown"

            val uptime = args.getOrNull(38)
                ?.toLongOrNull()
                ?: 0L

            val wanStatus = args.getOrNull(3)
                ?.takeIf { it.isNotBlank() }
                ?: "Unknown"

            RouterResult.Success(
                RouterInfo(
                    manufacturer = "Huawei",
                    model = HuaweiHs8346rProfile.MODEL,
                    firmwareVersion = HuaweiHs8346rProfile.FIRMWARE_VERSION,
                    hardwareRevision = HuaweiHs8346rProfile.HARDWARE_REVISION,
                    routerIp = hostIp,
                    wanIp = ipAddress.takeUnless { it == "Unknown" },
                    internetConnected = wanStatus.equals("Connected", ignoreCase = true) ||
                        wanStatus.equals("Up", ignoreCase = true),
                    uptimeSeconds = uptime,
                    // This firmware endpoint does not expose CPU or memory load here.
                    cpuLoadPercent = 0,
                    memoryLoadPercent = 0,
                    serialMasked = "Unknown",
                    connectionState = RouterConnectionState.CONNECTED,
                    adapterId = descriptor.id,
                    adapterName = descriptor.displayName
                )
            )

        } catch (e: Exception) {

            RouterResult.Failure(
                "Router information error: ${e.localizedMessage}"
            )
        }
    }

    // ------------------------------------------------
    // OPTICAL INFORMATION
    // ------------------------------------------------

    override suspend fun getOpticalInfo(): RouterResult<OpticalInfo> {

        return try {

            val request = Request.Builder()
                .url("$baseUrl${HuaweiHs8346rProfile.Paths.WAN_LIST_INFO}")
                .get()
                .build()

            val html = client.newCall(request)
                .execute()
                .use { response ->

                    if (!response.isSuccessful) {
                        return RouterResult.NotConnected(
                            "Router unreachable or session expired."
                        )
                    }

                    response.body?.string().orEmpty()
                }

            val opticRegex = Regex(
                """new\s+stOpticInfo\s*\(([^)]*)\)"""
            )

            val match = opticRegex.find(html)
                ?: return RouterResult.Failure(
                    "Optical telemetry record not found."
                )

            val args = parseJsArgs(match.groupValues[1])

            if (args.size < 10) {
                return RouterResult.Failure(
                    "Invalid optical telemetry structure."
                )
            }

            RouterResult.Success(
                OpticalInfo(
                    ponMode = "EPON",
                    linkState = "Online",
                    txPowerDbm = args[1].toFloatOrNull() ?: 0.0f,
                    rxPowerDbm = args[2].toFloatOrNull() ?: 0.0f,
                    temperatureC = args[4].toFloatOrNull() ?: 0.0f,
                    // The source field is named voltage in the router's optical record.
                    voltageV = args[3].toFloatOrNull() ?: 0.0f,
                    biasCurrentMa = args[5].toFloatOrNull() ?: 0.0f
                )
            )

        } catch (e: Exception) {

            RouterResult.Failure(
                "Optical information error: ${e.localizedMessage}"
            )
        }
    }

    // ------------------------------------------------
    // ROUTER REBOOT
    // ------------------------------------------------

    override suspend fun rebootRouter(): RouterResult<Unit> {

        if (activeSessionToken == null) {
            return RouterResult.NotConnected(
                "Authenticate before attempting router operations."
            )
        }

        // The actual reboot CGI endpoint and parameters have
        // not yet been verified against captured router traffic.

        return RouterResult.Failure(
            "Reboot is not enabled. Verify the Huawei reboot endpoint first."
        )
    }

    // ------------------------------------------------
    // JAVASCRIPT ARGUMENT PARSER
    // ------------------------------------------------

    private fun parseJsArgs(rawArgs: String): List<String> {

        val result = mutableListOf<String>()
        val current = StringBuilder()

        var quote: Char? = null
        var escaped = false

        for (char in rawArgs) {

            if (escaped) {
                current.append(char)
                escaped = false
                continue
            }

            if (char == '\\') {
                current.append(char)
                escaped = true
                continue
            }

            if (quote != null) {

                if (char == quote) {
                    quote = null
                } else {
                    current.append(char)
                }

                continue
            }

            if (char == '"' || char == '\'') {
                quote = char
                continue
            }

            if (char == ',') {
                result.add(decodeJsValue(current.toString()))
                current.clear()
                continue
            }

            current.append(char)
        }

        result.add(decodeJsValue(current.toString()))

        return result
    }

    private fun decodeJsValue(value: String): String {

        val cleaned = value.trim()

        return Regex("""\\x([0-9A-Fa-f]{2})""")
            .replace(cleaned) { match ->

                match.groupValues[1]
                    .toInt(16)
                    .toChar()
                    .toString()
            }
    }
}
