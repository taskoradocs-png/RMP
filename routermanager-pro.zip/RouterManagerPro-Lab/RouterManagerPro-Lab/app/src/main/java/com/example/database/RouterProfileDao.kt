package com.example.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface RouterProfileDao {
    @Query("SELECT * FROM router_profiles ORDER BY COALESCE(lastConnectedEpochMs, 0) DESC, displayName ASC")
    fun observeProfiles(): Flow<List<RouterProfileEntity>>

    @Query("SELECT * FROM router_profiles WHERE id = :id LIMIT 1")
    suspend fun getProfileById(id: String): RouterProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProfile(profile: RouterProfileEntity)

    @Query("DELETE FROM router_profiles WHERE id = :id")
    suspend fun deleteProfileById(id: String)

    @Query("UPDATE router_profiles SET encryptedPassword = NULL WHERE id = :id")
    suspend fun clearCredentialsForProfile(id: String)
}
