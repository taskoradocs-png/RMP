package com.example.database

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "router_profiles")
data class RouterProfileEntity(
    @PrimaryKey val id: String,
    val displayName: String,
    val manufacturer: String,
    val model: String,
    val hostIp: String,
    val port: Int,
    val useHttps: Boolean,
    val username: String,
    val encryptedPassword: String?,
    val firmwareVersion: String,
    val lastConnectedEpochMs: Long?
)
