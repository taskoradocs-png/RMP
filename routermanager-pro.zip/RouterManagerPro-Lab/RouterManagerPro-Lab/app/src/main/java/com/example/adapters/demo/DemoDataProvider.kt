package com.example.adapters.demo

import com.example.models.ActivityCategory
import com.example.models.ActivitySeverity
import com.example.models.ConnectedDevice
import com.example.models.ConnectionType
import com.example.models.DeviceCategory
import com.example.models.DhcpConfig
import com.example.models.DiagnosticResult
import com.example.models.DiagnosticStatus
import com.example.models.DnsConfig
import com.example.models.DnsHostEntry
import com.example.models.DnsMode
import com.example.models.EthernetPortInfo
import com.example.models.FirewallConfig
import com.example.models.FirewallLevel
import com.example.models.GuestNetworkConfig
import com.example.models.InterfaceStat
import com.example.models.LanConfig
import com.example.models.NetworkActivityEvent
import com.example.models.NetworkSettings
import com.example.models.OpticalInfo
import com.example.models.ParentalControlTemplate
import com.example.models.PortForwardRule
import com.example.models.ProtocolType
import com.example.models.RouterConnectionState
import com.example.models.RouterInfo
import com.example.models.RouterProfile
import com.example.models.SpeedTestResult
import com.example.models.TrafficSnapshot
import com.example.models.VoipLineInfo
import com.example.models.WanConnectionProfile
import com.example.models.WanConnectionType
import com.example.models.WanInfo
import com.example.models.WifiBand
import com.example.models.WifiBandConfig
import com.example.models.WifiConfig
import com.example.models.WifiSecurityMode
import java.util.UUID

/**
 * Completely isolated Demo Sandbox Data Provider for UI preview and offline exploration.
 * Never touches production networking or live router adapters.
 */
class DemoDataProvider {

    private var routerInfo = RouterInfo(
        manufacturer = "ASUS",
        model = "RT-AX86U Pro (Demo)",
        firmwareVersion = "3.0.0.4.388_24328-demo",
        hardwareRevision = "Rev A2",
        routerIp = "192.168.50.1",
        wanIp = "203.0.113.48",
        internetConnected = true,
        uptimeSeconds = 1_248_420L,
        cpuLoadPercent = 24,
        memoryLoadPercent = 41,
        serialMasked = "SN-AX86-••••-9421",
        connectionState = RouterConnectionState.CONNECTED,
        adapterId = "demo_sandbox",
        adapterName = "Demo Sandbox Adapter"
    )

    private var wifiConfig = WifiConfig(
        masterWifiEnabled = true,
        band24 = WifiBandConfig(
            band = WifiBand.BAND_2_4_GHZ,
            enabled = true,
            ssid = "Northstar_IoT_24",
            securityMode = WifiSecurityMode.WPA2_PSK,
            password = "Demo-24G-Passphrase!",
            hiddenSsid = false,
            channel = "6",
            availableChannels = listOf("Auto", "1", "6", "11"),
            bandwidthMhz = "20 MHz",
            availableBandwidthsMhz = listOf("20 MHz", "20/40 MHz"),
            txPowerPercent = 80,
            connectedClientsCount = 3
        ),
        band5 = WifiBandConfig(
            band = WifiBand.BAND_5_GHZ,
            enabled = true,
            ssid = "Northstar_Core_5G",
            securityMode = WifiSecurityMode.WPA2_WPA3_TRANSITION,
            password = "Demo-5G-Passphrase!",
            hiddenSsid = false,
            channel = "149",
            availableChannels = listOf("Auto", "36", "40", "44", "48", "149", "153", "157", "161"),
            bandwidthMhz = "160 MHz",
            availableBandwidthsMhz = listOf("20 MHz", "40 MHz", "80 MHz", "160 MHz"),
            txPowerPercent = 100,
            connectedClientsCount = 4
        ),
        guestNetwork = GuestNetworkConfig(
            enabled = true,
            ssid = "Northstar_Guest",
            securityMode = WifiSecurityMode.WPA2_PSK,
            password = "Guest-Demo-Access",
            isolateClients = true,
            bandwidthLimitMbps = 50,
            bandLabel = "2.4 GHz (Isolated VLAN)"
        )
    )

    private var devices = listOf(
        ConnectedDevice(
            macAddress = "A4:83:E7:21:9B:04",
            name = "MacBook Pro 16",
            ipAddress = "192.168.50.102",
            manufacturer = "Apple Inc.",
            connectionType = ConnectionType.WIFI_5_GHZ,
            category = DeviceCategory.LAPTOP,
            isOnline = true,
            isBlocked = false,
            staticIpReserved = true,
            frequencyBandLabel = "5 GHz · Ch 149 (160 MHz)",
            signalStrengthDbm = -48,
            linkSpeedMbps = 1201,
            rxRateMbps = 142.4f,
            txRateMbps = 28.6f,
            totalDownloadedBytes = 42_810_294_112L,
            totalUploadedBytes = 8_942_100_480L,
            connectedDurationSeconds = 54_200L,
            dhcpType = "Static Lease",
            lastSeenLabel = "Active now"
        ),
        ConnectedDevice(
            macAddress = "DC:A6:32:8F:12:C8",
            name = "HomeLab NAS-01",
            ipAddress = "192.168.50.10",
            manufacturer = "Synology Inc.",
            connectionType = ConnectionType.ETHERNET,
            category = DeviceCategory.DESKTOP,
            isOnline = true,
            isBlocked = false,
            staticIpReserved = true,
            frequencyBandLabel = "Wired Ethernet · 2.5 GbE",
            signalStrengthDbm = null,
            linkSpeedMbps = 2500,
            rxRateMbps = 86.2f,
            txRateMbps = 114.8f,
            totalDownloadedBytes = 318_240_912_100L,
            totalUploadedBytes = 194_201_480_220L,
            connectedDurationSeconds = 1_240_000L,
            dhcpType = "Static Lease",
            lastSeenLabel = "Active now"
        ),
        ConnectedDevice(
            macAddress = "3C:28:6D:44:7A:19",
            name = "Pixel 9 Pro",
            ipAddress = "192.168.50.114",
            manufacturer = "Google LLC",
            connectionType = ConnectionType.WIFI_5_GHZ,
            category = DeviceCategory.PHONE,
            isOnline = true,
            isBlocked = false,
            frequencyBandLabel = "5 GHz · Ch 149 (160 MHz)",
            signalStrengthDbm = -53,
            linkSpeedMbps = 960,
            rxRateMbps = 24.5f,
            txRateMbps = 4.8f,
            totalDownloadedBytes = 12_402_849_210L,
            totalUploadedBytes = 2_104_829_100L,
            connectedDurationSeconds = 18_400L,
            dhcpType = "Dynamic DHCP",
            lastSeenLabel = "Active now"
        ),
        ConnectedDevice(
            macAddress = "B8:27:EB:90:11:3D",
            name = "Living Room Shield TV",
            ipAddress = "192.168.50.128",
            manufacturer = "NVIDIA Corp.",
            connectionType = ConnectionType.ETHERNET,
            category = DeviceCategory.TV_MEDIA,
            isOnline = true,
            isBlocked = false,
            frequencyBandLabel = "Wired Ethernet · 1.0 GbE",
            signalStrengthDbm = null,
            linkSpeedMbps = 1000,
            rxRateMbps = 41.2f,
            txRateMbps = 1.9f,
            totalDownloadedBytes = 89_102_481_900L,
            totalUploadedBytes = 1_490_281_400L,
            connectedDurationSeconds = 320_100L,
            dhcpType = "Dynamic DHCP",
            lastSeenLabel = "Active now"
        ),
        ConnectedDevice(
            macAddress = "70:EE:50:6C:2A:F1",
            name = "Ecobee Thermostat",
            ipAddress = "192.168.50.141",
            manufacturer = "Ecobee Inc.",
            connectionType = ConnectionType.WIFI_2_4_GHZ,
            category = DeviceCategory.IOT,
            isOnline = true,
            isBlocked = false,
            frequencyBandLabel = "2.4 GHz · Ch 6 (20 MHz)",
            signalStrengthDbm = -64,
            linkSpeedMbps = 72,
            rxRateMbps = 0.2f,
            txRateMbps = 0.1f,
            totalDownloadedBytes = 184_291_000L,
            totalUploadedBytes = 94_120_400L,
            connectedDurationSeconds = 980_210L,
            dhcpType = "Dynamic DHCP",
            lastSeenLabel = "Active now"
        ),
        ConnectedDevice(
            macAddress = "50:EC:50:1D:8E:77",
            name = "Front Doorbell Cam",
            ipAddress = "192.168.50.149",
            manufacturer = "Ubiquiti Inc.",
            connectionType = ConnectionType.WIFI_2_4_GHZ,
            category = DeviceCategory.IOT,
            isOnline = true,
            isBlocked = false,
            isInternetBlocked = true,
            staticIpReserved = true,
            frequencyBandLabel = "2.4 GHz · Ch 6 (20 MHz)",
            signalStrengthDbm = -67,
            linkSpeedMbps = 144,
            rxRateMbps = 0.8f,
            txRateMbps = 6.4f,
            totalDownloadedBytes = 1_204_891_200L,
            totalUploadedBytes = 28_401_920_000L,
            connectedDurationSeconds = 640_120L,
            dhcpType = "Static Lease",
            lastSeenLabel = "Active now"
        ),
        ConnectedDevice(
            macAddress = "28:11:A5:77:03:B2",
            name = "Workstation-Win11",
            ipAddress = "192.168.50.163",
            manufacturer = "Intel Corporate",
            connectionType = ConnectionType.WIFI_5_GHZ,
            category = DeviceCategory.DESKTOP,
            isOnline = false,
            isBlocked = false,
            frequencyBandLabel = "5 GHz · Ch 149 (80 MHz)",
            signalStrengthDbm = -59,
            linkSpeedMbps = 866,
            rxRateMbps = 0f,
            txRateMbps = 0f,
            totalDownloadedBytes = 19_482_100_000L,
            totalUploadedBytes = 4_120_490_000L,
            connectedDurationSeconds = 0L,
            dhcpType = "Dynamic DHCP",
            lastSeenLabel = "2 hours ago"
        ),
        ConnectedDevice(
            macAddress = "9C:AD:97:33:E4:50",
            name = "Visitor-Tablet",
            ipAddress = "192.168.50.210",
            manufacturer = "Samsung Electronics",
            connectionType = ConnectionType.GUEST_WIFI,
            category = DeviceCategory.TABLET,
            isOnline = true,
            isBlocked = false,
            frequencyBandLabel = "2.4 GHz · Guest VLAN",
            signalStrengthDbm = -61,
            linkSpeedMbps = 300,
            rxRateMbps = 12.1f,
            txRateMbps = 1.4f,
            totalDownloadedBytes = 1_942_100_400L,
            totalUploadedBytes = 210_400_120L,
            connectedDurationSeconds = 5_400L,
            dhcpType = "Guest DHCP",
            lastSeenLabel = "Active now"
        ),
        ConnectedDevice(
            macAddress = "00:1A:7D:DA:71:13",
            name = "Unrecognized-ESP32-Node",
            ipAddress = "192.168.50.199",
            manufacturer = "Espressif Systems",
            connectionType = ConnectionType.WIFI_2_4_GHZ,
            category = DeviceCategory.IOT,
            isOnline = false,
            isBlocked = true,
            frequencyBandLabel = "2.4 GHz · Ch 6",
            signalStrengthDbm = -79,
            linkSpeedMbps = 54,
            rxRateMbps = 0f,
            txRateMbps = 0f,
            totalDownloadedBytes = 14_200_100L,
            totalUploadedBytes = 8_100_400L,
            connectedDurationSeconds = 0L,
            dhcpType = "Blocked MAC",
            lastSeenLabel = "Blocked yesterday"
        )
    )

    private var networkSettings = NetworkSettings(
        wan = WanInfo(
            statusLabel = "Connected (Demo Fiber WAN)",
            connectionType = WanConnectionType.PPPOE,
            publicIp = "203.0.113.48",
            subnetMask = "255.255.255.0",
            gatewayIp = "203.0.113.1",
            primaryDns = "1.1.1.1",
            secondaryDns = "9.9.9.9",
            mtu = 1492,
            ispName = "Northstar Fiber Telecom (Demo)"
        ),
        wanConnections = listOf(
            WanConnectionProfile(
                id = "wan-1",
                name = "WAN_INTERNET_PPPOE",
                serviceType = "INTERNET",
                connectionType = WanConnectionType.PPPOE,
                vlanId = 100,
                isDefaultRoute = true,
                statusLabel = "Connected",
                ipAddress = "203.0.113.48",
                enabled = true
            ),
            WanConnectionProfile(
                id = "wan-2",
                name = "WAN_VOIP_TR069",
                serviceType = "VOIP_TR069",
                connectionType = WanConnectionType.DHCP,
                vlanId = 200,
                isDefaultRoute = false,
                statusLabel = "Connected",
                ipAddress = "10.42.18.91",
                enabled = true
            )
        ),
        lan = LanConfig(
            routerIp = "192.168.50.1",
            subnetMask = "255.255.255.0",
            hostname = "northstar-gw.local",
            igmpSnoopingEnabled = true
        ),
        dhcp = DhcpConfig(
            enabled = true,
            startIp = "192.168.50.100",
            endIp = "192.168.50.250",
            leaseTimeMinutes = 1440,
            activeLeasesCount = 7,
            staticReservationsCount = 3
        ),
        dns = DnsConfig(
            mode = DnsMode.CUSTOM,
            primaryDns = "1.1.1.1",
            secondaryDns = "9.9.9.9",
            dnsOverHttpsEnabled = true,
            hostEntries = listOf(
                DnsHostEntry("host-1", "nas.home.local", "192.168.50.10"),
                DnsHostEntry("host-2", "router.home.local", "192.168.50.1")
            )
        ),
        portForwardingRules = listOf(
            PortForwardRule(
                id = "pf-1",
                name = "WireGuard VPN",
                externalPort = 51820,
                internalPort = 51820,
                internalIp = "192.168.50.10",
                protocol = ProtocolType.UDP,
                enabled = true
            ),
            PortForwardRule(
                id = "pf-2",
                name = "HomeLab HTTPS Reverse Proxy",
                externalPort = 443,
                internalPort = 8443,
                internalIp = "192.168.50.10",
                protocol = ProtocolType.TCP,
                enabled = false
            )
        ),
        firewall = FirewallConfig(
            level = FirewallLevel.CUSTOM,
            spiFirewallEnabled = true,
            dosProtectionEnabled = true,
            respondToWanPing = false,
            ipv6FirewallEnabled = true
        ),
        upnpEnabled = false
    )

    private var parentalTemplates = listOf(
        ParentalControlTemplate(
            id = "pc-1",
            name = "Kids Bedtime Schedule",
            scheduleWindow = "22:00 – 06:30 Daily",
            blockedKeywordsCount = 24,
            assignedDeviceMacs = listOf("9C:AD:97:33:E4:50"),
            enabled = true
        ),
        ParentalControlTemplate(
            id = "pc-2",
            name = "IoT Telemetry Block",
            scheduleWindow = "Always Active",
            blockedKeywordsCount = 12,
            assignedDeviceMacs = listOf("50:EC:50:1D:8E:77"),
            enabled = true
        )
    )

    private var activityEvents = mutableListOf(
        NetworkActivityEvent(
            id = "evt-1",
            timestampLabel = "2m ago",
            title = "Client Connected on 5 GHz",
            description = "Pixel 9 Pro (192.168.50.114) roamed to Channel 149 (160 MHz).",
            category = ActivityCategory.WIFI,
            severity = ActivitySeverity.INFO
        ),
        NetworkActivityEvent(
            id = "evt-2",
            timestampLabel = "41m ago",
            title = "Guest Isolation Policy Active",
            description = "Visitor-Tablet joined Northstar_Guest with LAN isolation enforced.",
            category = ActivityCategory.SECURITY,
            severity = ActivitySeverity.INFO
        ),
        NetworkActivityEvent(
            id = "evt-3",
            timestampLabel = "Yesterday",
            title = "Blocked MAC Association Attempt",
            description = "Blocked device 00:1A:7D:DA:71:13 denied 2.4 GHz authentication.",
            category = ActivityCategory.SECURITY,
            severity = ActivitySeverity.WARNING
        ),
        NetworkActivityEvent(
            id = "evt-4",
            timestampLabel = "3d ago",
            title = "WAN DHCP Lease Renewed",
            description = "Primary WAN 203.0.113.48 renewed via Northstar Fiber gateway.",
            category = ActivityCategory.NETWORK,
            severity = ActivitySeverity.INFO
        )
    )

    fun getRouterInfo(): RouterInfo = routerInfo

    fun getTrafficSnapshot(): TrafficSnapshot = TrafficSnapshot(
        downloadMbps = 307.2f,
        uploadMbps = 157.8f,
        totalDownloadedBytes = 475_242_818_422L,
        totalUploadedBytes = 238_563_191_720L,
        downloadHistoryMbps = listOf(184f, 210f, 198f, 265f, 342f, 290f, 318f, 275f, 330f, 295f, 312f, 307f),
        uploadHistoryMbps = listOf(92f, 108f, 115f, 140f, 132f, 168f, 151f, 145f, 172f, 161f, 149f, 158f),
        latencyMs = 11,
        packetLossPercent = 0.0f
    )

    fun getRecentActivity(): List<NetworkActivityEvent> = activityEvents.toList()

    fun getWifiConfig(): WifiConfig = wifiConfig

    fun setWifiEnabled(enabled: Boolean): WifiConfig {
        wifiConfig = wifiConfig.copy(masterWifiEnabled = enabled)
        prependActivity(
            title = if (enabled) "Demo Wi-Fi Radios Enabled" else "Demo Wi-Fi Radios Disabled",
            description = "Master wireless toggle updated in Demo Sandbox.",
            category = ActivityCategory.WIFI,
            severity = if (enabled) ActivitySeverity.INFO else ActivitySeverity.WARNING
        )
        return wifiConfig
    }

    fun updateSsid(band: WifiBand, ssid: String): WifiConfig {
        wifiConfig = when (band) {
            WifiBand.BAND_2_4_GHZ -> wifiConfig.copy(band24 = wifiConfig.band24.copy(ssid = ssid))
            WifiBand.BAND_5_GHZ -> wifiConfig.copy(band5 = wifiConfig.band5?.copy(ssid = ssid))
        }
        prependActivity(
            title = "${band.label} SSID Updated (Demo)",
            description = "Changed network SSID to \"$ssid\" in Demo Sandbox.",
            category = ActivityCategory.WIFI,
            severity = ActivitySeverity.INFO
        )
        return wifiConfig
    }

    fun updateWifiPassword(band: WifiBand, password: String): WifiConfig {
        wifiConfig = when (band) {
            WifiBand.BAND_2_4_GHZ -> wifiConfig.copy(band24 = wifiConfig.band24.copy(password = password))
            WifiBand.BAND_5_GHZ -> wifiConfig.copy(band5 = wifiConfig.band5?.copy(password = password))
        }
        prependActivity(
            title = "${band.label} Passphrase Updated (Demo)",
            description = "Updated wireless passphrase in Demo Sandbox.",
            category = ActivityCategory.SECURITY,
            severity = ActivitySeverity.INFO
        )
        return wifiConfig
    }

    fun updateWifiBandConfig(band: WifiBand, config: WifiBandConfig): WifiConfig {
        wifiConfig = when (band) {
            WifiBand.BAND_2_4_GHZ -> wifiConfig.copy(band24 = config)
            WifiBand.BAND_5_GHZ -> wifiConfig.copy(band5 = config)
        }
        prependActivity(
            title = "${band.label} Radio Config Saved (Demo)",
            description = "Updated SSID \"${config.ssid}\", channel ${config.channel}, ${config.bandwidthMhz}.",
            category = ActivityCategory.WIFI,
            severity = ActivitySeverity.INFO
        )
        return wifiConfig
    }

    fun updateGuestNetwork(config: GuestNetworkConfig): WifiConfig {
        wifiConfig = wifiConfig.copy(guestNetwork = config)
        prependActivity(
            title = "Guest Network Updated (Demo)",
            description = if (config.enabled) "Guest SSID \"${config.ssid}\" active." else "Guest network disabled.",
            category = ActivityCategory.WIFI,
            severity = ActivitySeverity.INFO
        )
        return wifiConfig
    }

    fun getDevices(): List<ConnectedDevice> = devices

    fun blockDevice(macAddress: String): Boolean {
        var found = false
        devices = devices.map { device ->
            if (device.macAddress.equals(macAddress, ignoreCase = true)) {
                found = true
                prependActivity(
                    title = "Device Blocked (Demo)",
                    description = "${device.name} (${device.macAddress}) added to MAC block list.",
                    category = ActivityCategory.SECURITY,
                    severity = ActivitySeverity.WARNING
                )
                device.copy(isBlocked = true, isOnline = false, rxRateMbps = 0f, txRateMbps = 0f, lastSeenLabel = "Blocked just now")
            } else device
        }
        return found
    }

    fun unblockDevice(macAddress: String): Boolean {
        var found = false
        devices = devices.map { device ->
            if (device.macAddress.equals(macAddress, ignoreCase = true)) {
                found = true
                prependActivity(
                    title = "Device Unblocked (Demo)",
                    description = "${device.name} (${device.macAddress}) removed from MAC block list.",
                    category = ActivityCategory.SECURITY,
                    severity = ActivitySeverity.INFO
                )
                device.copy(isBlocked = false, isOnline = true, lastSeenLabel = "Active now")
            } else device
        }
        return found
    }

    fun setDeviceInternetBlocked(macAddress: String, blocked: Boolean): Boolean {
        var found = false
        devices = devices.map { device ->
            if (device.macAddress.equals(macAddress, ignoreCase = true)) {
                found = true
                prependActivity(
                    title = if (blocked) "Internet Access Blocked (Demo)" else "Internet Access Restored (Demo)",
                    description = "${device.name} (${device.ipAddress}) WAN access ${if (blocked) "restricted to LAN only" else "allowed"}.",
                    category = ActivityCategory.SECURITY,
                    severity = if (blocked) ActivitySeverity.WARNING else ActivitySeverity.INFO
                )
                device.copy(isInternetBlocked = blocked)
            } else device
        }
        return found
    }

    fun renameDevice(macAddress: String, newName: String): Boolean {
        val trimmed = newName.trim()
        if (trimmed.isEmpty()) return false
        var found = false
        devices = devices.map { device ->
            if (device.macAddress.equals(macAddress, ignoreCase = true)) {
                found = true
                prependActivity(
                    title = "Device Renamed (Demo)",
                    description = "Renamed ${device.name} -> $trimmed ($macAddress).",
                    category = ActivityCategory.DEVICE,
                    severity = ActivitySeverity.INFO
                )
                device.copy(name = trimmed)
            } else device
        }
        return found
    }

    fun setDeviceGuestBlocked(macAddress: String, blocked: Boolean): Boolean {
        var found = false
        devices = devices.map { device ->
            if (device.macAddress.equals(macAddress, ignoreCase = true)) {
                found = true
                prependActivity(
                    title = if (blocked) "Guest Wi-Fi Blocked (Demo)" else "Guest Wi-Fi Allowed (Demo)",
                    description = "${device.name} (${device.macAddress}) Guest SSID policy updated.",
                    category = ActivityCategory.WIFI,
                    severity = if (blocked) ActivitySeverity.WARNING else ActivitySeverity.INFO
                )
                device.copy(isGuestBlocked = blocked)
            } else device
        }
        return found
    }

    fun setDeviceStaticIp(macAddress: String, reserved: Boolean): Boolean {
        var found = false
        devices = devices.map { device ->
            if (device.macAddress.equals(macAddress, ignoreCase = true)) {
                found = true
                prependActivity(
                    title = if (reserved) "Static IP Reserved (Demo)" else "Static IP Released (Demo)",
                    description = "${device.name} (${device.ipAddress}) lease updated.",
                    category = ActivityCategory.NETWORK,
                    severity = ActivitySeverity.INFO
                )
                device.copy(
                    staticIpReserved = reserved,
                    dhcpType = if (reserved) "Static Lease" else "Dynamic DHCP"
                )
            } else device
        }
        return found
    }

    fun setDeviceBandBlocked(macAddress: String, band: WifiBand, blocked: Boolean): Boolean {
        var found = false
        devices = devices.map { device ->
            if (device.macAddress.equals(macAddress, ignoreCase = true)) {
                found = true
                prependActivity(
                    title = if (blocked) "${band.label} Blocked for Client (Demo)" else "${band.label} Allowed for Client (Demo)",
                    description = "${device.name} (${device.macAddress}) ${band.label} radio ACL updated.",
                    category = ActivityCategory.WIFI,
                    severity = if (blocked) ActivitySeverity.WARNING else ActivitySeverity.INFO
                )
                when (band) {
                    WifiBand.BAND_2_4_GHZ -> device.copy(isBand24Blocked = blocked)
                    WifiBand.BAND_5_GHZ -> device.copy(isBand5Blocked = blocked)
                }
            } else device
        }
        return found
    }

    fun getNetworkSettings(): NetworkSettings = networkSettings

    fun updateLanConfig(lan: LanConfig): NetworkSettings {
        networkSettings = networkSettings.copy(lan = lan)
        routerInfo = routerInfo.copy(routerIp = lan.routerIp)
        prependActivity(
            title = "LAN Config Updated (Demo)",
            description = "Gateway IP ${lan.routerIp}, mask ${lan.subnetMask}.",
            category = ActivityCategory.NETWORK,
            severity = ActivitySeverity.INFO
        )
        return networkSettings
    }

    fun updateDhcpConfig(dhcp: DhcpConfig): NetworkSettings {
        networkSettings = networkSettings.copy(dhcp = dhcp)
        prependActivity(
            title = "DHCP Server Updated (Demo)",
            description = "Pool ${dhcp.startIp} - ${dhcp.endIp}, lease ${dhcp.leaseTimeMinutes}m.",
            category = ActivityCategory.NETWORK,
            severity = ActivitySeverity.INFO
        )
        return networkSettings
    }

    fun updateDnsConfig(dns: DnsConfig): NetworkSettings {
        networkSettings = networkSettings.copy(dns = dns)
        prependActivity(
            title = "DNS Settings Updated (Demo)",
            description = "Mode ${dns.mode.label} (${dns.primaryDns} / ${dns.secondaryDns}).",
            category = ActivityCategory.NETWORK,
            severity = ActivitySeverity.INFO
        )
        return networkSettings
    }

    fun savePortForwardRule(rule: PortForwardRule): NetworkSettings {
        val current = networkSettings.portForwardingRules.toMutableList()
        val idx = current.indexOfFirst { it.id == rule.id }
        if (idx >= 0) {
            current[idx] = rule
        } else {
            current.add(rule)
        }
        networkSettings = networkSettings.copy(portForwardingRules = current)
        prependActivity(
            title = "Port Forward Rule Saved (Demo)",
            description = "${rule.name}: ${rule.externalPort} -> ${rule.internalIp}:${rule.internalPort} (${rule.protocol.label}).",
            category = ActivityCategory.NETWORK,
            severity = ActivitySeverity.INFO
        )
        return networkSettings
    }

    fun deletePortForwardRule(ruleId: String): NetworkSettings {
        networkSettings = networkSettings.copy(
            portForwardingRules = networkSettings.portForwardingRules.filterNot { it.id == ruleId }
        )
        prependActivity(
            title = "Port Forward Rule Removed (Demo)",
            description = "Removed forwarding rule $ruleId in Demo Sandbox.",
            category = ActivityCategory.NETWORK,
            severity = ActivitySeverity.INFO
        )
        return networkSettings
    }

    fun updateFirewallConfig(firewall: FirewallConfig): NetworkSettings {
        networkSettings = networkSettings.copy(firewall = firewall)
        prependActivity(
            title = "Firewall Policy Updated (Demo)",
            description = "SPI=${firewall.spiFirewallEnabled}, DoS=${firewall.dosProtectionEnabled}.",
            category = ActivityCategory.SECURITY,
            severity = ActivitySeverity.INFO
        )
        return networkSettings
    }

    fun setUpnpEnabled(enabled: Boolean): NetworkSettings {
        networkSettings = networkSettings.copy(upnpEnabled = enabled)
        prependActivity(
            title = if (enabled) "UPnP Enabled (Demo)" else "UPnP Disabled (Demo)",
            description = "UPnP port mapping state changed in Demo Sandbox.",
            category = ActivityCategory.NETWORK,
            severity = if (enabled) ActivitySeverity.WARNING else ActivitySeverity.INFO
        )
        return networkSettings
    }

    fun saveWanConnection(profile: WanConnectionProfile): NetworkSettings {
        val current = networkSettings.wanConnections.toMutableList()
        val idx = current.indexOfFirst { it.id == profile.id }
        if (idx >= 0) current[idx] = profile else current.add(profile)
        networkSettings = networkSettings.copy(wanConnections = current)
        prependActivity(
            title = "WAN Profile Saved (Demo)",
            description = "${profile.name} (${profile.connectionType.label}, VLAN ${profile.vlanId ?: "Untagged"}).",
            category = ActivityCategory.NETWORK,
            severity = ActivitySeverity.INFO
        )
        return networkSettings
    }

    fun deleteWanConnection(profileId: String): NetworkSettings {
        networkSettings = networkSettings.copy(
            wanConnections = networkSettings.wanConnections.filterNot { it.id == profileId }
        )
        prependActivity(
            title = "WAN Profile Removed (Demo)",
            description = "Removed WAN interface $profileId in Demo Sandbox.",
            category = ActivityCategory.NETWORK,
            severity = ActivitySeverity.WARNING
        )
        return networkSettings
    }

    fun getOpticalInfo(): OpticalInfo = OpticalInfo(
        ponMode = "GPON · Class B+ SFP",
        linkState = "O5 (Operation State)",
        rxPowerDbm = -18.4f,
        txPowerDbm = 2.3f,
        temperatureC = 43.2f,
        voltageV = 3.29f,
        biasCurrentMa = 14.6f
    )

    fun getEthernetPorts(): List<EthernetPortInfo> = listOf(
        EthernetPortInfo(1, "LAN 1", isUp = true, speedLabel = "2500 Mbps", duplexLabel = "Full Duplex", macLearnedCount = 1),
        EthernetPortInfo(2, "LAN 2", isUp = true, speedLabel = "1000 Mbps", duplexLabel = "Full Duplex", macLearnedCount = 1),
        EthernetPortInfo(3, "LAN 3", isUp = false, speedLabel = "IDLE", duplexLabel = "Disconnected", macLearnedCount = 0),
        EthernetPortInfo(4, "LAN 4", isUp = false, speedLabel = "IDLE", duplexLabel = "Disconnected", macLearnedCount = 0)
    )

    fun getInterfaceStats(): List<InterfaceStat> = listOf(
        InterfaceStat("br-lan", "LAN Bridge", isUp = true, rxBytes = 148_291_482_110L, txBytes = 472_194_820_112L, rxPackets = 112_940_120L, txPackets = 342_810_400L, rxErrors = 0, txErrors = 0, droppedPackets = 4),
        InterfaceStat("eth0.100", "WAN Fiber PPPoE", isUp = true, rxBytes = 475_242_818_422L, txBytes = 238_563_191_720L, rxPackets = 368_192_010L, txPackets = 198_420_110L, rxErrors = 0, txErrors = 0, droppedPackets = 12),
        InterfaceStat("wlan0", "2.4 GHz Radio", isUp = wifiConfig.masterWifiEnabled && wifiConfig.band24.enabled, rxBytes = 18_492_100_400L, txBytes = 64_120_980_000L, rxPackets = 28_491_020L, txPackets = 51_280_100L, rxErrors = 2, txErrors = 0, droppedPackets = 19),
        InterfaceStat("wlan1", "5 GHz Radio", isUp = wifiConfig.masterWifiEnabled && (wifiConfig.band5?.enabled == true), rxBytes = 112_840_192_000L, txBytes = 384_920_481_000L, rxPackets = 92_104_820L, txPackets = 284_910_440L, rxErrors = 0, txErrors = 0, droppedPackets = 6)
    )

    fun getVoipStatus(): List<VoipLineInfo> = listOf(
        VoipLineInfo(1, "+1 (555) 014-8820", "sip.northstar-fiber.example", "Registered (TLS)", isRegistered = true, lastCallStatus = "Idle · No missed calls"),
        VoipLineInfo(2, "FXS Port 2 (Unassigned)", "Not configured", "Disabled", isRegistered = false, lastCallStatus = "Port idle")
    )

    fun getParentalTemplates(): List<ParentalControlTemplate> = parentalTemplates

    fun saveParentalTemplate(template: ParentalControlTemplate): List<ParentalControlTemplate> {
        val list = parentalTemplates.toMutableList()
        val idx = list.indexOfFirst { it.id == template.id }
        if (idx >= 0) list[idx] = template else list.add(template)
        parentalTemplates = list
        prependActivity(
            title = "Parental Template Updated (Demo)",
            description = "${template.name} (${template.scheduleWindow}).",
            category = ActivityCategory.SECURITY,
            severity = ActivitySeverity.INFO
        )
        return parentalTemplates
    }

    fun deleteParentalTemplate(templateId: String): List<ParentalControlTemplate> {
        parentalTemplates = parentalTemplates.filterNot { it.id == templateId }
        prependActivity(
            title = "Parental Template Deleted (Demo)",
            description = "Removed template $templateId in Demo Sandbox.",
            category = ActivityCategory.SECURITY,
            severity = ActivitySeverity.WARNING
        )
        return parentalTemplates
    }

    fun runSpeedTest(): SpeedTestResult {
        prependActivity(
            title = "WAN Speed Test Completed (Demo)",
            description = "Simulated WAN probe: 486.4 Mbps Down / 241.8 Mbps Up · 9 ms ping.",
            category = ActivityCategory.NETWORK,
            severity = ActivitySeverity.INFO
        )
        return SpeedTestResult(
            pingMs = 9,
            jitterMs = 2,
            downloadMbps = 486.4f,
            uploadMbps = 241.8f,
            serverLabel = "Northstar Fiber Edge · Sandbox",
            timestampLabel = "Just now"
        )
    }

    fun runDiagnostics(): List<DiagnosticResult> {
        prependActivity(
            title = "Demo Diagnostics Completed",
            description = "Gateway, DNS, and WAN reachability probes completed in Demo Sandbox.",
            category = ActivityCategory.SYSTEM,
            severity = ActivitySeverity.INFO
        )
        return listOf(
            DiagnosticResult(
                id = "diag-1",
                testName = "WAN Gateway Ping",
                target = networkSettings.wan.gatewayIp,
                status = DiagnosticStatus.PASS,
                latencyMs = 4,
                summary = "0% packet loss across 4 ICMP probes (Demo Sandbox).",
                timestampLabel = "Just now"
            ),
            DiagnosticResult(
                id = "diag-2",
                testName = "Primary DNS Resolution",
                target = networkSettings.dns.primaryDns,
                status = DiagnosticStatus.PASS,
                latencyMs = 11,
                summary = "Resolved A/AAAA records cleanly (Demo Sandbox).",
                timestampLabel = "Just now"
            ),
            DiagnosticResult(
                id = "diag-3",
                testName = "Upstream Internet Reachability",
                target = "1.1.1.1",
                status = DiagnosticStatus.PASS,
                latencyMs = 12,
                summary = "MTU 1500 path verified without fragmentation (Demo Sandbox).",
                timestampLabel = "Just now"
            )
        )
    }

    fun rebootDemoRouter() {
        routerInfo = routerInfo.copy(uptimeSeconds = 12L)
        prependActivity(
            title = "Demo Router Reboot Simulated",
            description = "Demo sandbox uptime reset after simulated reboot sequence.",
            category = ActivityCategory.SYSTEM,
            severity = ActivitySeverity.WARNING
        )
    }

    fun sampleSavedProfiles(): List<RouterProfile> = listOf(
        RouterProfile(
            id = "demo-profile-asus",
            displayName = "Home Fiber Gateway (Demo)",
            manufacturer = "ASUS",
            model = "RT-AX86U Pro",
            hostIp = "192.168.50.1",
            port = 8443,
            useHttps = true,
            username = "admin",
            hasStoredPassword = false,
            firmwareVersion = "3.0.0.4.388_24328",
            lastConnectedEpochMs = null
        )
    )

    private fun prependActivity(
        title: String,
        description: String,
        category: ActivityCategory,
        severity: ActivitySeverity
    ) {
        activityEvents.add(
            0,
            NetworkActivityEvent(
                id = "evt-${UUID.randomUUID().toString().take(8)}",
                timestampLabel = "Just now",
                title = title,
                description = description,
                category = category,
                severity = severity
            )
        )
        if (activityEvents.size > 20) {
            activityEvents = activityEvents.take(20).toMutableList()
        }
    }
}
