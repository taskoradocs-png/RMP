package com.example.features.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.adapters.AdapterMatchResult
import com.example.core.AccentColorOption
import com.example.core.AppMode
import com.example.core.CornerStyleOption
import com.example.core.RouterResult
import com.example.core.ThemePreference
import com.example.core.ThemeStyleOption
import com.example.core.Validators
import com.example.database.AppSecurityPreferences
import com.example.models.AdapterDescriptor
import com.example.models.DiscoveredRouter
import com.example.models.RouterCredentials
import com.example.models.RouterProfile
import com.example.models.RouterSession
import com.example.repositories.RouterRepository
import com.example.repositories.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

data class DiscoveryUiState(
    val isScanning: Boolean = false,
    val isWifiActive: Boolean = false,
    val interfaceName: String? = null,
    val localIpv4Address: String? = null,
    val localGatewayIp: String? = null,
    val gatewayReachable: Boolean = false,
    val discoveredRouters: List<DiscoveredRouter> = emptyList(),
    val statusMessage: String = "Inspect active Wi-Fi/LAN interface, local IPv4, default gateway, and HTTP/HTTPS admin ports."
)

data class LoginResultState(
    val isSubmitting: Boolean = false,
    val errorMessage: String? = null,
    val successMessage: String? = null
)

class SettingsViewModel(
    private val settingsRepository: SettingsRepository,
    private val routerRepository: RouterRepository
) : ViewModel() {

    val preferences: StateFlow<AppSecurityPreferences> = settingsRepository.preferencesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AppSecurityPreferences()
        )

    val savedProfiles: StateFlow<List<RouterProfile>> = settingsRepository.savedProfilesFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val appMode: StateFlow<AppMode> = routerRepository.appMode
    val currentSession: StateFlow<RouterSession?> = routerRepository.currentSession

    private val _discoveryState = MutableStateFlow(DiscoveryUiState())
    val discoveryState: StateFlow<DiscoveryUiState> = _discoveryState.asStateFlow()

    private val _loginState = MutableStateFlow(LoginResultState())
    val loginState: StateFlow<LoginResultState> = _loginState.asStateFlow()

    private val _compatibilityMatch = MutableStateFlow<AdapterMatchResult?>(null)
    val compatibilityMatch: StateFlow<AdapterMatchResult?> = _compatibilityMatch.asStateFlow()

    val supportedAdapters: List<AdapterDescriptor> = routerRepository.getSupportedAdapters()

    fun setAppMode(mode: AppMode) {
        viewModelScope.launch {
            settingsRepository.setAppMode(mode)
        }
    }

    fun setThemePreference(theme: ThemePreference) {
        viewModelScope.launch {
            settingsRepository.setThemePreference(theme)
        }
    }

    fun setAccentColor(accent: AccentColorOption) {
        viewModelScope.launch {
            settingsRepository.setAccentColor(accent)
        }
    }

    fun setThemeStyle(style: ThemeStyleOption) {
        viewModelScope.launch {
            settingsRepository.setThemeStyle(style)
        }
    }

    fun setCornerStyle(corner: CornerStyleOption) {
        viewModelScope.launch {
            settingsRepository.setCornerStyle(corner)
        }
    }

    fun setAppPinLockEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setAppPinLockEnabled(enabled)
        }
    }

    fun setConfirmDestructiveActions(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setConfirmDestructiveActions(enabled)
        }
    }

    fun setAutoClearSessionOnBackground(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepository.setAutoClearSessionOnBackground(enabled)
        }
    }

    fun runGatewayDiscovery() {
        viewModelScope.launch {
            _discoveryState.value = _discoveryState.value.copy(isScanning = true)
            val result = routerRepository.inspectLocalGateway()
            _discoveryState.value = DiscoveryUiState(
                isScanning = false,
                isWifiActive = result.isWifiActive,
                interfaceName = result.interfaceName,
                localIpv4Address = result.localIpv4Address,
                localGatewayIp = result.localGatewayIp,
                gatewayReachable = result.gatewayReachable,
                discoveredRouters = result.routers,
                statusMessage = result.statusMessage
            )
        }
    }

    fun checkCompatibility(manufacturer: String, model: String, firmware: String) {
        _compatibilityMatch.value = routerRepository.matchAdapter(manufacturer, model, firmware)
    }

    fun authenticateAndSaveProfile(
        profileId: String?,
        displayName: String,
        adapterId: String,
        hostIp: String,
        portText: String,
        useHttps: Boolean,
        username: String,
        password: String,
        saveCredentialsEncrypted: Boolean,
        allowSelfSignedTls: Boolean = false
    ) {
        val hostCheck = Validators.validateHostOrIp(hostIp, "Router host")
        if (!hostCheck.isValid) {
            _loginState.value = LoginResultState(errorMessage = hostCheck.errorOrNull)
            return
        }
        val portCheck = Validators.validatePort(portText, "Admin port")
        if (!portCheck.isValid) {
            _loginState.value = LoginResultState(errorMessage = portCheck.errorOrNull)
            return
        }
        if (username.isBlank()) {
            _loginState.value = LoginResultState(errorMessage = "Admin username is required.")
            return
        }
        if (password.isBlank()) {
            _loginState.value = LoginResultState(errorMessage = "Router password is required.")
            return
        }

        val port = portText.trim().toInt()
        val adapterDesc = supportedAdapters.firstOrNull { it.id == adapterId }

        viewModelScope.launch {
            _loginState.value = LoginResultState(isSubmitting = true)

            val resolvedId = profileId ?: "prof-${UUID.randomUUID().toString().take(8)}"
            val profile = RouterProfile(
                id = resolvedId,
                displayName = displayName.ifBlank { "${adapterDesc?.manufacturer ?: "Router"} ($hostIp)" },
                manufacturer = adapterDesc?.manufacturer ?: "Custom",
                model = adapterDesc?.supportedModels?.firstOrNull() ?: "Gateway",
                hostIp = hostIp.trim(),
                port = port,
                useHttps = useHttps,
                username = username.trim(),
                hasStoredPassword = saveCredentialsEncrypted,
                firmwareVersion = adapterDesc?.minFirmwareVersion ?: "Unknown",
                lastConnectedEpochMs = null
            )
            settingsRepository.saveRouterProfile(
                profile = profile,
                plainPasswordToStore = if (saveCredentialsEncrypted) password else null
            )
            settingsRepository.setAppMode(AppMode.LIVE)

            val result = routerRepository.authenticateLive(
                adapterId = adapterId,
                credentials = RouterCredentials(
                    hostIp = hostIp.trim(),
                    port = port,
                    useHttps = useHttps,
                    username = username.trim(),
                    password = password,
                    allowSelfSignedTls = allowSelfSignedTls
                )
            )
            if (result is RouterResult.Success) {
                settingsRepository.saveRouterProfile(
                    profile = profile.copy(lastConnectedEpochMs = result.data.establishedAtEpochMs),
                    plainPasswordToStore = if (saveCredentialsEncrypted) password else null
                )
            }
            _loginState.value = when (result) {
                is RouterResult.Success -> LoginResultState(
                    isSubmitting = false,
                    successMessage = "Authenticated session established with ${result.data.routerIp}."
                )
                is RouterResult.Failure -> LoginResultState(
                    isSubmitting = false,
                    errorMessage = result.message
                )
                is RouterResult.NotConnected -> LoginResultState(
                    isSubmitting = false,
                    errorMessage = result.reason
                )
                is RouterResult.Unsupported -> LoginResultState(
                    isSubmitting = false,
                    errorMessage = result.reason
                )
                is RouterResult.AuthRequired -> LoginResultState(
                    isSubmitting = false,
                    errorMessage = result.reason
                )
                is RouterResult.ValidationError -> LoginResultState(
                    isSubmitting = false,
                    errorMessage = result.message
                )
            }
        }
    }

    suspend fun loadSavedPasswordForProfile(profileId: String): String {
        return settingsRepository.loadDecryptedPassword(profileId).orEmpty()
    }

    fun clearProfileCredentials(profileId: String) {
        viewModelScope.launch {
            settingsRepository.clearStoredPassword(profileId)
        }
    }

    fun deleteProfile(profileId: String) {
        viewModelScope.launch {
            settingsRepository.deleteProfile(profileId)
        }
    }

    fun disconnectLiveSession() {
        viewModelScope.launch {
            routerRepository.disconnectLive()
        }
    }

    fun clearLoginFeedback() {
        _loginState.value = LoginResultState()
    }
}
