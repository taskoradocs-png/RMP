package com.example.features.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.designsystem.AdminCard
import com.example.designsystem.InfoBanner
import com.example.designsystem.KeyValueRow
import com.example.designsystem.PillTone
import com.example.designsystem.SectionHeader
import com.example.designsystem.StatusPill
import com.example.models.RouterFeature

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SupportedRoutersScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit
) {
    val adapters = viewModel.supportedAdapters
    val matchResult by viewModel.compatibilityMatch.collectAsStateWithLifecycle()

    var manufacturerQuery by remember { mutableStateOf("") }
    var modelQuery by remember { mutableStateOf("") }
    var firmwareQuery by remember { mutableStateOf("") }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("supported_routers_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("Supported Routers", style = MaterialTheme.typography.headlineMedium)
                }
            }

            item {
                AdminCard {
                    SectionHeader(
                        title = "Adapter Compatibility Lookup",
                        subtitle = "Match manufacturer, model, and firmware via RouterAdapterRegistry"
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = manufacturerQuery,
                        onValueChange = { manufacturerQuery = it },
                        label = { Text("Manufacturer (e.g. ASUS, OpenWrt, TP-Link, Netgear)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = modelQuery,
                        onValueChange = { modelQuery = it },
                        label = { Text("Model (e.g. RT-AX86U Pro, Archer AX73)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = firmwareQuery,
                        onValueChange = { firmwareQuery = it },
                        label = { Text("Firmware Version (Optional)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = {
                            viewModel.checkCompatibility(manufacturerQuery, modelQuery, firmwareQuery)
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Text("Check Adapter Compatibility")
                    }
                    matchResult?.let { match ->
                        Spacer(Modifier.height(10.dp))
                        InfoBanner(
                            message = "${match.confidenceLabel}: ${match.adapter.descriptor.displayName} — ${match.reason}"
                        )
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Registered Adapter Profiles",
                    subtitle = "Capabilities declared honestly per vendor API"
                )
            }

            items(adapters, key = { it.id }) { adapter ->
                val missingFeatures = RouterFeature.entries.filter { !adapter.capability.supports(it) }
                AdminCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(adapter.displayName, style = MaterialTheme.typography.titleMedium)
                            Text(
                                text = "${adapter.manufacturer} · Min FW ${adapter.minFirmwareVersion}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        StatusPill(
                            label = if (adapter.isLiveTransportReady) "Live Ready" else "Interface Ready",
                            tone = if (adapter.isLiveTransportReady) PillTone.ONLINE else PillTone.INFO
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    KeyValueRow("Protocol", adapter.protocolDescription)
                    KeyValueRow("Models", adapter.supportedModels.joinToString(", "))
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = adapter.capability.capabilityNotes,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "Supported: ${adapter.capability.supportedFeatures.size} / ${RouterFeature.entries.size} capabilities",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (missingFeatures.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Unsupported on this adapter:",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(4.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            missingFeatures.forEach { feat ->
                                StatusPill(label = feat.displayName, tone = PillTone.NEUTRAL)
                            }
                        }
                    }
                }
            }
        }
    }
}
