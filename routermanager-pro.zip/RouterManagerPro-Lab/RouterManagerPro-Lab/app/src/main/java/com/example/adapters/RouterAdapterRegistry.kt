package com.example.adapters

import com.example.adapters.demo.DemoDataProvider
import com.example.authentication.RouterSessionManager

/**
 * Compatibility subclass delegating directly to RouterCapabilityRegistry.
 */
class RouterAdapterRegistry(
    demoDataProvider: DemoDataProvider,
    sessionManager: RouterSessionManager = RouterSessionManager()
) : RouterCapabilityRegistry(demoDataProvider, sessionManager)
