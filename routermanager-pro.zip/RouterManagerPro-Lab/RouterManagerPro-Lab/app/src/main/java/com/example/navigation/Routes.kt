package com.example.navigation

import kotlinx.serialization.Serializable

@Serializable
data object DashboardRoute

@Serializable
data object DevicesRoute

@Serializable
data class DeviceDetailRoute(val macAddress: String)

@Serializable
data object BlockedDevicesRoute

@Serializable
data class WifiRoute(val guestOnly: Boolean = false)

@Serializable
data object NetworkRoute

@Serializable
data object AdvancedRoute

@Serializable
data object ThemeRoute

@Serializable
data object SettingsRoute

@Serializable
data object OpticalInfoRoute

@Serializable
data object EthernetStatusRoute

@Serializable
data object InterfaceStatsRoute

@Serializable
data object DeviceInfoRoute

@Serializable
data object UsageStatsRoute

@Serializable
data object VoipStatusRoute

@Serializable
data object ParentalControlRoute

@Serializable
data object DnsSettingsRoute

@Serializable
data object WanConnectionsRoute

@Serializable
data object FirewallRoute

@Serializable
data object SpeedTestRoute

@Serializable
data object HelpGuideRoute

@Serializable
data object RouterDiscoveryRoute

@Serializable
data object SupportedRoutersRoute

@Serializable
data class RouterLoginRoute(
    val profileId: String? = null,
    val hostIp: String? = null,
    val port: Int? = null,
    val useHttps: Boolean? = null,
    val adapterId: String? = null
)
