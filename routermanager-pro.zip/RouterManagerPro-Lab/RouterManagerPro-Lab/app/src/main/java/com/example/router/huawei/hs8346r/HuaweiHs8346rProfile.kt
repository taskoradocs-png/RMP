package com.example.router.huawei.hs8346r

/** Evidence-backed profile for the user's Huawei HS8346R (HWTC) firmware. */
object HuaweiHs8346rProfile {
    const val MODEL = "Huawei HS8346R"
    const val HARDWARE_REVISION = "1257.A"
    const val FIRMWARE_VERSION = "V3R018C10S108"
    const val VENDOR_ID = "HWTC"
    const val DEFAULT_HTTP_PORT = 80

    object Paths {
        const val LOGIN = "/login.cgi"
        const val LOGOUT = "/logout.cgi"
        const val DEVICE_INFO = "/html/ssmp/deviceinfo/deviceinfo.asp"
        const val LAN_DEVICES = "/html/bbsp/common/GetLanUserDevInfo.asp"
        const val DHCP_INFO = "/html/bbsp/common/GetLanUserDhcpInfo.asp"
        const val WAN_LIST = "/html/bbsp/common/getwanlist.asp"
        const val WAN_LIST_INFO = "/html/bbsp/common/wan_list_info.asp"
        const val OPTICAL_DIAGNOSTICS = "/html/amp/common/getSmartDiagnoseResult.asp"
        const val WLAN_LIST = "/html/amp/common/wlan_list.asp"
        const val WLAN_BASIC = "/html/amp/wlanbasic/WlanBasic.asp"
        const val WLAN_ADVANCED = "/html/amp/wlanadv/WlanAdvance.asp"
    }

    object WritePaths {
        /** The page JavaScript constructs set.cgi?x=<TR-069 object path>. */
        const val SET = "/set.cgi"
        const val ADD = "/add.cgi"
        const val DELETE = "/del.cgi"
    }
}
