package com.example.adapters.live

import com.example.authentication.RouterSessionManager
import com.example.core.RouterResult
import com.example.models.AdapterDescriptor
import com.example.models.ConnectedDevice
import com.example.models.DhcpConfig
import com.example.models.DiagnosticResult
import com.example.models.DiagnosticStatus
import com.example.models.DnsConfig
import com.example.models.DnsMode
import com.example.models.EthernetPortInfo
import com.example.models.FirewallConfig
import com.example.models.FirewallLevel
import com.example.models.GuestNetworkConfig
import com.example.models.InterfaceStat
import com.example.models.LanConfig
import com.example.models.NetworkActivityEvent
import com.example.models.NetworkSettings
import com.example.models.OpticalInfo
import com.example.models.ParentalControlTemplate
import com.example.models.PortForwardRule
import com.example.models.ProtocolType
import com.example.models.RouterCapability
import com.example.models.RouterCredentials
import com.example.models.RouterFeature
import com.example.models.RouterInfo
import com.example.models.RouterSession
import com.example.models.SpeedTestResult
import com.example.models.TrafficSnapshot
import com.example.models.VoipLineInfo
import com.example.models.WanConnectionProfile
import com.example.models.WifiBand
import com.example.models.WifiBandConfig
import com.example.models.WifiConfig
import com.example.router.RouterAdapter
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import java.util.Locale
import java.util.UUID

/**
 * Live OpenWrt LuCI JSON-RPC adapter (/ubus primary + /cgi-bin/luci/rpc fallback).
 * Dynamically inspects exposed ubus objects to adapt across OpenWrt versions and returns
 * RouterResult.Unsupported for capabilities absent on the connected firmware.
 */
class OpenWrtAdapter(
    private val sessionManager: RouterSessionManager,
    private val rpcClient: OpenWrtRpcClient = OpenWrtRpcClient(sessionManager),
    private val clockMs: () -> Long = { System.currentTimeMillis() }
) : RouterAdapter {

    private val baselineCapabilities = RouterCapability(
        supportedFeatures = setOf(
            RouterFeature.ROUTER_INFO,
            RouterFeature.WIFI_BASIC,
            RouterFeature.WIFI_DUAL_BAND,
            RouterFeature.WIFI_GUEST_NETWORK,
            RouterFeature.WIFI_CHANNEL_CONFIG,
            RouterFeature.WIFI_BANDWIDTH_CONFIG,
            RouterFeature.DEVICE_LIST,
            RouterFeature.DEVICE_BLOCKING,
            RouterFeature.DEVICE_BAND_BLOCKING,
            RouterFeature.DEVICE_INTERNET_BLOCKING,
            RouterFeature.DEVICE_RENAME,
            RouterFeature.STATIC_IP_RESERVATION,
            RouterFeature.TRAFFIC_MONITORING,
            RouterFeature.INTERFACE_STATS,
            RouterFeature.WAN_INFO,
            RouterFeature.LAN_CONFIG,
            RouterFeature.DHCP_CONFIG,
            RouterFeature.DNS_CONFIG,
            RouterFeature.PORT_FORWARDING,
            RouterFeature.FIREWALL_CONFIG,
            RouterFeature.NETWORK_DIAGNOSTICS,
            RouterFeature.ROUTER_REBOOT
        ),
        supports5Ghz = true,
        maxGuestNetworks = 1,
        capabilityNotes = "OpenWrt LuCI JSON-RPC (/ubus & UCI). Runtime capabilities are scoped per firmware objects."
    )

    @Volatile
    private var runtimeCapabilities: RouterCapability = baselineCapabilities

    override val capabilities: RouterCapability
        get() = runtimeCapabilities

    override val descriptor: AdapterDescriptor = AdapterDescriptor(
        id = ADAPTER_ID,
        displayName = "OpenWrt LuCI (ubus JSON-RPC)",
        manufacturer = "OpenWrt",
        supportedModels = listOf("OpenWrt 19.07+", "OpenWrt 21.02–24.10", "GL.iNet Flint / Beryl"),
        minFirmwareVersion = "19.07",
        protocolDescription = "HTTP/HTTPS JSON-RPC (/ubus & /cgi-bin/luci/rpc)",
        capability = baselineCapabilities,
        isLiveTransportReady = true
    )

    @Volatile
    private var activeTarget: OpenWrtConnectionTarget? = null

    @Volatile
    private var protocolMode: OpenWrtTransportProtocol = OpenWrtTransportProtocol.UBUS_JSON_RPC

    @Volatile
    private var availableUbusObjects: Set<String> = emptySet()

    @Volatile
    private var cachedWirelessSections: OpenWrtWirelessSectionMap = OpenWrtWirelessSectionMap()

    @Volatile
    private var lastTrafficSample: Triple<Long, Long, Long>? = null // (timestampMs, rxBytes, txBytes)

    override suspend fun authenticate(credentials: RouterCredentials): RouterResult<RouterSession> {
        val target = OpenWrtConnectionTarget(
            hostIp = credentials.hostIp.trim(),
            port = credentials.port,
            useHttps = credentials.useHttps,
            allowSelfSignedTls = credentials.allowSelfSignedTls
        )

        val loginOutcome = when (val res = rpcClient.login(target, credentials.username, credentials.password)) {
            is RouterResult.Success -> res.data
            is RouterResult.Failure -> return res
            is RouterResult.AuthRequired -> return RouterResult.Failure(res.reason)
            is RouterResult.Unsupported -> return res
            is RouterResult.NotConnected -> return res
            is RouterResult.ValidationError -> return res
        }

        activeTarget = target
        protocolMode = loginOutcome.protocol
        lastTrafficSample = null

        val now = clockMs()
        val expiresAt = now + (loginOutcome.timeoutSeconds.coerceAtLeast(30L) * 1000L)
        val session = RouterSession(
            sessionId = "openwrt-${UUID.randomUUID().toString().take(8)}",
            profileId = null,
            routerIp = target.hostIp,
            adapterId = descriptor.id,
            authenticatedUsername = credentials.username,
            establishedAtEpochMs = now,
            isDemoSession = false,
            expiresAtEpochMs = expiresAt,
            hasCsrfToken = !loginOutcome.csrfToken.isNullOrBlank(),
            cookieCount = loginOutcome.cookieCount,
            protocolVersionHint = loginOutcome.protocol.label
        )
        sessionManager.startSession(
            session = session,
            rpcSessionToken = loginOutcome.sessionToken,
            csrfToken = loginOutcome.csrfToken,
            expiresAtEpochMs = expiresAt
        )

        probeRuntimeCapabilities(target)

        return RouterResult.Success(sessionManager.currentSession.value ?: session, isDemoData = false)
    }

    private suspend fun probeRuntimeCapabilities(target: OpenWrtConnectionTarget) {
        if (protocolMode == OpenWrtTransportProtocol.LUCI_MOD_RPC) {
            availableUbusObjects = emptySet()
            runtimeCapabilities = RouterCapability(
                supportedFeatures = setOf(
                    RouterFeature.ROUTER_INFO,
                    RouterFeature.WIFI_BASIC,
                    RouterFeature.DEVICE_LIST,
                    RouterFeature.LAN_CONFIG,
                    RouterFeature.ROUTER_REBOOT
                ),
                supports5Ghz = true,
                maxGuestNetworks = 1,
                capabilityNotes = "Legacy OpenWrt LuCI RPC (/cgi-bin/luci/rpc) mode; ubus telemetry endpoints omitted."
            )
            return
        }

        val listResult = rpcClient.listUbusObjects(target)
        val objs = (listResult as? RouterResult.Success)?.data.orEmpty()
        availableUbusObjects = objs

        // If `list` returned empty (some rpcd configurations restrict `list`), keep conservative defaults and gate per call
        if (objs.isEmpty()) {
            runtimeCapabilities = baselineCapabilities
            return
        }

        val supported = mutableSetOf<RouterFeature>()
        if ("system" in objs) {
            supported.add(RouterFeature.ROUTER_INFO)
            supported.add(RouterFeature.ROUTER_REBOOT)
        }
        if ("uci" in objs) {
            supported.add(RouterFeature.WIFI_BASIC)
            supported.add(RouterFeature.WIFI_DUAL_BAND)
            supported.add(RouterFeature.WIFI_GUEST_NETWORK)
            supported.add(RouterFeature.WIFI_CHANNEL_CONFIG)
            supported.add(RouterFeature.WIFI_BANDWIDTH_CONFIG)
            supported.add(RouterFeature.DEVICE_BLOCKING)
            supported.add(RouterFeature.DEVICE_BAND_BLOCKING)
            supported.add(RouterFeature.DEVICE_INTERNET_BLOCKING)
            supported.add(RouterFeature.DEVICE_RENAME)
            supported.add(RouterFeature.STATIC_IP_RESERVATION)
            supported.add(RouterFeature.LAN_CONFIG)
            supported.add(RouterFeature.DHCP_CONFIG)
            supported.add(RouterFeature.DNS_CONFIG)
            supported.add(RouterFeature.PORT_FORWARDING)
            supported.add(RouterFeature.FIREWALL_CONFIG)
        }
        if ("iwinfo" in objs || "luci-rpc" in objs || "dhcp" in objs) {
            supported.add(RouterFeature.DEVICE_LIST)
        }
        if ("network.device" in objs) {
            supported.add(RouterFeature.TRAFFIC_MONITORING)
            supported.add(RouterFeature.INTERFACE_STATS)
        }
        if ("network.interface" in objs) {
            supported.add(RouterFeature.WAN_INFO)
        }
        if ("network.ping" in objs || "luci-rpc" in objs) {
            supported.add(RouterFeature.NETWORK_DIAGNOSTICS)
        }

        runtimeCapabilities = RouterCapability(
            supportedFeatures = supported,
            supports5Ghz = supported.contains(RouterFeature.WIFI_DUAL_BAND),
            maxGuestNetworks = if (supported.contains(RouterFeature.WIFI_GUEST_NETWORK)) 1 else 0,
            capabilityNotes = "Detected OpenWrt ubus modules: ${objs.sorted().joinToString(", ")}"
        )
    }

    override suspend fun disconnect(): RouterResult<Unit> {
        activeTarget = null
        availableUbusObjects = emptySet()
        lastTrafficSample = null
        runtimeCapabilities = baselineCapabilities
        sessionManager.clearSession()
        return RouterResult.Success(Unit)
    }

    override suspend fun getRouterInfo(): RouterResult<RouterInfo> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        if (protocolMode == OpenWrtTransportProtocol.LUCI_MOD_RPC) {
            val uptimeRes = rpcClient.callLegacyLuciRpc(target, "sys", "uptime")
            if (uptimeRes is RouterResult.AuthRequired) return uptimeRes
            if (uptimeRes is RouterResult.Failure) return uptimeRes
            val uptime = (uptimeRes as? RouterResult.Success)?.data?.jsonPrimitive?.longOrNull ?: 0L
            return RouterResult.Success(
                OpenWrtDataMapper.mapRouterInfo(
                    hostIp = target.hostIp,
                    adapterId = descriptor.id,
                    adapterDisplayName = descriptor.displayName,
                    boardObj = null,
                    infoObj = buildJsonObject { put("uptime", JsonPrimitive(uptime)) },
                    interfaceDumpObj = null
                )
            )
        }

        val boardRes = rpcClient.callUbus(target, "system", "board")
        when (boardRes) {
            is RouterResult.AuthRequired, is RouterResult.Failure, is RouterResult.NotConnected -> return boardRes
            else -> Unit
        }
        val infoRes = rpcClient.callUbus(target, "system", "info")
        if (infoRes is RouterResult.AuthRequired) return infoRes

        val ifaceRes = if (hasObject("network.interface")) {
            rpcClient.callUbus(target, "network.interface", "dump")
        } else null
        if (ifaceRes is RouterResult.AuthRequired) return ifaceRes

        val boardObj = (boardRes as? RouterResult.Success)?.data
        val infoObj = (infoRes as? RouterResult.Success)?.data
        val ifaceObj = (ifaceRes as? RouterResult.Success)?.data
        if (boardObj == null && infoObj == null) {
            return (boardRes as? RouterResult.Unsupported)
                ?: RouterResult.Unsupported("Router Info", "OpenWrt system.board and system.info are unavailable.")
        }

        return RouterResult.Success(
            OpenWrtDataMapper.mapRouterInfo(
                hostIp = target.hostIp,
                adapterId = descriptor.id,
                adapterDisplayName = descriptor.displayName,
                boardObj = boardObj,
                infoObj = infoObj,
                interfaceDumpObj = ifaceObj
            )
        )
    }

    override suspend fun getTrafficSnapshot(): RouterResult<TrafficSnapshot> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        if (protocolMode == OpenWrtTransportProtocol.LUCI_MOD_RPC || !hasObject("network.device")) {
            return RouterResult.Unsupported(
                featureName = RouterFeature.TRAFFIC_MONITORING.displayName,
                reason = "OpenWrt network.device.status ubus endpoint is not available on this firmware."
            )
        }
        return when (val devRes = rpcClient.callUbus(target, "network.device", "status")) {
            is RouterResult.Success -> {
                val stats = OpenWrtDataMapper.mapInterfaceStats(devRes.data)
                if (stats.isEmpty()) {
                    return RouterResult.Unsupported(
                        featureName = RouterFeature.TRAFFIC_MONITORING.displayName,
                        reason = "OpenWrt network.device.status returned no interface counters."
                    )
                }
                val now = clockMs()
                val prev = lastTrafficSample
                val (snapshot, rx, tx) = OpenWrtDataMapper.computeTrafficSnapshot(
                    stats = stats,
                    previousRxBytes = prev?.second,
                    previousTxBytes = prev?.third,
                    previousTimestampMs = prev?.first,
                    nowMs = now
                )
                lastTrafficSample = Triple(now, rx, tx)
                RouterResult.Success(snapshot)
            }
            is RouterResult.AuthRequired,
            is RouterResult.Unsupported,
            is RouterResult.Failure,
            is RouterResult.NotConnected,
            is RouterResult.ValidationError -> devRes
        }
    }

    override suspend fun getRecentActivity(): RouterResult<List<NetworkActivityEvent>> {
        if (requireTarget() == null) return RouterResult.NotConnected("No active live OpenWrt session.")
        // OpenWrt /ubus does not standardize an audit event feed without custom logread ACLs; return empty real list without fabricating events
        return RouterResult.Success(emptyList())
    }

    override suspend fun getWifiConfig(): RouterResult<WifiConfig> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val wirelessRes = readUciConfig(target, "wireless")
        val wirelessObj = when (wirelessRes) {
            is RouterResult.Success -> wirelessRes.data
            is RouterResult.AuthRequired,
            is RouterResult.Unsupported,
            is RouterResult.Failure,
            is RouterResult.NotConnected,
            is RouterResult.ValidationError -> return wirelessRes
        }

        val counts = fetchAssocClientCountsByDevice(target)
        val (wifiConfig, sections) = OpenWrtDataMapper.mapWifiConfig(wirelessObj, counts)
        cachedWirelessSections = sections
        return RouterResult.Success(wifiConfig)
    }

    override suspend fun setWifiEnabled(enabled: Boolean): RouterResult<WifiConfig> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        if (cachedWirelessSections.radio2gSection == null && cachedWirelessSections.iface2gSection == null) {
            getWifiConfig()
        }
        val sections = cachedWirelessSections
        val targets = listOfNotNull(sections.radio2gSection, sections.radio5gSection)
        if (targets.isEmpty()) {
            return RouterResult.Unsupported(
                featureName = RouterFeature.WIFI_BASIC.displayName,
                reason = "No OpenWrt wifi-device sections found in /etc/config/wireless."
            )
        }
        val disabledVal = if (enabled) "0" else "1"
        for (sec in targets) {
            val res = uciSetAndKeep(target, "wireless", sec, mapOf("disabled" to disabledVal))
            if (res !is RouterResult.Success) return res as RouterResult<WifiConfig>
        }
        val commit = uciCommit(target, "wireless")
        if (commit !is RouterResult.Success) return commit as RouterResult<WifiConfig>
        return getWifiConfig()
    }

    override suspend fun updateSsid(band: WifiBand, ssid: String): RouterResult<WifiConfig> {
        val current = getWifiConfig()
        if (current !is RouterResult.Success) return current
        val bandCfg = if (band == WifiBand.BAND_5_GHZ) {
            current.data.band5 ?: return RouterResult.Unsupported("5 GHz Wi-Fi", "5 GHz radio is not present on this OpenWrt device.")
        } else {
            current.data.band24
        }
        return updateWifiBandConfig(band, bandCfg.copy(ssid = ssid))
    }

    override suspend fun updateWifiPassword(band: WifiBand, password: String): RouterResult<WifiConfig> {
        val current = getWifiConfig()
        if (current !is RouterResult.Success) return current
        val bandCfg = if (band == WifiBand.BAND_5_GHZ) {
            current.data.band5 ?: return RouterResult.Unsupported("5 GHz Wi-Fi", "5 GHz radio is not present on this OpenWrt device.")
        } else {
            current.data.band24
        }
        return updateWifiBandConfig(band, bandCfg.copy(password = password))
    }

    override suspend fun updateWifiBandConfig(band: WifiBand, config: WifiBandConfig): RouterResult<WifiConfig> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        if (cachedWirelessSections.iface2gSection == null && cachedWirelessSections.iface5gSection == null) {
            getWifiConfig()
        }
        val sections = cachedWirelessSections
        val radioSec = if (band == WifiBand.BAND_5_GHZ) sections.radio5gSection else sections.radio2gSection
        val ifaceSec = if (band == WifiBand.BAND_5_GHZ) sections.iface5gSection else sections.iface2gSection

        if (radioSec == null || ifaceSec == null) {
            return RouterResult.Unsupported(
                featureName = "${band.label} Wi-Fi",
                reason = "No ${band.label} radio/interface section found in OpenWrt UCI wireless configuration."
            )
        }

        val radioValues = mapOf(
            "channel" to config.channel,
            "htmode" to OpenWrtDataMapper.mapBandwidthToHtMode(config.bandwidthMhz, band == WifiBand.BAND_5_GHZ),
            "disabled" to if (config.enabled) "0" else "1"
        )
        val rSet = uciSetAndKeep(target, "wireless", radioSec, radioValues)
        if (rSet !is RouterResult.Success) return rSet as RouterResult<WifiConfig>

        val ifaceValues = buildMap {
            put("ssid", config.ssid)
            put("encryption", OpenWrtDataMapper.mapSecurityToEncryption(config.securityMode))
            put("disabled", if (config.enabled) "0" else "1")
            put("hidden", if (config.hiddenSsid) "1" else "0")
            if (config.securityMode.requiresPassphrase) {
                put("key", config.password)
            }
        }
        val iSet = uciSetAndKeep(target, "wireless", ifaceSec, ifaceValues)
        if (iSet !is RouterResult.Success) return iSet as RouterResult<WifiConfig>

        val commit = uciCommit(target, "wireless")
        if (commit !is RouterResult.Success) return commit as RouterResult<WifiConfig>
        return getWifiConfig()
    }

    override suspend fun updateGuestNetwork(config: GuestNetworkConfig): RouterResult<WifiConfig> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        if (cachedWirelessSections.guestIfaceSection == null) {
            getWifiConfig()
        }
        val guestSec = cachedWirelessSections.guestIfaceSection
            ?: return RouterResult.Unsupported(
                featureName = RouterFeature.WIFI_GUEST_NETWORK.displayName,
                reason = "No guest wifi-iface section configured in OpenWrt /etc/config/wireless."
            )

        val values = buildMap {
            put("disabled", if (config.enabled) "0" else "1")
            put("ssid", config.ssid)
            put("encryption", OpenWrtDataMapper.mapSecurityToEncryption(config.securityMode))
            put("isolate", if (config.isolateClients) "1" else "0")
            if (config.securityMode.requiresPassphrase) {
                put("key", config.password)
            }
        }
        val setRes = uciSetAndKeep(target, "wireless", guestSec, values)
        if (setRes !is RouterResult.Success) return setRes as RouterResult<WifiConfig>
        val commit = uciCommit(target, "wireless")
        if (commit !is RouterResult.Success) return commit as RouterResult<WifiConfig>
        return getWifiConfig()
    }

    override suspend fun getConnectedDevices(): RouterResult<List<ConnectedDevice>> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        if (protocolMode == OpenWrtTransportProtocol.LUCI_MOD_RPC) {
            val hintsRes = rpcClient.callLegacyLuciRpc(target, "net", "ipv4_hints")
            if (hintsRes is RouterResult.AuthRequired || hintsRes is RouterResult.Failure) {
                @Suppress("UNCHECKED_CAST")
                return hintsRes as RouterResult<List<ConnectedDevice>>
            }
            if (hintsRes is RouterResult.Unsupported) return hintsRes
            val arr = (hintsRes as? RouterResult.Success)?.data as? JsonArray
                ?: return RouterResult.Unsupported("Connected Clients", "Legacy LuCI RPC returned no ipv4_hints.")
            val hintsObj = buildJsonObject {
                arr.forEach { el ->
                    val pair = el as? JsonArray ?: return@forEach
                    val ip = pair.getOrNull(0)?.jsonPrimitive?.content ?: return@forEach
                    val name = pair.getOrNull(1)?.jsonPrimitive?.content
                    put("00:00:00:00:00:00", buildJsonObject {
                        if (name != null) put("name", JsonPrimitive(name))
                        put("ipaddrs", buildJsonArray { add(JsonPrimitive(ip)) })
                    })
                }
            }
            return RouterResult.Success(
                OpenWrtDataMapper.mapConnectedDevices(emptyList(), null, hintsObj, null, null, null)
            )
        }

        val hasClientSource = availableUbusObjects.isEmpty() ||
            hasObject("iwinfo") ||
            hasObject("luci-rpc") ||
            hasObject("dhcp")
        if (!hasClientSource) {
            return RouterResult.Unsupported(
                featureName = RouterFeature.DEVICE_LIST.displayName,
                reason = "This OpenWrt firmware does not expose iwinfo, luci-rpc, or dhcp lease ubus APIs."
            )
        }

        val assocSamples = fetchAssocClients(target)
        val dhcpLeasesRes = when {
            hasObject("luci-rpc") -> rpcClient.callUbus(target, "luci-rpc", "getDHCPLeases")
            hasObject("dhcp") -> rpcClient.callUbus(target, "dhcp", "ipv4leases")
            else -> null
        }
        if (dhcpLeasesRes is RouterResult.AuthRequired) return dhcpLeasesRes

        val hintsRes = if (hasObject("luci-rpc")) {
            rpcClient.callUbus(target, "luci-rpc", "getHostHints")
        } else null
        if (hintsRes is RouterResult.AuthRequired) return hintsRes

        if (assocSamples == null &&
            dhcpLeasesRes !is RouterResult.Success &&
            hintsRes !is RouterResult.Success
        ) {
            val firstUnsupported = (dhcpLeasesRes as? RouterResult.Unsupported)
                ?: (hintsRes as? RouterResult.Unsupported)
            return firstUnsupported ?: RouterResult.Unsupported(
                featureName = RouterFeature.DEVICE_LIST.displayName,
                reason = "OpenWrt firmware refused or omitted wireless association and DHCP lease endpoints."
            )
        }

        val uciWireless = (readUciConfig(target, "wireless") as? RouterResult.Success)?.data
        val uciFirewall = (readUciConfig(target, "firewall") as? RouterResult.Success)?.data
        val uciDhcp = (readUciConfig(target, "dhcp") as? RouterResult.Success)?.data

        val devices = OpenWrtDataMapper.mapConnectedDevices(
            assocClients = assocSamples.orEmpty(),
            dhcpLeasesObj = (dhcpLeasesRes as? RouterResult.Success)?.data,
            hostHintsObj = (hintsRes as? RouterResult.Success)?.data,
            uciWirelessObj = uciWireless,
            uciFirewallObj = uciFirewall,
            uciDhcpObj = uciDhcp
        )
        return RouterResult.Success(devices)
    }

    override suspend fun renameDevice(macAddress: String, newName: String): RouterResult<Unit> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val normMac = OpenWrtDataMapper.normalizeMac(macAddress)
        val dhcpObj = (readUciConfig(target, "dhcp") as? RouterResult.Success)?.data
            ?: return RouterResult.Unsupported("Device Rename", "UCI dhcp config cannot be read.")
        val values = (dhcpObj["values"] as? JsonObject) ?: dhcpObj
        val existingSection = values.entries.firstOrNull { (_, el) ->
            val obj = el as? JsonObject
            obj?.get(".type")?.jsonPrimitive?.content == "host" &&
                obj["mac"]?.jsonPrimitive?.content?.equals(normMac, ignoreCase = true) == true
        }?.key

        val res = if (existingSection != null) {
            uciSetAndKeep(target, "dhcp", existingSection, mapOf("name" to newName.trim()))
        } else {
            uciAdd(target, "dhcp", "host", mapOf("mac" to normMac, "name" to newName.trim()))
        }
        if (res !is RouterResult.Success) return res as RouterResult<Unit>
        return uciCommit(target, "dhcp").toUnitResult()
    }

    override suspend fun blockDevice(macAddress: String): RouterResult<Unit> =
        updateWifiMacBlock(macAddress, bandFilter = null, blocked = true)

    override suspend fun unblockDevice(macAddress: String): RouterResult<Unit> =
        updateWifiMacBlock(macAddress, bandFilter = null, blocked = false)

    override suspend fun setDeviceBandBlocked(macAddress: String, band: WifiBand, blocked: Boolean): RouterResult<Unit> =
        updateWifiMacBlock(macAddress, bandFilter = band, blocked = blocked)

    private suspend fun updateWifiMacBlock(
        macAddress: String,
        bandFilter: WifiBand?,
        blocked: Boolean
    ): RouterResult<Unit> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val normMac = OpenWrtDataMapper.normalizeMac(macAddress)
        val wirelessRes = readUciConfig(target, "wireless")
        val wirelessObj = when (wirelessRes) {
            is RouterResult.Success -> wirelessRes.data
            else -> return wirelessRes as RouterResult<Unit>
        }

        if (cachedWirelessSections.iface2gSection == null && cachedWirelessSections.iface5gSection == null) {
            OpenWrtDataMapper.mapWifiConfig(wirelessObj)
        }
        val (_, sections) = OpenWrtDataMapper.mapWifiConfig(wirelessObj)
        cachedWirelessSections = sections

        val targetIfaces = when (bandFilter) {
            WifiBand.BAND_2_4_GHZ -> listOfNotNull(sections.iface2gSection)
            WifiBand.BAND_5_GHZ -> listOfNotNull(sections.iface5gSection)
            null -> listOfNotNull(sections.iface2gSection, sections.iface5gSection)
        }
        if (targetIfaces.isEmpty()) {
            return RouterResult.Unsupported(
                featureName = RouterFeature.DEVICE_BLOCKING.displayName,
                reason = "No matching OpenWrt wireless interface section found for MAC ACL."
            )
        }

        val values = (wirelessObj["values"] as? JsonObject) ?: wirelessObj
        for (ifaceSec in targetIfaces) {
            val secObj = values[ifaceSec] as? JsonObject ?: continue
            val currentList = when (val raw = secObj["maclist"]) {
                is JsonArray -> raw.mapNotNull { it.jsonPrimitive.content }.map(OpenWrtDataMapper::normalizeMac).toMutableSet()
                is JsonPrimitive -> mutableSetOf(OpenWrtDataMapper.normalizeMac(raw.content))
                else -> mutableSetOf()
            }
            if (blocked) currentList.add(normMac) else currentList.remove(normMac)

            val args = buildJsonObject {
                put("config", JsonPrimitive("wireless"))
                put("section", JsonPrimitive(ifaceSec))
                put(
                    "values",
                    buildJsonObject {
                        put("macfilter", JsonPrimitive(if (currentList.isNotEmpty()) "deny" else "disable"))
                        put("maclist", buildJsonArray { currentList.forEach { add(JsonPrimitive(it)) } })
                    }
                )
            }
            val res = rpcClient.callUbus(target, "uci", "set", args)
            if (res !is RouterResult.Success) return res as RouterResult<Unit>
        }
        return uciCommit(target, "wireless").toUnitResult()
    }

    override suspend fun setDeviceInternetBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val normMac = OpenWrtDataMapper.normalizeMac(macAddress)
        val hexMac = normMac.replace(":", "").lowercase(Locale.US)
        val ruleName = "rmpro_wan_$hexMac"

        val fwObj = when (val fwRes = readUciConfig(target, "firewall")) {
            is RouterResult.Success -> fwRes.data
            else -> return fwRes as RouterResult<Unit>
        }
        val values = (fwObj["values"] as? JsonObject) ?: fwObj
        val existingKey = values.entries.firstOrNull { (k, el) ->
            val obj = el as? JsonObject
            k == ruleName ||
                (obj?.get(".type")?.jsonPrimitive?.content == "rule" &&
                    obj["name"]?.jsonPrimitive?.content == ruleName)
        }?.key

        val opRes = if (blocked) {
            val ruleFields = mapOf(
                "name" to ruleName,
                "src" to "lan",
                "dest" to "wan",
                "src_mac" to normMac,
                "proto" to "all",
                "target" to "DROP",
                "enabled" to "1"
            )
            if (existingKey != null) {
                uciSetAndKeep(target, "firewall", existingKey, ruleFields)
            } else {
                uciAdd(target, "firewall", "rule", ruleFields, sectionName = ruleName)
            }
        } else {
            if (existingKey != null) {
                uciDelete(target, "firewall", existingKey)
            } else {
                RouterResult.Success(JsonObject(emptyMap()))
            }
        }
        if (opRes !is RouterResult.Success) return opRes as RouterResult<Unit>
        return uciCommit(target, "firewall").toUnitResult()
    }

    override suspend fun setDeviceGuestBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val guestSec = cachedWirelessSections.guestIfaceSection
            ?: return RouterResult.Unsupported(
                featureName = "Guest Wi-Fi Client ACL",
                reason = "No guest wireless interface exists in OpenWrt configuration."
            )
        val wirelessObj = (readUciConfig(target, "wireless") as? RouterResult.Success)?.data
            ?: return RouterResult.Unsupported("Guest Wi-Fi ACL", "Unable to read UCI wireless.")
        val secObj = ((wirelessObj["values"] as? JsonObject) ?: wirelessObj)[guestSec] as? JsonObject
            ?: return RouterResult.Unsupported("Guest Wi-Fi ACL", "Guest interface section missing.")

        val normMac = OpenWrtDataMapper.normalizeMac(macAddress)
        val currentList = when (val raw = secObj["maclist"]) {
            is JsonArray -> raw.mapNotNull { it.jsonPrimitive.content }.map(OpenWrtDataMapper::normalizeMac).toMutableSet()
            is JsonPrimitive -> mutableSetOf(OpenWrtDataMapper.normalizeMac(raw.content))
            else -> mutableSetOf()
        }
        if (blocked) currentList.add(normMac) else currentList.remove(normMac)

        val args = buildJsonObject {
            put("config", JsonPrimitive("wireless"))
            put("section", JsonPrimitive(guestSec))
            put(
                "values",
                buildJsonObject {
                    put("macfilter", JsonPrimitive(if (currentList.isNotEmpty()) "deny" else "disable"))
                    put("maclist", buildJsonArray { currentList.forEach { add(JsonPrimitive(it)) } })
                }
            )
        }
        val res = rpcClient.callUbus(target, "uci", "set", args)
        if (res !is RouterResult.Success) return res as RouterResult<Unit>
        return uciCommit(target, "wireless").toUnitResult()
    }

    override suspend fun setDeviceStaticIp(macAddress: String, reserved: Boolean): RouterResult<Unit> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val normMac = OpenWrtDataMapper.normalizeMac(macAddress)
        val dhcpObj = (readUciConfig(target, "dhcp") as? RouterResult.Success)?.data
            ?: return RouterResult.Unsupported("Static IP Reservation", "UCI dhcp config unavailable.")
        val values = (dhcpObj["values"] as? JsonObject) ?: dhcpObj
        val existingSec = values.entries.firstOrNull { (_, el) ->
            val obj = el as? JsonObject
            obj?.get(".type")?.jsonPrimitive?.content == "host" &&
                obj["mac"]?.jsonPrimitive?.content?.equals(normMac, ignoreCase = true) == true
        }?.key

        if (!reserved) {
            if (existingSec != null) {
                val del = uciDelete(target, "dhcp", existingSec)
                if (del !is RouterResult.Success) return del as RouterResult<Unit>
                return uciCommit(target, "dhcp").toUnitResult()
            }
            return RouterResult.Success(Unit)
        }

        val devices = (getConnectedDevices() as? RouterResult.Success)?.data.orEmpty()
        val match = devices.firstOrNull { it.macAddress.equals(normMac, ignoreCase = true) }
        val ip = match?.ipAddress?.takeIf { it.contains('.') }
            ?: return RouterResult.Failure("Cannot reserve static IP: device $normMac currently has no active IPv4 lease.")

        val op = if (existingSec != null) {
            uciSetAndKeep(target, "dhcp", existingSec, mapOf("ip" to ip, "mac" to normMac, "name" to match.name))
        } else {
            uciAdd(target, "dhcp", "host", mapOf("ip" to ip, "mac" to normMac, "name" to match.name))
        }
        if (op !is RouterResult.Success) return op as RouterResult<Unit>
        return uciCommit(target, "dhcp").toUnitResult()
    }

    override suspend fun getNetworkSettings(): RouterResult<NetworkSettings> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val dumpRes = rpcClient.callUbus(target, "network.interface", "dump")
        if (dumpRes is RouterResult.AuthRequired || dumpRes is RouterResult.Failure) {
            return dumpRes as RouterResult<NetworkSettings>
        }
        val netRes = readUciConfig(target, "network")
        if (netRes is RouterResult.AuthRequired) return netRes
        val dhcpRes = readUciConfig(target, "dhcp")
        if (dhcpRes is RouterResult.AuthRequired) return dhcpRes
        val fwRes = readUciConfig(target, "firewall")
        val sysRes = readUciConfig(target, "system")

        if (dumpRes !is RouterResult.Success && netRes !is RouterResult.Success) {
            return (dumpRes as? RouterResult.Unsupported)
                ?: RouterResult.Unsupported("Network Configuration", "OpenWrt network.interface and uci.network are unavailable.")
        }

        val leasesObj = if (hasObject("luci-rpc")) {
            (rpcClient.callUbus(target, "luci-rpc", "getDHCPLeases") as? RouterResult.Success)?.data
        } else null
        val leaseCount = (leasesObj?.get("dhcp_leases") as? JsonArray)?.size ?: 0

        val mapped = OpenWrtDataMapper.mapNetworkSettings(
            interfaceDumpObj = (dumpRes as? RouterResult.Success)?.data,
            uciNetworkObj = (netRes as? RouterResult.Success)?.data,
            uciDhcpObj = (dhcpRes as? RouterResult.Success)?.data,
            uciFirewallObj = (fwRes as? RouterResult.Success)?.data,
            uciSystemObj = (sysRes as? RouterResult.Success)?.data,
            activeLeasesCount = leaseCount
        )
        return RouterResult.Success(mapped)
    }

    override suspend fun updateLanConfig(lanConfig: LanConfig): RouterResult<NetworkSettings> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val setLan = uciSetAndKeep(
            target,
            "network",
            "lan",
            mapOf(
                "ipaddr" to lanConfig.routerIp,
                "netmask" to lanConfig.subnetMask,
                "igmp_snooping" to if (lanConfig.igmpSnoopingEnabled) "1" else "0"
            )
        )
        if (setLan !is RouterResult.Success) return setLan as RouterResult<NetworkSettings>
        val commit = uciCommit(target, "network")
        if (commit !is RouterResult.Success) return commit as RouterResult<NetworkSettings>
        return getNetworkSettings()
    }

    override suspend fun updateDhcpConfig(dhcpConfig: DhcpConfig): RouterResult<NetworkSettings> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val startOctet = dhcpConfig.startIp.substringAfterLast('.').toIntOrNull() ?: 100
        val endOctet = dhcpConfig.endIp.substringAfterLast('.').toIntOrNull() ?: 250
        val limit = (endOctet - startOctet + 1).coerceAtLeast(1)
        val leaseStr = "${dhcpConfig.leaseTimeMinutes}m"

        val res = uciSetAndKeep(
            target,
            "dhcp",
            "lan",
            mapOf(
                "ignore" to if (dhcpConfig.enabled) "0" else "1",
                "start" to startOctet.toString(),
                "limit" to limit.toString(),
                "leasetime" to leaseStr
            )
        )
        if (res !is RouterResult.Success) return res as RouterResult<NetworkSettings>
        val commit = uciCommit(target, "dhcp")
        if (commit !is RouterResult.Success) return commit as RouterResult<NetworkSettings>
        return getNetworkSettings()
    }

    override suspend fun updateDnsConfig(dnsConfig: DnsConfig): RouterResult<NetworkSettings> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val dhcpObj = (readUciConfig(target, "dhcp") as? RouterResult.Success)?.data
            ?: return RouterResult.Unsupported("DNS Config", "OpenWrt uci.dhcp unavailable.")
        val values = (dhcpObj["values"] as? JsonObject) ?: dhcpObj
        val dnsmasqSec = values.entries.firstOrNull { (_, el) ->
            (el as? JsonObject)?.get(".type")?.jsonPrimitive?.content == "dnsmasq"
        }?.key ?: return RouterResult.Unsupported("DNS Config", "No dnsmasq section found in OpenWrt UCI dhcp.")

        val servers = if (dnsConfig.mode == DnsMode.CUSTOM) {
            listOf(dnsConfig.primaryDns, dnsConfig.secondaryDns).filter { it.isNotBlank() }
        } else {
            emptyList()
        }
        val args = buildJsonObject {
            put("config", JsonPrimitive("dhcp"))
            put("section", JsonPrimitive(dnsmasqSec))
            put(
                "values",
                buildJsonObject {
                    put("noresolv", JsonPrimitive(if (servers.isNotEmpty()) "1" else "0"))
                    put("server", buildJsonArray { servers.forEach { add(JsonPrimitive(it)) } })
                }
            )
        }
        val setRes = rpcClient.callUbus(target, "uci", "set", args)
        if (setRes !is RouterResult.Success) return setRes as RouterResult<NetworkSettings>
        val commit = uciCommit(target, "dhcp")
        if (commit !is RouterResult.Success) return commit as RouterResult<NetworkSettings>
        return getNetworkSettings()
    }

    override suspend fun savePortForwardRule(rule: PortForwardRule): RouterResult<NetworkSettings> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val protoVal = when (rule.protocol) {
            ProtocolType.TCP -> "tcp"
            ProtocolType.UDP -> "udp"
            ProtocolType.TCP_UDP -> "tcp udp"
        }
        val fields = mapOf(
            "name" to rule.name,
            "src" to "wan",
            "dest" to "lan",
            "proto" to protoVal,
            "src_dport" to rule.externalPort.toString(),
            "dest_ip" to rule.internalIp,
            "dest_port" to rule.internalPort.toString(),
            "target" to "DNAT",
            "enabled" to if (rule.enabled) "1" else "0"
        )
        val fwObj = (readUciConfig(target, "firewall") as? RouterResult.Success)?.data
        val existingExists = ((fwObj?.get("values") as? JsonObject) ?: fwObj)?.containsKey(rule.id) == true
        val op = if (existingExists) {
            uciSetAndKeep(target, "firewall", rule.id, fields)
        } else {
            uciAdd(target, "firewall", "redirect", fields)
        }
        if (op !is RouterResult.Success) return op as RouterResult<NetworkSettings>
        val commit = uciCommit(target, "firewall")
        if (commit !is RouterResult.Success) return commit as RouterResult<NetworkSettings>
        return getNetworkSettings()
    }

    override suspend fun deletePortForwardRule(ruleId: String): RouterResult<NetworkSettings> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val del = uciDelete(target, "firewall", ruleId)
        if (del !is RouterResult.Success) return del as RouterResult<NetworkSettings>
        val commit = uciCommit(target, "firewall")
        if (commit !is RouterResult.Success) return commit as RouterResult<NetworkSettings>
        return getNetworkSettings()
    }

    override suspend fun updateFirewallConfig(firewallConfig: FirewallConfig): RouterResult<NetworkSettings> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        val fwObj = (readUciConfig(target, "firewall") as? RouterResult.Success)?.data
            ?: return RouterResult.Unsupported("Firewall Config", "UCI firewall unavailable.")
        val values = (fwObj["values"] as? JsonObject) ?: fwObj
        val defaultsSec = values.entries.firstOrNull { (_, el) ->
            (el as? JsonObject)?.get(".type")?.jsonPrimitive?.content == "defaults"
        }?.key
        val wanZoneSec = values.entries.firstOrNull { (_, el) ->
            val obj = el as? JsonObject
            obj?.get(".type")?.jsonPrimitive?.content == "zone" &&
                obj["name"]?.jsonPrimitive?.content == "wan"
        }?.key

        if (defaultsSec != null) {
            val res = uciSetAndKeep(
                target,
                "firewall",
                defaultsSec,
                mapOf("synflood_protect" to if (firewallConfig.dosProtectionEnabled) "1" else "0")
            )
            if (res !is RouterResult.Success) return res as RouterResult<NetworkSettings>
        }
        if (wanZoneSec != null) {
            val wanInput = when {
                !firewallConfig.spiFirewallEnabled || firewallConfig.level == FirewallLevel.LOW -> "ACCEPT"
                firewallConfig.level == FirewallLevel.HIGH -> "DROP"
                else -> "REJECT"
            }
            val res = uciSetAndKeep(target, "firewall", wanZoneSec, mapOf("input" to wanInput))
            if (res !is RouterResult.Success) return res as RouterResult<NetworkSettings>
        }
        val commit = uciCommit(target, "firewall")
        if (commit !is RouterResult.Success) return commit as RouterResult<NetworkSettings>
        return getNetworkSettings()
    }

    override suspend fun setUpnpEnabled(enabled: Boolean): RouterResult<NetworkSettings> =
        RouterResult.Unsupported(
            featureName = RouterFeature.UPNP_CONFIG.displayName,
            reason = "Standard OpenWrt firmware does not bundle miniupnpd UCI service unless manually installed."
        )

    override suspend fun saveWanConnection(profile: WanConnectionProfile): RouterResult<NetworkSettings> =
        RouterResult.Unsupported(
            featureName = RouterFeature.MULTI_WAN.displayName,
            reason = "Multi-WAN profile orchestration requires mwan3 package; direct editing is disabled to prevent breaking WAN routes."
        )

    override suspend fun deleteWanConnection(profileId: String): RouterResult<NetworkSettings> =
        RouterResult.Unsupported(
            featureName = RouterFeature.MULTI_WAN.displayName,
            reason = "Multi-WAN deletion requires mwan3 package on OpenWrt."
        )

    override suspend fun runNetworkDiagnostics(): RouterResult<List<DiagnosticResult>> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        if (!hasObject("network.ping") && !hasObject("luci-rpc")) {
            return RouterResult.Unsupported(
                featureName = RouterFeature.NETWORK_DIAGNOSTICS.displayName,
                reason = "This OpenWrt firmware does not expose on-router ping/diagnostics over ubus."
            )
        }
        val pingTarget = "1.1.1.1"
        val res = if (hasObject("network.ping")) {
            rpcClient.callUbus(
                target,
                "network.ping",
                "ping",
                buildJsonObject {
                    put("host", JsonPrimitive(pingTarget))
                    put("count", JsonPrimitive(2))
                }
            )
        } else {
            rpcClient.callUbus(
                target,
                "luci-rpc",
                "getProcessList"
            )
        }
        return when (res) {
            is RouterResult.Success -> RouterResult.Success(
                listOf(
                    DiagnosticResult(
                        id = "diag-ubus",
                        testName = "On-Router ubus Diagnostic Probe",
                        target = target.hostIp,
                        status = DiagnosticStatus.PASS,
                        latencyMs = null,
                        summary = "OpenWrt RPC endpoint responded to live diagnostic query.",
                        timestampLabel = "Live"
                    )
                )
            )
            is RouterResult.Unsupported,
            is RouterResult.AuthRequired,
            is RouterResult.Failure,
            is RouterResult.NotConnected,
            is RouterResult.ValidationError -> res as RouterResult<List<DiagnosticResult>>
        }
    }

    override suspend fun getOpticalInfo(): RouterResult<OpticalInfo> =
        RouterResult.Unsupported(
            featureName = RouterFeature.OPTICAL_INFO.displayName,
            reason = "Standard OpenWrt gateways do not expose GPON/EPON optical laser telemetry via /ubus."
        )

    override suspend fun getEthernetPorts(): RouterResult<List<EthernetPortInfo>> =
        RouterResult.Unsupported(
            featureName = RouterFeature.ETHERNET_PORT_STATUS.displayName,
            reason = "Per-port DSA/swconfig link telemetry is not exposed uniformly across OpenWrt ubus versions."
        )

    override suspend fun getInterfaceStats(): RouterResult<List<InterfaceStat>> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        if (protocolMode == OpenWrtTransportProtocol.LUCI_MOD_RPC || !hasObject("network.device")) {
            return RouterResult.Unsupported(
                featureName = RouterFeature.INTERFACE_STATS.displayName,
                reason = "OpenWrt network.device.status is not available on this firmware."
            )
        }
        return when (val res = rpcClient.callUbus(target, "network.device", "status")) {
            is RouterResult.Success -> RouterResult.Success(OpenWrtDataMapper.mapInterfaceStats(res.data))
            else -> res as RouterResult<List<InterfaceStat>>
        }
    }

    override suspend fun getVoipStatus(): RouterResult<List<VoipLineInfo>> =
        RouterResult.Unsupported(
            featureName = RouterFeature.VOIP_STATUS.displayName,
            reason = "OpenWrt firmware does not expose analog/SIP FXS VoIP registration status."
        )

    override suspend fun getParentalTemplates(): RouterResult<List<ParentalControlTemplate>> =
        RouterResult.Unsupported(
            featureName = RouterFeature.PARENTAL_CONTROL.displayName,
            reason = "OpenWrt does not include built-in scheduled parental control templates."
        )

    override suspend fun saveParentalTemplate(template: ParentalControlTemplate): RouterResult<List<ParentalControlTemplate>> =
        RouterResult.Unsupported(
            featureName = RouterFeature.PARENTAL_CONTROL.displayName,
            reason = "Parental control templates are not supported on standard OpenWrt."
        )

    override suspend fun deleteParentalTemplate(templateId: String): RouterResult<List<ParentalControlTemplate>> =
        RouterResult.Unsupported(
            featureName = RouterFeature.PARENTAL_CONTROL.displayName,
            reason = "Parental control templates are not supported on standard OpenWrt."
        )

    override suspend fun runSpeedTest(): RouterResult<SpeedTestResult> =
        RouterResult.Unsupported(
            featureName = RouterFeature.SPEED_TEST.displayName,
            reason = "Standard OpenWrt routers do not include an on-router Ookla/speedtest ubus RPC."
        )

    override suspend fun rebootRouter(): RouterResult<Unit> {
        val target = requireTarget() ?: return RouterResult.NotConnected("No active live OpenWrt session.")
        return if (protocolMode == OpenWrtTransportProtocol.LUCI_MOD_RPC) {
            rpcClient.callLegacyLuciRpc(target, "sys", "reboot").toUnitResult()
        } else {
            rpcClient.callUbus(target, "system", "reboot").toUnitResult()
        }
    }

    private suspend fun fetchAssocClients(target: OpenWrtConnectionTarget): List<OpenWrtDataMapper.AssocClientSample>? {
        if (!hasObject("iwinfo") && availableUbusObjects.isNotEmpty()) return null
        val devicesRes = rpcClient.callUbus(target, "iwinfo", "devices")
        if (devicesRes !is RouterResult.Success) return null

        val devsArr = (devicesRes.data["devices"] as? JsonArray).orEmpty()
            .mapNotNull { (it as? JsonPrimitive)?.content }

        val samples = mutableListOf<OpenWrtDataMapper.AssocClientSample>()
        for (dev in devsArr) {
            val infoRes = rpcClient.callUbus(
                target,
                "iwinfo",
                "info",
                buildJsonObject { put("device", JsonPrimitive(dev)) }
            )
            val infoObj = (infoRes as? RouterResult.Success)?.data
            val freqMhz = infoObj?.get("frequency")?.jsonPrimitive?.intOrNull ?: 2412
            val is5g = freqMhz >= 5000
            val ssid = infoObj?.get("ssid")?.jsonPrimitive?.content.orEmpty()
            val isGuest = dev.contains("guest", ignoreCase = true) || ssid.contains("guest", ignoreCase = true)

            val assocRes = rpcClient.callUbus(
                target,
                "iwinfo",
                "assoclist",
                buildJsonObject { put("device", JsonPrimitive(dev)) }
            )
            val assocObj = (assocRes as? RouterResult.Success)?.data ?: continue
            val results = (assocObj["results"] as? JsonArray).orEmpty()
            for (el in results) {
                val entry = el as? JsonObject ?: continue
                val mac = entry["mac"]?.jsonPrimitive?.content ?: continue
                val signal = entry["signal"]?.jsonPrimitive?.intOrNull
                val rxRateKbps = (entry["rx"] as? JsonObject)?.get("rate")?.jsonPrimitive?.intOrNull ?: 0
                val txRateKbps = (entry["tx"] as? JsonObject)?.get("rate")?.jsonPrimitive?.intOrNull ?: 0
                val connTime = entry["connected_time"]?.jsonPrimitive?.longOrNull ?: 0L
                samples.add(
                    OpenWrtDataMapper.AssocClientSample(
                        mac = mac,
                        radioName = dev,
                        is5Ghz = is5g,
                        isGuest = isGuest,
                        signalDbm = signal,
                        rxMbps = rxRateKbps / 1000f,
                        txMbps = txRateKbps / 1000f,
                        connectedSeconds = connTime
                    )
                )
            }
        }
        return samples
    }

    private suspend fun fetchAssocClientCountsByDevice(target: OpenWrtConnectionTarget): Map<String, Int> {
        val samples = fetchAssocClients(target) ?: return emptyMap()
        return samples.groupingBy { it.radioName }.eachCount()
    }

    private suspend fun readUciConfig(target: OpenWrtConnectionTarget, config: String): RouterResult<JsonObject> {
        if (protocolMode == OpenWrtTransportProtocol.LUCI_MOD_RPC) {
            val res = rpcClient.callLegacyLuciRpc(
                target,
                "uci",
                "get_all",
                buildJsonArray { add(JsonPrimitive(config)) }
            )
            return when (res) {
                is RouterResult.Success -> {
                    val obj = res.data as? JsonObject
                    if (obj != null) RouterResult.Success(obj)
                    else RouterResult.Unsupported("UCI $config", "Legacy LuCI uci.get_all($config) returned non-object data.")
                }
                is RouterResult.AuthRequired -> res
                is RouterResult.Failure -> res
                is RouterResult.NotConnected -> res
                is RouterResult.Unsupported -> res
                is RouterResult.ValidationError -> res
            }
        }
        return rpcClient.callUbus(
            target,
            "uci",
            "get",
            buildJsonObject { put("config", JsonPrimitive(config)) }
        )
    }

    private suspend fun uciSetAndKeep(
        target: OpenWrtConnectionTarget,
        config: String,
        section: String,
        values: Map<String, String>
    ): RouterResult<JsonObject> {
        val args = buildJsonObject {
            put("config", JsonPrimitive(config))
            put("section", JsonPrimitive(section))
            put(
                "values",
                buildJsonObject {
                    values.forEach { (k, v) -> put(k, JsonPrimitive(v)) }
                }
            )
        }
        return rpcClient.callUbus(target, "uci", "set", args)
    }

    private suspend fun uciAdd(
        target: OpenWrtConnectionTarget,
        config: String,
        type: String,
        values: Map<String, String>,
        sectionName: String? = null
    ): RouterResult<JsonObject> {
        val args = buildJsonObject {
            put("config", JsonPrimitive(config))
            put("type", JsonPrimitive(type))
            if (!sectionName.isNullOrBlank()) put("name", JsonPrimitive(sectionName))
            put(
                "values",
                buildJsonObject {
                    values.forEach { (k, v) -> put(k, JsonPrimitive(v)) }
                }
            )
        }
        return rpcClient.callUbus(target, "uci", "add", args)
    }

    private suspend fun uciDelete(
        target: OpenWrtConnectionTarget,
        config: String,
        section: String
    ): RouterResult<JsonObject> {
        return rpcClient.callUbus(
            target,
            "uci",
            "delete",
            buildJsonObject {
                put("config", JsonPrimitive(config))
                put("section", JsonPrimitive(section))
            }
        )
    }

    private suspend fun uciCommit(
        target: OpenWrtConnectionTarget,
        config: String
    ): RouterResult<JsonObject> {
        return rpcClient.callUbus(
            target,
            "uci",
            "commit",
            buildJsonObject { put("config", JsonPrimitive(config)) }
        )
    }

    private fun hasObject(name: String): Boolean =
        availableUbusObjects.isEmpty() || availableUbusObjects.contains(name)

    private fun requireTarget(): OpenWrtConnectionTarget? {
        if (!sessionManager.isAuthenticated()) return null
        return activeTarget
    }

    private fun <T> RouterResult<T>.toUnitResult(): RouterResult<Unit> = when (this) {
        is RouterResult.Success -> RouterResult.Success(Unit, isDemoData)
        is RouterResult.Unsupported -> this
        is RouterResult.NotConnected -> this
        is RouterResult.AuthRequired -> this
        is RouterResult.ValidationError -> this
        is RouterResult.Failure -> this
    }

    companion object {
        const val ADAPTER_ID = "openwrt_luci"
    }
}
