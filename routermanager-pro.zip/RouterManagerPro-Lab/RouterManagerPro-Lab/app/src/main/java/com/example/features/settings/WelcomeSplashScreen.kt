package com.example.features.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.designsystem.HexRouterEmblem
import com.example.designsystem.NavyVoid
import com.example.designsystem.RoseCritical

@Composable
fun WelcomeSplashScreen() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(NavyVoid)
            .testTag("welcome_splash_screen"),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            HexRouterEmblem(
                modifier = Modifier.size(116.dp),
                tint = Color(0xFF9BC6CD)
            )
            Spacer(modifier = Modifier.height(26.dp))
            Text(
                text = "Welcome to RouterManager Pro",
                style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.SemiBold),
                color = Color(0xFFF3F6FC)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Getting things ready...",
                style = MaterialTheme.typography.bodyMedium,
                color = Color(0xFF8C9BB8)
            )
            Spacer(modifier = Modifier.height(38.dp))
            CircularProgressIndicator(
                color = RoseCritical,
                strokeWidth = 3.2.dp,
                modifier = Modifier.size(34.dp)
            )
        }
    }
}
