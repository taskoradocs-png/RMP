package com.example.authentication

import com.example.adapters.RouterCapabilityRegistry
import com.example.core.RouterResult
import com.example.core.Validators
import com.example.models.RouterCredentials
import com.example.models.RouterSession
import com.example.router.RouterAdapter

interface RouterCredentialStore {
    suspend fun saveEncryptedPassword(profileId: String, plainPassword: String)
    suspend fun loadDecryptedPassword(profileId: String): String?
    suspend fun clearPassword(profileId: String)
}

/**
 * Coordinates router authentication lifecycle: validates connection targets & credentials,
 * invokes adapter authentication, populates RouterSessionManager (cookies, CSRF, RPC token, expiry),
 * and handles session expiration or disconnection cleanly.
 */
class RouterAuthenticationManager(
    private val capabilityRegistry: RouterCapabilityRegistry,
    private val sessionManager: RouterSessionManager,
    private val credentialCipher: CredentialCipher
) {
    suspend fun authenticate(
        adapterId: String,
        credentials: RouterCredentials,
        overrideAdapter: RouterAdapter? = null
    ): RouterResult<RouterSession> {
        val hostValidation = Validators.validateHostOrIp(credentials.hostIp, "Router host")
        if (!hostValidation.isValid) {
            return RouterResult.ValidationError("hostIp", hostValidation.errorOrNull ?: "Invalid host.")
        }
        val portValidation = Validators.validatePort(credentials.port.toString(), "Admin port")
        if (!portValidation.isValid) {
            return RouterResult.ValidationError("port", portValidation.errorOrNull ?: "Invalid port.")
        }
        if (credentials.username.isBlank()) {
            return RouterResult.ValidationError("username", "Administrator username is required.")
        }
        if (credentials.password.isBlank()) {
            return RouterResult.ValidationError("password", "Administrator password is required.")
        }

        val adapter = overrideAdapter ?: capabilityRegistry.getAdapterById(adapterId)
            ?: return RouterResult.Failure("Selected router adapter '$adapterId' is not registered.")

        // Reset any stale cookies/tokens from a previous live session before attempting login
        sessionManager.clearSession()

        val normalizedCredentials = credentials.copy(
            hostIp = credentials.hostIp.trim(),
            username = credentials.username.trim()
        )
        val result = adapter.authenticate(normalizedCredentials)
        when (result) {
            is RouterResult.Success -> {
                if (sessionManager.currentSession.value == null) {
                    sessionManager.startSession(result.data)
                }
            }
            is RouterResult.AuthRequired,
            is RouterResult.Failure,
            is RouterResult.NotConnected,
            is RouterResult.Unsupported,
            is RouterResult.ValidationError -> {
                sessionManager.clearSession()
            }
        }
        return result
    }

    suspend fun logout(adapter: RouterAdapter?): RouterResult<Unit> {
        val res = adapter?.disconnect() ?: RouterResult.Success(Unit)
        sessionManager.clearSession()
        return res
    }

    fun onSessionExpired(reason: String) {
        sessionManager.expireSession(reason)
    }

    fun encryptCredential(plainPassword: String): String {
        return credentialCipher.encrypt(plainPassword)
    }

    fun decryptCredential(encryptedPassword: String): String? {
        return credentialCipher.decrypt(encryptedPassword)
    }
}
