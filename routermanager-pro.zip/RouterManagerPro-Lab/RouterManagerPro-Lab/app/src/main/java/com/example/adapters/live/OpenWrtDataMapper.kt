package com.example.adapters.live

import com.example.models.ConnectedDevice
import com.example.models.ConnectionType
import com.example.models.DeviceCategory
import com.example.models.DhcpConfig
import com.example.models.DnsConfig
import com.example.models.DnsHostEntry
import com.example.models.DnsMode
import com.example.models.FirewallConfig
import com.example.models.FirewallLevel
import com.example.models.GuestNetworkConfig
import com.example.models.InterfaceStat
import com.example.models.LanConfig
import com.example.models.NetworkSettings
import com.example.models.PortForwardRule
import com.example.models.ProtocolType
import com.example.models.RouterConnectionState
import com.example.models.RouterInfo
import com.example.models.TrafficSnapshot
import com.example.models.WanConnectionProfile
import com.example.models.WanConnectionType
import com.example.models.WanInfo
import com.example.models.WifiBand
import com.example.models.WifiBandConfig
import com.example.models.WifiConfig
import com.example.models.WifiSecurityMode
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.floatOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import java.util.Locale

internal data class OpenWrtWirelessSectionMap(
    val radio2gSection: String? = null,
    val iface2gSection: String? = null,
    val radio5gSection: String? = null,
    val iface5gSection: String? = null,
    val guestIfaceSection: String? = null
)

internal object OpenWrtDataMapper {

    fun mapRouterInfo(
        hostIp: String,
        adapterId: String,
        adapterDisplayName: String,
        boardObj: JsonObject?,
        infoObj: JsonObject?,
        interfaceDumpObj: JsonObject?
    ): RouterInfo {
        val releaseObj = boardObj?.get("release") as? JsonObject
        val distribution = releaseObj?.str("distribution") ?: "OpenWrt"
        val version = releaseObj?.str("version") ?: "Unknown"
        val revision = releaseObj?.str("revision")
        val firmwareLabel = listOfNotNull(version, revision).joinToString(" ").ifBlank { "Unknown" }

        val model = boardObj?.str("model")
            ?: boardObj?.str("board_name")
            ?: "OpenWrt Router"
        val hardwareRev = boardObj?.str("system")
            ?: boardObj?.str("board_name")
            ?: "Unknown Architecture"
        val kernel = boardObj?.str("kernel")

        val uptimeSec = infoObj?.long("uptime") ?: 0L
        val loadArr = infoObj?.get("load") as? JsonArray
        val load1mRaw = loadArr?.getOrNull(0)?.jsonPrimitive?.longOrNull ?: 0L
        val cpuPercent = ((load1mRaw / 65536.0) * 100.0).toInt().coerceIn(0, 100)

        val memObj = infoObj?.get("memory") as? JsonObject
        val totalMem = memObj?.long("total") ?: 0L
        val freeMem = memObj?.long("free") ?: 0L
        val bufferedMem = memObj?.long("buffered") ?: 0L
        val usedMem = (totalMem - freeMem - bufferedMem).coerceAtLeast(0L)
        val memPercent = if (totalMem > 0L) ((usedMem * 100L) / totalMem).toInt().coerceIn(0, 100) else 0

        val interfaces = (interfaceDumpObj?.get("interface") as? JsonArray).orEmpty()
            .mapNotNull { it as? JsonObject }
        val wanIface = interfaces.firstOrNull {
            val name = it.str("interface").orEmpty().lowercase()
            name == "wan" || name == "wwan"
        } ?: interfaces.firstOrNull {
            val routeArr = it["route"] as? JsonArray
            routeArr?.any { r -> (r as? JsonObject)?.str("target") == "0.0.0.0" } == true
        }
        val lanIface = interfaces.firstOrNull { it.str("interface").equals("lan", ignoreCase = true) }

        val wanUp = wanIface?.bool("up") == true
        val wanIp = extractFirstIpv4(wanIface)
        val lanIp = extractFirstIpv4(lanIface) ?: hostIp

        return RouterInfo(
            manufacturer = distribution,
            model = model,
            firmwareVersion = firmwareLabel,
            hardwareRevision = if (kernel != null) "$hardwareRev · Kernel $kernel" else hardwareRev,
            routerIp = lanIp,
            wanIp = wanIp,
            internetConnected = wanUp && !wanIp.isNullOrBlank(),
            uptimeSeconds = uptimeSec,
            cpuLoadPercent = cpuPercent,
            memoryLoadPercent = memPercent,
            serialMasked = boardObj?.str("hostname") ?: "OPENWRT-UBUS",
            connectionState = RouterConnectionState.CONNECTED,
            adapterId = adapterId,
            adapterName = adapterDisplayName
        )
    }

    fun mapWifiConfig(
        uciWirelessObj: JsonObject,
        clientCountsByDevice: Map<String, Int> = emptyMap()
    ): Pair<WifiConfig, OpenWrtWirelessSectionMap> {
        val values = (uciWirelessObj["values"] as? JsonObject) ?: uciWirelessObj
        val devices = linkedMapOf<String, JsonObject>()
        val ifaces = linkedMapOf<String, JsonObject>()

        for ((sectionName, element) in values) {
            val obj = element as? JsonObject ?: continue
            when (obj.str(".type")) {
                "wifi-device" -> devices[sectionName] = obj
                "wifi-iface" -> ifaces[sectionName] = obj
            }
        }

        val radio2gEntry = devices.entries.firstOrNull { (_, dev) -> !is5GhzRadio(dev) }
        val radio5gEntry = devices.entries.firstOrNull { (_, dev) -> is5GhzRadio(dev) }

        val apIfaces = ifaces.entries.filter { (_, iface) ->
            val mode = iface.str("mode")
            mode == null || mode.equals("ap", ignoreCase = true)
        }

        val guestEntry = apIfaces.firstOrNull { (name, iface) ->
            val net = iface.str("network").orEmpty().lowercase()
            net.contains("guest") || name.lowercase().contains("guest")
        }

        val iface2gEntry = apIfaces.firstOrNull { (name, iface) ->
            name != guestEntry?.key &&
                (radio2gEntry == null || iface.str("device") == radio2gEntry.key)
        }
        val iface5gEntry = if (radio5gEntry != null) {
            apIfaces.firstOrNull { (name, iface) ->
                name != guestEntry?.key && iface.str("device") == radio5gEntry.key
            }
        } else null

        val band24Disabled = radio2gEntry?.value?.isUciTrue("disabled") == true ||
            iface2gEntry?.value?.isUciTrue("disabled") == true
        val band24Ssid = iface2gEntry?.value?.str("ssid") ?: ""
        val band24 = WifiBandConfig(
            band = WifiBand.BAND_2_4_GHZ,
            enabled = iface2gEntry != null && !band24Disabled,
            ssid = band24Ssid,
            securityMode = mapEncryptionToSecurity(iface2gEntry?.value?.str("encryption")),
            password = iface2gEntry?.value?.str("key") ?: "",
            hiddenSsid = iface2gEntry?.value?.isUciTrue("hidden") == true,
            channel = radio2gEntry?.value?.str("channel") ?: "auto",
            availableChannels = listOf("auto", "1", "6", "11", "3", "9"),
            bandwidthMhz = mapHtModeToBandwidth(radio2gEntry?.value?.str("htmode"), defaultMhz = "20 MHz"),
            availableBandwidthsMhz = listOf("20 MHz", "40 MHz"),
            txPowerPercent = radio2gEntry?.value?.str("txpower")?.toIntOrNull()?.coerceIn(1, 100) ?: 100,
            connectedClientsCount = clientCountsByDevice[radio2gEntry?.key] ?: 0
        )

        val band5 = if (radio5gEntry != null || iface5gEntry != null) {
            val disabled5 = radio5gEntry?.value?.isUciTrue("disabled") == true ||
                iface5gEntry?.value?.isUciTrue("disabled") == true
            WifiBandConfig(
                band = WifiBand.BAND_5_GHZ,
                enabled = iface5gEntry != null && !disabled5,
                ssid = iface5gEntry?.value?.str("ssid") ?: "",
                securityMode = mapEncryptionToSecurity(iface5gEntry?.value?.str("encryption")),
                password = iface5gEntry?.value?.str("key") ?: "",
                hiddenSsid = iface5gEntry?.value?.isUciTrue("hidden") == true,
                channel = radio5gEntry?.value?.str("channel") ?: "auto",
                availableChannels = listOf("auto", "36", "40", "44", "48", "149", "153", "157", "161"),
                bandwidthMhz = mapHtModeToBandwidth(radio5gEntry?.value?.str("htmode"), defaultMhz = "80 MHz"),
                availableBandwidthsMhz = listOf("20 MHz", "40 MHz", "80 MHz", "160 MHz"),
                txPowerPercent = radio5gEntry?.value?.str("txpower")?.toIntOrNull()?.coerceIn(1, 100) ?: 100,
                connectedClientsCount = clientCountsByDevice[radio5gEntry?.key] ?: 0
            )
        } else null

        val guestNetwork = guestEntry?.let { (_, g) ->
            GuestNetworkConfig(
                enabled = !g.isUciTrue("disabled"),
                ssid = g.str("ssid") ?: "",
                securityMode = mapEncryptionToSecurity(g.str("encryption")),
                password = g.str("key") ?: "",
                isolateClients = g.isUciTrue("isolate"),
                bandwidthLimitMbps = null,
                bandLabel = if (g.str("device") == radio5gEntry?.key) "5 GHz" else "2.4 GHz"
            )
        }

        val masterEnabled = band24.enabled || (band5?.enabled == true)
        val sections = OpenWrtWirelessSectionMap(
            radio2gSection = radio2gEntry?.key,
            iface2gSection = iface2gEntry?.key,
            radio5gSection = radio5gEntry?.key,
            iface5gSection = iface5gEntry?.key,
            guestIfaceSection = guestEntry?.key
        )
        return WifiConfig(
            masterWifiEnabled = masterEnabled,
            band24 = band24,
            band5 = band5,
            guestNetwork = guestNetwork
        ) to sections
    }

    data class AssocClientSample(
        val mac: String,
        val radioName: String,
        val is5Ghz: Boolean,
        val isGuest: Boolean,
        val signalDbm: Int?,
        val rxMbps: Float,
        val txMbps: Float,
        val connectedSeconds: Long
    )

    fun mapConnectedDevices(
        assocClients: List<AssocClientSample>,
        dhcpLeasesObj: JsonObject?,
        hostHintsObj: JsonObject?,
        uciWirelessObj: JsonObject?,
        uciFirewallObj: JsonObject?,
        uciDhcpObj: JsonObject?
    ): List<ConnectedDevice> {
        val blocked24Macs = mutableSetOf<String>()
        val blocked5Macs = mutableSetOf<String>()
        val allWifiBlockedMacs = mutableSetOf<String>()

        if (uciWirelessObj != null) {
            val values = (uciWirelessObj["values"] as? JsonObject) ?: uciWirelessObj
            val deviceBands = values.entries
                .mapNotNull { (k, v) -> (v as? JsonObject)?.takeIf { it.str(".type") == "wifi-device" }?.let { k to is5GhzRadio(it) } }
                .toMap()

            for ((_, el) in values) {
                val sec = el as? JsonObject ?: continue
                if (sec.str(".type") == "wifi-iface" && sec.str("macfilter") == "deny") {
                    val macs = sec.stringList("maclist").map { normalizeMac(it) }
                    allWifiBlockedMacs.addAll(macs)
                    val is5g = deviceBands[sec.str("device")] == true
                    if (is5g) blocked5Macs.addAll(macs) else blocked24Macs.addAll(macs)
                }
            }
        }

        val wanBlockedMacs = mutableSetOf<String>()
        if (uciFirewallObj != null) {
            val values = (uciFirewallObj["values"] as? JsonObject) ?: uciFirewallObj
            for ((secName, el) in values) {
                val sec = el as? JsonObject ?: continue
                if (sec.str(".type") == "rule" &&
                    sec.str("target").equals("DROP", ignoreCase = true) &&
                    sec.str("dest").equals("wan", ignoreCase = true) &&
                    sec.isUciTrue("enabled", defaultValue = true)
                ) {
                    val mac = sec.str("src_mac")
                    if (!mac.isNullOrBlank()) {
                        wanBlockedMacs.add(normalizeMac(mac))
                    } else if (secName.startsWith("rmpro_wan_")) {
                        val hex = secName.removePrefix("rmpro_wan_")
                        if (hex.length == 12) {
                            val formatted = hex.chunked(2).joinToString(":").uppercase(Locale.US)
                            wanBlockedMacs.add(formatted)
                        }
                    }
                }
            }
        }

        val staticNamesByMac = mutableMapOf<String, String>()
        val staticReservedMacs = mutableSetOf<String>()
        if (uciDhcpObj != null) {
            val values = (uciDhcpObj["values"] as? JsonObject) ?: uciDhcpObj
            for ((_, el) in values) {
                val sec = el as? JsonObject ?: continue
                if (sec.str(".type") == "host") {
                    val mac = sec.str("mac")?.let(::normalizeMac) ?: continue
                    staticReservedMacs.add(mac)
                    sec.str("name")?.takeIf { it.isNotBlank() }?.let { staticNamesByMac[mac] = it }
                }
            }
        }

        data class LeaseRecord(val mac: String, val ip: String?, val hostname: String?, val leaseExpiresSec: Long?)
        val leasesByMac = mutableMapOf<String, LeaseRecord>()

        // Support luci-rpc.getDHCPLeases (`dhcp_leases`) and dhcp.ipv4leases (`device -> { leases: [...] }`)
        val directLeases = dhcpLeasesObj?.get("dhcp_leases") as? JsonArray
        directLeases?.forEach { item ->
            val obj = item as? JsonObject ?: return@forEach
            val mac = (obj.str("macaddr") ?: obj.str("mac"))?.let(::normalizeMac) ?: return@forEach
            leasesByMac[mac] = LeaseRecord(
                mac = mac,
                ip = obj.str("ipaddr") ?: obj.str("ip"),
                hostname = obj.str("hostname"),
                leaseExpiresSec = obj.long("expires")
            )
        }
        val deviceMap = dhcpLeasesObj?.get("device") as? JsonObject
        deviceMap?.values?.forEach { ifaceEl ->
            val leasesArr = (ifaceEl as? JsonObject)?.get("leases") as? JsonArray
            leasesArr?.forEach { leaseEl ->
                val obj = leaseEl as? JsonObject ?: return@forEach
                val mac = obj.str("mac")?.let(::normalizeMac) ?: return@forEach
                leasesByMac[mac] = LeaseRecord(
                    mac = mac,
                    ip = obj.str("address") ?: obj.str("ip"),
                    hostname = obj.str("hostname"),
                    leaseExpiresSec = obj.long("valid")
                )
            }
        }

        // Host hints from luci-rpc.getHostHints (`{ "AA:BB:...": { "name": "...", "ipaddrs": [...] } }`)
        val hintsByMac = mutableMapOf<String, Pair<String?, String?>>()
        hostHintsObj?.forEach { (macKey, valEl) ->
            val obj = valEl as? JsonObject ?: return@forEach
            val mac = normalizeMac(macKey)
            val name = obj.str("name")
            val ip = (obj["ipaddrs"] as? JsonArray)?.firstOrNull()?.jsonPrimitive?.content
            hintsByMac[mac] = name to ip
        }

        val assocByMac = assocClients.associateBy { normalizeMac(it.mac) }
        val allMacs = (assocByMac.keys + leasesByMac.keys + hintsByMac.keys + allWifiBlockedMacs + wanBlockedMacs)
            .filter { it.matches(Regex("^([0-9A-F]{2}:){5}[0-9A-F]{2}$")) }
            .distinct()

        return allMacs.map { mac ->
            val assoc = assocByMac[mac]
            val lease = leasesByMac[mac]
            val hint = hintsByMac[mac]

            val connType = when {
                assoc?.isGuest == true -> ConnectionType.GUEST_WIFI
                assoc?.is5Ghz == true -> ConnectionType.WIFI_5_GHZ
                assoc != null -> ConnectionType.WIFI_2_4_GHZ
                else -> ConnectionType.ETHERNET
            }

            val resolvedName = staticNamesByMac[mac]
                ?: lease?.hostname?.takeIf { it.isNotBlank() && it != "*" }
                ?: hint?.first?.takeIf { it.isNotBlank() }
                ?: "Client ${mac.takeLast(5)}"

            val resolvedIp = lease?.ip ?: hint?.second ?: "Unassigned"
            val isWifiBlocked = allWifiBlockedMacs.contains(mac)
            val isOnline = (assoc != null || lease != null) && !isWifiBlocked
            val linkSpeed = assoc?.let { maxOf(it.rxMbps, it.txMbps).toInt().takeIf { v -> v > 0 } }

            ConnectedDevice(
                macAddress = mac,
                name = resolvedName,
                ipAddress = resolvedIp,
                manufacturer = "OUI ${mac.take(8)}",
                connectionType = connType,
                category = inferCategory(resolvedName),
                isOnline = isOnline,
                isBlocked = isWifiBlocked,
                isInternetBlocked = wanBlockedMacs.contains(mac),
                isGuestBlocked = false,
                isBand24Blocked = blocked24Macs.contains(mac),
                isBand5Blocked = blocked5Macs.contains(mac),
                staticIpReserved = staticReservedMacs.contains(mac),
                frequencyBandLabel = connType.label,
                signalStrengthDbm = assoc?.signalDbm,
                linkSpeedMbps = linkSpeed,
                rxRateMbps = assoc?.rxMbps ?: 0f,
                txRateMbps = assoc?.txMbps ?: 0f,
                totalDownloadedBytes = 0L,
                totalUploadedBytes = 0L,
                connectedDurationSeconds = assoc?.connectedSeconds ?: 0L,
                dhcpType = if (staticReservedMacs.contains(mac)) "Static" else "DHCP",
                lastSeenLabel = if (isWifiBlocked) "Blocked" else if (isOnline) "Online" else "Lease Inactive"
            )
        }.sortedWith(compareByDescending<ConnectedDevice> { it.isOnline }.thenBy { it.name.lowercase() })
    }

    fun mapNetworkSettings(
        interfaceDumpObj: JsonObject?,
        uciNetworkObj: JsonObject?,
        uciDhcpObj: JsonObject?,
        uciFirewallObj: JsonObject?,
        uciSystemObj: JsonObject?,
        activeLeasesCount: Int
    ): NetworkSettings {
        val netValues = (uciNetworkObj?.get("values") as? JsonObject) ?: uciNetworkObj ?: JsonObject(emptyMap())
        val dhcpValues = (uciDhcpObj?.get("values") as? JsonObject) ?: uciDhcpObj ?: JsonObject(emptyMap())
        val fwValues = (uciFirewallObj?.get("values") as? JsonObject) ?: uciFirewallObj ?: JsonObject(emptyMap())
        val sysValues = (uciSystemObj?.get("values") as? JsonObject) ?: uciSystemObj ?: JsonObject(emptyMap())

        val dumpedIfaces = (interfaceDumpObj?.get("interface") as? JsonArray).orEmpty()
            .mapNotNull { it as? JsonObject }

        val wanDump = dumpedIfaces.firstOrNull { it.str("interface").equals("wan", ignoreCase = true) }
        val lanDump = dumpedIfaces.firstOrNull { it.str("interface").equals("lan", ignoreCase = true) }
        val wanUci = netValues["wan"] as? JsonObject
        val lanUci = netValues["lan"] as? JsonObject

        val wanProto = wanDump?.str("proto") ?: wanUci?.str("proto") ?: "dhcp"
        val wanType = when (wanProto.lowercase()) {
            "pppoe" -> WanConnectionType.PPPOE
            "static" -> WanConnectionType.STATIC
            "none", "bridge" -> WanConnectionType.BRIDGE
            else -> WanConnectionType.DHCP
        }
        val wanDnsServers = (wanDump?.get("dns-server") as? JsonArray)
            ?.mapNotNull { (it as? JsonPrimitive)?.content }
            .orEmpty()
        val wanGateway = (wanDump?.get("route") as? JsonArray)
            ?.mapNotNull { it as? JsonObject }
            ?.firstOrNull { it.str("target") == "0.0.0.0" }
            ?.str("nexthop")
            ?: "N/A"
        val wanIp = extractFirstIpv4(wanDump) ?: "N/A"
        val wanMaskBits = extractFirstIpv4MaskBits(wanDump)
        val wanUp = wanDump?.bool("up") == true

        val wanInfo = WanInfo(
            statusLabel = if (wanUp) "Connected" else "Down",
            connectionType = wanType,
            publicIp = wanIp,
            subnetMask = wanMaskBits?.let(::prefixToSubnetMask) ?: "255.255.255.0",
            gatewayIp = wanGateway,
            primaryDns = wanDnsServers.getOrNull(0) ?: "Auto",
            secondaryDns = wanDnsServers.getOrNull(1) ?: "",
            mtu = wanUci?.str("mtu")?.toIntOrNull() ?: 1500,
            ispName = wanDump?.str("l3_device") ?: wanProto.uppercase(Locale.US)
        )

        val wanProfiles = dumpedIfaces
            .filter {
                val n = it.str("interface").orEmpty().lowercase()
                n.startsWith("wan") || n.startsWith("wwan")
            }
            .map { iface ->
                val name = iface.str("interface") ?: "wan"
                val proto = iface.str("proto") ?: "dhcp"
                WanConnectionProfile(
                    id = name,
                    name = name,
                    serviceType = "INTERNET",
                    connectionType = when (proto.lowercase()) {
                        "pppoe" -> WanConnectionType.PPPOE
                        "static" -> WanConnectionType.STATIC
                        else -> WanConnectionType.DHCP
                    },
                    vlanId = null,
                    isDefaultRoute = name == "wan",
                    statusLabel = if (iface.bool("up") == true) "Connected" else "Down",
                    ipAddress = extractFirstIpv4(iface) ?: "Disconnected",
                    enabled = iface.bool("up") == true
                )
            }

        val lanIp = extractFirstIpv4(lanDump) ?: lanUci?.str("ipaddr") ?: "192.168.1.1"
        val lanMask = lanUci?.str("netmask")
            ?: extractFirstIpv4MaskBits(lanDump)?.let(::prefixToSubnetMask)
            ?: "255.255.255.0"
        val hostname = sysValues.values
            .mapNotNull { it as? JsonObject }
            .firstOrNull { it.str(".type") == "system" }
            ?.str("hostname")
            ?: "OpenWrt"

        val lanConfig = LanConfig(
            routerIp = lanIp,
            subnetMask = lanMask,
            hostname = hostname,
            igmpSnoopingEnabled = lanUci?.isUciTrue("igmp_snooping") == true
        )

        val dhcpLanSec = dhcpValues["lan"] as? JsonObject
        val dhcpDisabled = dhcpLanSec?.str("ignore") == "1"
        val dhcpStartOffset = dhcpLanSec?.str("start")?.toIntOrNull() ?: 100
        val dhcpLimit = dhcpLanSec?.str("limit")?.toIntOrNull() ?: 150
        val lanPrefix = lanIp.substringBeforeLast('.', "192.168.1")
        val leaseMinutes = parseOpenWrtLeaseMinutes(dhcpLanSec?.str("leasetime") ?: "12h")
        val staticHostsCount = dhcpValues.values.count { (it as? JsonObject)?.str(".type") == "host" }

        val dhcpConfig = DhcpConfig(
            enabled = !dhcpDisabled,
            startIp = "$lanPrefix.$dhcpStartOffset",
            endIp = "$lanPrefix.${(dhcpStartOffset + dhcpLimit - 1).coerceAtMost(254)}",
            leaseTimeMinutes = leaseMinutes,
            activeLeasesCount = activeLeasesCount,
            staticReservationsCount = staticHostsCount
        )

        val dnsmasqSec = dhcpValues.values
            .mapNotNull { it as? JsonObject }
            .firstOrNull { it.str(".type") == "dnsmasq" }
        val customServers = dnsmasqSec?.stringList("server").orEmpty()
        val domainEntries = dhcpValues.entries.mapNotNull { (secId, el) ->
            val obj = el as? JsonObject ?: return@mapNotNull null
            if (obj.str(".type") == "domain") {
                val hName = obj.str("name") ?: return@mapNotNull null
                val ip = obj.str("ip") ?: return@mapNotNull null
                DnsHostEntry(id = secId, hostname = hName, ipAddress = ip)
            } else null
        }

        val dnsConfig = DnsConfig(
            mode = if (customServers.isNotEmpty()) DnsMode.CUSTOM else DnsMode.ISP_AUTO,
            primaryDns = customServers.getOrNull(0) ?: wanInfo.primaryDns.takeIf { it != "Auto" }.orEmpty(),
            secondaryDns = customServers.getOrNull(1) ?: wanInfo.secondaryDns,
            dnsOverHttpsEnabled = false,
            hostEntries = domainEntries
        )

        val portForwards = fwValues.entries.mapNotNull { (secId, el) ->
            val obj = el as? JsonObject ?: return@mapNotNull null
            if (obj.str(".type") != "redirect") return@mapNotNull null
            val extPort = obj.str("src_dport")?.toIntOrNull() ?: return@mapNotNull null
            val intPort = obj.str("dest_port")?.toIntOrNull() ?: extPort
            val destIp = obj.str("dest_ip") ?: return@mapNotNull null
            val proto = when (obj.str("proto")?.lowercase()) {
                "tcp" -> ProtocolType.TCP
                "udp" -> ProtocolType.UDP
                else -> ProtocolType.TCP_UDP
            }
            PortForwardRule(
                id = secId,
                name = obj.str("name") ?: secId,
                externalPort = extPort,
                internalPort = intPort,
                internalIp = destIp,
                protocol = proto,
                enabled = obj.str("enabled") != "0"
            )
        }

        val fwDefaults = fwValues.values
            .mapNotNull { it as? JsonObject }
            .firstOrNull { it.str(".type") == "defaults" }
        val synFlood = fwDefaults?.str("synflood_protect") != "0"
        val wanZone = fwValues.values
            .mapNotNull { it as? JsonObject }
            .firstOrNull { it.str(".type") == "zone" && it.str("name") == "wan" }
        val inputPolicy = wanZone?.str("input")?.uppercase() ?: "REJECT"
        val fwLevel = when {
            inputPolicy == "DROP" && synFlood -> FirewallLevel.HIGH
            inputPolicy == "REJECT" && synFlood -> FirewallLevel.MEDIUM
            inputPolicy == "ACCEPT" -> FirewallLevel.LOW
            else -> FirewallLevel.CUSTOM
        }

        val firewallConfig = FirewallConfig(
            level = fwLevel,
            spiFirewallEnabled = inputPolicy != "ACCEPT",
            dosProtectionEnabled = synFlood,
            respondToWanPing = fwValues.values.any { el ->
                val obj = el as? JsonObject
                obj?.str(".type") == "rule" &&
                    obj.str("name")?.contains("Ping", ignoreCase = true) == true &&
                    obj.str("target") == "ACCEPT" &&
                    obj.str("enabled") != "0"
            },
            ipv6FirewallEnabled = fwDefaults?.str("disable_ipv6") != "1"
        )

        return NetworkSettings(
            wan = wanInfo,
            wanConnections = wanProfiles,
            lan = lanConfig,
            dhcp = dhcpConfig,
            dns = dnsConfig,
            portForwardingRules = portForwards,
            firewall = firewallConfig,
            upnpEnabled = false
        )
    }

    fun mapInterfaceStats(deviceStatusObj: JsonObject): List<InterfaceStat> {
        return deviceStatusObj.entries.mapNotNull { (ifaceName, el) ->
            val obj = el as? JsonObject ?: return@mapNotNull null
            val stats = obj["statistics"] as? JsonObject ?: return@mapNotNull null
            InterfaceStat(
                interfaceName = ifaceName,
                description = obj.str("type") ?: "Network device",
                isUp = obj.bool("up") == true || obj.bool("carrier") == true,
                rxBytes = stats.long("rx_bytes") ?: 0L,
                txBytes = stats.long("tx_bytes") ?: 0L,
                rxPackets = stats.long("rx_packets") ?: 0L,
                txPackets = stats.long("tx_packets") ?: 0L,
                rxErrors = stats.long("rx_errors")?.toInt() ?: 0,
                txErrors = stats.long("tx_errors")?.toInt() ?: 0,
                droppedPackets = ((stats.long("rx_dropped") ?: 0L) + (stats.long("tx_dropped") ?: 0L)).toInt()
            )
        }.sortedBy { it.interfaceName }
    }

    fun computeTrafficSnapshot(
        stats: List<InterfaceStat>,
        previousRxBytes: Long?,
        previousTxBytes: Long?,
        previousTimestampMs: Long?,
        nowMs: Long
    ): Triple<TrafficSnapshot, Long, Long> {
        // Prefer WAN-like interface or sum non-loopback physical interfaces
        val wanStat = stats.firstOrNull {
            val n = it.interfaceName.lowercase()
            n == "wan" || n.startsWith("eth1") || n.startsWith("pppoe")
        } ?: stats.firstOrNull { it.interfaceName != "lo" && it.isUp }

        val totalRx = wanStat?.rxBytes ?: stats.filter { it.interfaceName != "lo" }.sumOf { it.rxBytes }
        val totalTx = wanStat?.txBytes ?: stats.filter { it.interfaceName != "lo" }.sumOf { it.txBytes }

        val elapsedSec = if (previousTimestampMs != null && nowMs > previousTimestampMs) {
            ((nowMs - previousTimestampMs) / 1000f).coerceAtLeast(0.1f)
        } else null

        val dlMbps = if (elapsedSec != null && previousRxBytes != null && totalRx >= previousRxBytes) {
            (((totalRx - previousRxBytes) * 8f) / 1_000_000f) / elapsedSec
        } else 0f

        val ulMbps = if (elapsedSec != null && previousTxBytes != null && totalTx >= previousTxBytes) {
            (((totalTx - previousTxBytes) * 8f) / 1_000_000f) / elapsedSec
        } else 0f

        val snapshot = TrafficSnapshot(
            downloadMbps = dlMbps,
            uploadMbps = ulMbps,
            totalDownloadedBytes = totalRx,
            totalUploadedBytes = totalTx,
            downloadHistoryMbps = listOf(dlMbps),
            uploadHistoryMbps = listOf(ulMbps),
            latencyMs = null,
            packetLossPercent = null
        )
        return Triple(snapshot, totalRx, totalTx)
    }

    fun mapSecurityToEncryption(mode: WifiSecurityMode): String = when (mode) {
        WifiSecurityMode.OPEN -> "none"
        WifiSecurityMode.WPA2_PSK -> "psk2"
        WifiSecurityMode.WPA2_WPA3_TRANSITION -> "sae-mixed"
        WifiSecurityMode.WPA3_SAE -> "sae"
    }

    fun mapEncryptionToSecurity(raw: String?): WifiSecurityMode {
        val norm = raw.orEmpty().lowercase()
        return when {
            norm.isBlank() || norm == "none" -> WifiSecurityMode.OPEN
            norm.contains("sae-mixed") || norm.contains("psk2+sae") -> WifiSecurityMode.WPA2_WPA3_TRANSITION
            norm.startsWith("sae") -> WifiSecurityMode.WPA3_SAE
            else -> WifiSecurityMode.WPA2_PSK
        }
    }

    fun mapBandwidthToHtMode(bandwidthMhz: String, is5Ghz: Boolean): String {
        val num = bandwidthMhz.filter(Char::isDigit).toIntOrNull() ?: 20
        return if (is5Ghz) {
            when {
                num >= 160 -> "VHT160"
                num >= 80 -> "VHT80"
                num >= 40 -> "VHT40"
                else -> "VHT20"
            }
        } else {
            if (num >= 40) "HT40" else "HT20"
        }
    }

    fun mapHtModeToBandwidth(htmode: String?, defaultMhz: String): String {
        val raw = htmode.orEmpty().uppercase()
        return when {
            raw.contains("160") -> "160 MHz"
            raw.contains("80") -> "80 MHz"
            raw.contains("40") -> "40 MHz"
            raw.contains("20") -> "20 MHz"
            else -> defaultMhz
        }
    }

    fun normalizeMac(raw: String): String {
        val clean = raw.trim().replace("-", ":").uppercase(Locale.US)
        return clean
    }

    private fun is5GhzRadio(radioObj: JsonObject): Boolean {
        val band = radioObj.str("band")?.lowercase()
        if (band == "5g" || band == "6g") return true
        if (band == "2g") return false
        val hwmode = radioObj.str("hwmode")?.lowercase()
        if (hwmode == "11a") return true
        val chan = radioObj.str("channel")?.toIntOrNull()
        if (chan != null && chan >= 36) return true
        return false
    }

    private fun extractFirstIpv4(ifaceObj: JsonObject?): String? {
        val addrs = ifaceObj?.get("ipv4-address") as? JsonArray ?: return null
        return (addrs.firstOrNull() as? JsonObject)?.str("address")
    }

    private fun extractFirstIpv4MaskBits(ifaceObj: JsonObject?): Int? {
        val addrs = ifaceObj?.get("ipv4-address") as? JsonArray ?: return null
        return (addrs.firstOrNull() as? JsonObject)?.long("mask")?.toInt()
    }

    private fun prefixToSubnetMask(prefix: Int): String {
        val p = prefix.coerceIn(0, 32)
        val mask = if (p == 0) 0L else (0xFFFFFFFFL shl (32 - p)) and 0xFFFFFFFFL
        return "${(mask shr 24) and 255}.${(mask shr 16) and 255}.${(mask shr 8) and 255}.${mask and 255}"
    }

    private fun parseOpenWrtLeaseMinutes(raw: String): Int {
        val clean = raw.trim().lowercase()
        return when {
            clean.endsWith("h") -> (clean.dropLast(1).toIntOrNull() ?: 12) * 60
            clean.endsWith("m") -> clean.dropLast(1).toIntOrNull() ?: 720
            clean.endsWith("d") -> (clean.dropLast(1).toIntOrNull() ?: 1) * 1440
            else -> clean.toIntOrNull() ?: 720
        }
    }

    private fun inferCategory(name: String): DeviceCategory {
        val n = name.lowercase()
        return when {
            n.contains("iphone") || n.contains("pixel") || n.contains("galaxy") || n.contains("android") -> DeviceCategory.PHONE
            n.contains("macbook") || n.contains("thinkpad") || n.contains("laptop") -> DeviceCategory.LAPTOP
            n.contains("ipad") || n.contains("tablet") -> DeviceCategory.TABLET
            n.contains("tv") || n.contains("roku") || n.contains("appletv") -> DeviceCategory.TV_MEDIA
            n.contains("playstation") || n.contains("xbox") || n.contains("switch") -> DeviceCategory.GAMING
            n.contains("esp") || n.contains("cam") || n.contains("hue") -> DeviceCategory.IOT
            else -> DeviceCategory.UNKNOWN
        }
    }

    private fun JsonObject.str(key: String): String? =
        (this[key] as? JsonPrimitive)?.content

    private fun JsonObject.long(key: String): Long? =
        (this[key] as? JsonPrimitive)?.longOrNull

    private fun JsonObject.bool(key: String): Boolean? =
        (this[key] as? JsonPrimitive)?.booleanOrNull

    private fun JsonObject.isUciTrue(key: String, defaultValue: Boolean = false): Boolean {
        val raw = str(key)?.lowercase() ?: return defaultValue
        return raw == "1" || raw == "true" || raw == "yes"
    }

    private fun JsonObject.stringList(key: String): List<String> {
        val el: JsonElement = this[key] ?: return emptyList()
        return when (el) {
            is JsonArray -> el.mapNotNull { (it as? JsonPrimitive)?.content }
            is JsonPrimitive -> listOf(el.content)
            else -> emptyList()
        }
    }
}
