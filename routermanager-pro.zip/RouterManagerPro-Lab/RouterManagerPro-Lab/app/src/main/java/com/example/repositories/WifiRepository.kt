package com.example.repositories

import com.example.core.AppMode
import com.example.core.RouterResult
import com.example.core.Validators
import com.example.models.GuestNetworkConfig
import com.example.models.RouterCapability
import com.example.models.WifiBand
import com.example.models.WifiBandConfig
import com.example.models.WifiConfig
import com.example.router.RouterController
import kotlinx.coroutines.flow.StateFlow

class WifiRepository(
    private val controller: RouterController
) {
    val appMode: StateFlow<AppMode> = controller.appMode
    val revision: StateFlow<Long> = controller.revision

    fun getCapabilities(): RouterCapability? = controller.getCurrentCapabilities()

    suspend fun getWifiConfig(): RouterResult<WifiConfig> = controller.getWifiConfig()

    suspend fun setMasterWifiEnabled(enabled: Boolean): RouterResult<WifiConfig> =
        controller.setWifiEnabled(enabled)

    suspend fun updateBandConfig(band: WifiBand, config: WifiBandConfig): RouterResult<WifiConfig> {
        val ssidValidation = Validators.validateSsid(config.ssid)
        if (!ssidValidation.isValid) {
            return RouterResult.ValidationError("ssid", ssidValidation.errorOrNull ?: "Invalid SSID.")
        }
        val passValidation = Validators.validateWifiPassword(config.password, config.securityMode)
        if (!passValidation.isValid) {
            return RouterResult.ValidationError("password", passValidation.errorOrNull ?: "Invalid passphrase.")
        }
        return controller.updateWifiBandConfig(band, config)
    }

    suspend fun updateGuestNetwork(config: GuestNetworkConfig): RouterResult<WifiConfig> {
        val ssidValidation = Validators.validateSsid(config.ssid)
        if (!ssidValidation.isValid) {
            return RouterResult.ValidationError("guest_ssid", ssidValidation.errorOrNull ?: "Invalid guest SSID.")
        }
        val passValidation = Validators.validateWifiPassword(config.password, config.securityMode)
        if (!passValidation.isValid) {
            return RouterResult.ValidationError("guest_password", passValidation.errorOrNull ?: "Invalid guest passphrase.")
        }
        return controller.updateGuestNetwork(config)
    }
}
