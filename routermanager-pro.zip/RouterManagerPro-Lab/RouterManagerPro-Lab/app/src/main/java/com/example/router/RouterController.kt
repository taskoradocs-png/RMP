package com.example.router

import com.example.adapters.RouterCapabilityRegistry
import com.example.authentication.KeystoreCredentialCipher
import com.example.authentication.RouterAuthenticationManager
import com.example.authentication.RouterSessionManager
import com.example.core.AppMode
import com.example.core.RouterResult
import com.example.models.ConnectedDevice
import com.example.models.DhcpConfig
import com.example.models.DiagnosticResult
import com.example.models.DnsConfig
import com.example.models.EthernetPortInfo
import com.example.models.FirewallConfig
import com.example.models.GuestNetworkConfig
import com.example.models.InterfaceStat
import com.example.models.LanConfig
import com.example.models.NetworkActivityEvent
import com.example.models.NetworkSettings
import com.example.models.OpticalInfo
import com.example.models.ParentalControlTemplate
import com.example.models.PortForwardRule
import com.example.models.RouterCapability
import com.example.models.RouterCredentials
import com.example.models.RouterFeature
import com.example.models.RouterInfo
import com.example.models.RouterSession
import com.example.models.SpeedTestResult
import com.example.models.TrafficSnapshot
import com.example.models.VoipLineInfo
import com.example.models.WanConnectionProfile
import com.example.models.WifiBand
import com.example.models.WifiBandConfig
import com.example.models.WifiConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Coordinates AppMode (DEMO vs LIVE), active RouterAdapter, capability gating,
 * authentication lifecycle, and ensures Live Mode never fabricates data.
 */
class RouterController(
    private val adapterRegistry: RouterCapabilityRegistry,
    private val sessionManager: RouterSessionManager,
    private val authenticationManager: RouterAuthenticationManager = RouterAuthenticationManager(
        capabilityRegistry = adapterRegistry,
        sessionManager = sessionManager,
        credentialCipher = KeystoreCredentialCipher(allowJreAesForTests = true)
    )
) {
    private val _appMode = MutableStateFlow(AppMode.DEMO)
    val appMode: StateFlow<AppMode> = _appMode.asStateFlow()

    private val _activeAdapter = MutableStateFlow<RouterAdapter?>(adapterRegistry.demoAdapter)
    val activeAdapter: StateFlow<RouterAdapter?> = _activeAdapter.asStateFlow()

    val currentSession: StateFlow<RouterSession?> = sessionManager.currentSession

    private val _revision = MutableStateFlow(0L)
    val revision: StateFlow<Long> = _revision.asStateFlow()

    init {
        sessionManager.startSession(
            RouterSession(
                sessionId = "demo-initial",
                profileId = "demo-profile-asus",
                routerIp = "192.168.50.1",
                adapterId = adapterRegistry.demoAdapter.descriptor.id,
                authenticatedUsername = "demo-admin",
                establishedAtEpochMs = System.currentTimeMillis(),
                isDemoSession = true
            )
        )
    }

    fun setAppMode(mode: AppMode) {
        if (_appMode.value == mode) return
        _appMode.value = mode
        if (mode == AppMode.DEMO) {
            _activeAdapter.value = adapterRegistry.demoAdapter
            sessionManager.startSession(
                RouterSession(
                    sessionId = "demo-${System.currentTimeMillis()}",
                    profileId = "demo-profile-asus",
                    routerIp = "192.168.50.1",
                    adapterId = adapterRegistry.demoAdapter.descriptor.id,
                    authenticatedUsername = "demo-admin",
                    establishedAtEpochMs = System.currentTimeMillis(),
                    isDemoSession = true
                )
            )
        } else {
            _activeAdapter.value = null
            sessionManager.clearSession()
        }
        bumpRevision()
    }

    fun selectLiveAdapter(adapterId: String) {
        if (_appMode.value == AppMode.LIVE) {
            val adapter = adapterRegistry.getAdapterById(adapterId)
            if (adapter != null && adapter.descriptor.id != adapterRegistry.demoAdapter.descriptor.id) {
                _activeAdapter.value = adapter
                sessionManager.clearSession()
                bumpRevision()
            }
        }
    }

    fun getCurrentCapabilities(): RouterCapability? = _activeAdapter.value?.capabilities

    fun supportsFeature(feature: RouterFeature): Boolean {
        val adapter = _activeAdapter.value ?: return false
        return adapter.capabilities.supports(feature)
    }

    suspend fun authenticateLive(
        adapterId: String,
        credentials: RouterCredentials
    ): RouterResult<RouterSession> {
        val adapter = adapterRegistry.getAdapterById(adapterId)
            ?: return RouterResult.Failure("Selected router adapter '$adapterId' was not found.")
        _appMode.value = AppMode.LIVE
        _activeAdapter.value = adapter
        val result = authenticationManager.authenticate(
            adapterId = adapterId,
            credentials = credentials,
            overrideAdapter = adapter
        )
        if (result !is RouterResult.Success) {
            _activeAdapter.value = null
        }
        bumpRevision()
        return result
    }

    suspend fun disconnectLive(): RouterResult<Unit> {
        val adapter = _activeAdapter.value
        val result = authenticationManager.logout(adapter)
        if (_appMode.value == AppMode.LIVE) {
            _activeAdapter.value = null
        }
        bumpRevision()
        return result
    }

    private suspend fun <T> requireReadyAndCapable(
        requiredFeature: RouterFeature? = null,
        block: suspend (RouterAdapter) -> RouterResult<T>
    ): RouterResult<T> {
        if (_appMode.value == AppMode.LIVE && sessionManager.isExpired()) {
            val reason = "Your router session expired. Please authenticate again."
            authenticationManager.onSessionExpired(reason)
            _activeAdapter.value = null
            bumpRevision()
            return RouterResult.AuthRequired(reason)
        }
        val adapter = _activeAdapter.value
            ?: return RouterResult.NotConnected("No router adapter connected in Live Router Mode.")
        if (_appMode.value == AppMode.LIVE && !sessionManager.isAuthenticated()) {
            return RouterResult.NotConnected("Not authenticated with a live router.")
        }
        if (requiredFeature != null && !adapter.capabilities.supports(requiredFeature)) {
            return RouterResult.Unsupported(
                featureName = requiredFeature.displayName,
                reason = "${adapter.descriptor.displayName} does not support ${requiredFeature.displayName}."
            )
        }
        val result = block(adapter)
        if (_appMode.value == AppMode.LIVE && result is RouterResult.AuthRequired) {
            authenticationManager.onSessionExpired(result.reason)
            _activeAdapter.value = null
            bumpRevision()
        }
        return result
    }

    suspend fun getRouterInfo(): RouterResult<RouterInfo> =
        requireReadyAndCapable(RouterFeature.ROUTER_INFO) { it.getRouterInfo() }

    suspend fun getTrafficSnapshot(): RouterResult<TrafficSnapshot> =
        requireReadyAndCapable(RouterFeature.TRAFFIC_MONITORING) { it.getTrafficSnapshot() }

    suspend fun getRecentActivity(): RouterResult<List<NetworkActivityEvent>> =
        requireReadyAndCapable(RouterFeature.ROUTER_INFO) { it.getRecentActivity() }

    suspend fun getWifiConfig(): RouterResult<WifiConfig> =
        requireReadyAndCapable(RouterFeature.WIFI_BASIC) { it.getWifiConfig() }

    suspend fun setWifiEnabled(enabled: Boolean): RouterResult<WifiConfig> =
        requireReadyAndCapable(RouterFeature.WIFI_BASIC) {
            it.setWifiEnabled(enabled).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun updateWifiBandConfig(band: WifiBand, config: WifiBandConfig): RouterResult<WifiConfig> =
        requireReadyAndCapable(RouterFeature.WIFI_BASIC) {
            it.updateWifiBandConfig(band, config).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun updateGuestNetwork(config: GuestNetworkConfig): RouterResult<WifiConfig> =
        requireReadyAndCapable(RouterFeature.WIFI_GUEST_NETWORK) {
            it.updateGuestNetwork(config).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun getConnectedDevices(): RouterResult<List<ConnectedDevice>> =
        requireReadyAndCapable(RouterFeature.DEVICE_LIST) { it.getConnectedDevices() }

    suspend fun renameDevice(macAddress: String, newName: String): RouterResult<Unit> =
        requireReadyAndCapable(RouterFeature.DEVICE_RENAME) {
            it.renameDevice(macAddress, newName).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun blockDevice(macAddress: String): RouterResult<Unit> =
        requireReadyAndCapable(RouterFeature.DEVICE_BLOCKING) {
            it.blockDevice(macAddress).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun unblockDevice(macAddress: String): RouterResult<Unit> =
        requireReadyAndCapable(RouterFeature.DEVICE_BLOCKING) {
            it.unblockDevice(macAddress).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun setDeviceInternetBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> =
        requireReadyAndCapable(RouterFeature.DEVICE_INTERNET_BLOCKING) {
            it.setDeviceInternetBlocked(macAddress, blocked).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun setDeviceGuestBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> =
        requireReadyAndCapable(RouterFeature.WIFI_GUEST_NETWORK) {
            it.setDeviceGuestBlocked(macAddress, blocked).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun setDeviceBandBlocked(macAddress: String, band: WifiBand, blocked: Boolean): RouterResult<Unit> =
        requireReadyAndCapable(RouterFeature.DEVICE_BAND_BLOCKING) {
            it.setDeviceBandBlocked(macAddress, band, blocked).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun setDeviceStaticIp(macAddress: String, reserved: Boolean): RouterResult<Unit> =
        requireReadyAndCapable(RouterFeature.STATIC_IP_RESERVATION) {
            it.setDeviceStaticIp(macAddress, reserved).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun getNetworkSettings(): RouterResult<NetworkSettings> =
        requireReadyAndCapable(RouterFeature.WAN_INFO) { it.getNetworkSettings() }

    suspend fun updateLanConfig(config: LanConfig): RouterResult<NetworkSettings> =
        requireReadyAndCapable(RouterFeature.LAN_CONFIG) {
            it.updateLanConfig(config).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun updateDhcpConfig(config: DhcpConfig): RouterResult<NetworkSettings> =
        requireReadyAndCapable(RouterFeature.DHCP_CONFIG) {
            it.updateDhcpConfig(config).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun updateDnsConfig(config: DnsConfig): RouterResult<NetworkSettings> =
        requireReadyAndCapable(RouterFeature.DNS_CONFIG) {
            it.updateDnsConfig(config).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun savePortForwardRule(rule: PortForwardRule): RouterResult<NetworkSettings> =
        requireReadyAndCapable(RouterFeature.PORT_FORWARDING) {
            it.savePortForwardRule(rule).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun deletePortForwardRule(ruleId: String): RouterResult<NetworkSettings> =
        requireReadyAndCapable(RouterFeature.PORT_FORWARDING) {
            it.deletePortForwardRule(ruleId).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun updateFirewallConfig(config: FirewallConfig): RouterResult<NetworkSettings> =
        requireReadyAndCapable(RouterFeature.FIREWALL_CONFIG) {
            it.updateFirewallConfig(config).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun setUpnpEnabled(enabled: Boolean): RouterResult<NetworkSettings> =
        requireReadyAndCapable(RouterFeature.UPNP_CONFIG) {
            it.setUpnpEnabled(enabled).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun saveWanConnection(profile: WanConnectionProfile): RouterResult<NetworkSettings> =
        requireReadyAndCapable(RouterFeature.MULTI_WAN) {
            it.saveWanConnection(profile).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun deleteWanConnection(profileId: String): RouterResult<NetworkSettings> =
        requireReadyAndCapable(RouterFeature.MULTI_WAN) {
            it.deleteWanConnection(profileId).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun runDiagnostics(): RouterResult<List<DiagnosticResult>> =
        requireReadyAndCapable(RouterFeature.NETWORK_DIAGNOSTICS) {
            it.runNetworkDiagnostics().also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun getOpticalInfo(): RouterResult<OpticalInfo> =
        requireReadyAndCapable(RouterFeature.OPTICAL_INFO) { it.getOpticalInfo() }

    suspend fun getEthernetPorts(): RouterResult<List<EthernetPortInfo>> =
        requireReadyAndCapable(RouterFeature.ETHERNET_PORT_STATUS) { it.getEthernetPorts() }

    suspend fun getInterfaceStats(): RouterResult<List<InterfaceStat>> =
        requireReadyAndCapable(RouterFeature.INTERFACE_STATS) { it.getInterfaceStats() }

    suspend fun getVoipStatus(): RouterResult<List<VoipLineInfo>> =
        requireReadyAndCapable(RouterFeature.VOIP_STATUS) { it.getVoipStatus() }

    suspend fun getParentalTemplates(): RouterResult<List<ParentalControlTemplate>> =
        requireReadyAndCapable(RouterFeature.PARENTAL_CONTROL) { it.getParentalTemplates() }

    suspend fun saveParentalTemplate(template: ParentalControlTemplate): RouterResult<List<ParentalControlTemplate>> =
        requireReadyAndCapable(RouterFeature.PARENTAL_CONTROL) {
            it.saveParentalTemplate(template).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun deleteParentalTemplate(templateId: String): RouterResult<List<ParentalControlTemplate>> =
        requireReadyAndCapable(RouterFeature.PARENTAL_CONTROL) {
            it.deleteParentalTemplate(templateId).also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun runSpeedTest(): RouterResult<SpeedTestResult> =
        requireReadyAndCapable(RouterFeature.SPEED_TEST) {
            it.runSpeedTest().also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    suspend fun rebootRouter(): RouterResult<Unit> =
        requireReadyAndCapable(RouterFeature.ROUTER_REBOOT) {
            it.rebootRouter().also { res -> if (res is RouterResult.Success) bumpRevision() }
        }

    private fun bumpRevision() {
        _revision.value += 1L
    }
}
