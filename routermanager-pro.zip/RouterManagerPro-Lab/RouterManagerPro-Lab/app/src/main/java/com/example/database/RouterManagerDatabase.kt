package com.example.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [RouterProfileEntity::class],
    version = 1,
    exportSchema = false
)
abstract class RouterManagerDatabase : RoomDatabase() {
    abstract fun routerProfileDao(): RouterProfileDao

    companion object {
        @Volatile
        private var instance: RouterManagerDatabase? = null

        fun getInstance(context: Context): RouterManagerDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    RouterManagerDatabase::class.java,
                    "router_manager_pro.db"
                ).build().also { instance = it }
            }
        }
    }
}
