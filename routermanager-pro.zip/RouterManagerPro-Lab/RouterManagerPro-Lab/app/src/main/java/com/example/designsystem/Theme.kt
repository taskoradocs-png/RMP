package com.example.designsystem

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.unit.dp
import com.example.core.AccentColorOption
import com.example.core.CornerStyleOption
import com.example.core.ThemePreference
import com.example.core.ThemeStyleOption

data class RouterThemeConfig(
    val accentColor: AccentColorOption = AccentColorOption.BLUE,
    val themeStyle: ThemeStyleOption = ThemeStyleOption.ICE,
    val cornerStyle: CornerStyleOption = CornerStyleOption.ROUNDED,
    val isDark: Boolean = true
)

val LocalRouterThemeConfig = staticCompositionLocalOf { RouterThemeConfig() }

fun accentPalette(accent: AccentColorOption): Pair<Color, Color> = when (accent) {
    AccentColorOption.BLUE -> Color(0xFF1E88FF) to Color(0xFF172D59)
    AccentColorOption.PURPLE -> Color(0xFF7C5CFF) to Color(0xFF2B2158)
    AccentColorOption.GREEN -> Color(0xFF10B981) to Color(0xFF0E392E)
    AccentColorOption.ORANGE -> Color(0xFFFF8A00) to Color(0xFF43260B)
    AccentColorOption.ROSE -> Color(0xFFEC4899) to Color(0xFF421732)
    AccentColorOption.TEAL -> Color(0xFF06B6D4) to Color(0xFF0D3847)
}

@Composable
fun RouterManagerTheme(
    themePreference: ThemePreference = ThemePreference.DARK,
    accentColor: AccentColorOption = AccentColorOption.BLUE,
    themeStyle: ThemeStyleOption = ThemeStyleOption.ICE,
    cornerStyle: CornerStyleOption = CornerStyleOption.ROUNDED,
    content: @Composable () -> Unit
) {
    val useDark = when (themePreference) {
        ThemePreference.DARK -> true
        ThemePreference.LIGHT -> false
        ThemePreference.SYSTEM -> isSystemInDarkTheme()
    }

    val (accentPrimary, accentContainerDark) = accentPalette(accentColor)

    val surfaceDark = when (themeStyle) {
        ThemeStyleOption.CLASSIC -> Color(0xFF0E1629)
        ThemeStyleOption.ONE_UI -> Color(0xFF131D35)
        ThemeStyleOption.ICE -> Color(0xFF10192E)
        ThemeStyleOption.HALO -> Color(0xFF101830)
    }

    val colorScheme = if (useDark) {
        darkColorScheme(
            primary = accentPrimary,
            onPrimary = Color.White,
            primaryContainer = accentContainerDark,
            onPrimaryContainer = accentPrimary,
            secondary = CyanAccent,
            onSecondary = NavyVoid,
            secondaryContainer = BlueMuted,
            onSecondaryContainer = TextPrimaryDark,
            tertiary = EmeraldOnline,
            onTertiary = NavyVoid,
            tertiaryContainer = EmeraldSurface,
            onTertiaryContainer = EmeraldOnline,
            background = NavyVoid,
            onBackground = TextPrimaryDark,
            surface = CharcoalBase,
            onSurface = TextPrimaryDark,
            surfaceVariant = CharcoalSurface,
            onSurfaceVariant = TextSecondaryDark,
            surfaceContainerLowest = NavyVoid,
            surfaceContainerLow = CharcoalBase,
            surfaceContainer = surfaceDark,
            surfaceContainerHigh = CharcoalElevated,
            surfaceContainerHighest = CharcoalHighest,
            outline = TextMutedDark,
            outlineVariant = if (themeStyle == ThemeStyleOption.ICE) accentPrimary.copy(alpha = 0.22f) else HairlineBorderDark,
            error = RoseCritical,
            onError = Color.White,
            errorContainer = RoseSurface,
            onErrorContainer = RoseCritical
        )
    } else {
        lightColorScheme(
            primary = accentPrimary,
            onPrimary = Color.White,
            primaryContainer = accentPrimary.copy(alpha = 0.14f),
            onPrimaryContainer = accentPrimary,
            secondary = BlueSecondaryLight,
            onSecondary = Color.White,
            secondaryContainer = Color(0xFFDBEAFE),
            onSecondaryContainer = Color(0xFF1E3A8A),
            tertiary = Color(0xFF047857),
            onTertiary = Color.White,
            tertiaryContainer = Color(0xFFD1FAE5),
            onTertiaryContainer = Color(0xFF064E3B),
            background = LightBackground,
            onBackground = TextPrimaryLight,
            surface = LightSurface,
            onSurface = TextPrimaryLight,
            surfaceVariant = LightSurfaceElevated,
            onSurfaceVariant = TextSecondaryLight,
            surfaceContainerLowest = Color.White,
            surfaceContainerLow = LightBackground,
            surfaceContainer = LightSurface,
            surfaceContainerHigh = LightSurfaceElevated,
            surfaceContainerHighest = Color(0xFFE2E8F0),
            outline = TextSecondaryLight,
            outlineVariant = HairlineBorderLight,
            error = Color(0xFFBE123C),
            onError = Color.White,
            errorContainer = Color(0xFFFFE4E6),
            onErrorContainer = Color(0xFF881337)
        )
    }

    val cardRadius = when (themeStyle) {
        ThemeStyleOption.ONE_UI -> (cornerStyle.cardRadiusDp + 4).dp
        else -> cornerStyle.cardRadiusDp.dp
    }
    val dynamicShapes = Shapes(
        extraSmall = RoundedCornerShape((cornerStyle.cardRadiusDp / 3).coerceAtLeast(4).dp),
        small = RoundedCornerShape((cornerStyle.buttonRadiusDp / 2).coerceAtLeast(6).dp),
        medium = RoundedCornerShape(cardRadius),
        large = RoundedCornerShape(cardRadius + 4.dp),
        extraLarge = RoundedCornerShape(cardRadius + 8.dp)
    )

    val themeConfig = RouterThemeConfig(
        accentColor = accentColor,
        themeStyle = themeStyle,
        cornerStyle = cornerStyle,
        isDark = useDark
    )

    CompositionLocalProvider(LocalRouterThemeConfig provides themeConfig) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = RouterTypography,
            shapes = dynamicShapes,
            content = content
        )
    }
}
