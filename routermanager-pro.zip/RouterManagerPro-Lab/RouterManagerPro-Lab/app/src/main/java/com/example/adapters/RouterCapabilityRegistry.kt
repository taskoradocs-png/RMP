package com.example.adapters

import com.example.adapters.demo.DemoDataProvider
import com.example.adapters.demo.DemoRouterAdapter
import com.example.adapters.live.AsusWrtRouterAdapter
import com.example.adapters.live.NetgearNighthawkAdapter
import com.example.adapters.live.OpenWrtAdapter
import com.example.adapters.live.TpLinkArcherAdapter
import com.example.authentication.RouterSessionManager
import com.example.models.AdapterDescriptor
import com.example.models.RouterCapability
import com.example.models.RouterFeature
import com.example.router.RouterAdapter

data class AdapterMatchResult(
    val adapter: RouterAdapter,
    val confidenceLabel: String,
    val reason: String
)

/**
 * Central registry for router adapters and per-firmware capabilities.
 * Supports live OpenWrt discovery/transport while keeping future manufacturer
 * adapters cleanly decoupled and staged.
 */
open class RouterCapabilityRegistry(
    demoDataProvider: DemoDataProvider,
    sessionManager: RouterSessionManager = RouterSessionManager()
) {
    val demoAdapter: RouterAdapter = DemoRouterAdapter(demoDataProvider)
    val openWrtAdapter: OpenWrtAdapter = OpenWrtAdapter(sessionManager)

    private val liveAdapters: List<RouterAdapter> = listOf(
        openWrtAdapter,
        AsusWrtRouterAdapter(),
        TpLinkArcherAdapter(),
        NetgearNighthawkAdapter()
    )

    fun getAllSupportedDescriptors(): List<AdapterDescriptor> =
        liveAdapters.map { it.descriptor }

    fun getAdapterById(id: String): RouterAdapter? {
        if (id == demoAdapter.descriptor.id) return demoAdapter
        return liveAdapters.firstOrNull { it.descriptor.id == id }
    }

    fun getCapabilities(adapterId: String): RouterCapability? =
        getAdapterById(adapterId)?.capabilities

    fun supportsFeature(adapterId: String, feature: RouterFeature): Boolean =
        getAdapterById(adapterId)?.capabilities?.supports(feature) == true

    fun identifyCompatibleAdapter(
        manufacturer: String,
        model: String,
        firmwareVersion: String = ""
    ): AdapterMatchResult? {
        val mfg = manufacturer.trim().lowercase()
        val mdl = model.trim().lowercase()
        val fw = firmwareVersion.trim().lowercase()

        val exactModelMatch = liveAdapters.firstOrNull { adapter ->
            val d = adapter.descriptor
            d.manufacturer.lowercase() == mfg &&
                d.supportedModels.any { it.lowercase().contains(mdl) || mdl.contains(it.lowercase()) }
        }
        if (exactModelMatch != null) {
            val fwNote = if (fw.isNotBlank() && fw >= exactModelMatch.descriptor.minFirmwareVersion.lowercase()) {
                "Firmware $firmwareVersion meets minimum ${exactModelMatch.descriptor.minFirmwareVersion}."
            } else if (fw.isNotBlank()) {
                "Firmware $firmwareVersion matched by manufacturer/model."
            } else {
                "Matched by manufacturer and model."
            }
            return AdapterMatchResult(
                adapter = exactModelMatch,
                confidenceLabel = "Exact Model Match",
                reason = fwNote
            )
        }

        val mfgMatch = liveAdapters.firstOrNull {
            it.descriptor.manufacturer.lowercase() == mfg ||
                ((mfg.contains("gl.inet") || mfg.contains("openwrt")) && it.descriptor.id == OpenWrtAdapter.ADAPTER_ID)
        }
        if (mfgMatch != null) {
            return AdapterMatchResult(
                adapter = mfgMatch,
                confidenceLabel = "Manufacturer Family Match",
                reason = "Matched ${mfgMatch.descriptor.manufacturer} adapter family; capabilities verified against device API."
            )
        }

        return null
    }
}
