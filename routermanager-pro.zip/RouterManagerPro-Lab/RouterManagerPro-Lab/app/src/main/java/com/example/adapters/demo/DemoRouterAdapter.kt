package com.example.adapters.demo

import com.example.core.RouterResult
import com.example.models.AdapterDescriptor
import com.example.models.ConnectedDevice
import com.example.models.DhcpConfig
import com.example.models.DiagnosticResult
import com.example.models.DnsConfig
import com.example.models.EthernetPortInfo
import com.example.models.FirewallConfig
import com.example.models.GuestNetworkConfig
import com.example.models.InterfaceStat
import com.example.models.LanConfig
import com.example.models.NetworkActivityEvent
import com.example.models.NetworkSettings
import com.example.models.OpticalInfo
import com.example.models.ParentalControlTemplate
import com.example.models.PortForwardRule
import com.example.models.RouterCapability
import com.example.models.RouterCredentials
import com.example.models.RouterFeature
import com.example.models.RouterInfo
import com.example.models.RouterSession
import com.example.models.SpeedTestResult
import com.example.models.TrafficSnapshot
import com.example.models.VoipLineInfo
import com.example.models.WanConnectionProfile
import com.example.models.WifiBand
import com.example.models.WifiBandConfig
import com.example.models.WifiConfig
import com.example.router.RouterAdapter

class DemoRouterAdapter(
    private val demoDataProvider: DemoDataProvider
) : RouterAdapter {

    override val capabilities = RouterCapability(
        supportedFeatures = RouterFeature.entries.toSet(),
        supports5Ghz = true,
        maxGuestNetworks = 1,
        capabilityNotes = "Demo Sandbox exposes all administration screens for preview."
    )

    override val descriptor = AdapterDescriptor(
        id = "demo_sandbox",
        displayName = "Demo Sandbox Adapter",
        manufacturer = "RouterManager Demo",
        supportedModels = listOf("RT-AX86U Pro (Demo)"),
        minFirmwareVersion = "3.0.0.4",
        protocolDescription = "Isolated in-memory demonstration sandbox (no network I/O).",
        capability = capabilities,
        isLiveTransportReady = false
    )

    override suspend fun authenticate(credentials: RouterCredentials): RouterResult<RouterSession> {
        return RouterResult.Success(
            data = RouterSession(
                sessionId = "demo-session",
                profileId = "demo-profile-asus",
                routerIp = demoDataProvider.getRouterInfo().routerIp,
                adapterId = descriptor.id,
                authenticatedUsername = credentials.username.ifBlank { "demo-admin" },
                establishedAtEpochMs = System.currentTimeMillis(),
                isDemoSession = true
            ),
            isDemoData = true
        )
    }

    override suspend fun disconnect(): RouterResult<Unit> = RouterResult.Success(Unit, isDemoData = true)

    override suspend fun getRouterInfo(): RouterResult<RouterInfo> =
        RouterResult.Success(demoDataProvider.getRouterInfo(), isDemoData = true)

    override suspend fun getTrafficSnapshot(): RouterResult<TrafficSnapshot> =
        RouterResult.Success(demoDataProvider.getTrafficSnapshot(), isDemoData = true)

    override suspend fun getRecentActivity(): RouterResult<List<NetworkActivityEvent>> =
        RouterResult.Success(demoDataProvider.getRecentActivity(), isDemoData = true)

    override suspend fun getWifiConfig(): RouterResult<WifiConfig> =
        RouterResult.Success(demoDataProvider.getWifiConfig(), isDemoData = true)

    override suspend fun setWifiEnabled(enabled: Boolean): RouterResult<WifiConfig> =
        RouterResult.Success(demoDataProvider.setWifiEnabled(enabled), isDemoData = true)

    override suspend fun updateSsid(band: WifiBand, ssid: String): RouterResult<WifiConfig> =
        RouterResult.Success(demoDataProvider.updateSsid(band, ssid), isDemoData = true)

    override suspend fun updateWifiPassword(band: WifiBand, password: String): RouterResult<WifiConfig> =
        RouterResult.Success(demoDataProvider.updateWifiPassword(band, password), isDemoData = true)

    override suspend fun updateWifiBandConfig(band: WifiBand, config: WifiBandConfig): RouterResult<WifiConfig> =
        RouterResult.Success(demoDataProvider.updateWifiBandConfig(band, config), isDemoData = true)

    override suspend fun updateGuestNetwork(config: GuestNetworkConfig): RouterResult<WifiConfig> =
        RouterResult.Success(demoDataProvider.updateGuestNetwork(config), isDemoData = true)

    override suspend fun getConnectedDevices(): RouterResult<List<ConnectedDevice>> =
        RouterResult.Success(demoDataProvider.getDevices(), isDemoData = true)

    override suspend fun renameDevice(macAddress: String, newName: String): RouterResult<Unit> {
        return if (demoDataProvider.renameDevice(macAddress, newName)) {
            RouterResult.Success(Unit, isDemoData = true)
        } else {
            RouterResult.Failure("Unable to rename $macAddress in Demo Sandbox.")
        }
    }

    override suspend fun blockDevice(macAddress: String): RouterResult<Unit> {
        return if (demoDataProvider.blockDevice(macAddress)) {
            RouterResult.Success(Unit, isDemoData = true)
        } else {
            RouterResult.Failure("Device $macAddress not found in Demo Sandbox.")
        }
    }

    override suspend fun unblockDevice(macAddress: String): RouterResult<Unit> {
        return if (demoDataProvider.unblockDevice(macAddress)) {
            RouterResult.Success(Unit, isDemoData = true)
        } else {
            RouterResult.Failure("Device $macAddress not found in Demo Sandbox.")
        }
    }

    override suspend fun setDeviceInternetBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> {
        return if (demoDataProvider.setDeviceInternetBlocked(macAddress, blocked)) {
            RouterResult.Success(Unit, isDemoData = true)
        } else {
            RouterResult.Failure("Device $macAddress not found in Demo Sandbox.")
        }
    }

    override suspend fun setDeviceGuestBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> {
        return if (demoDataProvider.setDeviceGuestBlocked(macAddress, blocked)) {
            RouterResult.Success(Unit, isDemoData = true)
        } else {
            RouterResult.Failure("Device $macAddress not found in Demo Sandbox.")
        }
    }

    override suspend fun setDeviceBandBlocked(macAddress: String, band: WifiBand, blocked: Boolean): RouterResult<Unit> {
        return if (demoDataProvider.setDeviceBandBlocked(macAddress, band, blocked)) {
            RouterResult.Success(Unit, isDemoData = true)
        } else {
            RouterResult.Failure("Device $macAddress not found in Demo Sandbox.")
        }
    }

    override suspend fun setDeviceStaticIp(macAddress: String, reserved: Boolean): RouterResult<Unit> {
        return if (demoDataProvider.setDeviceStaticIp(macAddress, reserved)) {
            RouterResult.Success(Unit, isDemoData = true)
        } else {
            RouterResult.Failure("Device $macAddress not found in Demo Sandbox.")
        }
    }

    override suspend fun getNetworkSettings(): RouterResult<NetworkSettings> =
        RouterResult.Success(demoDataProvider.getNetworkSettings(), isDemoData = true)

    override suspend fun updateLanConfig(lanConfig: LanConfig): RouterResult<NetworkSettings> =
        RouterResult.Success(demoDataProvider.updateLanConfig(lanConfig), isDemoData = true)

    override suspend fun updateDhcpConfig(dhcpConfig: DhcpConfig): RouterResult<NetworkSettings> =
        RouterResult.Success(demoDataProvider.updateDhcpConfig(dhcpConfig), isDemoData = true)

    override suspend fun updateDnsConfig(dnsConfig: DnsConfig): RouterResult<NetworkSettings> =
        RouterResult.Success(demoDataProvider.updateDnsConfig(dnsConfig), isDemoData = true)

    override suspend fun savePortForwardRule(rule: PortForwardRule): RouterResult<NetworkSettings> =
        RouterResult.Success(demoDataProvider.savePortForwardRule(rule), isDemoData = true)

    override suspend fun deletePortForwardRule(ruleId: String): RouterResult<NetworkSettings> =
        RouterResult.Success(demoDataProvider.deletePortForwardRule(ruleId), isDemoData = true)

    override suspend fun updateFirewallConfig(firewallConfig: FirewallConfig): RouterResult<NetworkSettings> =
        RouterResult.Success(demoDataProvider.updateFirewallConfig(firewallConfig), isDemoData = true)

    override suspend fun setUpnpEnabled(enabled: Boolean): RouterResult<NetworkSettings> =
        RouterResult.Success(demoDataProvider.setUpnpEnabled(enabled), isDemoData = true)

    override suspend fun saveWanConnection(profile: WanConnectionProfile): RouterResult<NetworkSettings> =
        RouterResult.Success(demoDataProvider.saveWanConnection(profile), isDemoData = true)

    override suspend fun deleteWanConnection(profileId: String): RouterResult<NetworkSettings> =
        RouterResult.Success(demoDataProvider.deleteWanConnection(profileId), isDemoData = true)

    override suspend fun runNetworkDiagnostics(): RouterResult<List<DiagnosticResult>> =
        RouterResult.Success(demoDataProvider.runDiagnostics(), isDemoData = true)

    override suspend fun getOpticalInfo(): RouterResult<OpticalInfo> =
        RouterResult.Success(demoDataProvider.getOpticalInfo(), isDemoData = true)

    override suspend fun getEthernetPorts(): RouterResult<List<EthernetPortInfo>> =
        RouterResult.Success(demoDataProvider.getEthernetPorts(), isDemoData = true)

    override suspend fun getInterfaceStats(): RouterResult<List<InterfaceStat>> =
        RouterResult.Success(demoDataProvider.getInterfaceStats(), isDemoData = true)

    override suspend fun getVoipStatus(): RouterResult<List<VoipLineInfo>> =
        RouterResult.Success(demoDataProvider.getVoipStatus(), isDemoData = true)

    override suspend fun getParentalTemplates(): RouterResult<List<ParentalControlTemplate>> =
        RouterResult.Success(demoDataProvider.getParentalTemplates(), isDemoData = true)

    override suspend fun saveParentalTemplate(template: ParentalControlTemplate): RouterResult<List<ParentalControlTemplate>> =
        RouterResult.Success(demoDataProvider.saveParentalTemplate(template), isDemoData = true)

    override suspend fun deleteParentalTemplate(templateId: String): RouterResult<List<ParentalControlTemplate>> =
        RouterResult.Success(demoDataProvider.deleteParentalTemplate(templateId), isDemoData = true)

    override suspend fun runSpeedTest(): RouterResult<SpeedTestResult> =
        RouterResult.Success(demoDataProvider.runSpeedTest(), isDemoData = true)

    override suspend fun rebootRouter(): RouterResult<Unit> {
        demoDataProvider.rebootDemoRouter()
        return RouterResult.Success(Unit, isDemoData = true)
    }
}
