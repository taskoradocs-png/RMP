package com.example.features.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Router
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.designsystem.AdminCard

private data class GuideItem(
    val title: String,
    val body: String,
    val icon: ImageVector
)

private val GUIDE_ITEMS = listOf(
    GuideItem(
        title = "Demo Sandbox vs. Live Router Mode",
        body = "Demo Mode runs completely offline with simulated ASUS/GPON sandbox telemetry so you can test every feature safely. Live Router Mode requires real gateway authentication and never fabricates connectivity or device counts.",
        icon = Icons.Outlined.Router
    ),
    GuideItem(
        title = "Dashboard & Quick Telemetry",
        body = "Swipe the Hero Card to toggle between hardware status and WAN throughput. Tap any tile under Stats & Diagnostics (Optical Info, Ethernet Ports, Device Info, Usage) to inspect real-time metrics.",
        icon = Icons.Outlined.Dashboard
    ),
    GuideItem(
        title = "Connected Devices & Blocking",
        body = "Tap a client card to view signal strength (dBm) and frequency band. Use the pencil icon to rename a device, reserve a Static IP, block Guest Wi-Fi, block WAN Internet only (keeping LAN alive), or block the MAC completely.",
        icon = Icons.Outlined.Devices
    ),
    GuideItem(
        title = "Wi-Fi & Guest Network",
        body = "Manage 2.4 GHz and 5 GHz SSIDs, passphrases, channels, bandwidth width, and isolated Guest Wi-Fi from the Dashboard or Advanced Settings.",
        icon = Icons.Outlined.Wifi
    ),
    GuideItem(
        title = "Advanced Admin, DNS, Firewall & Multi-WAN",
        body = "Configure DHCP pools, custom DNS resolvers and host entries, firewall levels (Custom needed for per-IP/WAN blocking), parental control schedules, and multiple WAN VLAN interfaces.",
        icon = Icons.Outlined.Settings
    ),
    GuideItem(
        title = "Credential & Action Safety",
        body = "Saved router passwords are encrypted using Android Keystore AES-256-GCM and never logged. Destructive changes such as blocking clients, changing LAN subnets, or rebooting always request confirmation.",
        icon = Icons.Outlined.Lock
    )
)

@Composable
fun HelpGuideScreen(
    onBack: () -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("help_guide_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("help_guide_back")) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("Help & Guide", style = MaterialTheme.typography.headlineMedium)
                }
            }
            items(GUIDE_ITEMS, key = { it.title }) { guide ->
                AdminCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = guide.icon,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(guide.title, style = MaterialTheme.typography.titleMedium)
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = guide.body,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
