package com.example.router

import com.example.core.RouterResult
import com.example.models.AdapterDescriptor
import com.example.models.ConnectedDevice
import com.example.models.DhcpConfig
import com.example.models.DiagnosticResult
import com.example.models.DnsConfig
import com.example.models.EthernetPortInfo
import com.example.models.FirewallConfig
import com.example.models.GuestNetworkConfig
import com.example.models.InterfaceStat
import com.example.models.LanConfig
import com.example.models.NetworkActivityEvent
import com.example.models.NetworkSettings
import com.example.models.OpticalInfo
import com.example.models.ParentalControlTemplate
import com.example.models.PortForwardRule
import com.example.models.RouterCapability
import com.example.models.RouterCredentials
import com.example.models.RouterInfo
import com.example.models.RouterSession
import com.example.models.SpeedTestResult
import com.example.models.TrafficSnapshot
import com.example.models.VoipLineInfo
import com.example.models.WanConnectionProfile
import com.example.models.WifiBand
import com.example.models.WifiBandConfig
import com.example.models.WifiConfig

interface RouterAdapter {
    val descriptor: AdapterDescriptor
    val capabilities: RouterCapability

    suspend fun authenticate(credentials: RouterCredentials): RouterResult<RouterSession>
    suspend fun disconnect(): RouterResult<Unit>

    suspend fun getRouterInfo(): RouterResult<RouterInfo>
    suspend fun getTrafficSnapshot(): RouterResult<TrafficSnapshot>
    suspend fun getRecentActivity(): RouterResult<List<NetworkActivityEvent>>

    suspend fun getWifiConfig(): RouterResult<WifiConfig>
    suspend fun setWifiEnabled(enabled: Boolean): RouterResult<WifiConfig>
    suspend fun updateSsid(band: WifiBand, ssid: String): RouterResult<WifiConfig>
    suspend fun updateWifiPassword(band: WifiBand, password: String): RouterResult<WifiConfig>
    suspend fun updateWifiBandConfig(band: WifiBand, config: WifiBandConfig): RouterResult<WifiConfig>
    suspend fun updateGuestNetwork(config: GuestNetworkConfig): RouterResult<WifiConfig>

    suspend fun getConnectedDevices(): RouterResult<List<ConnectedDevice>>
    suspend fun renameDevice(macAddress: String, newName: String): RouterResult<Unit>
    suspend fun blockDevice(macAddress: String): RouterResult<Unit>
    suspend fun unblockDevice(macAddress: String): RouterResult<Unit>
    suspend fun setDeviceInternetBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit>
    suspend fun setDeviceGuestBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit>
    suspend fun setDeviceBandBlocked(macAddress: String, band: WifiBand, blocked: Boolean): RouterResult<Unit>
    suspend fun setDeviceStaticIp(macAddress: String, reserved: Boolean): RouterResult<Unit>

    suspend fun getNetworkSettings(): RouterResult<NetworkSettings>
    suspend fun updateLanConfig(lanConfig: LanConfig): RouterResult<NetworkSettings>
    suspend fun updateDhcpConfig(dhcpConfig: DhcpConfig): RouterResult<NetworkSettings>
    suspend fun updateDnsConfig(dnsConfig: DnsConfig): RouterResult<NetworkSettings>
    suspend fun savePortForwardRule(rule: PortForwardRule): RouterResult<NetworkSettings>
    suspend fun deletePortForwardRule(ruleId: String): RouterResult<NetworkSettings>
    suspend fun updateFirewallConfig(firewallConfig: FirewallConfig): RouterResult<NetworkSettings>
    suspend fun setUpnpEnabled(enabled: Boolean): RouterResult<NetworkSettings>
    suspend fun saveWanConnection(profile: WanConnectionProfile): RouterResult<NetworkSettings>
    suspend fun deleteWanConnection(profileId: String): RouterResult<NetworkSettings>
    suspend fun runNetworkDiagnostics(): RouterResult<List<DiagnosticResult>>

    suspend fun getOpticalInfo(): RouterResult<OpticalInfo>
    suspend fun getEthernetPorts(): RouterResult<List<EthernetPortInfo>>
    suspend fun getInterfaceStats(): RouterResult<List<InterfaceStat>>
    suspend fun getVoipStatus(): RouterResult<List<VoipLineInfo>>
    suspend fun getParentalTemplates(): RouterResult<List<ParentalControlTemplate>>
    suspend fun saveParentalTemplate(template: ParentalControlTemplate): RouterResult<List<ParentalControlTemplate>>
    suspend fun deleteParentalTemplate(templateId: String): RouterResult<List<ParentalControlTemplate>>
    suspend fun runSpeedTest(): RouterResult<SpeedTestResult>

    suspend fun rebootRouter(): RouterResult<Unit>
}
