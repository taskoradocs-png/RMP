package com.example.repositories

import com.example.core.AppMode
import com.example.core.RouterResult
import com.example.models.DhcpConfig
import com.example.models.DiagnosticResult
import com.example.models.DnsConfig
import com.example.models.EthernetPortInfo
import com.example.models.FirewallConfig
import com.example.models.InterfaceStat
import com.example.models.LanConfig
import com.example.models.NetworkSettings
import com.example.models.OpticalInfo
import com.example.models.ParentalControlTemplate
import com.example.models.PortForwardRule
import com.example.models.RouterCapability
import com.example.models.SpeedTestResult
import com.example.models.VoipLineInfo
import com.example.models.WanConnectionProfile
import com.example.router.RouterController
import kotlinx.coroutines.flow.StateFlow

class NetworkRepository(
    private val controller: RouterController
) {
    val appMode: StateFlow<AppMode> = controller.appMode
    val revision: StateFlow<Long> = controller.revision

    fun getCapabilities(): RouterCapability? = controller.getCurrentCapabilities()

    suspend fun getNetworkSettings(): RouterResult<NetworkSettings> = controller.getNetworkSettings()

    suspend fun updateLanConfig(lanConfig: LanConfig): RouterResult<NetworkSettings> =
        controller.updateLanConfig(lanConfig)

    suspend fun updateDhcpConfig(dhcpConfig: DhcpConfig): RouterResult<NetworkSettings> =
        controller.updateDhcpConfig(dhcpConfig)

    suspend fun updateDnsConfig(dnsConfig: DnsConfig): RouterResult<NetworkSettings> =
        controller.updateDnsConfig(dnsConfig)

    suspend fun savePortForwardRule(rule: PortForwardRule): RouterResult<NetworkSettings> =
        controller.savePortForwardRule(rule)

    suspend fun deletePortForwardRule(ruleId: String): RouterResult<NetworkSettings> =
        controller.deletePortForwardRule(ruleId)

    suspend fun updateFirewallConfig(firewallConfig: FirewallConfig): RouterResult<NetworkSettings> =
        controller.updateFirewallConfig(firewallConfig)

    suspend fun setUpnpEnabled(enabled: Boolean): RouterResult<NetworkSettings> =
        controller.setUpnpEnabled(enabled)

    suspend fun saveWanConnection(profile: WanConnectionProfile): RouterResult<NetworkSettings> =
        controller.saveWanConnection(profile)

    suspend fun deleteWanConnection(profileId: String): RouterResult<NetworkSettings> =
        controller.deleteWanConnection(profileId)

    suspend fun runDiagnostics(): RouterResult<List<DiagnosticResult>> =
        controller.runDiagnostics()

    suspend fun getOpticalInfo(): RouterResult<OpticalInfo> =
        controller.getOpticalInfo()

    suspend fun getEthernetPorts(): RouterResult<List<EthernetPortInfo>> =
        controller.getEthernetPorts()

    suspend fun getInterfaceStats(): RouterResult<List<InterfaceStat>> =
        controller.getInterfaceStats()

    suspend fun getVoipStatus(): RouterResult<List<VoipLineInfo>> =
        controller.getVoipStatus()

    suspend fun getParentalTemplates(): RouterResult<List<ParentalControlTemplate>> =
        controller.getParentalTemplates()

    suspend fun saveParentalTemplate(template: ParentalControlTemplate): RouterResult<List<ParentalControlTemplate>> =
        controller.saveParentalTemplate(template)

    suspend fun deleteParentalTemplate(templateId: String): RouterResult<List<ParentalControlTemplate>> =
        controller.deleteParentalTemplate(templateId)

    suspend fun runSpeedTest(): RouterResult<SpeedTestResult> =
        controller.runSpeedTest()
}
