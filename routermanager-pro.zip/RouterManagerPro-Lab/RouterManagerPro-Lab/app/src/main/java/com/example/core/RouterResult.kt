package com.example.core

sealed interface RouterResult<out T> {
    data class Success<T>(val data: T, val isDemoData: Boolean = false) : RouterResult<T>
    data class Unsupported(val featureName: String, val reason: String) : RouterResult<Nothing>
    data class NotConnected(val reason: String) : RouterResult<Nothing>
    data class AuthRequired(val reason: String) : RouterResult<Nothing>
    data class ValidationError(val field: String, val message: String) : RouterResult<Nothing>
    data class Failure(val message: String, val cause: Throwable? = null) : RouterResult<Nothing>
}

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Ready<T>(val data: T, val isDemoMode: Boolean) : UiState<T>
    data class Disconnected(val title: String, val message: String) : UiState<Nothing>
    data class Error(val message: String) : UiState<Nothing>
}
