package com.example.features.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Radar
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.designsystem.AdminCard
import com.example.designsystem.InfoBanner
import com.example.designsystem.KeyValueRow
import com.example.designsystem.MonoValueStyle
import com.example.designsystem.PillTone
import com.example.designsystem.StatusPill
import com.example.models.DiscoveredRouter

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun RouterDiscoveryScreen(
    viewModel: SettingsViewModel,
    onBack: () -> Unit,
    onAuthenticateGateway: (DiscoveredRouter) -> Unit
) {
    val state by viewModel.discoveryState.collectAsStateWithLifecycle()

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("router_discovery_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("Router Discovery", style = MaterialTheme.typography.headlineMedium)
                }
            }

            item {
                AdminCard {
                    Text("Local Gateway Inspection", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = state.statusMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(10.dp))
                    KeyValueRow(
                        label = "Wi-Fi Transport",
                        value = if (state.isWifiActive) "Active${state.interfaceName?.let { " ($it)" } ?: ""}" else "Inactive / Other"
                    )
                    state.localIpv4Address?.let {
                        KeyValueRow(label = "Local IPv4", value = it, isMonospace = true)
                    }
                    state.localGatewayIp?.let {
                        KeyValueRow(
                            label = "Default Gateway",
                            value = "$it (${if (state.gatewayReachable) "Reachable" else "Unreachable"})",
                            isMonospace = true
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = viewModel::runGatewayDiscovery,
                        enabled = !state.isScanning,
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("scan_gateway_button")
                    ) {
                        Icon(Icons.Outlined.Radar, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(if (state.isScanning) "Probing Gateway..." else "Inspect Local Gateway")
                    }
                }
            }

            if (state.localGatewayIp != null) {
                item {
                    InfoBanner(
                        message = if (state.gatewayReachable) {
                            "Gateway ${state.localGatewayIp} responded. Review detected admin interfaces below before authenticating."
                        } else {
                            "Gateway ${state.localGatewayIp} did not respond to TCP/ICMP probes. Verify router access or enter address manually."
                        }
                    )
                }
            }

            items(state.discoveredRouters, key = { it.hostIp }) { router ->
                AdminCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(router.manufacturerHint, style = MaterialTheme.typography.titleMedium)
                        StatusPill(
                            label = if (router.isReachable) {
                                router.reachabilityLatencyMs?.let { "Reachable · ${it}ms" } ?: "Reachable"
                            } else {
                                "Unreachable"
                            },
                            tone = if (router.isReachable) PillTone.ONLINE else PillTone.CRITICAL
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    KeyValueRow("Gateway IP", router.hostIp, isMonospace = true)
                    KeyValueRow("Preferred Port", "${if (router.supportsHttps) "HTTPS" else "HTTP"}:${router.port}", isMonospace = true)
                    KeyValueRow("Source", router.discoverySource)
                    Text(
                        text = router.modelHint,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (router.adminInterfaces.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            router.adminInterfaces.forEach { iface ->
                                StatusPill(
                                    label = "${iface.scheme.uppercase()}:${iface.port}" +
                                        (iface.detectedAdapterId?.let { " · OpenWrt" } ?: ""),
                                    tone = if (iface.detectedAdapterId != null) PillTone.ONLINE else PillTone.INFO
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = { onAuthenticateGateway(router) },
                        modifier = Modifier.fillMaxWidth().height(48.dp)
                    ) {
                        Text("Configure & Authenticate", style = MonoValueStyle)
                    }
                }
            }
        }
    }
}
