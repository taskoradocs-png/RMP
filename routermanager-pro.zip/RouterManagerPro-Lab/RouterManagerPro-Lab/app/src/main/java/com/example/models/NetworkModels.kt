package com.example.models

enum class WanConnectionType(val label: String) {
    DHCP("Automatic (DHCP)"),
    PPPOE("PPPoE"),
    STATIC("Static IP"),
    BRIDGE("Bridge")
}

enum class DnsMode(val label: String) {
    ISP_AUTO("ISP Automatic"),
    CUSTOM("Custom DNS Servers")
}

enum class FirewallLevel(val label: String, val description: String) {
    LOW("Low", "Permissive inbound policy; basic stateful filtering"),
    MEDIUM("Medium", "Balanced protection blocking unsolicited inbound traffic"),
    HIGH("High", "Strict policy permitting only essential outbound responses"),
    CUSTOM("Custom", "Custom rules required for per-IP/WAN blocking")
}

enum class ProtocolType(val label: String) {
    TCP("TCP"),
    UDP("UDP"),
    TCP_UDP("TCP / UDP")
}

enum class DiagnosticStatus(val label: String) {
    PASS("Passed"),
    WARN("Degraded"),
    FAIL("Failed"),
    UNAVAILABLE("Unavailable")
}

data class WanInfo(
    val statusLabel: String,
    val connectionType: WanConnectionType,
    val publicIp: String,
    val subnetMask: String,
    val gatewayIp: String,
    val primaryDns: String,
    val secondaryDns: String,
    val mtu: Int,
    val ispName: String
)

data class WanConnectionProfile(
    val id: String,
    val name: String,
    val serviceType: String,
    val connectionType: WanConnectionType,
    val vlanId: Int?,
    val isDefaultRoute: Boolean,
    val statusLabel: String,
    val ipAddress: String,
    val enabled: Boolean
)

data class LanConfig(
    val routerIp: String,
    val subnetMask: String,
    val hostname: String,
    val igmpSnoopingEnabled: Boolean
)

data class DhcpConfig(
    val enabled: Boolean,
    val startIp: String,
    val endIp: String,
    val leaseTimeMinutes: Int,
    val activeLeasesCount: Int,
    val staticReservationsCount: Int
)

data class DnsHostEntry(
    val id: String,
    val hostname: String,
    val ipAddress: String
)

data class DnsConfig(
    val mode: DnsMode,
    val primaryDns: String,
    val secondaryDns: String,
    val dnsOverHttpsEnabled: Boolean,
    val hostEntries: List<DnsHostEntry> = emptyList()
)

data class PortForwardRule(
    val id: String,
    val name: String,
    val externalPort: Int,
    val internalPort: Int,
    val internalIp: String,
    val protocol: ProtocolType,
    val enabled: Boolean
)

data class FirewallConfig(
    val level: FirewallLevel = FirewallLevel.CUSTOM,
    val spiFirewallEnabled: Boolean,
    val dosProtectionEnabled: Boolean,
    val respondToWanPing: Boolean,
    val ipv6FirewallEnabled: Boolean
)

data class OpticalInfo(
    val ponMode: String,
    val linkState: String,
    val rxPowerDbm: Float,
    val txPowerDbm: Float,
    val temperatureC: Float,
    val voltageV: Float,
    val biasCurrentMa: Float
)

data class EthernetPortInfo(
    val portNumber: Int,
    val label: String,
    val isUp: Boolean,
    val speedLabel: String,
    val duplexLabel: String,
    val macLearnedCount: Int
)

data class InterfaceStat(
    val interfaceName: String,
    val description: String,
    val isUp: Boolean,
    val rxBytes: Long,
    val txBytes: Long,
    val rxPackets: Long,
    val txPackets: Long,
    val rxErrors: Int,
    val txErrors: Int,
    val droppedPackets: Int
)

data class VoipLineInfo(
    val lineNumber: Int,
    val numberLabel: String,
    val sipRegistrar: String,
    val registrationState: String,
    val isRegistered: Boolean,
    val lastCallStatus: String
)

data class ParentalControlTemplate(
    val id: String,
    val name: String,
    val scheduleWindow: String,
    val blockedKeywordsCount: Int,
    val assignedDeviceMacs: List<String>,
    val enabled: Boolean
)

data class SpeedTestResult(
    val pingMs: Int,
    val jitterMs: Int,
    val downloadMbps: Float,
    val uploadMbps: Float,
    val serverLabel: String,
    val timestampLabel: String
)

data class NetworkSettings(
    val wan: WanInfo,
    val wanConnections: List<WanConnectionProfile> = emptyList(),
    val lan: LanConfig,
    val dhcp: DhcpConfig,
    val dns: DnsConfig,
    val portForwardingRules: List<PortForwardRule>,
    val firewall: FirewallConfig,
    val upnpEnabled: Boolean
)

data class DiagnosticResult(
    val id: String,
    val testName: String,
    val target: String,
    val status: DiagnosticStatus,
    val latencyMs: Int?,
    val summary: String,
    val timestampLabel: String
)
