package com.example.router.huawei.hs8346r

/** In-memory session state only. Credentials and tokens must never be written to logs. */
data class HuaweiSessionState(
    val baseUrl: String,
    val authenticated: Boolean,
    val hasSessionCookie: Boolean,
    val hasWebToken: Boolean
)
