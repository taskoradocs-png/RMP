package com.example.features.devices

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.PublicOff
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.SignalCellularAlt
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TextButton
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.Formatters
import com.example.core.UiState
import com.example.designsystem.AdminCard
import com.example.designsystem.AmberDemo
import com.example.designsystem.ConfirmDestructiveDialog
import com.example.designsystem.CyanAccent
import com.example.designsystem.EmeraldOnline
import com.example.designsystem.InfoBanner
import com.example.designsystem.KeyValueRow
import com.example.designsystem.MonoLargeMetricStyle
import com.example.designsystem.MonoValueStyle
import com.example.designsystem.PillTone
import com.example.designsystem.RoseCritical
import com.example.designsystem.SectionHeader
import com.example.designsystem.StatusPill
import com.example.designsystem.UnsupportedFeatureNotice
import com.example.models.ConnectedDevice
import com.example.models.WifiBand

private sealed interface PendingDeviceAction {
    data class ToggleFullBlock(val block: Boolean) : PendingDeviceAction
    data class ToggleInternetBlock(val block: Boolean) : PendingDeviceAction
    data class ToggleGuestBlock(val block: Boolean) : PendingDeviceAction
    data class ToggleStaticIp(val reserve: Boolean) : PendingDeviceAction
    data class ToggleBandBlock(val band: WifiBand, val block: Boolean) : PendingDeviceAction
}

@Composable
fun DeviceDetailScreen(
    macAddress: String,
    viewModel: DevicesViewModel,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()
    var pendingAction by remember { mutableStateOf<PendingDeviceAction?>(null) }
    var showRenameDialog by remember { mutableStateOf(false) }

    val content = (uiState as? UiState.Ready)?.data
    val device = content?.devices?.firstOrNull { it.macAddress.equals(macAddress, ignoreCase = true) }

    if (showRenameDialog && device != null) {
        var nameInput by remember(device.macAddress) { mutableStateOf(device.name) }
        AlertDialog(
            onDismissRequest = { showRenameDialog = false },
            title = { Text("Rename Device") },
            text = {
                OutlinedTextField(
                    value = nameInput,
                    onValueChange = { nameInput = it },
                    label = { Text("Device Label") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (nameInput.isNotBlank()) {
                        viewModel.renameDevice(device.macAddress, nameInput)
                        showRenameDialog = false
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showRenameDialog = false }) { Text("Cancel") } }
        )
    }

    pendingAction?.let { action ->
        if (device != null) {
            when (action) {
                is PendingDeviceAction.ToggleFullBlock -> {
                    ConfirmDestructiveDialog(
                        title = if (action.block) "Block Entire Device?" else "Unblock Device?",
                        message = if (action.block) {
                            "Revoke all LAN and Wi-Fi association for ${device.name} (${device.macAddress})?"
                        } else {
                            "Restore network access for ${device.name} (${device.macAddress})?"
                        },
                        confirmLabel = if (action.block) "Block Device" else "Unblock Device",
                        isCritical = action.block,
                        onConfirm = {
                            pendingAction = null
                            if (action.block) viewModel.blockDevice(device.macAddress)
                            else viewModel.unblockDevice(device.macAddress)
                        },
                        onDismiss = { pendingAction = null }
                    )
                }
                is PendingDeviceAction.ToggleInternetBlock -> {
                    ConfirmDestructiveDialog(
                        title = if (action.block) "Block Internet Access?" else "Restore Internet Access?",
                        message = if (action.block) {
                            "Block WAN/internet traffic for ${device.name} (${device.ipAddress}) while keeping local LAN access intact?"
                        } else {
                            "Allow ${device.name} (${device.ipAddress}) to access the internet again?"
                        },
                        confirmLabel = if (action.block) "Block Internet" else "Restore Internet",
                        isCritical = action.block,
                        onConfirm = {
                            pendingAction = null
                            viewModel.setInternetBlocked(device.macAddress, action.block)
                        },
                        onDismiss = { pendingAction = null }
                    )
                }
                is PendingDeviceAction.ToggleGuestBlock -> {
                    ConfirmDestructiveDialog(
                        title = if (action.block) "Block Guest Wi-Fi?" else "Allow Guest Wi-Fi?",
                        message = "${if (action.block) "Deny" else "Allow"} ${device.name} on the isolated Guest SSID?",
                        confirmLabel = if (action.block) "Block Guest" else "Allow Guest",
                        isCritical = action.block,
                        onConfirm = {
                            pendingAction = null
                            viewModel.setGuestBlocked(device.macAddress, action.block)
                        },
                        onDismiss = { pendingAction = null }
                    )
                }
                is PendingDeviceAction.ToggleStaticIp -> {
                    ConfirmDestructiveDialog(
                        title = if (action.reserve) "Reserve Static IP?" else "Release Static IP?",
                        message = "${if (action.reserve) "Reserve ${device.ipAddress} in DHCP for" else "Release static reservation for"} ${device.name}?",
                        confirmLabel = if (action.reserve) "Reserve IP" else "Release",
                        isCritical = false,
                        onConfirm = {
                            pendingAction = null
                            viewModel.setStaticIp(device.macAddress, action.reserve)
                        },
                        onDismiss = { pendingAction = null }
                    )
                }
                is PendingDeviceAction.ToggleBandBlock -> {
                    ConfirmDestructiveDialog(
                        title = "${if (action.block) "Block" else "Allow"} ${action.band.label} Access?",
                        message = "${if (action.block) "Prevent" else "Allow"} ${device.name} (${device.macAddress}) from associating on the ${action.band.label} radio?",
                        confirmLabel = if (action.block) "Block ${action.band.label}" else "Allow ${action.band.label}",
                        isCritical = action.block,
                        onConfirm = {
                            pendingAction = null
                            viewModel.setBandBlocked(device.macAddress, action.band, action.block)
                        },
                        onDismiss = { pendingAction = null }
                    )
                }
            }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        when (uiState) {
            is UiState.Loading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            else -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp)
                        .testTag("device_detail_screen"),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            IconButton(
                                onClick = onBack,
                                modifier = Modifier.testTag("device_detail_back")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Outlined.ArrowBack,
                                    contentDescription = "Back to devices"
                                )
                            }
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = "Device Telemetry & ACL",
                                style = MaterialTheme.typography.headlineMedium
                            )
                        }
                    }

                    if (!actionMessage.isNullOrBlank()) {
                        item { InfoBanner(message = actionMessage!!) }
                    }

                    if (device == null) {
                        item {
                            AdminCard {
                                Text("Client Not Found", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "Device $macAddress is unavailable in the active router session.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        // 1. Identity Summary Header Card
                        item {
                            AdminCard {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = MaterialTheme.shapes.small,
                                        color = MaterialTheme.colorScheme.primaryContainer,
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Icon(
                                                imageVector = categoryIcon(device.category),
                                                contentDescription = device.category.label,
                                                tint = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(device.name, style = MaterialTheme.typography.titleLarge)
                                            if (content.supportsRename) {
                                                IconButton(
                                                    onClick = { showRenameDialog = true },
                                                    modifier = Modifier.size(32.dp).testTag("detail_rename_button")
                                                ) {
                                                    Icon(
                                                        imageVector = Icons.Outlined.Edit,
                                                        contentDescription = "Rename device",
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                }
                                            }
                                        }
                                        Text(
                                            text = "${device.manufacturer} · ${device.category.label}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Column(
                                        horizontalAlignment = Alignment.End,
                                        verticalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        StatusPill(
                                            label = when {
                                                device.isBlocked -> "MAC Blocked"
                                                device.isOnline -> "Online"
                                                else -> "Offline"
                                            },
                                            tone = when {
                                                device.isBlocked -> PillTone.CRITICAL
                                                device.isOnline -> PillTone.ONLINE
                                                else -> PillTone.NEUTRAL
                                            }
                                        )
                                        if (device.isInternetBlocked && !device.isBlocked) {
                                            StatusPill(
                                                label = "WAN Blocked",
                                                tone = PillTone.WARNING
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // 2. Prominent Signal Strength & Frequency Band Telemetry Card
                        item {
                            SignalAndBandCard(device = device)
                        }

                        // 3. Network Identity & Link Traffic Card
                        item {
                            AdminCard {
                                SectionHeader(title = "Network Identity & Traffic")
                                Spacer(Modifier.height(8.dp))
                                KeyValueRow("IPv4 Address", device.ipAddress, isMonospace = true)
                                KeyValueRow("MAC Address", device.macAddress, isMonospace = true)
                                KeyValueRow("Lease Policy", device.dhcpType)
                                KeyValueRow("Last Seen", device.lastSeenLabel)
                                Spacer(Modifier.height(6.dp))
                                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                                Spacer(Modifier.height(6.dp))
                                KeyValueRow(
                                    "PHY Link Speed",
                                    device.linkSpeedMbps?.let { "$it Mbps" } ?: "N/A",
                                    isMonospace = true
                                )
                                KeyValueRow(
                                    "Rx / Tx Rate",
                                    "${Formatters.formatMbps(device.rxRateMbps)} / ${Formatters.formatMbps(device.txRateMbps)}",
                                    isMonospace = true
                                )
                                KeyValueRow(
                                    "Session Duration",
                                    Formatters.formatUptime(device.connectedDurationSeconds),
                                    isMonospace = true
                                )
                                KeyValueRow(
                                    "Total Downloaded",
                                    Formatters.formatBytes(device.totalDownloadedBytes),
                                    isMonospace = true
                                )
                                KeyValueRow(
                                    "Total Uploaded",
                                    Formatters.formatBytes(device.totalUploadedBytes),
                                    isMonospace = true
                                )
                            }
                        }

                        // 4. Granular Blocking & Internet Access Control Card
                        item {
                            SectionHeader(
                                title = "Access Control & Blocking",
                                subtitle = "Actions gated by router adapter capabilities"
                            )
                        }

                        // 4a. Per-Device Internet Access Blocking
                        item {
                            if (content.supportsInternetBlocking) {
                                AdminCard(modifier = Modifier.testTag("internet_blocking_card")) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Icon(
                                                imageVector = if (device.isInternetBlocked) Icons.Outlined.PublicOff else Icons.Outlined.Language,
                                                contentDescription = "Internet access state",
                                                tint = if (device.isInternetBlocked) AmberDemo else EmeraldOnline
                                            )
                                            Spacer(Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = if (device.isInternetBlocked) "Internet Access Blocked" else "Internet Access Allowed",
                                                    style = MaterialTheme.typography.titleSmall
                                                )
                                                Text(
                                                    text = if (device.isInternetBlocked) {
                                                        "WAN routing disabled; local LAN access remains active."
                                                    } else {
                                                        "Device has full WAN internet routing enabled."
                                                    },
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                    }
                                    Spacer(Modifier.height(12.dp))
                                    OutlinedButton(
                                        onClick = {
                                            pendingAction = PendingDeviceAction.ToggleInternetBlock(!device.isInternetBlocked)
                                        },
                                        enabled = !device.isBlocked,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(48.dp)
                                            .testTag("device_internet_block_button")
                                    ) {
                                        Icon(
                                            imageVector = if (device.isInternetBlocked) Icons.Outlined.Language else Icons.Outlined.PublicOff,
                                            contentDescription = null,
                                            modifier = Modifier.size(18.dp)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Text(
                                            if (device.isInternetBlocked) "Allow Internet Access" else "Block Internet Access"
                                        )
                                    }
                                }
                            } else {
                                UnsupportedFeatureNotice(
                                    featureName = "Internet Access Blocking",
                                    reason = "Active router adapter does not support WAN-only per-device blocking."
                                )
                            }
                        }

                        // 4b. Band-Specific Wi-Fi Blocking (2.4 GHz / 5 GHz)
                        item {
                            if (content.supportsBandBlocking) {
                                AdminCard(modifier = Modifier.testTag("band_blocking_card")) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Outlined.Wifi,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Column {
                                            Text("Radio Band Access Rules", style = MaterialTheme.typography.titleSmall)
                                            Text(
                                                text = "Restrict client association on specific wireless bands",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Spacer(Modifier.height(12.dp))
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        OutlinedButton(
                                            onClick = {
                                                pendingAction = PendingDeviceAction.ToggleBandBlock(
                                                    band = WifiBand.BAND_2_4_GHZ,
                                                    block = !device.isBand24Blocked
                                                )
                                            },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(48.dp)
                                                .testTag("block_24g_button")
                                        ) {
                                            Text(if (device.isBand24Blocked) "Allow 2.4G" else "Block 2.4G")
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                pendingAction = PendingDeviceAction.ToggleBandBlock(
                                                    band = WifiBand.BAND_5_GHZ,
                                                    block = !device.isBand5Blocked
                                                )
                                            },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(48.dp)
                                                .testTag("block_5g_button")
                                        ) {
                                            Text(if (device.isBand5Blocked) "Allow 5G" else "Block 5G")
                                        }
                                    }
                                    if (content.supportsGuestBlocking) {
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedButton(
                                            onClick = {
                                                pendingAction = PendingDeviceAction.ToggleGuestBlock(!device.isGuestBlocked)
                                            },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(48.dp)
                                                .testTag("detail_guest_block_button")
                                        ) {
                                            Text(if (device.isGuestBlocked) "Allow Guest Wi-Fi" else "Block Guest Wi-Fi")
                                        }
                                    }
                                }
                            } else {
                                UnsupportedFeatureNotice(
                                    featureName = "Per-Band Wi-Fi Blocking",
                                    reason = "Active router adapter does not expose per-band client ACL rules."
                                )
                            }
                        }

                        // Static IP Reservation Card
                        if (content.supportsStaticIp) {
                            item {
                                AdminCard {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            Icon(Icons.Outlined.PushPin, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            Spacer(Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = if (device.staticIpReserved) "Static IP Reserved (${device.ipAddress})" else "Dynamic DHCP Lease",
                                                    style = MaterialTheme.typography.titleSmall
                                                )
                                                Text(
                                                    text = "Bind MAC address to fixed IPv4 lease",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                        }
                                        OutlinedButton(
                                            onClick = {
                                                pendingAction = PendingDeviceAction.ToggleStaticIp(!device.staticIpReserved)
                                            },
                                            modifier = Modifier.testTag("detail_static_ip_button")
                                        ) {
                                            Text(if (device.staticIpReserved) "Release" else "Static IP")
                                        }
                                    }
                                }
                            }
                        }

                        // 4c. Full MAC Device Block / Unblock
                        item {
                            if (content.supportsBlocking) {
                                Button(
                                    onClick = {
                                        pendingAction = PendingDeviceAction.ToggleFullBlock(!device.isBlocked)
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(50.dp)
                                        .testTag("device_block_toggle_button"),
                                    colors = if (device.isBlocked) {
                                        ButtonDefaults.buttonColors()
                                    } else {
                                        ButtonDefaults.buttonColors(
                                            containerColor = RoseCritical,
                                            contentColor = Color.White
                                        )
                                    }
                                ) {
                                    Icon(
                                        imageVector = if (device.isBlocked) Icons.Outlined.CheckCircle else Icons.Outlined.Block,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(if (device.isBlocked) "Unblock This Device" else "Block Device Completely")
                                }
                            } else {
                                UnsupportedFeatureNotice(
                                    featureName = "Device Blocking",
                                    reason = "The active router adapter does not support MAC access control."
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SignalAndBandCard(device: ConnectedDevice) {
    val dbm = device.signalStrengthDbm
    val (qualityLabel, qualityTone, activeBars) = when {
        dbm == null -> Triple("Wired Link", PillTone.INFO, 4)
        dbm >= -55 -> Triple("Excellent", PillTone.ONLINE, 4)
        dbm >= -67 -> Triple("Good", PillTone.INFO, 3)
        dbm >= -75 -> Triple("Fair", PillTone.WARNING, 2)
        else -> Triple("Weak", PillTone.CRITICAL, 1)
    }

    AdminCard(modifier = Modifier.testTag("signal_and_band_card")) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Outlined.SignalCellularAlt,
                    contentDescription = "Signal telemetry",
                    tint = CyanAccent
                )
                Spacer(Modifier.width(8.dp))
                Text("Signal & Frequency Band", style = MaterialTheme.typography.titleMedium)
            }
            StatusPill(label = qualityLabel, tone = qualityTone)
        }

        Spacer(Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Surface(
                shape = MaterialTheme.shapes.small,
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Signal Strength",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = dbm?.let { "$it dBm" } ?: "Ethernet",
                            style = MonoLargeMetricStyle,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        SignalBarsMeter(activeBars = activeBars, isWired = dbm == null)
                    }
                }
            }

            Surface(
                shape = MaterialTheme.shapes.small,
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier.weight(1f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "Frequency Band",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = device.connectionType.label,
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = device.frequencyBandLabel,
                        style = MonoValueStyle,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun SignalBarsMeter(
    activeBars: Int,
    isWired: Boolean
) {
    val activeColor = when {
        isWired -> CyanAccent
        activeBars >= 3 -> EmeraldOnline
        activeBars == 2 -> AmberDemo
        else -> RoseCritical
    }
    val inactiveColor = MaterialTheme.colorScheme.outlineVariant

    Row(
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        val heights = listOf(8.dp, 13.dp, 18.dp, 23.dp)
        heights.forEachIndexed { idx, barHeight ->
            val filled = idx < activeBars
            Box(
                modifier = Modifier
                    .width(5.dp)
                    .height(barHeight)
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (filled) activeColor else inactiveColor)
            )
        }
    }
}
