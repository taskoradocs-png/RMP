package com.example.networking

import android.annotation.SuppressLint
import okhttp3.CookieJar
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import java.net.InetAddress
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.concurrent.TimeUnit
import javax.net.ssl.HostnameVerifier
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

object RouterEndpointClient {

    fun createClient(
        cookieJar: CookieJar? = null,
        allowPrivateLanSelfSignedTls: Boolean = false,
        targetHost: String? = null,
        connectTimeoutSeconds: Long = 8,
        readTimeoutSeconds: Long = 12,
        enableDebugMetadataLogs: Boolean = false
    ): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(connectTimeoutSeconds, TimeUnit.SECONDS)
            .readTimeout(readTimeoutSeconds, TimeUnit.SECONDS)
            .writeTimeout(readTimeoutSeconds, TimeUnit.SECONDS)
            .followRedirects(false)
            .followSslRedirects(false)

        if (cookieJar != null) {
            builder.cookieJar(cookieJar)
        }

        // Only allow user-approved self-signed certs for RFC1918 private LAN / loopback router gateways.
        if (allowPrivateLanSelfSignedTls && targetHost != null && isPrivateOrLocalHost(targetHost)) {
            configurePrivateLanTls(builder, targetHost)
        }

        if (enableDebugMetadataLogs) {
            val logging = HttpLoggingInterceptor { message ->
                val sanitized = message.replace(
                    Regex("(?i)(authorization|cookie|set-cookie|x-csrf-token|ubus_rpc_session|password|passphrase|token)\\s*[:=].*"),
                    "$1: [REDACTED]"
                )
                android.util.Log.d("RouterEndpointClient", sanitized)
            }.apply {
                level = HttpLoggingInterceptor.Level.BASIC
                redactHeader("Authorization")
                redactHeader("Cookie")
                redactHeader("Set-Cookie")
                redactHeader("X-CSRF-Token")
            }
            builder.addInterceptor(logging)
        }
        return builder.build()
    }

    fun isPrivateOrLocalHost(host: String): Boolean {
        val normalized = host.trim().lowercase()
        if (normalized.isEmpty()) return false
        if (normalized == "localhost" || normalized == "127.0.0.1" || normalized.endsWith(".local") || normalized.endsWith(".lan")) {
            return true
        }
        val octets = normalized.split('.')
        if (octets.size == 4 && octets.all { it.toIntOrNull() in 0..255 }) {
            val a = octets[0].toInt()
            val b = octets[1].toInt()
            return a == 10 ||
                (a == 172 && b in 16..31) ||
                (a == 192 && b == 168) ||
                (a == 169 && b == 254) ||
                a == 127
        }
        return runCatching {
            val addr = InetAddress.getByName(normalized)
            addr.isLoopbackAddress || addr.isSiteLocalAddress || addr.isLinkLocalAddress
        }.getOrDefault(false)
    }

    @SuppressLint("CustomX509TrustManager", "TrustAllX509TrustManager")
    private fun configurePrivateLanTls(builder: OkHttpClient.Builder, allowedHost: String) {
        val trustManager = object : X509TrustManager {
            override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) = Unit
            override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
                // Intentionally permits self-signed certificates on private LAN gateways when opted in
                require(!chain.isNullOrEmpty()) { "Server presented an empty TLS certificate chain." }
            }

            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
        }
        val sslContext = SSLContext.getInstance("TLS").apply {
            init(null, arrayOf<TrustManager>(trustManager), SecureRandom())
        }
        val normalizedAllowed = allowedHost.trim().lowercase()
        val hostnameVerifier = HostnameVerifier { hostname, _ ->
            hostname.trim().lowercase() == normalizedAllowed || isPrivateOrLocalHost(hostname)
        }
        builder.sslSocketFactory(sslContext.socketFactory, trustManager)
        builder.hostnameVerifier(hostnameVerifier)
    }
}
