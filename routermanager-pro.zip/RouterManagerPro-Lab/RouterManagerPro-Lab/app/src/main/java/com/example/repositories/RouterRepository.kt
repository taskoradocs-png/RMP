package com.example.repositories

import com.example.adapters.AdapterMatchResult
import com.example.adapters.RouterCapabilityRegistry
import com.example.core.AppMode
import com.example.core.RouterResult
import com.example.models.AdapterDescriptor
import com.example.models.NetworkActivityEvent
import com.example.models.RouterCapability
import com.example.models.RouterCredentials
import com.example.models.RouterFeature
import com.example.models.RouterInfo
import com.example.models.RouterSession
import com.example.models.TrafficSnapshot
import com.example.networking.DiscoveryScanResult
import com.example.networking.GatewayDiscoveryService
import com.example.router.RouterController
import kotlinx.coroutines.flow.StateFlow

class RouterRepository(
    private val controller: RouterController,
    private val capabilityRegistry: RouterCapabilityRegistry,
    private val discoveryService: GatewayDiscoveryService
) {
    val appMode: StateFlow<AppMode> = controller.appMode
    val currentSession: StateFlow<RouterSession?> = controller.currentSession
    val revision: StateFlow<Long> = controller.revision

    fun getCurrentCapabilities(): RouterCapability? = controller.getCurrentCapabilities()

    fun supportsFeature(feature: RouterFeature): Boolean = controller.supportsFeature(feature)

    fun getSupportedAdapters(): List<AdapterDescriptor> = capabilityRegistry.getAllSupportedDescriptors()

    fun matchAdapter(manufacturer: String, model: String, firmware: String): AdapterMatchResult? =
        capabilityRegistry.identifyCompatibleAdapter(manufacturer, model, firmware)

    suspend fun inspectLocalGateway(): DiscoveryScanResult = discoveryService.inspectLocalNetwork()

    suspend fun getRouterInfo(): RouterResult<RouterInfo> = controller.getRouterInfo()

    suspend fun getTrafficSnapshot(): RouterResult<TrafficSnapshot> = controller.getTrafficSnapshot()

    suspend fun getRecentActivity(): RouterResult<List<NetworkActivityEvent>> = controller.getRecentActivity()

    suspend fun authenticateLive(adapterId: String, credentials: RouterCredentials): RouterResult<RouterSession> =
        controller.authenticateLive(adapterId, credentials)

    suspend fun disconnectLive(): RouterResult<Unit> = controller.disconnectLive()

    suspend fun rebootRouter(): RouterResult<Unit> = controller.rebootRouter()
}
