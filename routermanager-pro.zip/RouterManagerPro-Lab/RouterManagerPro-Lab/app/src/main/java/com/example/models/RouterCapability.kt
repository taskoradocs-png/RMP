package com.example.models

enum class RouterFeature(val displayName: String) {
    ROUTER_INFO("Router Hardware & Firmware Info"),
    WIFI_BASIC("Wi-Fi SSID & Password"),
    WIFI_DUAL_BAND("Dual-Band 2.4 / 5 GHz Radio Control"),
    WIFI_GUEST_NETWORK("Guest Wi-Fi Network"),
    WIFI_CHANNEL_CONFIG("Wireless Channel Selection"),
    WIFI_BANDWIDTH_CONFIG("Channel Bandwidth Selection"),
    DEVICE_LIST("Connected Client Discovery"),
    DEVICE_BLOCKING("MAC Access Control / Device Blocking"),
    DEVICE_BAND_BLOCKING("Per-Band Wi-Fi Access Control (2.4 / 5 GHz)"),
    DEVICE_INTERNET_BLOCKING("Per-Device Internet Access Blocking"),
    DEVICE_RENAME("Device Alias / Rename"),
    STATIC_IP_RESERVATION("Static DHCP IP Reservation"),
    TRAFFIC_MONITORING("Live Upload / Download Telemetry"),
    WAN_INFO("WAN Interface Telemetry"),
    MULTI_WAN("Multiple WAN Connections"),
    LAN_CONFIG("LAN IP & Subnet Configuration"),
    DHCP_CONFIG("DHCP Server Pool Configuration"),
    DNS_CONFIG("Custom Upstream DNS & Host Entries"),
    PORT_FORWARDING("Port Forwarding Rules"),
    FIREWALL_CONFIG("Firewall Level, SPI & DoS Protection"),
    UPNP_CONFIG("UPnP Port Mapping"),
    NETWORK_DIAGNOSTICS("On-Router Ping / DNS Diagnostics"),
    OPTICAL_INFO("ONT / Fiber Optical Power & Temperature"),
    ETHERNET_PORT_STATUS("Physical Ethernet Switch Port Status"),
    INTERFACE_STATS("Interface Packet & Byte Counters"),
    VOIP_STATUS("VoIP / SIP Line Status"),
    PARENTAL_CONTROL("Parental Control Templates & Schedules"),
    SPEED_TEST("On-Router WAN Speed Test"),
    ROUTER_REBOOT("Remote Router Reboot")
}

data class RouterCapability(
    val supportedFeatures: Set<RouterFeature>,
    val supports5Ghz: Boolean = supportedFeatures.contains(RouterFeature.WIFI_DUAL_BAND),
    val maxGuestNetworks: Int = if (supportedFeatures.contains(RouterFeature.WIFI_GUEST_NETWORK)) 1 else 0,
    val capabilityNotes: String = ""
) {
    fun supports(feature: RouterFeature): Boolean = supportedFeatures.contains(feature)
}
