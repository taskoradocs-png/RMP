# RouterManager Pro update notes

Changes in this source update:

1. Removed the `MainActivity.onStop()` behavior that disconnected the live router whenever the app entered the background.
2. Changed the default `autoClearSessionOnBackground` preference to `false` for fresh installs and unset preferences.
3. Wired the Huawei HS8346R adapter to the shared `RouterSessionManager.cookieJar` instead of a private adapter-only cookie jar. This keeps Huawei cookies available to the app's shared session manager while the process is alive.
4. Added exact gateway-IP matching for `192.168.100.1` to select adapter ID `huawei_hs8346r` in gateway discovery.
5. When the login screen host is `192.168.100.1`, it selects Huawei HS8346R, port 80, and HTTP.
6. Added navigation to Dashboard after successful authentication.

## Important limitations / verification

- This update does **not yet persist serialized router cookies securely across a force-stop or process death**. The shared cookie jar is still in-memory. A true restart restore requires encrypted cookie serialization, restoring the adapter/session state before dashboard requests, and checking whether the router-side session is still valid.
- Gateway-IP matching is a heuristic requested for this specific network. It does not prove the physical device model; the login still must succeed.
- No Gradle build was run: this ZIP does not include `gradlew` or the Gradle wrapper JAR, and no system `gradle` executable is available in the build environment. Please import the project into Android Studio/your existing build environment and run a Gradle build before installing.
