# RouterManager Pro — Huawei Family Edition

An Android router-management app edition focused on Huawei ONT/router web interfaces.

## Dashboard

The dashboard contains exactly four feature tiles:

1. **DEVICES** — connected-device list, Wi-Fi block/unblock, and the Internet-block control (currently visible but disabled until the captured IP-filter workflow is verified end-to-end).
2. **WIFI PASSWORD** — wireless SSID and password configuration.
3. **WAN ADMIN** — WAN administration/profile screen. Huawei WAN write operations are not enabled in this build.
4. **PON / OPTICAL** — optical diagnostics. The supplied HAR confirms the page and endpoint reference, but a successful optical-data response is still required to validate live RX/TX parsing.

A persistent **Return to Dashboard** button appears at the top of every non-dashboard screen. The primary bottom navigation and navigation rail have been removed.

## Router family scope

Only the Huawei live adapter is exposed by the adapter registry in this edition. Other vendor adapter source files remain in the repository but are not selectable. The Huawei adapter is family-oriented and resolves device identity from the router when available; model/firmware-specific behaviour must still be validated per device.

## Evidence-based implementation status

- Huawei login/session handling and existing router information paths are retained.
- Wi-Fi block/unblock now follows the captured `userdevinfosmart.asp` AJAX mechanism and dynamic token.
- Device Internet blocking is not enabled yet. The HAR shows IP Incoming Filter requests, but the exact per-device rule lifecycle and deletion/readback need end-to-end validation before enabling it.
- WAN profile creation/modification is not enabled. The captured `wan/addcfg.cgi` request is treated as research evidence only; its test PPPoE credentials are not embedded in the app.
- PON live readings need a successful response from `getOpticInfo.asp` before RX/TX decoding can be treated as verified.

## Build

The source archive does not include `gradlew` or the Gradle wrapper JAR. Open the project in Android Studio with a compatible Android SDK/Gradle setup and run `assembleDebug`. A full build was not available in the current editing environment.

## Safety

Use only routers you own or are authorized to administer. Do not commit router passwords, session cookies, tokens, or unredacted HAR files.
