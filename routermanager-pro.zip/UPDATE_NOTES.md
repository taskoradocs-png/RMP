# RouterManager Pro — login-flow and reference UI recalibration

## Changes in this revision

- App entry now routes directly to Router Login when no live session exists; it no longer opens a disconnected dashboard first.
- Removed the delayed welcome splash overlay from the app navigation shell.
- Router login automatically starts local gateway discovery on entry.
- When the discovered gateway is `192.168.100.1`, the login form selects the Huawei HS8346R adapter, HTTP port 80, and pre-fills the Huawei credentials supplied by the project owner (`telecomadmin` / `admintelecom`). The user still explicitly taps Connect to authenticate.
- Gateway detection updates the host field, avoiding a separate Router Scan page in the normal path. Manual scan remains available as a retry action.
- Dashboard primary controls are now four full-width stacked cards in the requested order: WiFi Password Management, Devices Information, PON Optical Information, WAN Admin Only.
- Replaced the large Return to Dashboard bar with a floating Home action on authenticated secondary screens.
- Dashboard logout now disconnects the live session before returning to login.
- Default accent is purple and dark surfaces are closer to the black/purple visual reference.

## Verification

- Source archive integrity checked.
- Full Android/Gradle build was not run in this environment because the project does not include a Gradle wrapper script and no system Gradle/Android SDK is installed here. Run the repository's GitHub Actions build to perform authoritative compilation.
- Router discovery, Huawei authentication, and all live router operations still require testing against the actual HS8346R firmware.
