# RouterManager Pro update notes

Changes in this source update:

1. Removed the `MainActivity.onStop()` behavior that disconnected the live router whenever the app entered the background.
2. Changed the default `autoClearSessionOnBackground` preference to `false` for fresh installs and unset preferences.
3. Wired the Huawei HS8346R adapter to the shared `RouterSessionManager.cookieJar` instead of a private adapter-only cookie jar. This keeps Huawei cookies available to the app's shared session manager while the process is alive.
4. Added exact gateway-IP matching for `192.168.100.1` to select adapter ID `huawei_hs8346r` in gateway discovery.
5. When the login screen host is `192.168.100.1`, it selects Huawei HS8346R, port 80, and HTTP.
6. Added navigation to Dashboard after successful authentication.

## Important limitations / verification

- This update does **not yet persist serialized router cookies securely across a force-stop or process death**. The shared cookie jar is still in-memory. A true restart restore requires encrypted cookie serialization, restoring the adapter/session state before dashboard requests, and checking whether the router-side session is still valid.
- Gateway-IP matching is a heuristic requested for this specific network. It does not prove the physical device model; the login still must succeed.
- No Gradle build was run: this ZIP does not include `gradlew` or the Gradle wrapper JAR, and no system `gradle` executable is available in the build environment. Please import the project into Android Studio/your existing build environment and run a Gradle build before installing.

## Huawei-family simplified edition (2026-11-16)

7. Reduced the dashboard to exactly four feature tiles: DEVICES, WIFI PASSWORD, WAN ADMIN, and PON / OPTICAL.
8. Removed the bottom navigation bar and navigation rail from the primary app shell.
9. Added a persistent `Return to Dashboard` button at the top of every non-dashboard screen; it returns directly to the dashboard root.
10. Restricted the live adapter registry and supported-router list to the Huawei adapter family for this edition. Other vendor adapter source files remain in the project but are not selectable through the registry.
11. Updated the Huawei Wi-Fi block/unblock implementation to use the captured `userdevinfosmart.asp` AJAX endpoints (`addajax.cgi` / `delajax.cgi`), dynamic page token, and `stWlanMacFilter` object path.
12. Connected-device results now read the Huawei WLAN MAC-filter list and reflect the captured blocked state.
13. The Devices screen keeps the Internet-block option visible, but disables it with an explicit firmware-verification message. The captured IP Incoming Filter workflow has not yet been verified end-to-end for safe per-device add/remove operations, so this build does not claim Internet blocking works.
14. The WAN ADMIN tile opens the existing WAN administration/profile screen. Actual Huawei WAN profile writes through `wan/addcfg.cgi` are not enabled in this build; the captured write included test PPPoE credentials and is not used as a production template.
15. The PON screen remains connected to the existing optical adapter. The supplied PON HAR confirms the page and the AJAX endpoint path in page JavaScript, but does not contain a successful `getOpticInfo.asp` response; live RX/TX decoding still requires that response to be captured and validated.

## Build verification

- Source-level Kotlin syntax scan completed for the changed Kotlin files; no parser/syntax errors were reported.
- A full Android Gradle build was not run. The supplied project archive has no Gradle wrapper script/JAR and this environment has no installed Gradle or Android SDK. Import into Android Studio and run `assembleDebug` before installing.
