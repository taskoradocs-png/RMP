package com.example.core

import android.content.Context
import com.example.adapters.RouterCapabilityRegistry
import com.example.adapters.guest.GuestSampleDataProvider
import com.example.authentication.KeystoreCredentialCipher
import com.example.authentication.RouterAuthenticationManager
import com.example.authentication.RouterSessionManager
import com.example.database.AppPreferencesStore
import com.example.database.RouterManagerDatabase
import com.example.networking.RouterDiscoveryManager
import com.example.networking.RouterEndpointClient
import com.example.repositories.DeviceRepository
import com.example.repositories.NetworkRepository
import com.example.repositories.RouterRepository
import com.example.repositories.SettingsRepository
import com.example.repositories.WifiRepository
import com.example.router.RouterController
import okhttp3.OkHttpClient

class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val guestSampleDataProvider = GuestSampleDataProvider()
    val sessionManager = RouterSessionManager()
    val capabilityRegistry = RouterCapabilityRegistry(
        guestSampleDataProvider = guestSampleDataProvider,
        sessionManager = sessionManager
    )
    val credentialCipher = KeystoreCredentialCipher()
    val authenticationManager = RouterAuthenticationManager(
        capabilityRegistry = capabilityRegistry,
        sessionManager = sessionManager,
        credentialCipher = credentialCipher
    )
    val okHttpClient: OkHttpClient = RouterEndpointClient.createClient(
        cookieJar = sessionManager.cookieJar,
        enableDebugMetadataLogs = false
    )
    val discoveryManager = RouterDiscoveryManager(appContext)

    val database = RouterManagerDatabase.getInstance(appContext)
    val preferencesStore = AppPreferencesStore(appContext)

    val routerController = RouterController(
        adapterRegistry = capabilityRegistry,
        sessionManager = sessionManager,
        authenticationManager = authenticationManager
    )

    @Volatile
    var hasSyncedInitialMode: Boolean = false

    val routerRepository = RouterRepository(
        controller = routerController,
        capabilityRegistry = capabilityRegistry,
        discoveryService = discoveryManager
    )
    val deviceRepository = DeviceRepository(routerController)
    val wifiRepository = WifiRepository(routerController)
    val networkRepository = NetworkRepository(routerController)
    val settingsRepository = SettingsRepository(
        preferencesStore = preferencesStore,
        profileDao = database.routerProfileDao(),
        credentialCipher = credentialCipher,
        controller = routerController
    )

    companion object {
        @Volatile
        private var instance: AppContainer? = null

        fun getInstance(context: Context): AppContainer {
            return instance ?: synchronized(this) {
                instance ?: AppContainer(context.applicationContext).also { instance = it }
            }
        }
    }
}
