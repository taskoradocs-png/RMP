package com.example.core

enum class AppMode {
    GUEST,
    LIVE
}

enum class ThemePreference(val label: String) {
    DARK("Dark (Default)"),
    LIGHT("Light"),
    SYSTEM("Follow System")
}

enum class AccentColorOption(val label: String, val hex: Long) {
    BLUE("Blue", 0xFF1E88FF),
    PURPLE("Purple", 0xFF7C5CFF),
    GREEN("Green", 0xFF10B981),
    ORANGE("Orange", 0xFFFF8A00),
    ROSE("Rose", 0xFFEC4899),
    TEAL("Teal", 0xFF06B6D4)
}

enum class ThemeStyleOption(val label: String, val subtitle: String) {
    CLASSIC("Classic", "Clean dark slate panels"),
    ONE_UI("One UI", "Glossy, rounded tiles"),
    ICE("Ice", "Frosted, translucent"),
    HALO("Halo", "Glowing router hero")
}

enum class CornerStyleOption(val label: String, val subtitle: String, val cardRadiusDp: Int, val buttonRadiusDp: Int) {
    ROUNDED("Rounded", "Soft pill & card edges", 22, 24),
    BALANCED("Balanced", "Modern crisp corners", 14, 14),
    SHARP("Sharp", "Technical grid edges", 8, 8)
}
