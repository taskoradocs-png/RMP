package com.example.database

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.core.AccentColorOption
import com.example.core.AppMode
import com.example.core.CornerStyleOption
import com.example.core.ThemePreference
import com.example.core.ThemeStyleOption
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.appPreferencesDataStore: DataStore<Preferences> by preferencesDataStore(
    name = "routermanager_settings"
)

data class AppSecurityPreferences(
    val themePreference: ThemePreference = ThemePreference.DARK,
    val accentColor: AccentColorOption = AccentColorOption.BLUE,
    val themeStyle: ThemeStyleOption = ThemeStyleOption.ICE,
    val cornerStyle: CornerStyleOption = CornerStyleOption.ROUNDED,
    val appMode: AppMode = AppMode.GUEST,
    val appPinLockEnabled: Boolean = false,
    val confirmDestructiveActions: Boolean = true,
    val autoClearSessionOnBackground: Boolean = false
)

class AppPreferencesStore(private val context: Context) {

    private object Keys {
        val THEME = stringPreferencesKey("theme_preference")
        val ACCENT_COLOR = stringPreferencesKey("accent_color")
        val THEME_STYLE = stringPreferencesKey("theme_style")
        val CORNER_STYLE = stringPreferencesKey("corner_style")
        val APP_MODE = stringPreferencesKey("app_mode")
        val APP_PIN_LOCK = booleanPreferencesKey("app_pin_lock")
        val CONFIRM_DESTRUCTIVE = booleanPreferencesKey("confirm_destructive")
        val AUTO_CLEAR_SESSION = booleanPreferencesKey("auto_clear_session")
    }

    val preferencesFlow: Flow<AppSecurityPreferences> = context.appPreferencesDataStore.data.map { prefs ->
        val theme = prefs[Keys.THEME]?.let { runCatching { ThemePreference.valueOf(it) }.getOrNull() }
            ?: ThemePreference.DARK
        val accent = prefs[Keys.ACCENT_COLOR]?.let { runCatching { AccentColorOption.valueOf(it) }.getOrNull() }
            ?: AccentColorOption.BLUE
        val style = prefs[Keys.THEME_STYLE]?.let { runCatching { ThemeStyleOption.valueOf(it) }.getOrNull() }
            ?: ThemeStyleOption.ICE
        val corner = prefs[Keys.CORNER_STYLE]?.let { runCatching { CornerStyleOption.valueOf(it) }.getOrNull() }
            ?: CornerStyleOption.ROUNDED
        val mode = prefs[Keys.APP_MODE]?.let { runCatching { AppMode.valueOf(it) }.getOrNull() }
            ?: AppMode.GUEST
        AppSecurityPreferences(
            themePreference = theme,
            accentColor = accent,
            themeStyle = style,
            cornerStyle = corner,
            appMode = mode,
            appPinLockEnabled = prefs[Keys.APP_PIN_LOCK] ?: false,
            confirmDestructiveActions = prefs[Keys.CONFIRM_DESTRUCTIVE] ?: true,
            autoClearSessionOnBackground = prefs[Keys.AUTO_CLEAR_SESSION] ?: false
        )
    }

    suspend fun setThemePreference(theme: ThemePreference) {
        context.appPreferencesDataStore.edit { it[Keys.THEME] = theme.name }
    }

    suspend fun setAccentColor(accent: AccentColorOption) {
        context.appPreferencesDataStore.edit { it[Keys.ACCENT_COLOR] = accent.name }
    }

    suspend fun setThemeStyle(style: ThemeStyleOption) {
        context.appPreferencesDataStore.edit { it[Keys.THEME_STYLE] = style.name }
    }

    suspend fun setCornerStyle(corner: CornerStyleOption) {
        context.appPreferencesDataStore.edit { it[Keys.CORNER_STYLE] = corner.name }
    }

    suspend fun setAppMode(mode: AppMode) {
        context.appPreferencesDataStore.edit { it[Keys.APP_MODE] = mode.name }
    }

    suspend fun setAppPinLockEnabled(enabled: Boolean) {
        context.appPreferencesDataStore.edit { it[Keys.APP_PIN_LOCK] = enabled }
    }

    suspend fun setConfirmDestructiveActions(enabled: Boolean) {
        context.appPreferencesDataStore.edit { it[Keys.CONFIRM_DESTRUCTIVE] = enabled }
    }

    suspend fun setAutoClearSessionOnBackground(enabled: Boolean) {
        context.appPreferencesDataStore.edit { it[Keys.AUTO_CLEAR_SESSION] = enabled }
    }
}
