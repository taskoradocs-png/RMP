package com.example.navigation

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.displayCutoutPadding
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.outlined.Palette
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.core.AppContainer
import com.example.core.AppMode
import com.example.core.UiState
import com.example.designsystem.GuestModeBanner
import com.example.features.dashboard.DashboardScreen
import com.example.features.dashboard.DashboardViewModel
import com.example.features.devices.BlockedDevicesScreen
import com.example.features.devices.DeviceDetailScreen
import com.example.features.devices.DevicesScreen
import com.example.features.devices.DevicesViewModel
import com.example.features.network.DeviceInfoScreen
import com.example.features.network.DnsSettingsScreen
import com.example.features.network.EthernetStatusScreen
import com.example.features.network.FirewallScreen
import com.example.features.network.InterfaceStatsScreen
import com.example.features.network.NetworkScreen
import com.example.features.network.NetworkViewModel
import com.example.features.network.OpticalInfoScreen
import com.example.features.network.ParentalControlScreen
import com.example.features.network.SpeedTestScreen
import com.example.features.network.UsageStatsScreen
import com.example.features.network.VoipStatusScreen
import com.example.features.network.WanConnectionsScreen
import com.example.features.settings.AdvancedSettingsScreen
import com.example.features.settings.HelpGuideScreen
import com.example.features.settings.RouterDiscoveryScreen
import com.example.features.settings.RouterLoginScreen
import com.example.features.settings.SettingsScreen
import com.example.features.settings.SettingsViewModel
import com.example.features.settings.SupportedRoutersScreen
import com.example.features.settings.ThemeScreen
import com.example.features.settings.WelcomeSplashScreen
import com.example.features.wifi.WifiScreen
import com.example.features.wifi.WifiViewModel
import kotlinx.coroutines.delay
import kotlin.reflect.KClass

private data class TopLevelNavItem(
    val label: String,
    val route: Any,
    val routeClass: KClass<*>,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

private val TOP_LEVEL_ITEMS = listOf(
    TopLevelNavItem(
        label = "Dashboard",
        route = DashboardRoute,
        routeClass = DashboardRoute::class,
        selectedIcon = Icons.Filled.Dashboard,
        unselectedIcon = Icons.Outlined.Dashboard,
        testTag = "nav_dashboard"
    ),
    TopLevelNavItem(
        label = "Devices",
        route = DevicesRoute,
        routeClass = DevicesRoute::class,
        selectedIcon = Icons.Filled.Devices,
        unselectedIcon = Icons.Outlined.Devices,
        testTag = "nav_devices"
    ),
    TopLevelNavItem(
        label = "Advanced",
        route = AdvancedRoute,
        routeClass = AdvancedRoute::class,
        selectedIcon = Icons.Filled.Settings,
        unselectedIcon = Icons.Outlined.Settings,
        testTag = "nav_advanced"
    ),
    TopLevelNavItem(
        label = "Theme",
        route = ThemeRoute,
        routeClass = ThemeRoute::class,
        selectedIcon = Icons.Filled.Palette,
        unselectedIcon = Icons.Outlined.Palette,
        testTag = "nav_theme"
    )
)

@Composable
fun RouterNavShell(
    appContainer: AppContainer
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry?.destination
    val appMode by appContainer.routerController.appMode.collectAsStateWithLifecycle()

    var showWelcomeSplash by rememberSaveable { mutableStateOf(true) }
    LaunchedEffect(Unit) {
        if (showWelcomeSplash) {
            delay(650L)
            showWelcomeSplash = false
        }
    }

    val vmFactory = remember(appContainer) {
        object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                return when (modelClass) {
                    DashboardViewModel::class.java -> DashboardViewModel(
                        routerRepository = appContainer.routerRepository,
                        wifiRepository = appContainer.wifiRepository,
                        deviceRepository = appContainer.deviceRepository,
                        networkRepository = appContainer.networkRepository,
                        settingsRepository = appContainer.settingsRepository
                    ) as T
                    DevicesViewModel::class.java -> DevicesViewModel(
                        deviceRepository = appContainer.deviceRepository,
                        settingsRepository = appContainer.settingsRepository
                    ) as T
                    WifiViewModel::class.java -> WifiViewModel(
                        wifiRepository = appContainer.wifiRepository,
                        settingsRepository = appContainer.settingsRepository
                    ) as T
                    NetworkViewModel::class.java -> NetworkViewModel(
                        networkRepository = appContainer.networkRepository,
                        routerRepository = appContainer.routerRepository,
                        settingsRepository = appContainer.settingsRepository
                    ) as T
                    SettingsViewModel::class.java -> SettingsViewModel(
                        settingsRepository = appContainer.settingsRepository,
                        routerRepository = appContainer.routerRepository
                    ) as T
                    else -> throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
                }
            }
        }
    }

    val dashboardViewModel: DashboardViewModel = viewModel(factory = vmFactory)
    val devicesViewModel: DevicesViewModel = viewModel(factory = vmFactory)
    val wifiViewModel: WifiViewModel = viewModel(factory = vmFactory)
    val networkViewModel: NetworkViewModel = viewModel(factory = vmFactory)
    val settingsViewModel: SettingsViewModel = viewModel(factory = vmFactory)

    val devicesState by devicesViewModel.uiState.collectAsStateWithLifecycle()

    fun navigateTopLevel(route: Any) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    val isOnTopLevelTab = TOP_LEVEL_ITEMS.any { item ->
        currentDestination?.hierarchy?.any { it.hasRoute(item.routeClass) } == true
    }

    Box(modifier = Modifier.fillMaxSize()) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val useRail = maxWidth >= 840.dp

            val navHostContent: @Composable (Modifier) -> Unit = { hostModifier ->
                Column(modifier = hostModifier.fillMaxSize()) {
                    if (appMode == AppMode.GUEST) {
                        GuestModeBanner(
                            onSwitchToLiveMode = {
                                settingsViewModel.setAppMode(AppMode.LIVE)
                            }
                        )
                    }
                    Box(modifier = Modifier.weight(1f)) {
                        NavHost(
                            navController = navController,
                            startDestination = DashboardRoute
                        ) {
                            composable<DashboardRoute> {
                                DashboardScreen(
                                    viewModel = dashboardViewModel,
                                    onNavigateToWifi = { navController.navigate(WifiRoute(guestOnly = false)) },
                                    onNavigateToGuestWifi = { navController.navigate(WifiRoute(guestOnly = true)) },
                                    onNavigateToDevices = { navigateTopLevel(DevicesRoute) },
                                    onNavigateToNetwork = { navController.navigate(NetworkRoute) },
                                    onNavigateToBlockedDevices = { navController.navigate(BlockedDevicesRoute) },
                                    onNavigateToOpticalInfo = { navController.navigate(OpticalInfoRoute) },
                                    onNavigateToEthernetStatus = { navController.navigate(EthernetStatusRoute) },
                                    onNavigateToDeviceInfo = { navController.navigate(DeviceInfoRoute) },
                                    onNavigateToUsageStats = { navController.navigate(UsageStatsRoute) },
                                    onNavigateToVoipStatus = { navController.navigate(VoipStatusRoute) },
                                    onNavigateToParentalControl = { navController.navigate(ParentalControlRoute) },
                                    onNavigateToDnsSettings = { navController.navigate(DnsSettingsRoute) },
                                    onNavigateToFirewall = { navController.navigate(FirewallRoute) },
                                    onNavigateToHelpGuide = { navController.navigate(HelpGuideRoute) },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<DevicesRoute> {
                                DevicesScreen(
                                    viewModel = devicesViewModel,
                                    onOpenDeviceDetail = { mac -> navController.navigate(DeviceDetailRoute(mac)) },
                                    onOpenBlockedDevices = { navController.navigate(BlockedDevicesRoute) },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<AdvancedRoute> {
                                AdvancedSettingsScreen(
                                    onOpenOpticalInfo = { navController.navigate(OpticalInfoRoute) },
                                    onOpenEthernetStatus = { navController.navigate(EthernetStatusRoute) },
                                    onOpenInterfaceStats = { navController.navigate(InterfaceStatsRoute) },
                                    onOpenDeviceInfo = { navController.navigate(DeviceInfoRoute) },
                                    onOpenParentalControl = { navController.navigate(ParentalControlRoute) },
                                    onOpenDnsSettings = { navController.navigate(DnsSettingsRoute) },
                                    onOpenWanConnections = { navController.navigate(WanConnectionsRoute) },
                                    onOpenWifi = { navController.navigate(WifiRoute(guestOnly = false)) },
                                    onOpenNetworkAdmin = { navController.navigate(NetworkRoute) },
                                    onOpenSettings = { navController.navigate(SettingsRoute) },
                                    onOpenLogin = { navController.navigate(RouterLoginRoute(null)) }
                                )
                            }
                            composable<ThemeRoute> {
                                ThemeScreen(viewModel = settingsViewModel)
                            }
                            composable<DeviceDetailRoute> { entry ->
                                val route = entry.toRoute<DeviceDetailRoute>()
                                DeviceDetailScreen(
                                    macAddress = route.macAddress,
                                    viewModel = devicesViewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                            composable<BlockedDevicesRoute> {
                                BlockedDevicesScreen(
                                    viewModel = devicesViewModel,
                                    onBack = { navController.popBackStack() },
                                    onOpenDeviceDetail = { mac -> navController.navigate(DeviceDetailRoute(mac)) }
                                )
                            }
                            composable<WifiRoute> { entry ->
                                val route = entry.toRoute<WifiRoute>()
                                val guestList = (devicesState as? UiState.Ready)?.data?.devices.orEmpty()
                                WifiScreen(
                                    viewModel = wifiViewModel,
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) },
                                    guestOnly = route.guestOnly,
                                    guestDevices = guestList,
                                    onToggleGuestBlock = { mac, block -> devicesViewModel.setGuestBlocked(mac, block) },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                            composable<NetworkRoute> {
                                NetworkScreen(
                                    viewModel = networkViewModel,
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                            composable<OpticalInfoRoute> {
                                OpticalInfoScreen(
                                    viewModel = networkViewModel,
                                    onBack = { navController.popBackStack() },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<EthernetStatusRoute> {
                                EthernetStatusScreen(
                                    viewModel = networkViewModel,
                                    onBack = { navController.popBackStack() },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<InterfaceStatsRoute> {
                                InterfaceStatsScreen(
                                    viewModel = networkViewModel,
                                    onBack = { navController.popBackStack() },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<DeviceInfoRoute> {
                                DeviceInfoScreen(
                                    viewModel = networkViewModel,
                                    onBack = { navController.popBackStack() },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<UsageStatsRoute> {
                                UsageStatsScreen(
                                    viewModel = networkViewModel,
                                    onBack = { navController.popBackStack() },
                                    onOpenSpeedTest = { navController.navigate(SpeedTestRoute) },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<VoipStatusRoute> {
                                VoipStatusScreen(
                                    viewModel = networkViewModel,
                                    onBack = { navController.popBackStack() },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<ParentalControlRoute> {
                                ParentalControlScreen(
                                    viewModel = networkViewModel,
                                    onBack = { navController.popBackStack() },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<DnsSettingsRoute> {
                                DnsSettingsScreen(
                                    viewModel = networkViewModel,
                                    onBack = { navController.popBackStack() },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<WanConnectionsRoute> {
                                WanConnectionsScreen(
                                    viewModel = networkViewModel,
                                    onBack = { navController.popBackStack() },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<FirewallRoute> {
                                FirewallScreen(
                                    viewModel = networkViewModel,
                                    onBack = { navController.popBackStack() },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<SpeedTestRoute> {
                                SpeedTestScreen(
                                    viewModel = networkViewModel,
                                    onBack = { navController.popBackStack() },
                                    onNavigateToLogin = { navController.navigate(RouterLoginRoute(null)) },
                                    onNavigateToDiscovery = { navController.navigate(RouterDiscoveryRoute) }
                                )
                            }
                            composable<HelpGuideRoute> {
                                HelpGuideScreen(onBack = { navController.popBackStack() })
                            }
                            composable<SettingsRoute> {
                                SettingsScreen(
                                    viewModel = settingsViewModel,
                                    onOpenLogin = { profileId -> navController.navigate(RouterLoginRoute(profileId)) },
                                    onOpenDiscovery = { navController.navigate(RouterDiscoveryRoute) },
                                    onOpenSupportedRouters = { navController.navigate(SupportedRoutersRoute) },
                                    onBack = { navController.popBackStack() }
                                )
                            }
                            composable<RouterDiscoveryRoute> {
                                RouterDiscoveryScreen(
                                    viewModel = settingsViewModel,
                                    onBack = { navController.popBackStack() },
                                    onAuthenticateGateway = { router ->
                                        navController.navigate(
                                            RouterLoginRoute(
                                                profileId = null,
                                                hostIp = router.hostIp,
                                                port = router.port,
                                                useHttps = router.supportsHttps,
                                                adapterId = router.matchedAdapterId
                                            )
                                        )
                                    }
                                )
                            }
                            composable<SupportedRoutersRoute> {
                                SupportedRoutersScreen(
                                    viewModel = settingsViewModel,
                                    onBack = { navController.popBackStack() }
                                )
                            }
                            composable<RouterLoginRoute> { entry ->
                                val route = entry.toRoute<RouterLoginRoute>()
                                RouterLoginScreen(
                                    profileId = route.profileId,
                                    prefillHostIp = route.hostIp,
                                    prefillPort = route.port,
                                    prefillUseHttps = route.useHttps,
                                    prefillAdapterId = route.adapterId,
                                    viewModel = settingsViewModel,
                                    onBack = { navController.popBackStack() },
                                    onOpenDiscovery = { navController.navigate(RouterDiscoveryRoute) },
                                    onAuthenticated = {
                                        navController.navigate(DashboardRoute) {
                                            popUpTo<RouterLoginRoute> { inclusive = true }
                                            launchSingleTop = true
                                        }
                                    }
                                )
                            }
                        }
                    }
                }
            }

            if (useRail) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .displayCutoutPadding()
                        .imePadding()
                ) {
                    NavigationRail(
                        modifier = Modifier.fillMaxHeight(),
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        TOP_LEVEL_ITEMS.forEach { item ->
                            val selected = currentDestination?.hierarchy?.any {
                                it.hasRoute(item.routeClass)
                            } == true
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopLevel(item.route) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = { Text(item.label) },
                                modifier = Modifier.testTag(item.testTag)
                            )
                        }
                    }
                    navHostContent(Modifier.weight(1f))
                }
            } else {
                Scaffold(
                    containerColor = MaterialTheme.colorScheme.background,
                    contentWindowInsets = WindowInsets(0, 0, 0, 0),
                    floatingActionButton = {
                        if (isOnTopLevelTab) {
                            SpeedTestFloatingButton(
                                onClick = { navController.navigate(SpeedTestRoute) }
                            )
                        }
                    },
                    bottomBar = {
                        NavigationBar(
                            windowInsets = WindowInsets.navigationBars,
                            containerColor = MaterialTheme.colorScheme.surface
                        ) {
                            TOP_LEVEL_ITEMS.forEach { item ->
                                val selected = currentDestination?.hierarchy?.any {
                                    it.hasRoute(item.routeClass)
                                } == true
                                NavigationBarItem(
                                    selected = selected,
                                    onClick = { navigateTopLevel(item.route) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.label
                                        )
                                    },
                                    label = { Text(item.label) },
                                    modifier = Modifier.testTag(item.testTag)
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    navHostContent(
                        Modifier
                            .padding(innerPadding)
                            .consumeWindowInsets(innerPadding)
                            .statusBarsPadding()
                            .imePadding()
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = showWelcomeSplash,
            exit = fadeOut()
        ) {
            WelcomeSplashScreen()
        }
    }
}

@Composable
private fun SpeedTestFloatingButton(onClick: () -> Unit) {
    val accent = MaterialTheme.colorScheme.primary
    FloatingActionButton(
        onClick = onClick,
        shape = CircleShape,
        containerColor = Color.Transparent,
        elevation = FloatingActionButtonDefaults.elevation(defaultElevation = 8.dp),
        modifier = Modifier
            .size(58.dp)
            .shadow(10.dp, CircleShape, ambientColor = accent, spotColor = accent)
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(Color(0xFF7B8DFB), accent)
                ),
                shape = CircleShape
            )
            .testTag("fab_speed_test")
    ) {
        Icon(
            imageVector = Icons.Outlined.Speed,
            contentDescription = "Run WAN Speed Test",
            tint = Color.White,
            modifier = Modifier.size(26.dp)
        )
    }
}
