package com.example.features.network

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.NetworkCheck
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.UiState
import com.example.designsystem.AdminCard
import com.example.designsystem.ConfirmDestructiveDialog
import com.example.designsystem.InfoBanner
import com.example.designsystem.KeyValueRow
import com.example.designsystem.LiveDisconnectedPanel
import com.example.designsystem.MonoValueStyle
import com.example.designsystem.PillTone
import com.example.designsystem.SectionHeader
import com.example.designsystem.StatusPill
import com.example.designsystem.UnsupportedFeatureNotice
import com.example.models.DiagnosticStatus
import com.example.models.DnsMode
import com.example.models.PortForwardRule
import com.example.models.ProtocolType

@Composable
fun NetworkScreen(
    viewModel: NetworkViewModel,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit,
    onBack: (() -> Unit)? = null
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val lanDraft by viewModel.lanDraft.collectAsStateWithLifecycle()
    val dhcpDraft by viewModel.dhcpDraft.collectAsStateWithLifecycle()
    val dnsDraft by viewModel.dnsDraft.collectAsStateWithLifecycle()
    val diagnostics by viewModel.diagnostics.collectAsStateWithLifecycle()
    val isRunningDiagnostics by viewModel.isRunningDiagnostics.collectAsStateWithLifecycle()
    val feedback by viewModel.feedback.collectAsStateWithLifecycle()

    var showLanConfirm by remember { mutableStateOf(false) }
    var showUpnpEnableConfirm by remember { mutableStateOf(false) }
    var showAddPortDialog by remember { mutableStateOf(false) }
    var pendingDeleteRule by remember { mutableStateOf<PortForwardRule?>(null) }

    if (showLanConfirm) {
        ConfirmDestructiveDialog(
            title = "Apply LAN Gateway Changes?",
            message = "Changing the router IP or subnet mask will renew DHCP leases and may require reconnecting to the new gateway IP.",
            confirmLabel = "Apply LAN Config",
            isCritical = true,
            onConfirm = {
                showLanConfirm = false
                viewModel.commitLanSave()
            },
            onDismiss = { showLanConfirm = false }
        )
    }

    if (showUpnpEnableConfirm) {
        ConfirmDestructiveDialog(
            title = "Enable UPnP Port Mapping?",
            message = "UPnP allows local devices to automatically open inbound ports. Keep disabled unless required by gaming or peer-to-peer apps.",
            confirmLabel = "Enable UPnP",
            isCritical = false,
            onConfirm = {
                showUpnpEnableConfirm = false
                viewModel.setUpnpEnabled(true)
            },
            onDismiss = { showUpnpEnableConfirm = false }
        )
    }

    pendingDeleteRule?.let { rule ->
        ConfirmDestructiveDialog(
            title = "Delete Port Forward Rule?",
            message = "Remove '${rule.name}' (${rule.externalPort} -> ${rule.internalIp}:${rule.internalPort})?",
            confirmLabel = "Delete Rule",
            isCritical = true,
            onConfirm = {
                pendingDeleteRule = null
                viewModel.deletePortForwardRule(rule.id)
            },
            onDismiss = { pendingDeleteRule = null }
        )
    }

    if (showAddPortDialog) {
        AddPortForwardDialog(
            onDismiss = { showAddPortDialog = false },
            onSave = { name, extPort, intPort, ip, proto ->
                val error = viewModel.addPortForwardRule(name, extPort, intPort, ip, proto)
                if (error == null) {
                    showAddPortDialog = false
                }
                error
            }
        )
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        when (val state = uiState) {
            is UiState.Loading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is UiState.Disconnected -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item { Text("Network & Routing", style = MaterialTheme.typography.headlineMedium) }
                    item {
                        LiveDisconnectedPanel(
                            title = state.title,
                            subtitle = state.message,
                            onConnectClick = onNavigateToLogin,
                            onDiscoverClick = onNavigateToDiscovery,
                            onSwitchToGuestClick = viewModel::switchToGuestMode
                        )
                    }
                }
            }
            is UiState.Error -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    item { InfoBanner(message = state.message) }
                }
            }
            is UiState.Ready -> {
                val content = state.data
                val settings = content.settings

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp)
                        .testTag("network_screen_list"),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (onBack != null) {
                                IconButton(onClick = onBack, modifier = Modifier.testTag("network_back_button")) {
                                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                                }
                                Spacer(Modifier.width(6.dp))
                            }
                            Text("Network & Routing", style = MaterialTheme.typography.headlineMedium)
                        }
                    }

                    if (!feedback.isNullOrBlank()) {
                        item { InfoBanner(message = feedback!!) }
                    }

                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(NetworkSectionTab.entries) { tab ->
                                FilterChip(
                                    selected = selectedTab == tab,
                                    onClick = { viewModel.selectTab(tab) },
                                    label = { Text(tab.label) },
                                    modifier = Modifier.testTag("network_tab_${tab.name}")
                                )
                            }
                        }
                    }

                    when (selectedTab) {
                        NetworkSectionTab.INTERFACES -> {
                            item {
                                AdminCard {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        SectionHeader(title = "WAN Interface", subtitle = settings.wan.ispName)
                                        StatusPill(label = settings.wan.connectionType.label, tone = PillTone.INFO)
                                    }
                                    Spacer(Modifier.height(10.dp))
                                    KeyValueRow("Status", settings.wan.statusLabel)
                                    KeyValueRow("Public IP", settings.wan.publicIp, isMonospace = true)
                                    KeyValueRow("Subnet Mask", settings.wan.subnetMask, isMonospace = true)
                                    KeyValueRow("WAN Gateway", settings.wan.gatewayIp, isMonospace = true)
                                    KeyValueRow("Primary / Secondary DNS", "${settings.wan.primaryDns} / ${settings.wan.secondaryDns}", isMonospace = true)
                                    KeyValueRow("MTU Size", "${settings.wan.mtu} bytes", isMonospace = true)
                                }
                            }

                            item {
                                if (!content.supportsLanConfig || lanDraft == null) {
                                    UnsupportedFeatureNotice(
                                        featureName = "LAN Configuration",
                                        reason = "Active adapter does not expose LAN subnet modification."
                                    )
                                } else {
                                    val draft = lanDraft!!
                                    AdminCard {
                                        SectionHeader(title = "LAN Configuration", subtitle = "Local bridge & gateway settings")
                                        Spacer(Modifier.height(12.dp))
                                        OutlinedTextField(
                                            value = draft.routerIp,
                                            onValueChange = { v -> viewModel.updateLanDraft { it.copy(routerIp = v, ipError = null) } },
                                            label = { Text("Router Gateway IP") },
                                            isError = draft.ipError != null,
                                            supportingText = draft.ipError?.let { { Text(it) } },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth().testTag("lan_ip_input")
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(
                                            value = draft.subnetMask,
                                            onValueChange = { v -> viewModel.updateLanDraft { it.copy(subnetMask = v, maskError = null) } },
                                            label = { Text("Subnet Mask") },
                                            isError = draft.maskError != null,
                                            supportingText = draft.maskError?.let { { Text(it) } },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth().testTag("lan_mask_input")
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(
                                            value = draft.hostname,
                                            onValueChange = { v -> viewModel.updateLanDraft { it.copy(hostname = v) } },
                                            label = { Text("Local Hostname") },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("IGMP Snooping", style = MaterialTheme.typography.bodyMedium)
                                            Switch(
                                                checked = draft.igmpSnoopingEnabled,
                                                onCheckedChange = { checked ->
                                                    viewModel.updateLanDraft { it.copy(igmpSnoopingEnabled = checked) }
                                                }
                                            )
                                        }
                                        Spacer(Modifier.height(12.dp))
                                        Button(
                                            onClick = {
                                                if (viewModel.validateLanDraft()) {
                                                    showLanConfirm = true
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_lan_button")
                                        ) {
                                            Text("Save LAN Configuration")
                                        }
                                    }
                                }
                            }
                        }

                        NetworkSectionTab.SERVICES -> {
                            item {
                                if (!content.supportsDhcpConfig || dhcpDraft == null) {
                                    UnsupportedFeatureNotice(
                                        featureName = "DHCP Server",
                                        reason = "Active adapter does not support DHCP pool administration."
                                    )
                                } else {
                                    val draft = dhcpDraft!!
                                    AdminCard {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            SectionHeader(
                                                title = "DHCP Server",
                                                subtitle = "${settings.dhcp.activeLeasesCount} active · ${settings.dhcp.staticReservationsCount} static"
                                            )
                                            Switch(
                                                checked = draft.enabled,
                                                onCheckedChange = { enabled ->
                                                    viewModel.updateDhcpDraft { it.copy(enabled = enabled) }
                                                }
                                            )
                                        }
                                        Spacer(Modifier.height(10.dp))
                                        OutlinedTextField(
                                            value = draft.startIp,
                                            onValueChange = { v -> viewModel.updateDhcpDraft { it.copy(startIp = v, rangeError = null) } },
                                            label = { Text("Pool Start IP") },
                                            isError = draft.rangeError != null,
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth().testTag("dhcp_start_input")
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(
                                            value = draft.endIp,
                                            onValueChange = { v -> viewModel.updateDhcpDraft { it.copy(endIp = v, rangeError = null) } },
                                            label = { Text("Pool End IP") },
                                            isError = draft.rangeError != null,
                                            supportingText = draft.rangeError?.let { { Text(it) } },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth().testTag("dhcp_end_input")
                                        )
                                        Spacer(Modifier.height(8.dp))
                                        OutlinedTextField(
                                            value = draft.leaseTimeMinutes,
                                            onValueChange = { v ->
                                                viewModel.updateDhcpDraft { it.copy(leaseTimeMinutes = v.filter { c -> c.isDigit() }, leaseError = null) }
                                            },
                                            label = { Text("Lease Duration (Minutes)") },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            isError = draft.leaseError != null,
                                            supportingText = draft.leaseError?.let { { Text(it) } },
                                            singleLine = true,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                        Spacer(Modifier.height(12.dp))
                                        Button(
                                            onClick = {
                                                if (viewModel.validateDhcpDraft()) {
                                                    viewModel.commitDhcpSave()
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_dhcp_button")
                                        ) {
                                            Text("Save DHCP Pool")
                                        }
                                    }
                                }
                            }

                            item {
                                if (!content.supportsDnsConfig || dnsDraft == null) {
                                    UnsupportedFeatureNotice(
                                        featureName = "DNS Configuration",
                                        reason = "Active adapter does not expose custom DNS configuration."
                                    )
                                } else {
                                    val draft = dnsDraft!!
                                    AdminCard {
                                        SectionHeader(title = "DNS Configuration", subtitle = "Upstream resolver settings")
                                        Spacer(Modifier.height(10.dp))
                                        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                                            DnsMode.entries.forEachIndexed { idx, mode ->
                                                SegmentedButton(
                                                    selected = draft.mode == mode,
                                                    onClick = {
                                                        viewModel.updateDnsDraft { it.copy(mode = mode, primaryError = null, secondaryError = null) }
                                                    },
                                                    shape = SegmentedButtonDefaults.itemShape(idx, DnsMode.entries.size)
                                                ) {
                                                    Text(mode.label)
                                                }
                                            }
                                        }
                                        if (draft.mode == DnsMode.CUSTOM) {
                                            Spacer(Modifier.height(10.dp))
                                            OutlinedTextField(
                                                value = draft.primaryDns,
                                                onValueChange = { v -> viewModel.updateDnsDraft { it.copy(primaryDns = v, primaryError = null) } },
                                                label = { Text("Primary DNS IPv4") },
                                                isError = draft.primaryError != null,
                                                supportingText = draft.primaryError?.let { { Text(it) } },
                                                singleLine = true,
                                                modifier = Modifier.fillMaxWidth().testTag("primary_dns_input")
                                            )
                                            Spacer(Modifier.height(8.dp))
                                            OutlinedTextField(
                                                value = draft.secondaryDns,
                                                onValueChange = { v -> viewModel.updateDnsDraft { it.copy(secondaryDns = v, secondaryError = null) } },
                                                label = { Text("Secondary DNS IPv4 (Optional)") },
                                                isError = draft.secondaryError != null,
                                                supportingText = draft.secondaryError?.let { { Text(it) } },
                                                singleLine = true,
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                        }
                                        Spacer(Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("DNS over HTTPS (DoH)", style = MaterialTheme.typography.bodyMedium)
                                            Switch(
                                                checked = draft.dnsOverHttpsEnabled,
                                                onCheckedChange = { doh ->
                                                    viewModel.updateDnsDraft { it.copy(dnsOverHttpsEnabled = doh) }
                                                }
                                            )
                                        }
                                        Spacer(Modifier.height(12.dp))
                                        Button(
                                            onClick = {
                                                if (viewModel.validateDnsDraft()) {
                                                    viewModel.commitDnsSave()
                                                }
                                            },
                                            modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_dns_button")
                                        ) {
                                            Text("Save DNS Settings")
                                        }
                                    }
                                }
                            }
                        }

                        NetworkSectionTab.SECURITY -> {
                            item {
                                if (!content.supportsPortForwarding) {
                                    UnsupportedFeatureNotice(
                                        featureName = "Port Forwarding",
                                        reason = "Active router adapter does not support NAT port forwarding."
                                    )
                                } else {
                                    AdminCard {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            SectionHeader(
                                                title = "Port Forwarding",
                                                subtitle = "${settings.portForwardingRules.size} rules configured"
                                            )
                                            OutlinedButton(
                                                onClick = { showAddPortDialog = true },
                                                modifier = Modifier.height(44.dp).testTag("add_port_rule_button")
                                            ) {
                                                Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(Modifier.width(4.dp))
                                                Text("Add")
                                            }
                                        }
                                        Spacer(Modifier.height(10.dp))
                                        if (settings.portForwardingRules.isEmpty()) {
                                            Text(
                                                text = "No port forwarding rules configured.",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        } else {
                                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                                settings.portForwardingRules.forEach { rule ->
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column(modifier = Modifier.weight(1f)) {
                                                            Text(rule.name, style = MaterialTheme.typography.titleSmall)
                                                            Text(
                                                                text = "Ext ${rule.externalPort} -> ${rule.internalIp}:${rule.internalPort} (${rule.protocol.label})",
                                                                style = MonoValueStyle,
                                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                                            )
                                                        }
                                                        Switch(
                                                            checked = rule.enabled,
                                                            onCheckedChange = { viewModel.togglePortForwardRule(rule) }
                                                        )
                                                        IconButton(onClick = { pendingDeleteRule = rule }) {
                                                            Icon(
                                                                imageVector = Icons.Outlined.DeleteOutline,
                                                                contentDescription = "Delete rule"
                                                            )
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            item {
                                if (!content.supportsFirewall) {
                                    UnsupportedFeatureNotice(
                                        featureName = "Firewall Policy",
                                        reason = "Active adapter does not expose SPI firewall toggles."
                                    )
                                } else {
                                    val fw = settings.firewall
                                    AdminCard {
                                        SectionHeader(title = "Firewall", subtitle = "Inbound packet filtering & DoS protection")
                                        Spacer(Modifier.height(8.dp))
                                        ToggleRow(
                                            label = "SPI Stateful Packet Inspection",
                                            checked = fw.spiFirewallEnabled,
                                            onCheckedChange = { viewModel.updateFirewall(fw.copy(spiFirewallEnabled = it)) }
                                        )
                                        ToggleRow(
                                            label = "DoS Flood Protection",
                                            checked = fw.dosProtectionEnabled,
                                            onCheckedChange = { viewModel.updateFirewall(fw.copy(dosProtectionEnabled = it)) }
                                        )
                                        ToggleRow(
                                            label = "Respond to WAN Ping (ICMP)",
                                            checked = fw.respondToWanPing,
                                            onCheckedChange = { viewModel.updateFirewall(fw.copy(respondToWanPing = it)) }
                                        )
                                        ToggleRow(
                                            label = "IPv6 Firewall",
                                            checked = fw.ipv6FirewallEnabled,
                                            onCheckedChange = { viewModel.updateFirewall(fw.copy(ipv6FirewallEnabled = it)) }
                                        )
                                    }
                                }
                            }

                            item {
                                if (!content.supportsUpnp) {
                                    UnsupportedFeatureNotice(
                                        featureName = "UPnP",
                                        reason = "Active adapter does not support UPnP control."
                                    )
                                } else {
                                    AdminCard {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text("UPnP Automatic Port Mapping", style = MaterialTheme.typography.titleMedium)
                                                Text(
                                                    text = "Recommended OFF for strict security posture.",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                            }
                                            Switch(
                                                checked = settings.upnpEnabled,
                                                onCheckedChange = { enable ->
                                                    if (enable) {
                                                        showUpnpEnableConfirm = true
                                                    } else {
                                                        viewModel.setUpnpEnabled(false)
                                                    }
                                                },
                                                modifier = Modifier.testTag("upnp_switch")
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        NetworkSectionTab.DIAGNOSTICS -> {
                            item {
                                if (!content.supportsDiagnostics) {
                                    UnsupportedFeatureNotice(
                                        featureName = "Network Diagnostics",
                                        reason = "Active router adapter does not support remote ping/DNS diagnostics."
                                    )
                                } else {
                                    AdminCard {
                                        SectionHeader(
                                            title = "Network Diagnostics",
                                            subtitle = if (state.isGuestMode) "Guest sample diagnostic preview" else "Execute ICMP & DNS probes from router"
                                        )
                                        Spacer(Modifier.height(12.dp))
                                        Button(
                                            onClick = viewModel::runDiagnostics,
                                            enabled = !isRunningDiagnostics,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(48.dp)
                                                .testTag("run_diagnostics_button")
                                        ) {
                                            Icon(Icons.Outlined.NetworkCheck, contentDescription = null, modifier = Modifier.size(18.dp))
                                            Spacer(Modifier.width(8.dp))
                                            Text(if (isRunningDiagnostics) "Running Probes..." else "Run Diagnostic Suite")
                                        }
                                    }
                                }
                            }

                            items(diagnostics, key = { it.id }) { diag ->
                                AdminCard {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(diag.testName, style = MaterialTheme.typography.titleSmall)
                                            Text("Target: ${diag.target}", style = MonoValueStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        StatusPill(
                                            label = diag.status.label,
                                            tone = when (diag.status) {
                                                DiagnosticStatus.PASS -> PillTone.ONLINE
                                                DiagnosticStatus.WARN -> PillTone.WARNING
                                                DiagnosticStatus.FAIL -> PillTone.CRITICAL
                                                DiagnosticStatus.UNAVAILABLE -> PillTone.NEUTRAL
                                            }
                                        )
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Text(diag.summary, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    diag.latencyMs?.let {
                                        Spacer(Modifier.height(4.dp))
                                        Text("RTT: $it ms · ${diag.timestampLabel}", style = MonoValueStyle)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ToggleRow(
    label: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun AddPortForwardDialog(
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, ProtocolType) -> String?
) {
    var name by remember { mutableStateOf("") }
    var extPort by remember { mutableStateOf("") }
    var intPort by remember { mutableStateOf("") }
    var internalIp by remember { mutableStateOf("192.168.50.10") }
    var protocol by remember { mutableStateOf(ProtocolType.TCP_UDP) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New Port Forward Rule") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (errorMsg != null) {
                    Text(
                        text = errorMsg!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it; errorMsg = null },
                    label = { Text("Service Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = extPort,
                        onValueChange = { extPort = it.filter(Char::isDigit); errorMsg = null },
                        label = { Text("Ext Port") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = intPort,
                        onValueChange = { intPort = it.filter(Char::isDigit); errorMsg = null },
                        label = { Text("Int Port") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = internalIp,
                    onValueChange = { internalIp = it; errorMsg = null },
                    label = { Text("Internal Host IPv4") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ProtocolType.entries.forEach { p ->
                        FilterChip(
                            selected = protocol == p,
                            onClick = { protocol = p },
                            label = { Text(p.label) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                errorMsg = onSave(name, extPort, intPort, internalIp, protocol)
            }) {
                Text("Add Rule")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
