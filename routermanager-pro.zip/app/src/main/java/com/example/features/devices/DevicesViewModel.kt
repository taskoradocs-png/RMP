package com.example.features.devices

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.AppMode
import com.example.core.RouterResult
import com.example.core.UiState
import com.example.models.ConnectedDevice
import com.example.models.ConnectionType
import com.example.repositories.DeviceRepository
import com.example.repositories.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

import com.example.models.WifiBand

enum class DeviceFilter(val label: String) {
    ALL("All"),
    ONLINE("Online"),
    OFFLINE("Offline"),
    WIFI_5G("5 GHz"),
    WIFI_24G("2.4 GHz"),
    ETHERNET("Ethernet")
}

data class DevicesListContent(
    val devices: List<ConnectedDevice>,
    val blockedCount: Int,
    val supportsBlocking: Boolean,
    val supportsInternetBlocking: Boolean,
    val supportsBandBlocking: Boolean,
    val supportsGuestBlocking: Boolean,
    val supportsStaticIp: Boolean,
    val supportsRename: Boolean
)

class DevicesViewModel(
    private val deviceRepository: DeviceRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<UiState<DevicesListContent>>(UiState.Loading)
    val uiState: StateFlow<UiState<DevicesListContent>> = _uiState.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedFilter = MutableStateFlow(DeviceFilter.ALL)
    val selectedFilter: StateFlow<DeviceFilter> = _selectedFilter.asStateFlow()

    private val _actionMessage = MutableStateFlow<String?>(null)
    val actionMessage: StateFlow<String?> = _actionMessage.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                deviceRepository.appMode,
                deviceRepository.revision
            ) { mode, rev -> mode to rev }
                .collect { (mode, _) ->
                    loadDevices(mode)
                }
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectFilter(filter: DeviceFilter) {
        _selectedFilter.value = filter
    }

    fun refresh() {
        viewModelScope.launch {
            loadDevices(deviceRepository.appMode.value)
        }
    }

    fun switchToGuestMode() {
        viewModelScope.launch {
            settingsRepository.setAppMode(AppMode.GUEST)
        }
    }

    fun renameDevice(macAddress: String, newName: String) {
        viewModelScope.launch {
            when (val res = deviceRepository.renameDevice(macAddress, newName)) {
                is RouterResult.Success -> {
                    _actionMessage.value = if (res.isGuestData) {
                        "Renamed $macAddress to \"$newName\" in Guest Experience."
                    } else {
                        "Renamed $macAddress to \"$newName\"."
                    }
                }
                is RouterResult.Unsupported -> _actionMessage.value = res.reason
                is RouterResult.NotConnected -> _actionMessage.value = res.reason
                is RouterResult.AuthRequired -> _actionMessage.value = res.reason
                is RouterResult.ValidationError -> _actionMessage.value = res.message
                is RouterResult.Failure -> _actionMessage.value = res.message
            }
        }
    }

    fun blockDevice(macAddress: String) {
        viewModelScope.launch {
            when (val res = deviceRepository.blockDevice(macAddress)) {
                is RouterResult.Success -> {
                    _actionMessage.value = if (res.isGuestData) {
                        "Device $macAddress blocked in Guest Experience."
                    } else {
                        "Device $macAddress blocked."
                    }
                }
                is RouterResult.Unsupported -> _actionMessage.value = res.reason
                is RouterResult.NotConnected -> _actionMessage.value = res.reason
                is RouterResult.AuthRequired -> _actionMessage.value = res.reason
                is RouterResult.ValidationError -> _actionMessage.value = res.message
                is RouterResult.Failure -> _actionMessage.value = res.message
            }
        }
    }

    fun unblockDevice(macAddress: String) {
        viewModelScope.launch {
            when (val res = deviceRepository.unblockDevice(macAddress)) {
                is RouterResult.Success -> {
                    _actionMessage.value = if (res.isGuestData) {
                        "Device $macAddress unblocked in Guest Experience."
                    } else {
                        "Device $macAddress unblocked."
                    }
                }
                is RouterResult.Unsupported -> _actionMessage.value = res.reason
                is RouterResult.NotConnected -> _actionMessage.value = res.reason
                is RouterResult.AuthRequired -> _actionMessage.value = res.reason
                is RouterResult.ValidationError -> _actionMessage.value = res.message
                is RouterResult.Failure -> _actionMessage.value = res.message
            }
        }
    }

    fun setInternetBlocked(macAddress: String, blocked: Boolean) {
        viewModelScope.launch {
            when (val res = deviceRepository.setInternetBlocked(macAddress, blocked)) {
                is RouterResult.Success -> {
                    _actionMessage.value = if (res.isGuestData) {
                        if (blocked) "Internet access blocked for $macAddress in Guest Experience (LAN allowed)."
                        else "Internet access restored for $macAddress in Guest Experience."
                    } else {
                        if (blocked) "Internet access blocked for $macAddress."
                        else "Internet access restored for $macAddress."
                    }
                }
                is RouterResult.Unsupported -> _actionMessage.value = res.reason
                is RouterResult.NotConnected -> _actionMessage.value = res.reason
                is RouterResult.AuthRequired -> _actionMessage.value = res.reason
                is RouterResult.ValidationError -> _actionMessage.value = res.message
                is RouterResult.Failure -> _actionMessage.value = res.message
            }
        }
    }

    fun setGuestBlocked(macAddress: String, blocked: Boolean) {
        viewModelScope.launch {
            when (val res = deviceRepository.setGuestBlocked(macAddress, blocked)) {
                is RouterResult.Success -> {
                    _actionMessage.value = if (res.isGuestData) {
                        "Guest Wi-Fi ${if (blocked) "blocked" else "allowed"} for $macAddress in Guest Experience."
                    } else {
                        "Guest Wi-Fi ${if (blocked) "blocked" else "allowed"} for $macAddress."
                    }
                }
                is RouterResult.Unsupported -> _actionMessage.value = res.reason
                is RouterResult.NotConnected -> _actionMessage.value = res.reason
                is RouterResult.AuthRequired -> _actionMessage.value = res.reason
                is RouterResult.ValidationError -> _actionMessage.value = res.message
                is RouterResult.Failure -> _actionMessage.value = res.message
            }
        }
    }

    fun setBandBlocked(macAddress: String, band: WifiBand, blocked: Boolean) {
        viewModelScope.launch {
            when (val res = deviceRepository.setBandBlocked(macAddress, band, blocked)) {
                is RouterResult.Success -> {
                    _actionMessage.value = if (res.isGuestData) {
                        "${band.label} access ${if (blocked) "blocked" else "allowed"} for $macAddress in Guest Experience."
                    } else {
                        "${band.label} access ${if (blocked) "blocked" else "allowed"} for $macAddress."
                    }
                }
                is RouterResult.Unsupported -> _actionMessage.value = res.reason
                is RouterResult.NotConnected -> _actionMessage.value = res.reason
                is RouterResult.AuthRequired -> _actionMessage.value = res.reason
                is RouterResult.ValidationError -> _actionMessage.value = res.message
                is RouterResult.Failure -> _actionMessage.value = res.message
            }
        }
    }

    fun setStaticIp(macAddress: String, reserved: Boolean) {
        viewModelScope.launch {
            when (val res = deviceRepository.setStaticIp(macAddress, reserved)) {
                is RouterResult.Success -> {
                    _actionMessage.value = if (res.isGuestData) {
                        if (reserved) "Static IP reservation enabled for $macAddress (Guest)."
                        else "Static IP reservation removed for $macAddress (Guest)."
                    } else {
                        if (reserved) "Static IP reservation enabled." else "Static IP reservation removed."
                    }
                }
                is RouterResult.Unsupported -> _actionMessage.value = res.reason
                is RouterResult.NotConnected -> _actionMessage.value = res.reason
                is RouterResult.AuthRequired -> _actionMessage.value = res.reason
                is RouterResult.ValidationError -> _actionMessage.value = res.message
                is RouterResult.Failure -> _actionMessage.value = res.message
            }
        }
    }

    fun clearMessage() {
        _actionMessage.value = null
    }

    fun filterDevices(
        allDevices: List<ConnectedDevice>,
        query: String,
        filter: DeviceFilter
    ): List<ConnectedDevice> {
        val q = query.trim().lowercase()
        return allDevices
            .filter { !it.isBlocked }
            .filter { device ->
                when (filter) {
                    DeviceFilter.ALL -> true
                    DeviceFilter.ONLINE -> device.isOnline
                    DeviceFilter.OFFLINE -> !device.isOnline
                    DeviceFilter.WIFI_5G -> device.connectionType == ConnectionType.WIFI_5_GHZ
                    DeviceFilter.WIFI_24G -> device.connectionType == ConnectionType.WIFI_2_4_GHZ
                    DeviceFilter.ETHERNET -> device.connectionType == ConnectionType.ETHERNET
                }
            }
            .filter { device ->
                if (q.isEmpty()) true else {
                    device.name.lowercase().contains(q) ||
                        device.ipAddress.lowercase().contains(q) ||
                        device.macAddress.lowercase().contains(q) ||
                        device.manufacturer.lowercase().contains(q)
                }
            }
    }

    private suspend fun loadDevices(mode: AppMode) {
        when (val result = deviceRepository.getDevices()) {
            is RouterResult.NotConnected -> {
                _uiState.value = UiState.Disconnected(
                    title = "No Live Router Connected",
                    message = "Client discovery is unavailable until authenticated with a live router adapter."
                )
            }
            is RouterResult.AuthRequired -> {
                _uiState.value = UiState.Disconnected(
                    title = "Authentication Required",
                    message = result.reason
                )
            }
            is RouterResult.Unsupported -> {
                _uiState.value = UiState.Error(result.reason)
            }
            is RouterResult.ValidationError -> {
                _uiState.value = UiState.Error(result.message)
            }
            is RouterResult.Failure -> {
                _uiState.value = UiState.Error(result.message)
            }
            is RouterResult.Success -> {
                _uiState.value = UiState.Ready(
                    data = DevicesListContent(
                        devices = result.data,
                        blockedCount = result.data.count { it.isBlocked },
                        supportsBlocking = deviceRepository.supportsBlocking(),
                        supportsInternetBlocking = deviceRepository.supportsInternetBlocking(),
                        supportsBandBlocking = deviceRepository.supportsBandBlocking(),
                        supportsGuestBlocking = deviceRepository.supportsGuestBlocking(),
                        supportsStaticIp = deviceRepository.supportsStaticIp(),
                        supportsRename = deviceRepository.supportsRename()
                    ),
                    isGuestMode = mode == AppMode.GUEST
                )
            }
        }
    }
}
