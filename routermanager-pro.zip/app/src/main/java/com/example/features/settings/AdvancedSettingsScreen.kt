package com.example.features.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Cable
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.FamilyRestroom
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Layers
import androidx.compose.material.icons.outlined.Router
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.designsystem.AdminCard

@Composable
fun AdvancedSettingsScreen(
    onOpenOpticalInfo: () -> Unit,
    onOpenEthernetStatus: () -> Unit,
    onOpenInterfaceStats: () -> Unit,
    onOpenDeviceInfo: () -> Unit,
    onOpenParentalControl: () -> Unit,
    onOpenDnsSettings: () -> Unit,
    onOpenWanConnections: () -> Unit,
    onOpenWifi: () -> Unit,
    onOpenNetworkAdmin: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenLogin: () -> Unit,
    onBack: (() -> Unit)? = null
) {
    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("advanced_settings_screen"),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onBack != null) {
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                        }
                        Spacer(Modifier.width(4.dp))
                    }
                    Text(
                        text = "Advanced Settings",
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }
            }

            item {
                Text(
                    text = "DIAGNOSTIC TOOLS",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            item {
                AdvancedToolRowCard(
                    title = "Optical Info",
                    subtitle = "Laser power & link status",
                    icon = Icons.Outlined.Layers,
                    iconColor = Color(0xFF8B5CF6),
                    onClick = onOpenOpticalInfo,
                    testTag = "adv_optical_info"
                )
            }
            item {
                AdvancedToolRowCard(
                    title = "Ethernet Status",
                    subtitle = "Physical port link speeds",
                    icon = Icons.Outlined.Cable,
                    iconColor = Color(0xFF3B82F6),
                    onClick = onOpenEthernetStatus,
                    testTag = "adv_ethernet_status"
                )
            }
            item {
                AdvancedToolRowCard(
                    title = "Interface Stats",
                    subtitle = "Traffic packet counters",
                    icon = Icons.Outlined.BarChart,
                    iconColor = Color(0xFF38BDF8),
                    onClick = onOpenInterfaceStats,
                    testTag = "adv_interface_stats"
                )
            }
            item {
                AdvancedToolRowCard(
                    title = "Device Info",
                    subtitle = "Hardware & software versions",
                    icon = Icons.Outlined.Info,
                    iconColor = Color(0xFF94A3B8),
                    onClick = onOpenDeviceInfo,
                    testTag = "adv_device_info"
                )
            }
            item {
                AdvancedToolRowCard(
                    title = "Parental Control",
                    subtitle = "Templates & restricted devices",
                    icon = Icons.Outlined.FamilyRestroom,
                    iconColor = Color(0xFFFACC15),
                    onClick = onOpenParentalControl,
                    testTag = "adv_parental_control"
                )
            }
            item {
                AdvancedToolRowCard(
                    title = "DNS Settings",
                    subtitle = "DNS policy, custom rules & host entries",
                    icon = Icons.Outlined.Dns,
                    iconColor = Color(0xFF38BDF8),
                    onClick = onOpenDnsSettings,
                    testTag = "adv_dns_settings"
                )
            }
            item {
                AdvancedToolRowCard(
                    title = "WAN Connections",
                    subtitle = "Add, edit, or bind multiple WAN connections",
                    icon = Icons.Outlined.Hub,
                    iconColor = Color(0xFF3B82F6),
                    onClick = onOpenWanConnections,
                    testTag = "adv_wan_connections"
                )
            }

            item {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = "ROUTER & APP CONFIGURATION",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                AdvancedToolRowCard(
                    title = "Wi-Fi & Guest Configuration",
                    subtitle = "2.4 GHz, 5 GHz, channels, security & guest SSID",
                    icon = Icons.Outlined.Wifi,
                    iconColor = Color(0xFF22D3EE),
                    onClick = onOpenWifi,
                    testTag = "adv_wifi_config"
                )
            }
            item {
                AdvancedToolRowCard(
                    title = "Network Admin (LAN / DHCP / Ports)",
                    subtitle = "Gateway subnet, DHCP pool, port forwarding & diagnostics",
                    icon = Icons.Outlined.AdminPanelSettings,
                    iconColor = Color(0xFF10B981),
                    onClick = onOpenNetworkAdmin,
                    testTag = "adv_network_admin"
                )
            }
            item {
                AdvancedToolRowCard(
                    title = "Router Login & Profiles",
                    subtitle = "Authenticate live gateway or switch profiles",
                    icon = Icons.Outlined.Router,
                    iconColor = Color(0xFF60A5FA),
                    onClick = onOpenLogin,
                    testTag = "adv_router_login"
                )
            }
            item {
                AdvancedToolRowCard(
                    title = "Connection & Security Settings",
                    subtitle = "Guest/Live mode, discovery, Keystore profiles & PIN guard",
                    icon = Icons.Outlined.Settings,
                    iconColor = Color(0xFFA78BFA),
                    onClick = onOpenSettings,
                    testTag = "adv_app_settings"
                )
            }
        }
    }
}

@Composable
private fun AdvancedToolRowCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    AdminCard(
        onClick = onClick,
        modifier = Modifier.testTag(testTag)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surfaceContainerHighest),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconColor,
                    modifier = Modifier.size(21.dp)
                )
            }
            Spacer(Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
