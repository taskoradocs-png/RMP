package com.example.features.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.rememberScrollState
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.AccentColorOption
import com.example.core.CornerStyleOption
import com.example.core.ThemePreference
import com.example.core.ThemeStyleOption
import com.example.designsystem.AdminCard

@Composable
fun ThemeScreen(viewModel: SettingsViewModel, onBack: () -> Unit = {}) {
    val prefs by viewModel.preferences.collectAsStateWithLifecycle()
    val selectedTheme = prefs.themePreference

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().widthIn(max = 720.dp).testTag("theme_screen"),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 18.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("theme_back_button")) {
                        Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                    }
                    Spacer(Modifier.width(4.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Theme Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Text("Personalize your router dashboard", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    SectionLabel("APPEARANCE MODE")
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
                        AppearanceOption(
                            modifier = Modifier.weight(1f),
                            title = "Light",
                            icon = { Icon(Icons.Outlined.LightMode, null, tint = Color(0xFFFFB21C)) },
                            selected = selectedTheme == ThemePreference.LIGHT,
                            tag = "appearance_light"
                        ) { viewModel.setThemePreference(ThemePreference.LIGHT) }
                        AppearanceOption(
                            modifier = Modifier.weight(1f),
                            title = "Dark",
                            icon = { Icon(Icons.Outlined.DarkMode, null, tint = Color(0xFFB58CFF)) },
                            selected = selectedTheme == ThemePreference.DARK,
                            tag = "appearance_dark"
                        ) { viewModel.setThemePreference(ThemePreference.DARK) }
                        AppearanceOption(
                            modifier = Modifier.weight(1f),
                            title = "Dynamic",
                            icon = { Icon(Icons.Outlined.Settings, null, tint = MaterialTheme.colorScheme.secondary) },
                            selected = selectedTheme == ThemePreference.SYSTEM,
                            tag = "appearance_system"
                        ) { viewModel.setThemePreference(ThemePreference.SYSTEM) }
                    }
                }
            }
            item {
                Text(
                    "Dynamic Mode follows your Android system appearance setting.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            item {
                AdminCard {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Text("Accent Color", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text("Select the primary highlight used by controls and navigation.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Row(
                            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AccentColorOption.entries.forEach { option ->
                                val selected = prefs.accentColor == option
                                val swatch = Color(option.hex)
                                Column(
                                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { viewModel.setAccentColor(option) }.padding(4.dp).testTag("accent_color_${option.name}"),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(5.dp)
                                ) {
                                    Box(
                                        modifier = Modifier.size(38.dp).clip(CircleShape).background(swatch)
                                            .then(if (selected) Modifier.border(2.dp, Color.White, CircleShape) else Modifier),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (selected) Icon(Icons.Filled.Check, "Selected", tint = Color.White, modifier = Modifier.size(19.dp))
                                    }
                                    Text(option.label, style = MaterialTheme.typography.labelSmall, color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    SectionLabel("INTERFACE STYLE")
                    ThemeStyleOption.entries.forEach { style ->
                        val selected = prefs.themeStyle == style
                        Surface(
                            onClick = { viewModel.setThemeStyle(style) },
                            modifier = Modifier.fillMaxWidth().testTag("theme_style_${style.name}"),
                            shape = RoundedCornerShape(15.dp),
                            color = MaterialTheme.colorScheme.surfaceContainer,
                            border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                        ) {
                            Row(Modifier.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(42.dp).clip(RoundedCornerShape(11.dp)).background(
                                    when (style) {
                                        ThemeStyleOption.CLASSIC -> Color(0xFF27334B)
                                        ThemeStyleOption.ONE_UI -> Color(0xFF423071)
                                        ThemeStyleOption.ICE -> Color(0xFF3D526E)
                                        ThemeStyleOption.HALO -> Color(0xFF26305A)
                                    }
                                ), contentAlignment = Alignment.Center) {
                                    Box(Modifier.size(18.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary))
                                }
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Text(style.label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                    Text(style.subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                if (selected) Icon(Icons.Filled.Check, "Selected", tint = Color(0xFF20C875))
                            }
                        }
                    }
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    SectionLabel("CARD CORNERS")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        CornerStyleOption.entries.forEach { corner ->
                            val selected = prefs.cornerStyle == corner
                            Surface(
                                onClick = { viewModel.setCornerStyle(corner) },
                                modifier = Modifier.weight(1f).testTag("corner_style_${corner.name}"),
                                shape = RoundedCornerShape(corner.cardRadiusDp.dp),
                                color = MaterialTheme.colorScheme.surfaceContainer,
                                border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                            ) {
                                Column(Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Box(Modifier.fillMaxWidth().height(26.dp).clip(RoundedCornerShape(corner.cardRadiusDp.dp)).background(MaterialTheme.colorScheme.primary.copy(alpha = 0.25f)))
                                    Spacer(Modifier.height(6.dp))
                                    Text(corner.label, style = MaterialTheme.typography.labelMedium)
                                    if (selected) Text("Applied", style = MaterialTheme.typography.labelSmall, color = Color(0xFF20C875))
                                }
                            }
                        }
                    }
                }
            }
            item {
                Text("Your appearance choices are saved automatically and apply throughout the app.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun AppearanceOption(
    modifier: Modifier,
    title: String,
    icon: @Composable () -> Unit,
    selected: Boolean,
    tag: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(104.dp).testTag(tag),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(if (selected) 2.dp else 1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(Modifier.fillMaxSize().padding(9.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(Modifier.size(34.dp), contentAlignment = Alignment.Center) { icon() }
            Spacer(Modifier.height(5.dp))
            Text(title, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold)
            if (selected) Text("Applied", style = MaterialTheme.typography.labelSmall, color = Color(0xFF20C875))
        }
    }
}

@Composable
private fun SectionLabel(label: String) {
    Text(label, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
}
