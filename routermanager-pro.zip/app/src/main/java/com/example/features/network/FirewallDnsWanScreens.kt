package com.example.features.network

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.FamilyRestroom
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.RouterResult
import com.example.core.UiState
import com.example.designsystem.AdminCard
import com.example.designsystem.ConfirmDestructiveDialog
import com.example.designsystem.InfoBanner
import com.example.designsystem.KeyValueRow
import com.example.designsystem.LiveDisconnectedPanel
import com.example.designsystem.MonoValueStyle
import com.example.designsystem.PillTone
import com.example.designsystem.SectionHeader
import com.example.designsystem.StatusPill
import com.example.designsystem.UnsupportedFeatureNotice
import com.example.models.DnsMode
import com.example.models.FirewallLevel
import com.example.models.ParentalControlTemplate
import com.example.models.WanConnectionProfile
import com.example.models.WanConnectionType

@Composable
private fun ConfigTopBar(title: String, onBack: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.testTag("config_back_button")) {
            Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
        }
        Spacer(Modifier.width(6.dp))
        Text(title, style = MaterialTheme.typography.headlineMedium)
    }
}

@Composable
fun ParentalControlScreen(
    viewModel: NetworkViewModel,
    onBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val templatesResult by viewModel.parentalTemplates.collectAsStateWithLifecycle()
    val feedback by viewModel.feedback.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<ParentalControlTemplate?>(null) }

    LaunchedEffect(Unit) { viewModel.refreshDiagnosticsModules() }

    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var window by remember { mutableStateOf("21:00 – 07:00 Daily") }
        var keywords by remember { mutableStateOf("10") }
        var error by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("New Parental Template") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Template Name") }, singleLine = true)
                    OutlinedTextField(value = window, onValueChange = { window = it }, label = { Text("Restriction Schedule") }, singleLine = true)
                    OutlinedTextField(value = keywords, onValueChange = { keywords = it.filter(Char::isDigit) }, label = { Text("Blocked Keyword Filters") }, singleLine = true)
                    error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val err = viewModel.saveParentalTemplate(name, window, keywords)
                    if (err == null) showAddDialog = false else error = err
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Cancel") } }
        )
    }

    pendingDelete?.let { tpl ->
        ConfirmDestructiveDialog(
            title = "Delete Template?",
            message = "Remove parental control template '${tpl.name}'?",
            confirmLabel = "Delete",
            isCritical = true,
            onConfirm = {
                pendingDelete = null
                viewModel.deleteParentalTemplate(tpl.id)
            },
            onDismiss = { pendingDelete = null }
        )
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("parental_control_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { ConfigTopBar("Parental Control", onBack = onBack) }
            if (!feedback.isNullOrBlank()) item { InfoBanner(message = feedback!!) }

            when (val res = templatesResult) {
                null -> item { CircularProgressIndicator() }
                is RouterResult.NotConnected -> item {
                    LiveDisconnectedPanel("No Live Router Connected", res.reason, onNavigateToLogin, onNavigateToDiscovery, viewModel::switchToGuestMode)
                }
                is RouterResult.AuthRequired -> item {
                    LiveDisconnectedPanel("Authentication Required", res.reason, onNavigateToLogin, onNavigateToDiscovery, viewModel::switchToGuestMode)
                }
                is RouterResult.Unsupported -> item {
                    UnsupportedFeatureNotice("Parental Control", res.reason)
                }
                is RouterResult.Failure -> item { InfoBanner(res.message) }
                is RouterResult.ValidationError -> item { InfoBanner(res.message) }
                is RouterResult.Success -> {
                    item {
                        SectionHeader(
                            title = "Templates & Restricted Devices",
                            subtitle = "${res.data.size} schedules configured",
                            trailing = {
                                OutlinedButton(onClick = { showAddDialog = true }, modifier = Modifier.testTag("add_parental_template_button")) {
                                    Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Add")
                                }
                            }
                        )
                    }
                    items(res.data, key = { it.id }) { tpl ->
                        AdminCard {
                            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Outlined.FamilyRestroom, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(10.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(tpl.name, style = MaterialTheme.typography.titleMedium)
                                    Text("${tpl.scheduleWindow} · ${tpl.blockedKeywordsCount} URL rules", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${tpl.assignedDeviceMacs.size} restricted devices", style = MonoValueStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(checked = tpl.enabled, onCheckedChange = { viewModel.toggleParentalTemplate(tpl) })
                                IconButton(onClick = { pendingDelete = tpl }) {
                                    Icon(Icons.Outlined.DeleteOutline, contentDescription = "Delete template")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DnsSettingsScreen(
    viewModel: NetworkViewModel,
    onBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val dnsDraft by viewModel.dnsDraft.collectAsStateWithLifecycle()
    val feedback by viewModel.feedback.collectAsStateWithLifecycle()
    var showAddHostDialog by remember { mutableStateOf(false) }

    if (showAddHostDialog) {
        var hostname by remember { mutableStateOf("") }
        var ip by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showAddHostDialog = false },
            title = { Text("Add Static DNS Host") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = hostname, onValueChange = { hostname = it }, label = { Text("Hostname (e.g. nas.home.local)") }, singleLine = true)
                    OutlinedTextField(value = ip, onValueChange = { ip = it }, label = { Text("IPv4 Address") }, singleLine = true)
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val res = viewModel.addDnsHostEntry(hostname, ip)
                    if (res == null) showAddHostDialog = false else err = res
                }) { Text("Add Host") }
            },
            dismissButton = { TextButton(onClick = { showAddHostDialog = false }) { Text("Cancel") } }
        )
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("dns_settings_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { ConfigTopBar("DNS Settings", onBack = onBack) }
            if (!feedback.isNullOrBlank()) item { InfoBanner(message = feedback!!) }

            when (val state = uiState) {
                is UiState.Loading -> item { CircularProgressIndicator() }
                is UiState.Disconnected -> item {
                    LiveDisconnectedPanel(state.title, state.message, onNavigateToLogin, onNavigateToDiscovery, viewModel::switchToGuestMode)
                }
                is UiState.Error -> item { InfoBanner(state.message) }
                is UiState.Ready -> {
                    if (!state.data.supportsDnsConfig || dnsDraft == null) {
                        item { UnsupportedFeatureNotice("DNS Configuration", "Adapter does not allow editing DNS settings.") }
                    } else {
                        val d = dnsDraft!!
                        item {
                            AdminCard {
                                SectionHeader(
                                    title = "DNS Policy & Resolvers",
                                    subtitle = "Configure upstream servers & DoH"
                                )
                                Spacer(Modifier.height(10.dp))
                                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                                    DnsMode.entries.forEachIndexed { idx, mode ->
                                        SegmentedButton(
                                            selected = d.mode == mode,
                                            onClick = { viewModel.updateDnsDraft { it.copy(mode = mode) } },
                                            shape = SegmentedButtonDefaults.itemShape(idx, DnsMode.entries.size)
                                        ) { Text(mode.label) }
                                    }
                                }
                                if (d.mode == DnsMode.CUSTOM) {
                                    Spacer(Modifier.height(10.dp))
                                    OutlinedTextField(
                                        value = d.primaryDns,
                                        onValueChange = { v -> viewModel.updateDnsDraft { it.copy(primaryDns = v, primaryError = null) } },
                                        label = { Text("Primary DNS") },
                                        isError = d.primaryError != null,
                                        supportingText = d.primaryError?.let { { Text(it) } },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    Spacer(Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = d.secondaryDns,
                                        onValueChange = { v -> viewModel.updateDnsDraft { it.copy(secondaryDns = v, secondaryError = null) } },
                                        label = { Text("Secondary DNS") },
                                        isError = d.secondaryError != null,
                                        supportingText = d.secondaryError?.let { { Text(it) } },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                                Spacer(Modifier.height(10.dp))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("DNS-over-HTTPS (DoH)", style = MaterialTheme.typography.bodyMedium)
                                    Switch(checked = d.dnsOverHttpsEnabled, onCheckedChange = { e -> viewModel.updateDnsDraft { it.copy(dnsOverHttpsEnabled = e) } })
                                }
                                Spacer(Modifier.height(12.dp))
                                Button(
                                    onClick = { if (viewModel.validateDnsDraft()) viewModel.commitDnsSave() },
                                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("save_dns_settings_button")
                                ) { Text("Save DNS Policy") }
                            }
                        }
                        item {
                            SectionHeader(
                                title = "Static DNS Host Entries",
                                subtitle = "Local hostname -> IPv4 overrides",
                                trailing = {
                                    OutlinedButton(onClick = { showAddHostDialog = true }) {
                                        Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Add Host")
                                    }
                                }
                            )
                        }
                        items(state.data.settings.dns.hostEntries, key = { it.id }) { entry ->
                            AdminCard {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.Dns, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(entry.hostname, style = MaterialTheme.typography.titleSmall)
                                        Text(entry.ipAddress, style = MonoValueStyle, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    IconButton(onClick = { viewModel.deleteDnsHostEntry(entry.id) }) {
                                        Icon(Icons.Outlined.DeleteOutline, contentDescription = "Delete host entry")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WanConnectionsScreen(
    viewModel: NetworkViewModel,
    onBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val feedback by viewModel.feedback.collectAsStateWithLifecycle()
    var showAddDialog by remember { mutableStateOf(false) }
    var pendingDelete by remember { mutableStateOf<WanConnectionProfile?>(null) }

    if (showAddDialog) {
        var name by remember { mutableStateOf("") }
        var serviceType by remember { mutableStateOf("INTERNET") }
        var vlan by remember { mutableStateOf("100") }
        var connType by remember { mutableStateOf(WanConnectionType.PPPOE) }
        var expanded by remember { mutableStateOf(false) }
        var err by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Add WAN Connection") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Interface Name") }, singleLine = true)
                    OutlinedTextField(value = serviceType, onValueChange = { serviceType = it }, label = { Text("Service (INTERNET/TR069/IPTV)") }, singleLine = true)
                    OutlinedTextField(value = vlan, onValueChange = { vlan = it.filter(Char::isDigit) }, label = { Text("VLAN ID (optional)") }, singleLine = true)
                    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
                        OutlinedTextField(
                            value = connType.label,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Encapsulation") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                            modifier = Modifier.menuAnchor(MenuAnchorType.PrimaryNotEditable).fillMaxWidth()
                        )
                        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            WanConnectionType.entries.forEach { t ->
                                DropdownMenuItem(text = { Text(t.label) }, onClick = { connType = t; expanded = false })
                            }
                        }
                    }
                    err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val res = viewModel.saveWanConnection(name, serviceType, connType, vlan)
                    if (res == null) showAddDialog = false else err = res
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showAddDialog = false }) { Text("Cancel") } }
        )
    }

    pendingDelete?.let { profile ->
        ConfirmDestructiveDialog(
            title = "Delete WAN Connection?",
            message = "Removing '${profile.name}' will drop traffic bound to this WAN interface.",
            confirmLabel = "Delete WAN",
            isCritical = true,
            onConfirm = {
                pendingDelete = null
                viewModel.deleteWanConnection(profile.id)
            },
            onDismiss = { pendingDelete = null }
        )
    }

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("wan_connections_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { ConfigTopBar("WAN Connections", onBack = onBack) }
            if (!feedback.isNullOrBlank()) item { InfoBanner(message = feedback!!) }

            when (val state = uiState) {
                is UiState.Loading -> item { CircularProgressIndicator() }
                is UiState.Disconnected -> item {
                    LiveDisconnectedPanel(state.title, state.message, onNavigateToLogin, onNavigateToDiscovery, viewModel::switchToGuestMode)
                }
                is UiState.Error -> item { InfoBanner(state.message) }
                is UiState.Ready -> {
                    if (!state.data.supportsMultiWan) {
                        item { UnsupportedFeatureNotice("Multi-WAN Management", "Adapter exposes primary WAN only.") }
                    } else {
                        item {
                            SectionHeader(
                                title = "WAN Profiles (${state.data.settings.wanConnections.size})",
                                subtitle = "Add, toggle, or bind VLAN WAN profiles",
                                trailing = {
                                    OutlinedButton(onClick = { showAddDialog = true }, modifier = Modifier.testTag("add_wan_profile_button")) {
                                        Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Add WAN")
                                    }
                                }
                            )
                        }
                        items(state.data.settings.wanConnections, key = { it.id }) { profile ->
                            AdminCard {
                                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.Hub, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(profile.name, style = MaterialTheme.typography.titleMedium)
                                        Text("${profile.connectionType.label} · ${profile.serviceType} · VLAN ${profile.vlanId ?: "Untagged"}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    StatusPill(
                                        label = if (profile.enabled) profile.statusLabel else "Disabled",
                                        tone = if (profile.enabled) PillTone.ONLINE else PillTone.NEUTRAL
                                    )
                                }
                                Spacer(Modifier.height(8.dp))
                                KeyValueRow("Assigned IP", profile.ipAddress, isMonospace = true)
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Text("Interface Enabled", style = MaterialTheme.typography.bodySmall)
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Switch(checked = profile.enabled, onCheckedChange = { viewModel.toggleWanConnection(profile) })
                                        IconButton(onClick = { pendingDelete = profile }) {
                                            Icon(Icons.Outlined.DeleteOutline, contentDescription = "Delete WAN profile")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FirewallScreen(
    viewModel: NetworkViewModel,
    onBack: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val feedback by viewModel.feedback.collectAsStateWithLifecycle()

    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .widthIn(max = 720.dp)
                .testTag("firewall_screen"),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { ConfigTopBar("Firewall", onBack = onBack) }
            if (!feedback.isNullOrBlank()) item { InfoBanner(message = feedback!!) }

            when (val state = uiState) {
                is UiState.Loading -> item { CircularProgressIndicator() }
                is UiState.Disconnected -> item {
                    LiveDisconnectedPanel(state.title, state.message, onNavigateToLogin, onNavigateToDiscovery, viewModel::switchToGuestMode)
                }
                is UiState.Error -> item { InfoBanner(state.message) }
                is UiState.Ready -> {
                    val fw = state.data.settings.firewall
                    if (!state.data.supportsFirewall) {
                        item { UnsupportedFeatureNotice("Firewall", "Active adapter does not expose firewall policy.") }
                    } else {
                        item {
                            InfoBanner(
                                message = "Custom firewall level is required to enforce per-device WAN / IP blocking without disconnecting Wi-Fi."
                            )
                        }
                        item {
                            AdminCard {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Outlined.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                    Spacer(Modifier.width(10.dp))
                                    Text("Firewall Security Level", style = MaterialTheme.typography.titleMedium)
                                }
                                Spacer(Modifier.height(10.dp))
                                FirewallLevel.entries.forEach { level ->
                                    val selected = fw.level == level
                                    Surface(
                                        onClick = { viewModel.updateFirewall(fw.copy(level = level)) },
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        shape = RoundedCornerShape(12.dp),
                                        color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f) else MaterialTheme.colorScheme.surfaceContainerLow,
                                        border = BorderStroke(1.dp, if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant)
                                    ) {
                                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                            RadioButton(selected = selected, onClick = { viewModel.updateFirewall(fw.copy(level = level)) })
                                            Spacer(Modifier.width(8.dp))
                                            Column {
                                                Text(level.label, style = MaterialTheme.typography.titleSmall)
                                                Text(level.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        item {
                            AdminCard {
                                SectionHeader("Packet Inspection & UPnP")
                                Spacer(Modifier.height(8.dp))
                                TogglePolicyRow("SPI Firewall", fw.spiFirewallEnabled) { viewModel.updateFirewall(fw.copy(spiFirewallEnabled = it)) }
                                TogglePolicyRow("DoS / Flood Protection", fw.dosProtectionEnabled) { viewModel.updateFirewall(fw.copy(dosProtectionEnabled = it)) }
                                TogglePolicyRow("Respond to WAN Ping", fw.respondToWanPing) { viewModel.updateFirewall(fw.copy(respondToWanPing = it)) }
                                TogglePolicyRow("IPv6 Firewall", fw.ipv6FirewallEnabled) { viewModel.updateFirewall(fw.copy(ipv6FirewallEnabled = it)) }
                                if (state.data.supportsUpnp) {
                                    TogglePolicyRow("UPnP Port Mapping", state.data.settings.upnpEnabled) { viewModel.setUpnpEnabled(it) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TogglePolicyRow(
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, style = MaterialTheme.typography.bodyMedium)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}
