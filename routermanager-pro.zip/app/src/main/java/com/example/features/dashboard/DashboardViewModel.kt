package com.example.features.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.AppMode
import com.example.core.RouterResult
import com.example.core.UiState
import com.example.core.ThemePreference
import com.example.models.NetworkActivityEvent
import com.example.models.RouterInfo
import com.example.models.RouterConnectionState
import com.example.models.TrafficSnapshot
import com.example.models.WifiConfig
import com.example.repositories.DeviceRepository
import com.example.repositories.NetworkRepository
import com.example.repositories.RouterRepository
import com.example.repositories.SettingsRepository
import com.example.repositories.WifiRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

data class DashboardContent(
    val routerInfo: RouterInfo,
    val routerInfoWarning: String? = null,
    val wifiConfig: WifiConfig?,
    val connectedDevicesCount: Int,
    val offlineDevicesCount: Int,
    val blockedDevicesCount: Int,
    val wanConnectionLabel: String,
    val opticalRxDbm: Float?,
    val parentalTemplatesCount: Int,
    val firewallLevelLabel: String,
    val trafficSnapshot: TrafficSnapshot?,
    val trafficUnsupportedReason: String?,
    val recentActivity: List<NetworkActivityEvent>
)

class DashboardViewModel(
    private val routerRepository: RouterRepository,
    private val wifiRepository: WifiRepository,
    private val deviceRepository: DeviceRepository,
    private val networkRepository: NetworkRepository,
    private val settingsRepository: SettingsRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<UiState<DashboardContent>>(UiState.Loading)
    val uiState: StateFlow<UiState<DashboardContent>> = _uiState.asStateFlow()

    private val _actionFeedback = MutableStateFlow<String?>(null)
    val actionFeedback: StateFlow<String?> = _actionFeedback.asStateFlow()

    init {
        viewModelScope.launch {
            combine(
                routerRepository.appMode,
                routerRepository.revision
            ) { mode, rev -> mode to rev }
                .collect { (mode, _) ->
                    loadDashboard(mode)
                }
        }
    }

    fun refresh() {
        viewModelScope.launch {
            loadDashboard(routerRepository.appMode.value)
        }
    }

    fun switchToGuestMode() {
        viewModelScope.launch {
            settingsRepository.setAppMode(AppMode.GUEST)
        }
    }

    fun toggleTheme() {
        viewModelScope.launch {
            val current = settingsRepository.preferencesFlow.first().themePreference
            val next = if (current == ThemePreference.LIGHT) ThemePreference.DARK else ThemePreference.LIGHT
            settingsRepository.setThemePreference(next)
        }
    }

    fun rebootRouter() {
        viewModelScope.launch {
            when (val res = routerRepository.rebootRouter()) {
                is RouterResult.Success -> {
                    _actionFeedback.value = if (res.isGuestData) {
                        "Guest Experience: Simulated router reboot completed (uptime reset)."
                    } else {
                        "Router reboot command acknowledged."
                    }
                    loadDashboard(routerRepository.appMode.value)
                }
                is RouterResult.Unsupported -> _actionFeedback.value = res.reason
                is RouterResult.NotConnected -> _actionFeedback.value = res.reason
                is RouterResult.AuthRequired -> _actionFeedback.value = res.reason
                is RouterResult.ValidationError -> _actionFeedback.value = res.message
                is RouterResult.Failure -> _actionFeedback.value = res.message
            }
        }
    }

    fun clearFeedback() {
        _actionFeedback.value = null
    }

    private suspend fun loadDashboard(mode: AppMode) {
        val infoResult = routerRepository.getRouterInfo()

        // Authentication/connection state is still a true blocker. A missing
        // optional information endpoint must not hide the dashboard itself.
        when (infoResult) {
            is RouterResult.NotConnected -> {
                _uiState.value = UiState.Disconnected(
                    title = "No Live Router Connected",
                    message = "Connect and authenticate with a supported router gateway to inspect live telemetry, connected devices, and wireless radios."
                )
                return
            }
            is RouterResult.AuthRequired -> {
                _uiState.value = UiState.Disconnected(
                    title = "Router Authentication Required",
                    message = infoResult.reason
                )
                return
            }
            else -> Unit
        }

        val wifiResult = wifiRepository.getWifiConfig()
        val devicesResult = deviceRepository.getDevices()
        val networkResult = networkRepository.getNetworkSettings()
        val trafficResult = routerRepository.getTrafficSnapshot()
        val activityResult = routerRepository.getRecentActivity()
        val opticalResult = networkRepository.getOpticalInfo()
        val parentalResult = networkRepository.getParentalTemplates()

        val devices = (devicesResult as? RouterResult.Success)?.data.orEmpty()
        val networkSettings = (networkResult as? RouterResult.Success)?.data
        val traffic = (trafficResult as? RouterResult.Success)?.data
        val trafficUnsupported = when (trafficResult) {
            is RouterResult.Unsupported -> trafficResult.reason
            is RouterResult.Failure -> trafficResult.message
            else -> null
        }

        val liveSession = routerRepository.currentSession.value
        val adapter = liveSession?.let { session ->
            routerRepository.getSupportedAdapters().firstOrNull { it.id == session.adapterId }
        }
        val routerInfo = (infoResult as? RouterResult.Success)?.data ?: RouterInfo(
            manufacturer = adapter?.manufacturer ?: "Router",
            model = adapter?.displayName ?: "Router information unavailable",
            firmwareVersion = "Unavailable",
            hardwareRevision = "Unavailable",
            routerIp = liveSession?.routerIp ?: "Unknown",
            wanIp = null,
            internetConnected = false,
            uptimeSeconds = 0L,
            cpuLoadPercent = 0,
            memoryLoadPercent = 0,
            serialMasked = "Unavailable",
            connectionState = RouterConnectionState.UNREACHABLE,
            adapterId = liveSession?.adapterId ?: "unknown",
            adapterName = adapter?.displayName ?: "Connected router"
        )

        val routerInfoWarning = when (infoResult) {
            is RouterResult.Failure -> infoResult.message
            is RouterResult.Unsupported -> infoResult.reason
            is RouterResult.ValidationError -> infoResult.message
            else -> null
        }

        _uiState.value = UiState.Ready(
            data = DashboardContent(
                routerInfo = routerInfo,
                routerInfoWarning = routerInfoWarning,
                wifiConfig = (wifiResult as? RouterResult.Success)?.data,
                connectedDevicesCount = devices.count { it.isOnline && !it.isBlocked },
                offlineDevicesCount = devices.count { !it.isOnline && !it.isBlocked },
                blockedDevicesCount = devices.count { it.isBlocked },
                wanConnectionLabel = networkSettings?.wan?.connectionType?.name ?: "Unavailable",
                opticalRxDbm = (opticalResult as? RouterResult.Success)?.data?.rxPowerDbm,
                parentalTemplatesCount = (parentalResult as? RouterResult.Success)?.data?.size ?: 0,
                firewallLevelLabel = networkSettings?.firewall?.level?.label ?: "Unavailable",
                trafficSnapshot = traffic,
                trafficUnsupportedReason = trafficUnsupported,
                recentActivity = (activityResult as? RouterResult.Success)?.data.orEmpty()
            ),
            isGuestMode = mode == AppMode.GUEST
        )
    }
}
