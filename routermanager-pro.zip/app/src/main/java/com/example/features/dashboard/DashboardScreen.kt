package com.example.features.dashboard

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.HelpOutline
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.outlined.Logout
import androidx.compose.material.icons.outlined.AdminPanelSettings
import androidx.compose.material.icons.outlined.ArrowDownward
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Call
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.DonutLarge
import androidx.compose.material.icons.outlined.FamilyRestroom
import androidx.compose.material.icons.outlined.Group
import androidx.compose.material.icons.outlined.Hub
import androidx.compose.material.icons.outlined.Memory
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Public
import androidx.compose.material.icons.outlined.PublicOff
import androidx.compose.material.icons.outlined.RestartAlt
import androidx.compose.material.icons.outlined.Security
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material.icons.outlined.WifiPassword
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.Formatters
import com.example.core.UiState
import com.example.designsystem.AdminCard
import com.example.designsystem.AmberGuest
import com.example.designsystem.ConfirmDestructiveDialog
import com.example.designsystem.CyanAccent
import com.example.designsystem.EmeraldOnline
import com.example.designsystem.InfoBanner
import com.example.designsystem.LiveDisconnectedPanel
import com.example.designsystem.MonoLargeMetricStyle
import com.example.designsystem.MonoValueStyle
import com.example.designsystem.PillTone
import com.example.designsystem.RoseCritical
import com.example.designsystem.StatusPill
import com.example.designsystem.ThroughputChart
import com.example.models.ActivitySeverity
import com.example.models.NetworkActivityEvent
import com.example.models.RouterInfo
import com.example.models.TrafficSnapshot

@Composable
private fun RouterHeaderBar(
    title: String,
    subtitle: String,
    statusColor: Color,
    onNotifications: () -> Unit,
    onToggleTheme: () -> Unit,
    onLogoutOrLogin: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceContainer,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 6.dp, top = 12.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(shape = CircleShape, color = statusColor, modifier = Modifier.size(7.dp)) {}
                    Spacer(modifier = Modifier.width(7.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            IconButton(onClick = onNotifications) {
                Icon(Icons.Outlined.Notifications, contentDescription = "Notifications and activity")
            }
            IconButton(onClick = onToggleTheme) {
                Icon(Icons.Outlined.WbSunny, contentDescription = "Toggle theme")
            }
            IconButton(onClick = onLogoutOrLogin) {
                Icon(Icons.AutoMirrored.Outlined.Logout, contentDescription = "Login or logout")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onNavigateToWifi: () -> Unit,
    onNavigateToGuestWifi: () -> Unit,
    onNavigateToDevices: () -> Unit,
    onNavigateToWanAdmin: () -> Unit,
    onNavigateToBlockedDevices: () -> Unit,
    onNavigateToOpticalInfo: () -> Unit,
    onNavigateToEthernetStatus: () -> Unit,
    onNavigateToDeviceInfo: () -> Unit,
    onNavigateToUsageStats: () -> Unit,
    onNavigateToVoipStatus: () -> Unit,
    onNavigateToParentalControl: () -> Unit,
    onNavigateToDnsSettings: () -> Unit,
    onNavigateToFirewall: () -> Unit,
    onNavigateToHelpGuide: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val feedback by viewModel.actionFeedback.collectAsStateWithLifecycle()
    var showRebootDialog by remember { mutableStateOf(false) }
    var showActivitySheet by remember { mutableStateOf(false) }

    if (showRebootDialog) {
        ConfirmDestructiveDialog(
            title = "Reboot Router?",
            message = "Rebooting will temporarily disconnect all Wi-Fi and wired clients for 60–120 seconds.",
            confirmLabel = "Reboot Now",
            isCritical = true,
            onConfirm = {
                showRebootDialog = false
                viewModel.rebootRouter()
            },
            onDismiss = { showRebootDialog = false }
        )
    }

    val readyContent = (uiState as? UiState.Ready)?.data
    if (showActivitySheet && readyContent != null) {
        ModalBottomSheet(onDismissRequest = { showActivitySheet = false }) {
            ActivityLogSheetContent(
                events = readyContent.recentActivity,
                onRebootClick = {
                    showActivitySheet = false
                    showRebootDialog = true
                },
                onRefreshClick = {
                    viewModel.refresh()
                }
            )
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        when (val state = uiState) {
            is UiState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is UiState.Disconnected -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        RouterHeaderBar(
                            title = "RouterManager Pro",
                            subtitle = "Live Mode · Disconnected",
                            statusColor = RoseCritical,
                            onNotifications = { },
                            onToggleTheme = viewModel::toggleTheme,
                            onLogoutOrLogin = onNavigateToLogin
                        )
                    }
                    item {
                        LiveDisconnectedPanel(
                            title = state.title,
                            subtitle = state.message,
                            onConnectClick = onNavigateToLogin,
                            onDiscoverClick = onNavigateToDiscovery,
                            onSwitchToGuestClick = viewModel::switchToGuestMode
                        )
                    }
                }
            }
            is UiState.Error -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        RouterHeaderBar(
                            title = "RouterManager Pro",
                            subtitle = "Connection Error",
                            statusColor = RoseCritical,
                            onNotifications = { },
                            onToggleTheme = viewModel::toggleTheme,
                            onLogoutOrLogin = onNavigateToLogin
                        )
                    }
                    item { InfoBanner(message = state.message) }
                }
            }
            is UiState.Ready -> {
                val content = state.data
                val info = content.routerInfo

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp)
                        .testTag("dashboard_list"),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 112.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        RouterHeaderBar(
                            title = "${info.manufacturer} ${info.model}",
                            subtitle = "${info.routerIp} · ${if (state.isGuestMode) "GUEST MODE" else "LIVE MODE"}",
                            statusColor = if (state.isGuestMode) AmberGuest else MaterialTheme.colorScheme.primary,
                            onNotifications = { showActivitySheet = true },
                            onToggleTheme = viewModel::toggleTheme,
                            onLogoutOrLogin = onNavigateToLogin
                        )
                    }
                    if (!feedback.isNullOrBlank()) item { InfoBanner(message = feedback!!) }
                    if (!content.routerInfoWarning.isNullOrBlank()) {
                        item { InfoBanner(message = "Router information warning: ${content.routerInfoWarning}") }
                    }
                    item {
                        Text(
                            text = "HUAWEI ROUTER CONTROLS",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            DashboardTileCard(
                                title = "WiFi Password Management",
                                subtitle = "View or change your WiFi name and password",
                                icon = Icons.Outlined.WifiPassword,
                                iconTint = Color(0xFF9B70FF),
                                onClick = onNavigateToWifi,
                                modifier = Modifier.fillMaxWidth().testTag("tile_wifi_password")
                            )
                            DashboardTileCard(
                                title = "Devices Information",
                                subtitle = "See connected devices and manage access",
                                icon = Icons.Outlined.Devices,
                                iconTint = Color(0xFF31D98A),
                                onClick = onNavigateToDevices,
                                modifier = Modifier.fillMaxWidth().testTag("tile_devices")
                            )
                            DashboardTileCard(
                                title = "PON Optical Information",
                                subtitle = "RX and TX power, temperature and LOS status",
                                icon = Icons.Outlined.WbSunny,
                                iconTint = Color(0xFF38BDF8),
                                onClick = onNavigateToOpticalInfo,
                                modifier = Modifier.fillMaxWidth().testTag("tile_pon_optical")
                            )
                            DashboardTileCard(
                                title = "WAN Admin Only",
                                subtitle = "View and manage WAN connections",
                                icon = Icons.Outlined.Public,
                                iconTint = Color(0xFFA78BFA),
                                onClick = onNavigateToWanAdmin,
                                modifier = Modifier.fillMaxWidth().testTag("tile_wan_admin")
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HeroStatColumn(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.Start
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            color = Color.White.copy(alpha = 0.78f)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun RouterGlyphIllustration(
    accentColor: Color
) {
    Canvas(modifier = Modifier.size(width = 210.dp, height = 88.dp)) {
        val w = size.width
        val h = size.height
        val cx = w / 2f

        // Signal arc above router
        drawArc(
            color = Color.White.copy(alpha = 0.65f),
            startAngle = 220f,
            sweepAngle = 100f,
            useCenter = false,
            topLeft = Offset(cx - 20.dp.toPx(), 4.dp.toPx()),
            size = Size(40.dp.toPx(), 24.dp.toPx()),
            style = Stroke(width = 2.6.dp.toPx(), cap = StrokeCap.Round)
        )

        val bodyTop = h * 0.38f
        val bodyHeight = h * 0.34f
        val bodyWidth = 104.dp.toPx()
        val bodyLeft = (w - bodyWidth) / 2f

        // Dual antennas
        drawLine(
            color = Color.White,
            start = Offset(bodyLeft + 16.dp.toPx(), bodyTop),
            end = Offset(bodyLeft + 11.dp.toPx(), bodyTop - 16.dp.toPx()),
            strokeWidth = 3.2.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color.White,
            start = Offset(bodyLeft + bodyWidth - 16.dp.toPx(), bodyTop),
            end = Offset(bodyLeft + bodyWidth - 11.dp.toPx(), bodyTop - 16.dp.toPx()),
            strokeWidth = 3.2.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Chassis
        drawRoundRect(
            color = Color(0xFFF3F6FC),
            topLeft = Offset(bodyLeft, bodyTop),
            size = Size(bodyWidth, bodyHeight),
            cornerRadius = CornerRadius(12.dp.toPx(), 12.dp.toPx())
        )

        // LED dots + power port
        val ledY = bodyTop + bodyHeight / 2f
        drawCircle(color = EmeraldOnline, radius = 2.6.dp.toPx(), center = Offset(bodyLeft + 16.dp.toPx(), ledY))
        drawCircle(color = accentColor, radius = 2.6.dp.toPx(), center = Offset(bodyLeft + 27.dp.toPx(), ledY))
        drawCircle(color = AmberGuest, radius = 2.6.dp.toPx(), center = Offset(bodyLeft + 38.dp.toPx(), ledY))
        drawRoundRect(
            color = Color(0xFF1E293B),
            topLeft = Offset(bodyLeft + bodyWidth - 24.dp.toPx(), ledY - 3.dp.toPx()),
            size = Size(11.dp.toPx(), 6.dp.toPx()),
            cornerRadius = CornerRadius(2.dp.toPx(), 2.dp.toPx())
        )

        // Dotted telemetry arc underneath matching screenshot #7
        val dashEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 8f), 0f)
        drawArc(
            color = Color.White.copy(alpha = 0.5f),
            startAngle = 200f,
            sweepAngle = 140f,
            useCenter = false,
            topLeft = Offset(cx - 88.dp.toPx(), bodyTop + bodyHeight + 6.dp.toPx()),
            size = Size(176.dp.toPx(), 42.dp.toPx()),
            style = Stroke(width = 1.8.dp.toPx(), pathEffect = dashEffect)
        )
        listOf(cx - 50.dp.toPx() to bodyTop + bodyHeight + 11.dp.toPx(), cx to bodyTop + bodyHeight + 6.dp.toPx(), cx + 50.dp.toPx() to bodyTop + bodyHeight + 11.dp.toPx()).forEach { (px, py) ->
            drawCircle(color = Color.White.copy(alpha = 0.35f), radius = 6.dp.toPx(), center = Offset(px, py))
            drawCircle(color = Color.White, radius = 2.5.dp.toPx(), center = Offset(px, py))
        }
    }
}

@Composable
private fun DashboardTileCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    iconTint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    AdminCard(onClick = onClick, modifier = modifier) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = iconTint.copy(alpha = 0.16f),
                border = BorderStroke(1.dp, iconTint.copy(alpha = 0.30f)),
                modifier = Modifier.size(58.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(imageVector = icon, contentDescription = null, tint = iconTint, modifier = Modifier.size(30.dp))
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                Text(title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onSurface, maxLines = 2)
                Spacer(modifier = Modifier.height(3.dp))
                Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
            }
            Icon(Icons.AutoMirrored.Outlined.KeyboardArrowRight, contentDescription = null, tint = iconTint, modifier = Modifier.size(28.dp))
        }
    }
}

@Composable
private fun MoreGroupRow(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        onClick = onClick,
        color = Color.Transparent,
        modifier = Modifier.fillMaxWidth().testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(19.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun ActivityLogSheetContent(
    events: List<NetworkActivityEvent>,
    onRebootClick: () -> Unit,
    onRefreshClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Router Activity & Quick Actions", style = MaterialTheme.typography.titleLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onRefreshClick) {
                    Text("Refresh")
                }
                OutlinedButton(onClick = onRebootClick) {
                    Icon(Icons.Outlined.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Reboot")
                }
            }
        }
        LazyColumn(
            modifier = Modifier.height(340.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(events, key = { it.id }) { event ->
                AdminCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(event.title, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                        StatusPill(
                            label = event.category.label,
                            tone = when (event.severity) {
                                ActivitySeverity.CRITICAL -> PillTone.CRITICAL
                                ActivitySeverity.WARNING -> PillTone.WARNING
                                ActivitySeverity.INFO -> PillTone.INFO
                            }
                        )
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(event.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(2.dp))
                    Text(event.timestampLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.outline)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
    }
}
