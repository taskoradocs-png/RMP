package com.example.features.wifi

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.UiState
import com.example.designsystem.AdminCard
import com.example.designsystem.ConfirmDestructiveDialog
import com.example.designsystem.InfoBanner
import com.example.designsystem.LiveDisconnectedPanel
import com.example.designsystem.PillTone
import com.example.designsystem.SectionHeader
import com.example.designsystem.StatusPill
import com.example.designsystem.UnsupportedFeatureNotice
import com.example.models.ConnectedDevice
import com.example.models.ConnectionType
import com.example.models.WifiBand
import com.example.models.WifiBandConfig
import com.example.models.WifiSecurityMode

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WifiScreen(
    viewModel: WifiViewModel,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit,
    guestOnly: Boolean = false,
    guestDevices: List<ConnectedDevice> = emptyList(),
    onToggleGuestBlock: ((String, Boolean) -> Unit)? = null,
    onBack: (() -> Unit)? = null
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val selectedBand by viewModel.selectedBand.collectAsStateWithLifecycle()
    val band24Draft by viewModel.band24Draft.collectAsStateWithLifecycle()
    val band5Draft by viewModel.band5Draft.collectAsStateWithLifecycle()
    val guestDraft by viewModel.guestDraft.collectAsStateWithLifecycle()
    val feedback by viewModel.feedbackMessage.collectAsStateWithLifecycle()

    var showDisableMasterConfirm by remember { mutableStateOf(false) }
    var pendingSaveBand by remember { mutableStateOf<WifiBand?>(null) }
    var showGuestSaveConfirm by remember { mutableStateOf(false) }
    var showBandPassword by remember { mutableStateOf(false) }
    var showGuestPassword by remember { mutableStateOf(false) }

    if (showDisableMasterConfirm) {
        ConfirmDestructiveDialog(
            title = "Disable All Wi-Fi Radios?",
            message = "Turning off master Wi-Fi will disconnect every wireless client immediately.",
            confirmLabel = "Disable Wi-Fi",
            isCritical = true,
            onConfirm = {
                showDisableMasterConfirm = false
                viewModel.setMasterWifiEnabled(false)
            },
            onDismiss = { showDisableMasterConfirm = false }
        )
    }

    pendingSaveBand?.let { band ->
        ConfirmDestructiveDialog(
            title = "Apply ${band.label} Changes?",
            message = "Wireless clients on ${band.label} may briefly reconnect when SSID, security, or channel changes are applied.",
            confirmLabel = "Apply Changes",
            isCritical = false,
            onConfirm = {
                pendingSaveBand = null
                viewModel.commitBandSave(band)
            },
            onDismiss = { pendingSaveBand = null }
        )
    }

    if (showGuestSaveConfirm) {
        ConfirmDestructiveDialog(
            title = "Update Guest Network?",
            message = "Apply updated Guest SSID and isolation policy?",
            confirmLabel = "Save Guest Settings",
            isCritical = false,
            onConfirm = {
                showGuestSaveConfirm = false
                viewModel.commitGuestSave()
            },
            onDismiss = { showGuestSaveConfirm = false }
        )
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        when (val state = uiState) {
            is UiState.Loading -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is UiState.Disconnected -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item { Text("Wi-Fi Configuration", style = MaterialTheme.typography.headlineMedium) }
                    item {
                        LiveDisconnectedPanel(
                            title = state.title,
                            subtitle = state.message,
                            onConnectClick = onNavigateToLogin,
                            onDiscoverClick = onNavigateToDiscovery,
                            onSwitchToGuestClick = viewModel::switchToGuestMode
                        )
                    }
                }
            }
            is UiState.Error -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    item { InfoBanner(message = state.message) }
                }
            }
            is UiState.Ready -> {
                val content = state.data
                val wifi = content.wifiConfig
                val activeBandConfig: WifiBandConfig? =
                    if (selectedBand == WifiBand.BAND_2_4_GHZ) wifi.band24 else wifi.band5
                val activeDraft = if (selectedBand == WifiBand.BAND_2_4_GHZ) band24Draft else band5Draft

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp)
                        .testTag("wifi_screen_list"),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (onBack != null) {
                                IconButton(onClick = onBack, modifier = Modifier.testTag("wifi_back_button")) {
                                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                                }
                                Spacer(Modifier.width(6.dp))
                            }
                            Text(
                                text = if (guestOnly) "Guest" else "Wi-Fi Configuration",
                                style = MaterialTheme.typography.titleLarge
                            )
                        }
                    }

                    if (!feedback.isNullOrBlank()) {
                        item { InfoBanner(message = feedback!!) }
                    }

                    if (!guestOnly) {
                    // Master Wi-Fi Switch
                    item {
                        AdminCard {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Master Wi-Fi Radios", style = MaterialTheme.typography.titleMedium)
                                    Text(
                                        text = if (wifi.masterWifiEnabled) "2.4 GHz and 5 GHz radios broadcasting" else "All wireless radios disabled",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Switch(
                                    checked = wifi.masterWifiEnabled,
                                    onCheckedChange = { enable ->
                                        if (enable) {
                                            viewModel.setMasterWifiEnabled(true)
                                        } else {
                                            showDisableMasterConfirm = true
                                        }
                                    },
                                    modifier = Modifier.testTag("master_wifi_switch")
                                )
                            }
                        }
                    }

                    // Band Selector
                    item {
                        SingleChoiceSegmentedButtonRow(
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            WifiBand.entries.forEachIndexed { index, band ->
                                val enabledOption = band == WifiBand.BAND_2_4_GHZ || (content.supportsDualBand && wifi.band5 != null)
                                SegmentedButton(
                                    selected = selectedBand == band,
                                    onClick = { if (enabledOption) viewModel.selectBand(band) },
                                    enabled = enabledOption,
                                    shape = SegmentedButtonDefaults.itemShape(index, WifiBand.entries.size),
                                    modifier = Modifier.testTag("wifi_band_tab_${band.name}")
                                ) {
                                    Text(band.label)
                                }
                            }
                        }
                    }

                    // Selected Band Configuration Form
                    if (activeBandConfig != null && activeDraft != null) {
                        item {
                            AdminCard {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    SectionHeader(
                                        title = "${selectedBand.label} Wireless Settings",
                                        subtitle = "${activeBandConfig.connectedClientsCount} active clients"
                                    )
                                    StatusPill(
                                        label = if (activeDraft.enabled && wifi.masterWifiEnabled) "Broadcasting" else "Disabled",
                                        tone = if (activeDraft.enabled && wifi.masterWifiEnabled) PillTone.ONLINE else PillTone.NEUTRAL
                                    )
                                }

                                Spacer(Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Enable ${selectedBand.label} Radio", style = MaterialTheme.typography.bodyMedium)
                                    Switch(
                                        checked = activeDraft.enabled,
                                        onCheckedChange = { checked ->
                                            viewModel.updateDraft(selectedBand) { it.copy(enabled = checked) }
                                        },
                                        modifier = Modifier.testTag("band_enabled_switch")
                                    )
                                }

                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = activeDraft.ssid,
                                    onValueChange = { value ->
                                        viewModel.updateDraft(selectedBand) { it.copy(ssid = value, ssidError = null) }
                                    },
                                    label = { Text("Network Name (SSID)") },
                                    isError = activeDraft.ssidError != null,
                                    supportingText = activeDraft.ssidError?.let { { Text(it) } },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("wifi_ssid_input")
                                )

                                Spacer(Modifier.height(10.dp))
                                SecurityModeDropdown(
                                    selected = activeDraft.securityMode,
                                    onSelect = { mode ->
                                        viewModel.updateDraft(selectedBand) { it.copy(securityMode = mode, passwordError = null) }
                                    }
                                )

                                if (activeDraft.securityMode.requiresPassphrase) {
                                    Spacer(Modifier.height(10.dp))
                                    OutlinedTextField(
                                        value = activeDraft.password,
                                        onValueChange = { value ->
                                            viewModel.updateDraft(selectedBand) { it.copy(password = value, passwordError = null) }
                                        },
                                        label = { Text("Wi-Fi Passphrase") },
                                        isError = activeDraft.passwordError != null,
                                        supportingText = activeDraft.passwordError?.let { { Text(it) } },
                                        singleLine = true,
                                        visualTransformation = if (showBandPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                        trailingIcon = {
                                            IconButton(onClick = { showBandPassword = !showBandPassword }) {
                                                Icon(
                                                    imageVector = if (showBandPassword) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                                                    contentDescription = "Toggle password visibility"
                                                )
                                            }
                                        },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("wifi_password_input")
                                    )
                                }

                                Spacer(Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Hide SSID Broadcast", style = MaterialTheme.typography.bodyMedium)
                                    Switch(
                                        checked = activeDraft.hiddenSsid,
                                        onCheckedChange = { hidden ->
                                            viewModel.updateDraft(selectedBand) { it.copy(hiddenSsid = hidden) }
                                        }
                                    )
                                }

                                Spacer(Modifier.height(12.dp))
                                if (content.supportsChannelConfig) {
                                    OptionSelectorDropdown(
                                        label = "Channel",
                                        selectedValue = activeDraft.channel,
                                        options = activeBandConfig.availableChannels,
                                        onSelect = { ch ->
                                            viewModel.updateDraft(selectedBand) { it.copy(channel = ch) }
                                        },
                                        testTag = "wifi_channel_dropdown"
                                    )
                                } else {
                                    UnsupportedFeatureNotice(
                                        featureName = "Channel Selection",
                                        reason = "Active adapter does not expose manual channel selection."
                                    )
                                }

                                Spacer(Modifier.height(10.dp))
                                if (content.supportsBandwidthConfig) {
                                    OptionSelectorDropdown(
                                        label = "Channel Bandwidth",
                                        selectedValue = activeDraft.bandwidthMhz,
                                        options = activeBandConfig.availableBandwidthsMhz,
                                        onSelect = { bw ->
                                            viewModel.updateDraft(selectedBand) { it.copy(bandwidthMhz = bw) }
                                        },
                                        testTag = "wifi_bandwidth_dropdown"
                                    )
                                } else {
                                    UnsupportedFeatureNotice(
                                        featureName = "Bandwidth Configuration",
                                        reason = "Active adapter does not support 20/40/80/160 MHz width tuning."
                                    )
                                }

                                Spacer(Modifier.height(16.dp))
                                Button(
                                    onClick = {
                                        if (viewModel.validateAndPrepareBandSave(selectedBand)) {
                                            pendingSaveBand = selectedBand
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("wifi_save_band_button")
                                ) {
                                    Text("Apply ${selectedBand.label} Settings")
                                }
                            }
                        }
                    }

                    }

                    // Guest Network Configuration (supports Name & Password + Guest Users tabs)
                    item {
                        if (!guestOnly) {
                            SectionHeader(
                                title = "Guest Network",
                                subtitle = "Isolated wireless access for visitors"
                            )
                        }
                    }
                    item {
                        if (!content.supportsGuestNetwork || guestDraft == null) {
                            UnsupportedFeatureNotice(
                                featureName = "Guest Wi-Fi Network",
                                reason = "Active router adapter does not support isolated guest SSIDs."
                            )
                        } else {
                            var guestTabIndex by remember { mutableIntStateOf(0) }
                            val gDraft = guestDraft!!
                            AdminCard {
                                TabRow(selectedTabIndex = guestTabIndex) {
                                    Tab(
                                        selected = guestTabIndex == 0,
                                        onClick = { guestTabIndex = 0 },
                                        text = { Text("Name & Password") }
                                    )
                                    Tab(
                                        selected = guestTabIndex == 1,
                                        onClick = { guestTabIndex = 1 },
                                        text = { Text("Guest Users") }
                                    )
                                }
                                Spacer(Modifier.height(12.dp))
                                if (guestTabIndex == 1) {
                                    val filteredGuests = guestDevices.filter {
                                        it.connectionType == ConnectionType.GUEST_WIFI || it.isGuestBlocked
                                    }
                                    if (filteredGuests.isEmpty()) {
                                        Text(
                                            text = "No clients currently associated on Guest SSID.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    } else {
                                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                            filteredGuests.forEach { guest ->
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column(modifier = Modifier.weight(1f)) {
                                                        Text(guest.name, style = MaterialTheme.typography.titleSmall)
                                                        Text(
                                                            text = "${guest.ipAddress} · ${guest.macAddress}",
                                                            style = MaterialTheme.typography.bodySmall,
                                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                    if (onToggleGuestBlock != null) {
                                                        OutlinedButton(
                                                            onClick = { onToggleGuestBlock(guest.macAddress, !guest.isGuestBlocked) },
                                                            shape = RoundedCornerShape(50)
                                                        ) {
                                                            Text(if (guest.isGuestBlocked) "Allow Guest" else "Block Guest")
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                } else {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Enable Guest SSID", style = MaterialTheme.typography.titleMedium)
                                        Text(
                                            text = wifi.guestNetwork?.bandLabel ?: "Guest VLAN",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = gDraft.enabled,
                                        onCheckedChange = { enabled ->
                                            viewModel.updateGuestDraft { it.copy(enabled = enabled) }
                                        },
                                        modifier = Modifier.testTag("guest_wifi_switch")
                                    )
                                }

                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = gDraft.ssid,
                                    onValueChange = { v ->
                                        viewModel.updateGuestDraft { it.copy(ssid = v, ssidError = null) }
                                    },
                                    label = { Text("Guest Network Name (SSID)") },
                                    isError = gDraft.ssidError != null,
                                    supportingText = gDraft.ssidError?.let { { Text(it) } },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("guest_ssid_input")
                                )

                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = gDraft.password,
                                    onValueChange = { v ->
                                        viewModel.updateGuestDraft { it.copy(password = v, passwordError = null) }
                                    },
                                    label = { Text("Guest Passphrase") },
                                    isError = gDraft.passwordError != null,
                                    supportingText = gDraft.passwordError?.let { { Text(it) } },
                                    singleLine = true,
                                    visualTransformation = if (showGuestPassword) VisualTransformation.None else PasswordVisualTransformation(),
                                    trailingIcon = {
                                        IconButton(onClick = { showGuestPassword = !showGuestPassword }) {
                                            Icon(
                                                imageVector = if (showGuestPassword) Icons.Outlined.VisibilityOff else Icons.Outlined.Visibility,
                                                contentDescription = "Toggle guest password visibility"
                                            )
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("guest_password_input")
                                )

                                Spacer(Modifier.height(10.dp))
                                OutlinedTextField(
                                    value = gDraft.bandwidthLimitMbps,
                                    onValueChange = { v ->
                                        viewModel.updateGuestDraft { it.copy(bandwidthLimitMbps = v.filter { ch -> ch.isDigit() }) }
                                    },
                                    label = { Text("Bandwidth Cap (Mbps, optional)") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("Isolate from Local LAN", style = MaterialTheme.typography.bodyMedium)
                                        Text(
                                            text = "Prevent guests from reaching NAS, printers, or router admin",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Switch(
                                        checked = gDraft.isolateClients,
                                        onCheckedChange = { iso ->
                                            viewModel.updateGuestDraft { it.copy(isolateClients = iso) }
                                        }
                                    )
                                }

                                Spacer(Modifier.height(14.dp))
                                Button(
                                    onClick = {
                                        if (viewModel.validateAndPrepareGuestSave()) {
                                            showGuestSaveConfirm = true
                                        }
                                    },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("wifi_save_guest_button")
                                ) {
                                    Text("Save Guest Network")
                                }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SecurityModeDropdown(
    selected: WifiSecurityMode,
    onSelect: (WifiSecurityMode) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = selected.label,
            onValueChange = {},
            readOnly = true,
            label = { Text("Security Mode") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                .fillMaxWidth()
                .testTag("wifi_security_dropdown")
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            WifiSecurityMode.entries.forEach { mode ->
                DropdownMenuItem(
                    text = { Text(mode.label) },
                    onClick = {
                        expanded = false
                        onSelect(mode)
                    }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun OptionSelectorDropdown(
    label: String,
    selectedValue: String,
    options: List<String>,
    onSelect: (String) -> Unit,
    testTag: String
) {
    var expanded by remember { mutableStateOf(false) }
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = selectedValue,
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                .fillMaxWidth()
                .testTag(testTag)
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { opt ->
                DropdownMenuItem(
                    text = { Text(opt) },
                    onClick = {
                        expanded = false
                        onSelect(opt)
                    }
                )
            }
        }
    }
}
