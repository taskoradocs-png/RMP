package com.example.features.devices

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Cable
import androidx.compose.material.icons.outlined.Devices
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material.icons.outlined.PublicOff
import androidx.compose.material.icons.outlined.PushPin
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Wifi
import androidx.compose.material.icons.outlined.WifiOff
import androidx.compose.material.icons.outlined.Computer
import androidx.compose.material.icons.outlined.DevicesOther
import androidx.compose.material.icons.outlined.LaptopMac
import androidx.compose.material.icons.outlined.PhoneAndroid
import androidx.compose.material.icons.outlined.Sensors
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material.icons.outlined.TabletMac
import androidx.compose.material.icons.outlined.Tv
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.Formatters
import com.example.core.UiState
import com.example.designsystem.AdminCard
import com.example.designsystem.ConfirmDestructiveDialog
import com.example.designsystem.CyanAccent
import com.example.designsystem.EmeraldOnline
import com.example.designsystem.InfoBanner
import com.example.designsystem.LiveDisconnectedPanel
import com.example.designsystem.MonoValueStyle
import com.example.designsystem.RoseCritical
import com.example.designsystem.RoseSurface
import com.example.designsystem.EmeraldSurface
import com.example.models.ConnectedDevice
import com.example.models.ConnectionType
import com.example.models.DeviceCategory

private sealed interface InlineDeviceAction {
    data class BlockWifi(val device: ConnectedDevice) : InlineDeviceAction
    data class BlockGuest(val device: ConnectedDevice, val block: Boolean) : InlineDeviceAction
    data class BlockInternet(val device: ConnectedDevice, val block: Boolean) : InlineDeviceAction
    data class ToggleStaticIp(val device: ConnectedDevice, val reserve: Boolean) : InlineDeviceAction
    data class Rename(val device: ConnectedDevice) : InlineDeviceAction
}

@Composable
fun DevicesScreen(
    viewModel: DevicesViewModel,
    onOpenDeviceDetail: (String) -> Unit,
    onOpenBlockedDevices: () -> Unit,
    onNavigateToLogin: () -> Unit,
    onNavigateToDiscovery: () -> Unit,
    onBack: (() -> Unit)? = null
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedFilter by viewModel.selectedFilter.collectAsStateWithLifecycle()
    val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()

    var pendingAction by remember { mutableStateOf<InlineDeviceAction?>(null) }

    pendingAction?.let { action ->
        when (action) {
            is InlineDeviceAction.BlockWifi -> {
                ConfirmDestructiveDialog(
                    title = "Block Device Wi-Fi?",
                    message = "Disconnect and add ${action.device.name} (${action.device.macAddress}) to the MAC block list?",
                    confirmLabel = "Block WiFi",
                    isCritical = true,
                    onConfirm = {
                        pendingAction = null
                        viewModel.blockDevice(action.device.macAddress)
                    },
                    onDismiss = { pendingAction = null }
                )
            }
            is InlineDeviceAction.BlockGuest -> {
                ConfirmDestructiveDialog(
                    title = if (action.block) "Block Guest Wi-Fi?" else "Allow Guest Wi-Fi?",
                    message = "${if (action.block) "Deny" else "Permit"} Guest SSID association for ${action.device.name}?",
                    confirmLabel = if (action.block) "Block Guest" else "Allow Guest",
                    isCritical = action.block,
                    onConfirm = {
                        pendingAction = null
                        viewModel.setGuestBlocked(action.device.macAddress, action.block)
                    },
                    onDismiss = { pendingAction = null }
                )
            }
            is InlineDeviceAction.BlockInternet -> {
                ConfirmDestructiveDialog(
                    title = if (action.block) "Block Internet Access?" else "Restore Internet Access?",
                    message = if (action.block) {
                        "Stop WAN internet traffic for ${action.device.name} (${action.device.ipAddress}) without disconnecting Wi-Fi?"
                    } else {
                        "Restore full WAN internet access for ${action.device.name}?"
                    },
                    confirmLabel = if (action.block) "Block Internet" else "Allow Internet",
                    isCritical = action.block,
                    onConfirm = {
                        pendingAction = null
                        viewModel.setInternetBlocked(action.device.macAddress, action.block)
                    },
                    onDismiss = { pendingAction = null }
                )
            }
            is InlineDeviceAction.ToggleStaticIp -> {
                ConfirmDestructiveDialog(
                    title = if (action.reserve) "Reserve Static IP?" else "Remove Static IP?",
                    message = if (action.reserve) {
                        "Bind ${action.device.ipAddress} permanently to ${action.device.macAddress} in DHCP?"
                    } else {
                        "Release static DHCP lease for ${action.device.name}?"
                    },
                    confirmLabel = if (action.reserve) "Reserve IP" else "Remove Static",
                    isCritical = false,
                    onConfirm = {
                        pendingAction = null
                        viewModel.setStaticIp(action.device.macAddress, action.reserve)
                    },
                    onDismiss = { pendingAction = null }
                )
            }
            is InlineDeviceAction.Rename -> {
                var editedName by remember(action.device.macAddress) { mutableStateOf(action.device.name) }
                AlertDialog(
                    onDismissRequest = { pendingAction = null },
                    title = { Text("Rename Device") },
                    text = {
                        OutlinedTextField(
                            value = editedName,
                            onValueChange = { editedName = it },
                            label = { Text("Device Label") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().testTag("rename_device_input")
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                if (editedName.isNotBlank()) {
                                    viewModel.renameDevice(action.device.macAddress, editedName)
                                    pendingAction = null
                                }
                            },
                            modifier = Modifier.testTag("rename_device_confirm")
                        ) { Text("Save Name") }
                    },
                    dismissButton = {
                        TextButton(onClick = { pendingAction = null }) { Text("Cancel") }
                    }
                )
            }
        }
    }

    Box(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.TopCenter
    ) {
        when (val state = uiState) {
            is UiState.Loading -> {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is UiState.Disconnected -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        DevicesTopBar(
                            onBack = onBack,
                            onRefresh = viewModel::refresh
                        )
                    }
                    item {
                        LiveDisconnectedPanel(
                            title = state.title,
                            subtitle = state.message,
                            onConnectClick = onNavigateToLogin,
                            onDiscoverClick = onNavigateToDiscovery,
                            onSwitchToGuestClick = viewModel::switchToGuestMode
                        )
                    }
                }
            }
            is UiState.Error -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    item { InfoBanner(message = state.message) }
                }
            }
            is UiState.Ready -> {
                val filteredDevices = viewModel.filterDevices(
                    allDevices = state.data.devices,
                    query = searchQuery,
                    filter = selectedFilter
                )
                val liveCount = state.data.devices.count { it.isOnline && !it.isBlocked }
                val offlineCount = state.data.devices.count { !it.isOnline && !it.isBlocked }

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .widthIn(max = 720.dp)
                        .testTag("devices_list"),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        DevicesTopBar(
                            onBack = onBack,
                            onRefresh = viewModel::refresh
                        )
                    }

                    // 2 Summary Cards: Live/Offline & Blocked >
                    item {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            AdminCard(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(EmeraldSurface),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Devices,
                                            contentDescription = "Online clients",
                                            tint = EmeraldOnline,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "$liveCount live",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "$offlineCount offline",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }

                            AdminCard(
                                onClick = onOpenBlockedDevices,
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("open_blocked_devices_button")
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .clip(CircleShape)
                                            .background(RoseSurface),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Outlined.Block,
                                            contentDescription = "Blocked clients",
                                            tint = RoseCritical,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = state.data.blockedCount.toString(),
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "Blocked",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Outlined.KeyboardArrowRight,
                                        contentDescription = "View blocked devices",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }

                    // Blue Instructional Tip Banner (matching screenshot #4)
                    item {
                        InfoBanner(
                            message = "Click on the pencil icon to manage a device's access or rename it. Tap any card for signal strength and band details."
                        )
                    }

                    if (!actionMessage.isNullOrBlank()) {
                        item { InfoBanner(message = actionMessage!!) }
                    }

                    // Search & Filters
                    item {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = viewModel::updateSearchQuery,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("device_search_input"),
                            placeholder = { Text("Search name, IP, MAC, or vendor") },
                            leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                            singleLine = true,
                            shape = MaterialTheme.shapes.small
                        )
                    }

                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(DeviceFilter.entries) { filter ->
                                FilterChip(
                                    selected = selectedFilter == filter,
                                    onClick = { viewModel.selectFilter(filter) },
                                    label = { Text(filter.label) },
                                    modifier = Modifier.testTag("device_filter_${filter.name}")
                                )
                            }
                        }
                    }

                    if (filteredDevices.isEmpty()) {
                        item {
                            AdminCard {
                                Text("No matching clients", style = MaterialTheme.typography.titleMedium)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = "Try clearing your search filter or inspect the Blocked Devices list.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    } else {
                        items(filteredDevices, key = { it.macAddress }) { device ->
                            ScreenshotDeviceCard(
                                device = device,
                                supportsBlocking = state.data.supportsBlocking,
                                supportsGuestBlocking = state.data.supportsGuestBlocking,
                                supportsInternetBlocking = state.data.supportsInternetBlocking,
                                supportsStaticIp = state.data.supportsStaticIp,
                                supportsRename = state.data.supportsRename,
                                onCardClick = { onOpenDeviceDetail(device.macAddress) },
                                onRenameClick = { pendingAction = InlineDeviceAction.Rename(device) },
                                onBlockWifiClick = { pendingAction = InlineDeviceAction.BlockWifi(device) },
                                onToggleGuestBlock = { pendingAction = InlineDeviceAction.BlockGuest(device, !device.isGuestBlocked) },
                                onToggleInternetBlock = { pendingAction = InlineDeviceAction.BlockInternet(device, !device.isInternetBlocked) },
                                onToggleStaticIp = { pendingAction = InlineDeviceAction.ToggleStaticIp(device, !device.staticIpReserved) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DevicesTopBar(
    onBack: (() -> Unit)?,
    onRefresh: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (onBack != null) {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Outlined.ArrowBack, contentDescription = "Back")
                }
                Spacer(Modifier.width(4.dp))
            }
            Text(
                text = "Connected Devices",
                style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
            )
        }
        IconButton(
            onClick = onRefresh,
            modifier = Modifier.testTag("devices_refresh_button")
        ) {
            Icon(Icons.Outlined.Refresh, contentDescription = "Refresh device list")
        }
    }
}

@Composable
private fun ScreenshotDeviceCard(
    device: ConnectedDevice,
    supportsBlocking: Boolean,
    supportsGuestBlocking: Boolean,
    supportsInternetBlocking: Boolean,
    supportsStaticIp: Boolean,
    supportsRename: Boolean,
    onCardClick: () -> Unit,
    onRenameClick: () -> Unit,
    onBlockWifiClick: () -> Unit,
    onToggleGuestBlock: () -> Unit,
    onToggleInternetBlock: () -> Unit,
    onToggleStaticIp: () -> Unit
) {
    val bandLabel = when (device.connectionType) {
        ConnectionType.WIFI_5_GHZ -> "5G"
        ConnectionType.WIFI_2_4_GHZ -> "2.4G"
        ConnectionType.ETHERNET -> "LAN"
        ConnectionType.GUEST_WIFI -> "Guest"
    }
    val bandColor = when (device.connectionType) {
        ConnectionType.WIFI_5_GHZ -> Color(0xFF8B5CF6)
        ConnectionType.WIFI_2_4_GHZ -> Color(0xFF6366F1)
        ConnectionType.ETHERNET -> CyanAccent
        ConnectionType.GUEST_WIFI -> Color(0xFFF59E0B)
    }

    AdminCard(
        onClick = onCardClick,
        modifier = Modifier.testTag("device_card_${device.macAddress}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            // Left band badge
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.width(48.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(bandColor.copy(alpha = 0.16f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (device.connectionType == ConnectionType.ETHERNET) Icons.Outlined.Cable else Icons.Outlined.Wifi,
                        contentDescription = device.connectionType.label,
                        tint = bandColor
                    )
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    text = bandLabel,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                    color = bandColor,
                    maxLines = 1
                )
            }

            Spacer(Modifier.width(12.dp))

            // Middle Name + IP + MAC
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = device.name,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(2.dp))
                Text(
                    text = "${device.ipAddress} ·",
                    style = MonoValueStyle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = device.macAddress.lowercase(),
                    style = MonoValueStyle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Right Pencil + Online duration
            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (supportsRename) {
                        IconButton(
                            onClick = onRenameClick,
                            modifier = Modifier
                                .size(32.dp)
                                .testTag("rename_device_${device.macAddress}")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Edit,
                                contentDescription = "Rename ${device.name}",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Spacer(Modifier.width(2.dp))
                    Text(
                        text = if (device.isOnline) "Online from" else "Status",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(
                    text = if (device.isOnline) Formatters.formatUptime(device.connectedDurationSeconds) else device.lastSeenLabel,
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                    color = if (device.isOnline) EmeraldOnline else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        // Block WiFi & Block Guest Dual Action Pills
        if (supportsBlocking || supportsGuestBlocking) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (supportsBlocking) {
                    InlineActionPill(
                        label = "Block WiFi",
                        bgColor = RoseSurface,
                        fgColor = RoseCritical,
                        onClick = onBlockWifiClick,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("inline_block_wifi_${device.macAddress}")
                    )
                }
                if (supportsGuestBlocking) {
                    InlineActionPill(
                        label = if (device.isGuestBlocked) "Allow Guest" else "Block Guest",
                        bgColor = if (device.isGuestBlocked) EmeraldSurface else RoseSurface,
                        fgColor = if (device.isGuestBlocked) EmeraldOnline else RoseCritical,
                        onClick = onToggleGuestBlock,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("inline_block_guest_${device.macAddress}")
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
        }

        // Internet access is always visible in the Huawei Devices section.
        // It remains disabled until the captured IP-filter workflow is verified
        // end-to-end for the target firmware.
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = if (device.isInternetBlocked) Icons.Outlined.PublicOff else Icons.Outlined.Language,
                        contentDescription = null,
                        tint = if (device.isInternetBlocked) RoseCritical else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = when {
                            !supportsInternetBlocking -> "Internet blocking not verified for this firmware"
                            device.isInternetBlocked -> "Internet blocked"
                            else -> "Internet access allowed"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = if (device.isInternetBlocked) RoseCritical else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    onClick = onToggleInternetBlock,
                    enabled = supportsInternetBlocking,
                    shape = RoundedCornerShape(50),
                    color = if (device.isInternetBlocked) EmeraldSurface else RoseSurface,
                    border = BorderStroke(1.dp, (if (device.isInternetBlocked) EmeraldOnline else RoseCritical).copy(alpha = 0.35f)),
                    modifier = Modifier.testTag("inline_block_internet_${device.macAddress}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = if (device.isInternetBlocked) Icons.Outlined.Wifi else Icons.Outlined.WifiOff,
                            contentDescription = null,
                            tint = if (device.isInternetBlocked) EmeraldOnline else RoseCritical,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (device.isInternetBlocked) "Allow Internet" else "Block Internet",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (device.isInternetBlocked) EmeraldOnline else RoseCritical
                        )
                    }
                }
            }
        Spacer(Modifier.height(8.dp))

        // Static IP reservation row
        if (supportsStaticIp) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Outlined.PushPin,
                        contentDescription = null,
                        tint = if (device.staticIpReserved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        text = if (device.staticIpReserved) "Static IP: ${device.ipAddress}" else "No static IP reserved",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (device.staticIpReserved) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Surface(
                    onClick = onToggleStaticIp,
                    shape = RoundedCornerShape(50),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)),
                    modifier = Modifier.testTag("inline_static_ip_${device.macAddress}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.PushPin,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (device.staticIpReserved) "Release IP" else "Static IP",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun InlineActionPill(
    label: String,
    bgColor: Color,
    fgColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(48.dp),
        shape = RoundedCornerShape(12.dp),
        color = bgColor,
        border = BorderStroke(1.dp, fgColor.copy(alpha = 0.28f))
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                color = fgColor
            )
        }
    }
}

fun categoryIcon(category: DeviceCategory): ImageVector = when (category) {
    DeviceCategory.PHONE -> Icons.Outlined.PhoneAndroid
    DeviceCategory.LAPTOP -> Icons.Outlined.LaptopMac
    DeviceCategory.DESKTOP -> Icons.Outlined.Computer
    DeviceCategory.TABLET -> Icons.Outlined.TabletMac
    DeviceCategory.TV_MEDIA -> Icons.Outlined.Tv
    DeviceCategory.IOT -> Icons.Outlined.Sensors
    DeviceCategory.GAMING -> Icons.Outlined.SportsEsports
    DeviceCategory.UNKNOWN -> Icons.Outlined.DevicesOther
}
