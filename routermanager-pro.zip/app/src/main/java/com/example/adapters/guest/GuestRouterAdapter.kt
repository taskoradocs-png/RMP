package com.example.adapters.guest

import com.example.core.RouterResult
import com.example.models.AdapterDescriptor
import com.example.models.ConnectedDevice
import com.example.models.DhcpConfig
import com.example.models.DiagnosticResult
import com.example.models.DnsConfig
import com.example.models.EthernetPortInfo
import com.example.models.FirewallConfig
import com.example.models.GuestNetworkConfig
import com.example.models.InterfaceStat
import com.example.models.LanConfig
import com.example.models.NetworkActivityEvent
import com.example.models.NetworkSettings
import com.example.models.OpticalInfo
import com.example.models.ParentalControlTemplate
import com.example.models.PortForwardRule
import com.example.models.RouterCapability
import com.example.models.RouterCredentials
import com.example.models.RouterFeature
import com.example.models.RouterInfo
import com.example.models.RouterSession
import com.example.models.SpeedTestResult
import com.example.models.TrafficSnapshot
import com.example.models.VoipLineInfo
import com.example.models.WanConnectionProfile
import com.example.models.WifiBand
import com.example.models.WifiBandConfig
import com.example.models.WifiConfig
import com.example.router.RouterAdapter

class GuestExperienceAdapter(
    private val guestSampleDataProvider: GuestSampleDataProvider
) : RouterAdapter {

    override val capabilities = RouterCapability(
        supportedFeatures = RouterFeature.entries.toSet(),
        supports5Ghz = true,
        maxGuestNetworks = 1,
        capabilityNotes = "Guest Experience exposes all administration screens for preview."
    )

    override val descriptor = AdapterDescriptor(
        id = "guest_sandbox",
        displayName = "Guest Experience Adapter",
        manufacturer = "RouterManager Guest",
        supportedModels = listOf("RT-AX86U Pro (Guest)"),
        minFirmwareVersion = "3.0.0.4",
        protocolDescription = "Isolated in-memory guestnstration sandbox (no network I/O).",
        capability = capabilities,
        isLiveTransportReady = false
    )

    override suspend fun authenticate(credentials: RouterCredentials): RouterResult<RouterSession> {
        return RouterResult.Success(
            data = RouterSession(
                sessionId = "guest-session",
                profileId = "guest-profile-sample",
                routerIp = guestSampleDataProvider.getRouterInfo().routerIp,
                adapterId = descriptor.id,
                authenticatedUsername = credentials.username.ifBlank { "guest-viewer" },
                establishedAtEpochMs = System.currentTimeMillis(),
                isGuestSession = true
            ),
            isGuestData = true
        )
    }

    override suspend fun disconnect(): RouterResult<Unit> = RouterResult.Success(Unit, isGuestData = true)

    override suspend fun getRouterInfo(): RouterResult<RouterInfo> =
        RouterResult.Success(guestSampleDataProvider.getRouterInfo(), isGuestData = true)

    override suspend fun getTrafficSnapshot(): RouterResult<TrafficSnapshot> =
        RouterResult.Success(guestSampleDataProvider.getTrafficSnapshot(), isGuestData = true)

    override suspend fun getRecentActivity(): RouterResult<List<NetworkActivityEvent>> =
        RouterResult.Success(guestSampleDataProvider.getRecentActivity(), isGuestData = true)

    override suspend fun getWifiConfig(): RouterResult<WifiConfig> =
        RouterResult.Success(guestSampleDataProvider.getWifiConfig(), isGuestData = true)

    override suspend fun setWifiEnabled(enabled: Boolean): RouterResult<WifiConfig> =
        RouterResult.Success(guestSampleDataProvider.setWifiEnabled(enabled), isGuestData = true)

    override suspend fun updateSsid(band: WifiBand, ssid: String): RouterResult<WifiConfig> =
        RouterResult.Success(guestSampleDataProvider.updateSsid(band, ssid), isGuestData = true)

    override suspend fun updateWifiPassword(band: WifiBand, password: String): RouterResult<WifiConfig> =
        RouterResult.Success(guestSampleDataProvider.updateWifiPassword(band, password), isGuestData = true)

    override suspend fun updateWifiBandConfig(band: WifiBand, config: WifiBandConfig): RouterResult<WifiConfig> =
        RouterResult.Success(guestSampleDataProvider.updateWifiBandConfig(band, config), isGuestData = true)

    override suspend fun updateGuestNetwork(config: GuestNetworkConfig): RouterResult<WifiConfig> =
        RouterResult.Success(guestSampleDataProvider.updateGuestNetwork(config), isGuestData = true)

    override suspend fun getConnectedDevices(): RouterResult<List<ConnectedDevice>> =
        RouterResult.Success(guestSampleDataProvider.getDevices(), isGuestData = true)

    override suspend fun renameDevice(macAddress: String, newName: String): RouterResult<Unit> {
        return if (guestSampleDataProvider.renameDevice(macAddress, newName)) {
            RouterResult.Success(Unit, isGuestData = true)
        } else {
            RouterResult.Failure("Unable to rename $macAddress in Guest Experience.")
        }
    }

    override suspend fun blockDevice(macAddress: String): RouterResult<Unit> {
        return if (guestSampleDataProvider.blockDevice(macAddress)) {
            RouterResult.Success(Unit, isGuestData = true)
        } else {
            RouterResult.Failure("Device $macAddress not found in Guest Experience.")
        }
    }

    override suspend fun unblockDevice(macAddress: String): RouterResult<Unit> {
        return if (guestSampleDataProvider.unblockDevice(macAddress)) {
            RouterResult.Success(Unit, isGuestData = true)
        } else {
            RouterResult.Failure("Device $macAddress not found in Guest Experience.")
        }
    }

    override suspend fun setDeviceInternetBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> {
        return if (guestSampleDataProvider.setDeviceInternetBlocked(macAddress, blocked)) {
            RouterResult.Success(Unit, isGuestData = true)
        } else {
            RouterResult.Failure("Device $macAddress not found in Guest Experience.")
        }
    }

    override suspend fun setDeviceGuestBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> {
        return if (guestSampleDataProvider.setDeviceGuestBlocked(macAddress, blocked)) {
            RouterResult.Success(Unit, isGuestData = true)
        } else {
            RouterResult.Failure("Device $macAddress not found in Guest Experience.")
        }
    }

    override suspend fun setDeviceBandBlocked(macAddress: String, band: WifiBand, blocked: Boolean): RouterResult<Unit> {
        return if (guestSampleDataProvider.setDeviceBandBlocked(macAddress, band, blocked)) {
            RouterResult.Success(Unit, isGuestData = true)
        } else {
            RouterResult.Failure("Device $macAddress not found in Guest Experience.")
        }
    }

    override suspend fun setDeviceStaticIp(macAddress: String, reserved: Boolean): RouterResult<Unit> {
        return if (guestSampleDataProvider.setDeviceStaticIp(macAddress, reserved)) {
            RouterResult.Success(Unit, isGuestData = true)
        } else {
            RouterResult.Failure("Device $macAddress not found in Guest Experience.")
        }
    }

    override suspend fun getNetworkSettings(): RouterResult<NetworkSettings> =
        RouterResult.Success(guestSampleDataProvider.getNetworkSettings(), isGuestData = true)

    override suspend fun updateLanConfig(lanConfig: LanConfig): RouterResult<NetworkSettings> =
        RouterResult.Success(guestSampleDataProvider.updateLanConfig(lanConfig), isGuestData = true)

    override suspend fun updateDhcpConfig(dhcpConfig: DhcpConfig): RouterResult<NetworkSettings> =
        RouterResult.Success(guestSampleDataProvider.updateDhcpConfig(dhcpConfig), isGuestData = true)

    override suspend fun updateDnsConfig(dnsConfig: DnsConfig): RouterResult<NetworkSettings> =
        RouterResult.Success(guestSampleDataProvider.updateDnsConfig(dnsConfig), isGuestData = true)

    override suspend fun savePortForwardRule(rule: PortForwardRule): RouterResult<NetworkSettings> =
        RouterResult.Success(guestSampleDataProvider.savePortForwardRule(rule), isGuestData = true)

    override suspend fun deletePortForwardRule(ruleId: String): RouterResult<NetworkSettings> =
        RouterResult.Success(guestSampleDataProvider.deletePortForwardRule(ruleId), isGuestData = true)

    override suspend fun updateFirewallConfig(firewallConfig: FirewallConfig): RouterResult<NetworkSettings> =
        RouterResult.Success(guestSampleDataProvider.updateFirewallConfig(firewallConfig), isGuestData = true)

    override suspend fun setUpnpEnabled(enabled: Boolean): RouterResult<NetworkSettings> =
        RouterResult.Success(guestSampleDataProvider.setUpnpEnabled(enabled), isGuestData = true)

    override suspend fun saveWanConnection(profile: WanConnectionProfile): RouterResult<NetworkSettings> =
        RouterResult.Success(guestSampleDataProvider.saveWanConnection(profile), isGuestData = true)

    override suspend fun deleteWanConnection(profileId: String): RouterResult<NetworkSettings> =
        RouterResult.Success(guestSampleDataProvider.deleteWanConnection(profileId), isGuestData = true)

    override suspend fun runNetworkDiagnostics(): RouterResult<List<DiagnosticResult>> =
        RouterResult.Success(guestSampleDataProvider.runDiagnostics(), isGuestData = true)

    override suspend fun getOpticalInfo(): RouterResult<OpticalInfo> =
        RouterResult.Success(guestSampleDataProvider.getOpticalInfo(), isGuestData = true)

    override suspend fun getEthernetPorts(): RouterResult<List<EthernetPortInfo>> =
        RouterResult.Success(guestSampleDataProvider.getEthernetPorts(), isGuestData = true)

    override suspend fun getInterfaceStats(): RouterResult<List<InterfaceStat>> =
        RouterResult.Success(guestSampleDataProvider.getInterfaceStats(), isGuestData = true)

    override suspend fun getVoipStatus(): RouterResult<List<VoipLineInfo>> =
        RouterResult.Success(guestSampleDataProvider.getVoipStatus(), isGuestData = true)

    override suspend fun getParentalTemplates(): RouterResult<List<ParentalControlTemplate>> =
        RouterResult.Success(guestSampleDataProvider.getParentalTemplates(), isGuestData = true)

    override suspend fun saveParentalTemplate(template: ParentalControlTemplate): RouterResult<List<ParentalControlTemplate>> =
        RouterResult.Success(guestSampleDataProvider.saveParentalTemplate(template), isGuestData = true)

    override suspend fun deleteParentalTemplate(templateId: String): RouterResult<List<ParentalControlTemplate>> =
        RouterResult.Success(guestSampleDataProvider.deleteParentalTemplate(templateId), isGuestData = true)

    override suspend fun runSpeedTest(): RouterResult<SpeedTestResult> =
        RouterResult.Success(guestSampleDataProvider.runSpeedTest(), isGuestData = true)

    override suspend fun rebootRouter(): RouterResult<Unit> {
        guestSampleDataProvider.rebootGuestRouter()
        return RouterResult.Success(Unit, isGuestData = true)
    }
}
