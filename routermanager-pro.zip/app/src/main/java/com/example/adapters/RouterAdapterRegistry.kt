package com.example.adapters

import com.example.adapters.guest.GuestSampleDataProvider
import com.example.authentication.RouterSessionManager

/**
 * Compatibility subclass delegating directly to RouterCapabilityRegistry.
 */
class RouterAdapterRegistry(
    guestSampleDataProvider: GuestSampleDataProvider,
    sessionManager: RouterSessionManager = RouterSessionManager()
) : RouterCapabilityRegistry(guestSampleDataProvider, sessionManager)
