package com.example.adapters

import com.example.adapters.guest.GuestSampleDataProvider
import com.example.adapters.guest.GuestExperienceAdapter
import com.example.adapters.live.HuaweiHs8346rAdapter
import com.example.authentication.RouterSessionManager
import com.example.models.AdapterDescriptor
import com.example.models.RouterCapability
import com.example.models.RouterFeature
import com.example.router.RouterAdapter

data class AdapterMatchResult(
    val adapter: RouterAdapter,
    val confidenceLabel: String,
    val reason: String
)

/**
 * Central registry for router adapters and per-firmware capabilities.
 * Registers every live adapter exposed by the login screen.
 */
open class RouterCapabilityRegistry(
    guestSampleDataProvider: GuestSampleDataProvider,
    sessionManager: RouterSessionManager = RouterSessionManager()
) {
    val guestAdapter: RouterAdapter = GuestExperienceAdapter(guestSampleDataProvider)
    val huaweiHs8346rAdapter: HuaweiHs8346rAdapter = HuaweiHs8346rAdapter(sessionManager = sessionManager)

    // This edition intentionally exposes only the Huawei ONT adapter family.
    // Other vendor adapters remain in source but are not selectable in this build.
    private val liveAdapters: List<RouterAdapter> = listOf(huaweiHs8346rAdapter)

    fun getAllSupportedDescriptors(): List<AdapterDescriptor> =
        liveAdapters.map { it.descriptor }

    fun getAdapterById(id: String): RouterAdapter? {
        if (id == guestAdapter.descriptor.id) return guestAdapter
        return liveAdapters.firstOrNull { it.descriptor.id == id }
    }

    fun getCapabilities(adapterId: String): RouterCapability? =
        getAdapterById(adapterId)?.capabilities

    fun supportsFeature(adapterId: String, feature: RouterFeature): Boolean =
        getAdapterById(adapterId)?.capabilities?.supports(feature) == true

    fun identifyCompatibleAdapter(
        manufacturer: String,
        model: String,
        firmwareVersion: String = ""
    ): AdapterMatchResult? {
        val mfg = manufacturer.trim().lowercase()
        val mdl = model.trim().lowercase()
        val fw = firmwareVersion.trim().lowercase()

        val exactModelMatch = liveAdapters.firstOrNull { adapter ->
            val d = adapter.descriptor
            d.manufacturer.lowercase() == mfg &&
                d.supportedModels.any { it.lowercase().contains(mdl) || mdl.contains(it.lowercase()) }
        }
        if (exactModelMatch != null) {
            val fwNote = if (fw.isNotBlank() && fw >= exactModelMatch.descriptor.minFirmwareVersion.lowercase()) {
                "Firmware $firmwareVersion meets minimum ${exactModelMatch.descriptor.minFirmwareVersion}."
            } else if (fw.isNotBlank()) {
                "Firmware $firmwareVersion matched by manufacturer/model."
            } else {
                "Matched by manufacturer and model."
            }
            return AdapterMatchResult(
                adapter = exactModelMatch,
                confidenceLabel = "Exact Model Match",
                reason = fwNote
            )
        }

        val mfgMatch = liveAdapters.firstOrNull {
            it.descriptor.manufacturer.lowercase() == mfg ||
                mfg.contains("huawei") && it.descriptor.id == huaweiHs8346rAdapter.descriptor.id
        }
        if (mfgMatch != null) {
            return AdapterMatchResult(
                adapter = mfgMatch,
                confidenceLabel = "Manufacturer Family Match",
                reason = "Matched ${mfgMatch.descriptor.manufacturer} adapter family; capabilities verified against device API."
            )
        }

        return null
    }
}
