package com.example.designsystem

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Block
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Router
import androidx.compose.material.icons.outlined.Science
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R

enum class PillTone {
    ONLINE,
    WARNING,
    CRITICAL,
    INFO,
    NEUTRAL
}

@Composable
fun AdminCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val themeCfg = LocalRouterThemeConfig.current
    val shape = MaterialTheme.shapes.medium
    val borderColor = when (themeCfg.themeStyle) {
        com.example.core.ThemeStyleOption.ICE -> MaterialTheme.colorScheme.outlineVariant
        com.example.core.ThemeStyleOption.HALO -> MaterialTheme.colorScheme.primary.copy(alpha = 0.28f)
        else -> MaterialTheme.colorScheme.outlineVariant
    }
    val border = BorderStroke(1.dp, borderColor)
    val containerColor = when {
        !themeCfg.isDark -> MaterialTheme.colorScheme.surfaceContainer
        themeCfg.themeStyle == com.example.core.ThemeStyleOption.ICE -> MaterialTheme.colorScheme.surfaceContainer.copy(alpha = 0.92f)
        themeCfg.themeStyle == com.example.core.ThemeStyleOption.ONE_UI -> MaterialTheme.colorScheme.surfaceContainerHigh
        else -> MaterialTheme.colorScheme.surfaceContainer
    }

    if (onClick != null) {
        Surface(
            onClick = onClick,
            modifier = modifier.fillMaxWidth(),
            shape = shape,
            color = containerColor,
            border = border,
            tonalElevation = if (themeCfg.themeStyle == com.example.core.ThemeStyleOption.ONE_UI) 2.dp else 1.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                content = content
            )
        }
    } else {
        Surface(
            modifier = modifier.fillMaxWidth(),
            shape = shape,
            color = containerColor,
            border = border,
            tonalElevation = if (themeCfg.themeStyle == com.example.core.ThemeStyleOption.ONE_UI) 2.dp else 1.dp
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                content = content
            )
        }
    }
}

@Composable
fun HexRouterEmblem(
    modifier: Modifier = Modifier,
    tint: Color = Color(0xFF9AC4CA)
) {
    Canvas(modifier = modifier.size(104.dp)) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f
        val r = w * 0.44f

        // Hexagon outline
        val hex = Path()
        for (i in 0 until 6) {
            val angleRad = Math.toRadians((60.0 * i) - 90.0)
            val px = cx + (r * kotlin.math.cos(angleRad)).toFloat()
            val py = cy + (r * kotlin.math.sin(angleRad)).toFloat()
            if (i == 0) hex.moveTo(px, py) else hex.lineTo(px, py)
        }
        hex.close()
        drawPath(
            path = hex,
            color = tint,
            style = Stroke(width = 3.dp.toPx(), join = StrokeJoin.Round)
        )

        // Router base silhouette
        val bodyW = w * 0.40f
        val bodyH = h * 0.14f
        val bodyTop = cy + h * 0.06f
        val bodyLeft = cx - bodyW / 2f
        drawRoundRect(
            color = tint,
            topLeft = Offset(bodyLeft, bodyTop),
            size = androidx.compose.ui.geometry.Size(bodyW, bodyH),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6.dp.toPx(), 6.dp.toPx())
        )

        // Antennas
        drawLine(
            color = tint,
            start = Offset(bodyLeft + 6.dp.toPx(), bodyTop),
            end = Offset(bodyLeft + 1.dp.toPx(), bodyTop - 16.dp.toPx()),
            strokeWidth = 3.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawLine(
            color = tint,
            start = Offset(bodyLeft + bodyW - 6.dp.toPx(), bodyTop),
            end = Offset(bodyLeft + bodyW - 1.dp.toPx(), bodyTop - 16.dp.toPx()),
            strokeWidth = 3.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Branching routing arrows upward
        val arrows = listOf(
            Offset(cx, cy - h * 0.30f),
            Offset(cx - w * 0.16f, cy - h * 0.24f),
            Offset(cx + w * 0.16f, cy - h * 0.24f),
            Offset(cx - w * 0.25f, cy - h * 0.10f),
            Offset(cx + w * 0.25f, cy - h * 0.10f)
        )
        arrows.forEach { tip ->
            drawLine(
                color = tint,
                start = Offset(cx, bodyTop - 2.dp.toPx()),
                end = tip,
                strokeWidth = 2.4.dp.toPx(),
                cap = StrokeCap.Round
            )
            drawCircle(color = tint, radius = 2.4.dp.toPx(), center = tip)
        }

        // Gear badge at bottom center
        val gearCenter = Offset(cx, bodyTop + bodyH + 6.dp.toPx())
        drawCircle(
            color = Color(0xFF0A1020),
            radius = 8.dp.toPx(),
            center = gearCenter
        )
        drawCircle(
            color = tint,
            radius = 6.dp.toPx(),
            center = gearCenter,
            style = Stroke(width = 2.4.dp.toPx())
        )
        drawCircle(
            color = tint,
            radius = 2.2.dp.toPx(),
            center = gearCenter
        )
    }
}

@Composable
fun SectionHeader(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    trailing: @Composable (() -> Unit)? = null
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground
            )
            if (!subtitle.isNullOrBlank()) {
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        if (trailing != null) {
            Spacer(modifier = Modifier.width(8.dp))
            trailing()
        }
    }
}

@Composable
fun StatusPill(
    label: String,
    tone: PillTone,
    modifier: Modifier = Modifier
) {
    val (bg, fg) = when (tone) {
        PillTone.ONLINE -> EmeraldSurface to EmeraldOnline
        PillTone.WARNING -> AmberSurface to AmberGuest
        PillTone.CRITICAL -> RoseSurface to RoseCritical
        PillTone.INFO -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.primary
        PillTone.NEUTRAL -> MaterialTheme.colorScheme.surfaceContainerHighest to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(50),
        color = bg,
        border = BorderStroke(1.dp, fg.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(fg)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = fg,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun KeyValueRow(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    isMonospace: Boolean = false,
    valueColor: Color = MaterialTheme.colorScheme.onSurface
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.weight(1f)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = value,
            style = if (isMonospace) MonoValueStyle else MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium),
            color = valueColor,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun GuestModeBanner(
    onSwitchToLiveMode: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("guest_mode_banner"),
        color = AmberSurface,
        border = BorderStroke(1.dp, AmberGuest.copy(alpha = 0.45f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Icon(
                    imageVector = Icons.Outlined.Science,
                    contentDescription = "Guest experience active",
                    tint = AmberGuest,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = "GUEST MODE · SANDBOX DATA",
                        style = MaterialTheme.typography.labelLarge,
                        color = AmberGuest
                    )
                    Text(
                        text = "Simulated router telemetry. Not connected to hardware.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFFFDE68A),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            TextButton(
                onClick = onSwitchToLiveMode,
                modifier = Modifier.testTag("switch_to_live_button")
            ) {
                Text(
                    text = "Go Live",
                    style = MaterialTheme.typography.labelLarge,
                    color = AmberGuest
                )
            }
        }
    }
}

@Composable
fun LiveDisconnectedPanel(
    title: String,
    subtitle: String,
    onConnectClick: () -> Unit,
    onDiscoverClick: () -> Unit,
    onSwitchToGuestClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    AdminCard(modifier = modifier.testTag("live_disconnected_panel")) {
        Image(
            painter = painterResource(id = R.drawable.img_router_topology_1794636262553),
            contentDescription = "Network router hardware topology diagram",
            modifier = Modifier
                .fillMaxWidth()
                .height(148.dp)
                .clip(RoundedCornerShape(10.dp))
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp)),
            contentScale = ContentScale.Crop
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            StatusPill(label = "LIVE MODE · DISCONNECTED", tone = PillTone.CRITICAL)
        }
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = subtitle,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = onConnectClick,
                modifier = Modifier
                    .weight(1f)
                    .testTag("live_connect_button")
            ) {
                Icon(
                    imageVector = Icons.Outlined.Router,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text("Authenticate")
            }
            OutlinedButton(
                onClick = onDiscoverClick,
                modifier = Modifier
                    .weight(1f)
                    .testTag("live_discover_button")
            ) {
                Text("Scan Router")
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        TextButton(
            onClick = onSwitchToGuestClick,
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .testTag("switch_to_guest_button")
        ) {
            Text("Explore as Guest")
        }
    }
}

@Composable
fun UnsupportedFeatureNotice(
    featureName: String,
    reason: String,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.small,
        color = MaterialTheme.colorScheme.surfaceContainerHighest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = Icons.Outlined.Block,
                contentDescription = "Unsupported feature",
                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(18.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "$featureName · Unsupported",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = reason,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun InfoBanner(
    message: String,
    modifier: Modifier = Modifier,
    icon: ImageVector = Icons.Outlined.Info
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.small,
        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp)
            )
            Text(
                text = message,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface
            )
        }
    }
}

@Composable
fun ConfirmDestructiveDialog(
    title: String,
    message: String,
    confirmLabel: String,
    isCritical: Boolean = true,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Outlined.WarningAmber,
                contentDescription = "Confirmation required",
                tint = if (isCritical) RoseCritical else AmberGuest
            )
        },
        title = {
            Text(
                text = title,
                style = MaterialTheme.typography.titleLarge
            )
        },
        text = {
            Text(
                text = message,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = if (isCritical) {
                    ButtonDefaults.buttonColors(
                        containerColor = RoseCritical,
                        contentColor = Color.White
                    )
                } else {
                    ButtonDefaults.buttonColors()
                },
                modifier = Modifier.testTag("confirm_dialog_button")
            ) {
                Text(confirmLabel)
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("cancel_dialog_button")
            ) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun ThroughputChart(
    downloadHistoryMbps: List<Float>,
    uploadHistoryMbps: List<Float>,
    modifier: Modifier = Modifier
) {
    val downloadColor = MaterialTheme.colorScheme.primary
    val uploadColor = MaterialTheme.colorScheme.secondary
    val gridColor = MaterialTheme.colorScheme.outlineVariant

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .border(1.dp, gridColor, RoundedCornerShape(10.dp))
            .padding(12.dp)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            if (w <= 0f || h <= 0f) return@Canvas

            // Draw subtle horizontal telemetry gridlines
            val lines = 3
            for (i in 0..lines) {
                val y = h * (i.toFloat() / lines.toFloat())
                drawLine(
                    color = gridColor.copy(alpha = 0.5f),
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1.dp.toPx()
                )
            }

            val maxVal = maxOf(
                downloadHistoryMbps.maxOrNull() ?: 1f,
                uploadHistoryMbps.maxOrNull() ?: 1f,
                50f
            ) * 1.12f

            fun drawSeries(series: List<Float>, lineColor: Color) {
                if (series.size < 2) return
                val stepX = w / (series.size - 1).toFloat()
                val strokePath = Path()
                val fillPath = Path()

                series.forEachIndexed { index, value ->
                    val x = index * stepX
                    val y = h - ((value / maxVal).coerceIn(0f, 1f) * h)
                    if (index == 0) {
                        strokePath.moveTo(x, y)
                        fillPath.moveTo(x, h)
                        fillPath.lineTo(x, y)
                    } else {
                        strokePath.lineTo(x, y)
                        fillPath.lineTo(x, y)
                    }
                    if (index == series.lastIndex) {
                        fillPath.lineTo(x, h)
                        fillPath.close()
                    }
                }

                drawPath(
                    path = fillPath,
                    color = lineColor.copy(alpha = 0.14f)
                )
                drawPath(
                    path = strokePath,
                    color = lineColor,
                    style = Stroke(
                        width = 2.2.dp.toPx(),
                        cap = StrokeCap.Round,
                        join = StrokeJoin.Round
                    )
                )
            }

            drawSeries(downloadHistoryMbps, downloadColor)
            drawSeries(uploadHistoryMbps, uploadColor)
        }
    }
}
