package com.example.designsystem

import androidx.compose.ui.graphics.Color

// Deep Midnight Navy Dark-First Palette (matched to screenshots)
val NavyVoid = Color(0xFF070C1A)
val CharcoalBase = Color(0xFF0B1122)
val CharcoalSurface = Color(0xFF10172A)
val CharcoalElevated = Color(0xFF162038)
val CharcoalHighest = Color(0xFF1E2947)
val HairlineBorderDark = Color(0xFF212E4D)

val CyanAccent = Color(0xFF22D3EE)
val CyanMuted = Color(0xFF0E4A5C)
val ElectricBlue = Color(0xFF1E88FF)
val BlueMuted = Color(0xFF172D59)

val TextPrimaryDark = Color(0xFFF3F6FC)
val TextSecondaryDark = Color(0xFF8C9BB8)
val TextMutedDark = Color(0xFF60708F)

// Semantic Status Colors
val EmeraldOnline = Color(0xFF10B981)
val EmeraldSurface = Color(0xFF0D2F27)
val AmberGuest = Color(0xFFF59E0B)
val AmberSurface = Color(0xFF3A280A)
val RoseCritical = Color(0xFFEF4444)
val RoseSurface = Color(0xFF331823)
val SlateOffline = Color(0xFF64748B)

// Optional Light Palette (Crisp Technical Slate)
val LightBackground = Color(0xFFF2F6FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceElevated = Color(0xFFE7EEF9)
val HairlineBorderLight = Color(0xFFCFE0F2)
val CyanPrimaryLight = Color(0xFF0E7490)
val BlueSecondaryLight = Color(0xFF1D4ED8)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
