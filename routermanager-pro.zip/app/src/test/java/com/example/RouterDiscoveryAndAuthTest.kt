package com.example

import com.example.adapters.RouterCapabilityRegistry
import com.example.adapters.guest.GuestSampleDataProvider
import com.example.adapters.live.OpenWrtAdapter
import com.example.authentication.KeystoreCredentialCipher
import com.example.authentication.RouterAuthenticationManager
import com.example.authentication.RouterSessionManager
import com.example.core.AppMode
import com.example.core.RouterResult
import com.example.models.RouterCredentials
import com.example.models.RouterFeature
import com.example.networking.LocalNetworkSnapshot
import com.example.networking.NetworkEnvironmentInspector
import com.example.networking.OkHttpGatewayEndpointProber
import com.example.networking.RouterDiscoveryManager
import com.example.networking.RouterEndpointClient
import com.example.router.RouterController
import com.sun.net.httpserver.HttpServer
import kotlinx.coroutines.test.runTest
import okhttp3.Cookie
import okhttp3.HttpUrl.Companion.toHttpUrl
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.util.concurrent.Executors

class RouterDiscoveryAndAuthTest {

    @Test
    fun discoveryManager_detectsWifiLocalIpv4ReachableGatewayAndOpenWrtUbus() = runTest {
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        val port = server.address.port
        server.executor = Executors.newSingleThreadExecutor()
        server.createContext("/ubus") { ex ->
            val payload = """{"jsonrpc":"2.0","id":1,"error":{"code":-32002,"message":"Access denied"}}"""
            val bytes = payload.toByteArray()
            ex.responseHeaders.add("Content-Type", "application/json")
            ex.sendResponseHeaders(200, bytes.size.toLong())
            ex.responseBody.use { it.write(bytes) }
        }
        server.start()

        try {
            val inspector = object : NetworkEnvironmentInspector {
                override suspend fun inspectActiveNetwork() = LocalNetworkSnapshot(
                    isWifiActive = true,
                    isEthernetActive = false,
                    interfaceName = "wlan0",
                    localIpv4Address = "192.168.1.42",
                    subnetPrefixLength = 24,
                    defaultGatewayIp = "127.0.0.1"
                )
            }
            val discovery = RouterDiscoveryManager(
                networkInspector = inspector,
                endpointProber = OkHttpGatewayEndpointProber(),
                candidateAdminPorts = listOf("http" to port),
                probeTimeoutMs = 1500
            )

            val result = discovery.inspectLocalNetwork()
            assertTrue(result.isWifiActive)
            assertEquals("192.168.1.42", result.localIpv4Address)
            assertEquals("127.0.0.1", result.localGatewayIp)
            assertTrue(result.gatewayReachable)
            assertEquals(1, result.routers.size)

            val router = result.routers.first()
            assertTrue(router.isReachable)
            assertEquals(port, router.port)
            assertEquals(OpenWrtAdapter.ADAPTER_ID, router.matchedAdapterId)
            assertTrue(router.manufacturerHint.contains("OpenWrt", ignoreCase = true))
            assertTrue(router.adminInterfaces.any { it.scheme == "http" && it.port == port && it.detectedAdapterId == OpenWrtAdapter.ADAPTER_ID })
        } finally {
            server.stop(0)
        }
    }

    @Test
    fun discoveryManager_neverAssumesNonRouterHttpServerIsCompatible() = runTest {
        val server = HttpServer.create(InetSocketAddress("127.0.0.1", 0), 0)
        val port = server.address.port
        server.executor = Executors.newSingleThreadExecutor()
        server.createContext("/") { ex ->
            val bytes = "<html><title>Generic NAS</title></html>".toByteArray()
            ex.responseHeaders.add("Server", "nginx/1.24")
            ex.sendResponseHeaders(200, bytes.size.toLong())
            ex.responseBody.use { it.write(bytes) }
        }
        server.start()

        try {
            val inspector = object : NetworkEnvironmentInspector {
                override suspend fun inspectActiveNetwork() = LocalNetworkSnapshot(
                    isWifiActive = true,
                    isEthernetActive = false,
                    interfaceName = "wlan0",
                    localIpv4Address = "10.0.0.15",
                    subnetPrefixLength = 24,
                    defaultGatewayIp = "127.0.0.1"
                )
            }
            val discovery = RouterDiscoveryManager(
                networkInspector = inspector,
                endpointProber = OkHttpGatewayEndpointProber(),
                candidateAdminPorts = listOf("http" to port),
                probeTimeoutMs = 1500
            )

            val result = discovery.inspectLocalNetwork()
            assertTrue(result.gatewayReachable)
            val router = result.routers.first()
            assertNull(router.matchedAdapterId)
            assertEquals("Unidentified Gateway", router.manufacturerHint)
            assertTrue(router.adminInterfaces.any { it.detectedAdapterId == null && it.statusCode == 200 })
        } finally {
            server.stop(0)
        }
    }

    @Test
    fun discoveryManager_reportsUnreachableClosedGatewayAndDisconnectedWifi() = runTest {
        val unreachableProber = object : com.example.networking.GatewayEndpointProber {
            override suspend fun checkReachability(
                hostIp: String,
                probePorts: List<Int>,
                timeoutMs: Int
            ): Pair<Boolean, Long?> = false to null

            override suspend fun probeAdminInterface(
                hostIp: String,
                scheme: String,
                port: Int,
                timeoutMs: Int
            ) = null
        }
        val unreachableDiscovery = RouterDiscoveryManager(
            networkInspector = object : NetworkEnvironmentInspector {
                override suspend fun inspectActiveNetwork() = LocalNetworkSnapshot(
                    isWifiActive = true,
                    isEthernetActive = false,
                    interfaceName = "wlan0",
                    localIpv4Address = "192.0.2.10",
                    subnetPrefixLength = 24,
                    defaultGatewayIp = "192.0.2.254"
                )
            },
            endpointProber = unreachableProber,
            candidateAdminPorts = listOf("http" to 80, "https" to 443),
            probeTimeoutMs = 200
        )

        val unreachableScan = unreachableDiscovery.inspectLocalNetwork()
        assertFalse(unreachableScan.gatewayReachable)
        assertEquals("Unreachable Gateway", unreachableScan.routers.first().manufacturerHint)

        val disconnectedDiscovery = RouterDiscoveryManager(
            networkInspector = object : NetworkEnvironmentInspector {
                override suspend fun inspectActiveNetwork() = LocalNetworkSnapshot(
                    isWifiActive = false,
                    isEthernetActive = false,
                    interfaceName = null,
                    localIpv4Address = null,
                    subnetPrefixLength = null,
                    defaultGatewayIp = null,
                    errorDetail = "No active Wi-Fi or Ethernet connection detected."
                )
            }
        )
        val disconnectedScan = disconnectedDiscovery.inspectLocalNetwork()
        assertFalse(disconnectedScan.isWifiActive)
        assertNull(disconnectedScan.localGatewayIp)
        assertTrue(disconnectedScan.routers.isEmpty())
    }

    @Test
    fun sessionManager_managesCookiesCsrfAndExpiration() = runTest {
        var fakeNow = 1_000_000L
        val sessionManager = RouterSessionManager(clockMs = { fakeNow })
        val registry = RouterCapabilityRegistry(GuestSampleDataProvider(), sessionManager)
        val authManager = RouterAuthenticationManager(
            capabilityRegistry = registry,
            sessionManager = sessionManager,
            credentialCipher = KeystoreCredentialCipher(allowJreAesForTests = true)
        )
        val controller = RouterController(registry, sessionManager, authManager)

        controller.setAppMode(AppMode.LIVE)
        assertFalse(sessionManager.isAuthenticated())

        val url = "http://192.168.1.1/ubus".toHttpUrl()
        val cookie = Cookie.Builder()
            .name("sysauth")
            .value("cookie-abc-123")
            .domain("192.168.1.1")
            .path("/")
            .expiresAt(fakeNow + 60_000L)
            .build()
        sessionManager.cookieJar.saveFromResponse(url, listOf(cookie))
        sessionManager.startSession(
            session = com.example.models.RouterSession(
                sessionId = "s-1",
                profileId = null,
                routerIp = "192.168.1.1",
                adapterId = OpenWrtAdapter.ADAPTER_ID,
                authenticatedUsername = "root",
                establishedAtEpochMs = fakeNow,
                isGuestSession = false
            ),
            rpcSessionToken = "sid-xyz",
            csrfToken = "csrf-999",
            expiresAtEpochMs = fakeNow + 10_000L
        )

        assertTrue(sessionManager.isAuthenticated())
        assertFalse(sessionManager.isExpired())
        assertEquals("csrf-999", sessionManager.getCsrfToken())
        assertEquals(1, sessionManager.cookieJar.loadForRequest(url).size)

        // Advance clock past expiration
        fakeNow += 15_000L
        assertTrue(sessionManager.isExpired())
        assertFalse(sessionManager.isAuthenticated())

        val result = controller.getRouterInfo()
        assertTrue(result is RouterResult.NotConnected || result is RouterResult.AuthRequired)
        assertNull(sessionManager.currentSession.value)
        assertNull(sessionManager.getRpcSessionToken())
        assertNull(sessionManager.getCsrfToken())
    }

    @Test
    fun authenticationManager_validatesInputsAndEncryptsCredentials() = runTest {
        val sessionManager = RouterSessionManager()
        val registry = RouterCapabilityRegistry(GuestSampleDataProvider(), sessionManager)
        val cipher = KeystoreCredentialCipher(allowJreAesForTests = true)
        val authManager = RouterAuthenticationManager(registry, sessionManager, cipher)

        val badHost = authManager.authenticate(
            OpenWrtAdapter.ADAPTER_ID,
            RouterCredentials("not valid host!", 80, false, "root", "pass")
        )
        assertTrue(badHost is RouterResult.ValidationError)

        val blankPass = authManager.authenticate(
            OpenWrtAdapter.ADAPTER_ID,
            RouterCredentials("192.168.1.1", 80, false, "root", "")
        )
        assertTrue(blankPass is RouterResult.ValidationError)

        val encrypted = authManager.encryptCredential("MyRouterSecret!42")
        assertNotEquals("MyRouterSecret!42", encrypted)
        assertFalse(encrypted.contains("MyRouterSecret"))
        assertEquals("MyRouterSecret!42", authManager.decryptCredential(encrypted))
    }

    @Test
    fun privateLanTlsHelper_onlyAllowsLocalAndRfc1918Hosts() {
        assertTrue(RouterEndpointClient.isPrivateOrLocalHost("192.168.1.1"))
        assertTrue(RouterEndpointClient.isPrivateOrLocalHost("10.0.0.1"))
        assertTrue(RouterEndpointClient.isPrivateOrLocalHost("172.16.5.1"))
        assertTrue(RouterEndpointClient.isPrivateOrLocalHost("127.0.0.1"))
        assertTrue(RouterEndpointClient.isPrivateOrLocalHost("openwrt.lan"))
        assertFalse(RouterEndpointClient.isPrivateOrLocalHost("8.8.8.8"))
        assertFalse(RouterEndpointClient.isPrivateOrLocalHost("example.com"))
    }
}
