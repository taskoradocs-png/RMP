package com.example

import com.example.adapters.RouterAdapterRegistry
import com.example.adapters.guest.GuestSampleDataProvider
import com.example.authentication.SessionManager
import com.example.core.AppMode
import com.example.core.RouterResult
import com.example.core.Validators
import com.example.models.RouterCredentials
import com.example.models.RouterFeature
import com.example.models.WifiBand
import com.example.models.WifiSecurityMode
import com.example.router.RouterController
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RouterManagerUnitTest {

    @Test
    fun validators_validateIpv4AndSubnetAndPorts() {
        assertTrue(Validators.validateIpv4("192.168.50.1").isValid)
        assertFalse(Validators.validateIpv4("999.168.1.1").isValid)
        assertTrue(Validators.validateSubnetMask("255.255.255.0").isValid)
        assertFalse(Validators.validateSubnetMask("255.255.123.0").isValid)
        assertTrue(Validators.validatePort("443").isValid)
        assertFalse(Validators.validatePort("70000").isValid)
    }

    @Test
    fun validators_validateWifiSsidAndPassphrase() {
        assertTrue(Validators.validateSsid("Northstar_Core_5G").isValid)
        assertFalse(Validators.validateSsid("").isValid)
        assertFalse(Validators.validateWifiPassword("short", WifiSecurityMode.WPA2_PSK).isValid)
        assertTrue(Validators.validateWifiPassword("StrongPassphrase123", WifiSecurityMode.WPA3_SAE).isValid)
        assertTrue(Validators.validateWifiPassword("", WifiSecurityMode.OPEN).isValid)
    }

    @Test
    fun validators_validateDhcpPoolDoesNotOverlapGateway() {
        assertTrue(Validators.validateDhcpRange("192.168.50.100", "192.168.50.250", "192.168.50.1").isValid)
        assertFalse(Validators.validateDhcpRange("192.168.50.1", "192.168.50.200", "192.168.50.1").isValid)
        assertFalse(Validators.validateDhcpRange("192.168.50.200", "192.168.50.100", "192.168.50.1").isValid)
    }

    @Test
    fun credentialsToString_neverExposesPassword() {
        val creds = RouterCredentials(
            hostIp = "192.168.1.1",
            port = 443,
            useHttps = true,
            username = "admin",
            password = "SuperSecretRouterPassword!"
        )
        val rendered = creds.toString()
        assertFalse(rendered.contains("SuperSecretRouterPassword!"))
        assertTrue(rendered.contains("****"))
    }

    @Test
    fun liveMode_neverPretendsToBeConnected() = runTest {
        val registry = RouterAdapterRegistry(GuestSampleDataProvider())
        val controller = RouterController(registry, SessionManager())

        // Guest mode returns guest data
        assertEquals(AppMode.GUEST, controller.appMode.value)
        val guestInfo = controller.getRouterInfo()
        assertTrue(guestInfo is RouterResult.Success && guestInfo.isGuestData)

        // Switching to Live Mode immediately clears session & refuses to fabricate data
        controller.setAppMode(AppMode.LIVE)
        assertEquals(AppMode.LIVE, controller.appMode.value)
        assertTrue(controller.getRouterInfo() is RouterResult.NotConnected)
        assertTrue(controller.getConnectedDevices() is RouterResult.NotConnected)
        assertTrue(controller.getWifiConfig() is RouterResult.NotConnected)
        assertTrue(controller.getNetworkSettings() is RouterResult.NotConnected)
    }

    @Test
    fun adapterRegistry_exposesOnlyHuaweiLiveAdapterInHuaweiEdition() {
        val registry = RouterAdapterRegistry(GuestSampleDataProvider())
        val huawei = registry.identifyCompatibleAdapter("Huawei", "HG8145C", "V3R018C10S108")
        assertNotNull(huawei)
        assertEquals("huawei_hs8346r", huawei!!.adapter.descriptor.id)
        assertTrue(huawei.adapter.capabilities.supports(RouterFeature.WIFI_BASIC))
        assertTrue(huawei.adapter.capabilities.supports(RouterFeature.DEVICE_BLOCKING))
        assertTrue(huawei.adapter.capabilities.supports(RouterFeature.OPTICAL_INFO))
        assertFalse(huawei.adapter.capabilities.supports(RouterFeature.DEVICE_INTERNET_BLOCKING))

        assertNull(registry.identifyCompatibleAdapter("ASUS", "RT-AX86U Pro", "3.0.0.4.388"))
        assertNull(registry.identifyCompatibleAdapter("TP-Link", "Archer AX73", "1.1.0"))
        assertNull(registry.identifyCompatibleAdapter("OpenWrt", "GL-MT6000", "23.05"))
        assertEquals(listOf("huawei_hs8346r"), registry.getAllSupportedDescriptors().map { it.id })
    }

    @Test
    fun guestController_supportsInternetAndBandBlocking() = runTest {
        val registry = RouterAdapterRegistry(GuestSampleDataProvider())
        val controller = RouterController(registry, SessionManager())

        val initialDevices = (controller.getConnectedDevices() as RouterResult.Success).data
        val target = initialDevices.first { !it.isInternetBlocked && !it.isBlocked }

        val wanBlockResult = controller.setDeviceInternetBlocked(target.macAddress, true)
        assertTrue(wanBlockResult is RouterResult.Success)

        val bandBlockResult = controller.setDeviceBandBlocked(target.macAddress, WifiBand.BAND_5_GHZ, true)
        assertTrue(bandBlockResult is RouterResult.Success)

        val updatedDevices = (controller.getConnectedDevices() as RouterResult.Success).data
        val updated = updatedDevices.first { it.macAddress == target.macAddress }
        assertTrue(updated.isInternetBlocked)
        assertTrue(updated.isBand5Blocked)
        assertFalse(updated.isBand24Blocked)
    }

    @Test
    fun huaweiAdapter_returnsUnsupportedForUnverifiedInternetAndBandBlocking() = runTest {
        val registry = RouterAdapterRegistry(GuestSampleDataProvider())
        val huawei = registry.identifyCompatibleAdapter("Huawei", "HG8145C")!!.adapter

        val internetBlockRes = huawei.setDeviceInternetBlocked("AA:BB:CC:DD:EE:FF", true)
        assertTrue(internetBlockRes is RouterResult.Unsupported)

        val bandBlockRes = huawei.setDeviceBandBlocked("AA:BB:CC:DD:EE:FF", WifiBand.BAND_2_4_GHZ, true)
        assertTrue(bandBlockRes is RouterResult.Unsupported)

        val opticalRes = huawei.getOpticalInfo()
        assertTrue(opticalRes is RouterResult.NotConnected)

        val voipRes = huawei.getVoipStatus()
        assertTrue(voipRes is RouterResult.Unsupported)
    }

    @Test
    fun guestController_supportsRenameGuestBlockAndStaticIp() = runTest {
        val registry = RouterAdapterRegistry(GuestSampleDataProvider())
        val controller = RouterController(registry, SessionManager())

        val initial = (controller.getConnectedDevices() as RouterResult.Success).data
        val target = initial.first { !it.isBlocked && !it.staticIpReserved }

        assertTrue(controller.renameDevice(target.macAddress, "Office Laptop") is RouterResult.Success)
        assertTrue(controller.setDeviceGuestBlocked(target.macAddress, true) is RouterResult.Success)
        assertTrue(controller.setDeviceStaticIp(target.macAddress, true) is RouterResult.Success)

        val updated = (controller.getConnectedDevices() as RouterResult.Success).data
            .first { it.macAddress == target.macAddress }
        assertEquals("Office Laptop", updated.name)
        assertTrue(updated.isGuestBlocked)
        assertTrue(updated.staticIpReserved)
    }

    @Test
    fun guestController_exposesDiagnosticsParentalMultiWanAndSpeedTest() = runTest {
        val registry = RouterAdapterRegistry(GuestSampleDataProvider())
        val controller = RouterController(registry, SessionManager())

        val optical = controller.getOpticalInfo()
        assertTrue(optical is RouterResult.Success && optical.data.ponMode.contains("GPON"))

        val ports = controller.getEthernetPorts()
        assertTrue(ports is RouterResult.Success && ports.data.size == 4)

        val stats = controller.getInterfaceStats()
        assertTrue(stats is RouterResult.Success && stats.data.isNotEmpty())

        val voip = controller.getVoipStatus()
        assertTrue(voip is RouterResult.Success && voip.data.size == 2)

        val speed = controller.runSpeedTest()
        assertTrue(speed is RouterResult.Success && speed.data.downloadMbps > 0f)

        val createdTemplate = com.example.models.ParentalControlTemplate(
            id = "pc-test",
            name = "Study Hours",
            scheduleWindow = "16:00 – 19:00",
            blockedKeywordsCount = 5,
            assignedDeviceMacs = emptyList(),
            enabled = true
        )
        val afterSave = controller.saveParentalTemplate(createdTemplate) as RouterResult.Success
        assertTrue(afterSave.data.any { it.id == "pc-test" })
        val afterDelete = controller.deleteParentalTemplate("pc-test") as RouterResult.Success
        assertFalse(afterDelete.data.any { it.id == "pc-test" })

        val wanProfile = com.example.models.WanConnectionProfile(
            id = "wan-test",
            name = "WAN_IPTV",
            serviceType = "IPTV",
            connectionType = com.example.models.WanConnectionType.BRIDGE,
            vlanId = 300,
            isDefaultRoute = false,
            statusLabel = "Ready",
            ipAddress = "Bridge L2",
            enabled = true
        )
        val wanSaved = controller.saveWanConnection(wanProfile) as RouterResult.Success
        assertTrue(wanSaved.data.wanConnections.any { it.id == "wan-test" })
        val wanDeleted = controller.deleteWanConnection("wan-test") as RouterResult.Success
        assertFalse(wanDeleted.data.wanConnections.any { it.id == "wan-test" })
    }
}

