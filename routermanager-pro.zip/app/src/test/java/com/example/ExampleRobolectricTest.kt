package com.example

import android.Manifest
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.test.core.app.ApplicationProvider
import com.example.core.AppContainer
import com.example.core.AppMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createAndroidComposeRule<MainActivity>()

    @Test
    fun manifestAndAppMetadata_areConfiguredForPhysicalDeviceInstall() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("RouterManager Pro", context.getString(R.string.app_name))

        val pkgInfo = context.packageManager.getPackageInfo(
            context.packageName,
            PackageManager.GET_PERMISSIONS
        )
        val permissions = pkgInfo.requestedPermissions?.toSet().orEmpty()
        assertTrue(Manifest.permission.INTERNET in permissions)
        assertTrue(Manifest.permission.ACCESS_NETWORK_STATE in permissions)
        assertTrue(Manifest.permission.ACCESS_WIFI_STATE in permissions)
        assertFalse(Manifest.permission.ACCESS_FINE_LOCATION in permissions)

        val appFlags = context.applicationInfo.flags
        assertTrue((appFlags and ApplicationInfo.FLAG_USES_CLEARTEXT_TRAFFIC) != 0)
        assertFalse((appFlags and ApplicationInfo.FLAG_ALLOW_BACKUP) != 0)
    }

    @Test
    fun appContainer_isSingletonAcrossRecreateAndPreservesMode() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val first = AppContainer.getInstance(context)
        val second = AppContainer.getInstance(context)
        assertSame(first, second)

        first.routerController.setAppMode(AppMode.LIVE)
        composeRule.activityRule.scenario.recreate()
        composeRule.waitForIdle()

        assertEquals(AppMode.LIVE, AppContainer.getInstance(context).routerController.appMode.value)
        first.routerController.setAppMode(AppMode.GUEST)
    }

    @Test
    fun mainActivity_startupAndBottomNavigationWorkInGuestMode() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        AppContainer.getInstance(context).routerController.setAppMode(AppMode.GUEST)

        composeRule.waitUntil(timeoutMillis = 5000) {
            composeRule.onAllNodesWithTag("dashboard_list").fetchSemanticsNodes().isNotEmpty()
        }
        composeRule.onNodeWithTag("dashboard_list").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_devices").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("nav_advanced").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("advanced_settings_screen").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_theme").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("theme_screen").assertIsDisplayed()

        composeRule.onNodeWithTag("nav_dashboard").performClick()
        composeRule.waitForIdle()
        composeRule.onNodeWithTag("dashboard_list").assertIsDisplayed()
    }
}
