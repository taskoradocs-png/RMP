# RouterManager Pro UI refresh

This refresh is based on the user's supplied reference image.

## UI changes
- Dashboard now uses a compact modem status strip with model, PON RX and connected Wi-Fi count.
- Four primary actions remain in the requested order: Wi-Fi Password Management, Devices Information, Optical Information, WAN Admin Only.
- Primary dashboard actions are wide, vertically stacked gradient cards with larger icon wells, stronger contrast, and increased touch height.
- Dashboard horizontal inset reduced to 12dp to make cards use more of the available phone width while respecting screen safe areas.
- Existing Theme screen and floating assistive Home button remain in the project.

## Verification
- Source ZIP was unpacked and the dashboard composable updated.
- A full Android compile was not run in this environment because the project has no checked-in Gradle wrapper and no system Gradle/Android SDK is configured.
- This is a source/UI refresh, not a claim that an APK has been built or runtime-tested.
