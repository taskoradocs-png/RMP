# RouterManager Pro — Huawei recalibration notes

Baseline: the newly supplied `routermanager-pro (1).zip` source plus the six Huawei HAR captures supplied on 2026-11-18. The earlier patch ZIPs were not used as the baseline.

## Dashboard and navigation

1. Replaced the 2×2 tile grid with four wide, stacked dashboard bars in the requested order: Wi-Fi Password Management, Devices Information, Optical Information, WAN Admin Only.
2. Added a modem status card showing the detected model in the header, PON RX power and online Wi-Fi device count.
3. Added a persistent floating Home assistive button that returns directly to the dashboard from any navigation depth.
4. Added a direct Theme Settings entry in the dashboard header while retaining the quick light/dark toggle. Selected theme controls use green state feedback.
5. Added an explicit logout action that calls `disconnectLive()` and clears the shared session.

## Login and discovery

6. Gateway discovery now inspects the root login page for Huawei's `ProductName` variable and labels the detected modem from the actual login page response.
7. The `192.168.100.1` gateway selects `huawei_hs8346r`, HTTP port 80.
8. The login screen's detected Huawei Connect action pre-fills `telecomadmin` / `admintelecom` and submits the Huawei authentication flow using the live page nonce and shared cookie jar.
9. No background lifecycle disconnect was added. The session stays in memory while the process remains alive; process death/restart persistence is not implemented.

## Huawei adapter

10. Router model resolution prefers the login page's `ProductName`, then falls back to the model field in the device information page. Supported model labels include HS8346R and HG8145C.
11. Connected-device parsing no longer treats `IPv4Enabled` as online status. It reads `USERDevice(...)` status, host name, MAC, IP and connection type, and merges Wi-Fi block state from `stWlanMacFilter(...)`.
12. Wi-Fi block/unblock uses the captured `addajax.cgi` / `delajax.cgi` flow and the per-router dynamic token. Blocking adds only missing SSID-1 / SSID-2 entries; unblocking removes every matching MAC-filter object. AJAX JSON is hex-escaped by this firmware, so the response is decoded before checking `result`.
13. The Wi-Fi action label changes between Block WiFi and Unblock WiFi; the active blocked state is green for that device. Internet-block state is also represented as green with an Unblock Internet Access label.
14. Internet filtering reads `stFilterIn(...)` and `stPortFilter(...)`. When necessary it switches the Huawei IP-filter policy to Custom mode, creates a per-device `Drop` rule and verifies the rule by reading the page back. This policy change is global to the router's IP-filter feature and is disclosed in the confirmation prompt. The supplied HAR proves the CGI fields and policy page structure; the custom-mode Drop sequence is an implementation inference from that page's JavaScript and must be tested on the physical firmware before relying on it.
15. WAN retrieval now reads the dynamic token from `/html/bbsp/wan/wan.asp`, POSTs `/html/bbsp/common/getwanlist.asp`, and parses the active PPPoE/IP record. WAN UI displays primary WAN details read-only; WAN profile writes remain disabled to avoid modifying ISP service configuration.
16. Optical parsing uses `stOpticInfo(...)` embedded in the captured optical page. Missing `--` readings are represented as unavailable, and module vendor, serial, wavelengths and max distance are exposed.

## Verification status

- The source and HARs were inspected and the changes were made against the supplied baseline.
- A full Android Gradle build could not be run here: this archive lacks `gradlew` and the Gradle wrapper JAR, and this environment has no Android SDK or system Gradle installation.
- No live Huawei router was available for integration testing. In particular, verify Internet filtering on the physical router because the captured requests did not include a fully confirmed custom-mode Drop rule readback cycle.
