package com.example.adapters.live

import android.util.Base64
import com.example.core.RouterResult
import com.example.models.*
import com.example.networking.RouterEndpointClient
import com.example.router.huawei.hs8346r.HuaweiHs8346rProfile
import com.example.authentication.RouterSessionManager
import okhttp3.FormBody
import okhttp3.HttpUrl
import okhttp3.Request
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Live adapter for the compatible Huawei ONT web-UI / CGI family. The device model is resolved from router information at runtime.
 *
 * Handles HTTP authentication, router information,
 * optical telemetry and session management.
 */
class HuaweiHs8346rAdapter(
    private val hostIp: String = "192.168.100.1",
    private val port: Int = 80,
    private val sessionManager: RouterSessionManager = RouterSessionManager()
) : BaseLiveRouterAdapter() {

    private val baseUrl = "http://$hostIp:$port"

    private val client = RouterEndpointClient.createClient(
        allowPrivateLanSelfSignedTls = true,
        targetHost = hostIp,
        enableDebugMetadataLogs = false
    ).newBuilder()
        .cookieJar(sessionManager.cookieJar)
        .build()

    private var activeSessionToken: String? = null

    override val capabilities = RouterCapability(
        supportedFeatures = setOf(
            RouterFeature.ROUTER_INFO,
            RouterFeature.WAN_INFO,
            RouterFeature.DEVICE_LIST,
            RouterFeature.OPTICAL_INFO,
            RouterFeature.WIFI_BASIC,
            RouterFeature.DEVICE_BLOCKING,
            RouterFeature.DEVICE_INTERNET_BLOCKING,
        ),
        supports5Ghz = false,
        maxGuestNetworks = 0,
        capabilityNotes =
            "Huawei family HTTP CGI/ASP adapter. Actual model is read from device information when available; unsupported firmware-specific capabilities remain disabled until verified."
    )

    override val descriptor = AdapterDescriptor(
        id = "huawei_hs8346r",
        displayName = "Huawei Modem",
        manufacturer = "Huawei",
        supportedModels = listOf("HS8346R", "HG8145C"),
        minFirmwareVersion = HuaweiHs8346rProfile.FIRMWARE_VERSION,
        protocolDescription =
            "Huawei ONT HTTP CGI / ASP session communication",
        capability = capabilities,
        isLiveTransportReady = true
    )

    // ------------------------------------------------
    // AUTHENTICATION
    // ------------------------------------------------

    override suspend fun authenticate(
        credentials: RouterCredentials
    ): RouterResult<RouterSession> = withContext(Dispatchers.IO) {
        try {
                sessionManager.clearSession()
                activeSessionToken = null

                // Fetch router login page.
                val indexRequest = Request.Builder()
                    .url("$baseUrl/")
                    .get()
                    .build()

                val indexHtml = client.newCall(indexRequest)
                    .execute()
                    .use { response ->

                        if (!response.isSuccessful) {
                            return@withContext RouterResult.Failure(
                                "Unable to access Huawei login page. HTTP ${response.code}"
                            )
                        }

                        response.body?.string().orEmpty()
                    }

                // Extract dynamic Huawei token.
                val tokenRegex = Regex(
                    """function\s+GetRandCnt\s*\(\s*\)\s*\{\s*return\s*['"]([a-fA-F0-9]+)['"]"""
                )

                val token = tokenRegex.find(indexHtml)
                    ?.groupValues
                    ?.get(1)
                    ?: return@withContext RouterResult.Failure(
                        "Huawei authentication token was not found."
                    )

                // Encode password according to the observed login protocol.
                val encodedPassword = Base64.encodeToString(
                    credentials.password.toByteArray(Charsets.UTF_8),
                    Base64.NO_WRAP
                )

                val loginBody = FormBody.Builder()
                    .add("UserName", credentials.username)
                    .add("PassWord", encodedPassword)
                    .add("x.X_HW_Token", token)
                    .build()

                val loginRequest = Request.Builder()
                    .url("$baseUrl${HuaweiHs8346rProfile.Paths.LOGIN}")
                    .post(loginBody)
                    .addHeader(
                        "Cookie",
                        "Cookie=body:Language:english:id=-1"
                    )
                    .build()

                val loginSuccess = client.newCall(loginRequest)
                    .execute()
                    .use { response ->

                        val body = response.body?.string().orEmpty()

                        response.isSuccessful &&
                            !body.contains("DivErrPage", ignoreCase = true) &&
                            !body.contains("Login failed", ignoreCase = true)
                    }

                if (!loginSuccess) {
                    sessionManager.clearSession()

                    return@withContext RouterResult.Failure(
                        "Huawei modem authentication rejected. Verify credentials."
                    )
                }

                activeSessionToken = token

                val session = RouterSession(
                    sessionId = "huawei-session-${System.currentTimeMillis()}",
                    profileId = "huawei_hs8346r",
                    routerIp = hostIp,
                    adapterId = descriptor.id,
                    authenticatedUsername = credentials.username,
                    establishedAtEpochMs = System.currentTimeMillis(),
                    isGuestSession = false
                )

                RouterResult.Success(session)

        } catch (e: Exception) {
            sessionManager.clearSession()
            val detail = e.message?.takeIf { it.isNotBlank() }
                ?: e.cause?.message?.takeIf { it.isNotBlank() }
                ?: "no exception message"
            RouterResult.Failure(
                "Huawei authentication failed (${e::class.java.simpleName}): $detail"
            )
        }
    }

    // ------------------------------------------------
    // DISCONNECT
    // ------------------------------------------------

    override suspend fun disconnect(): RouterResult<Unit> {

        return try {

            val request = Request.Builder()
                .url(
                    "$baseUrl${HuaweiHs8346rProfile.Paths.LOGOUT}" +
                        "?RequestFile=html/logout.html"
                )
                .post(FormBody.Builder().build())
                .build()

            client.newCall(request).execute().close()

            activeSessionToken = null
            sessionManager.clearSession()

            RouterResult.Success(Unit)

        } catch (e: Exception) {

            activeSessionToken = null
            sessionManager.clearSession()

            RouterResult.Failure(
                "Huawei logout failed: ${e.localizedMessage}"
            )
        }
    }

    // ------------------------------------------------
    // ROUTER INFORMATION
    // ------------------------------------------------

    override suspend fun getRouterInfo(): RouterResult<RouterInfo> =
        withContext(Dispatchers.IO) {
            try {
                if (activeSessionToken == null) {
                    return@withContext RouterResult.NotConnected(
                        "Authenticate before requesting router information."
                    )
                }

                val deviceHtml = client.newCall(
                    Request.Builder()
                        .url("$baseUrl/html/ssmp/deviceinfo/deviceinfo.asp")
                        .get()
                        .build()
                ).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext RouterResult.Failure(
                            "Huawei device information request failed: HTTP ${response.code}."
                        )
                    }
                    response.body?.string().orEmpty()
                }

                val deviceArgs = Regex(
                    """new\s+stDeviceInfo\s*\((.*?)\)"""
                ).find(deviceHtml)?.groupValues?.get(1)?.let(::parseJsArgs)
                    ?: return@withContext RouterResult.Failure(
                        "Huawei device information page did not contain stDeviceInfo."
                    )

                if (deviceArgs.size < 10) {
                    return@withContext RouterResult.Failure(
                        "Huawei device information record is incomplete (${deviceArgs.size}/10 fields)."
                    )
                }

                val loginPageModel = runCatching {
                    client.newCall(Request.Builder().url("$baseUrl/").get().build()).execute().use { response ->
                        val loginHtml = response.body?.string().orEmpty()
                        Regex("""ProductName\s*=\s*['\"]([^'\"]+)['\"]""", RegexOption.IGNORE_CASE)
                            .find(loginHtml)?.groupValues?.get(1)
                    }
                }.getOrNull()
                val model = loginPageModel?.takeIf { it.isNotBlank() }
                    ?: deviceArgs[4].trim().takeIf { it.isNotBlank() && !it.equals("unknown", true) }
                    ?: "Huawei Modem"
                val manufacturer = when (deviceArgs[5].uppercase()) {
                    "HWTC" -> "Huawei"
                    else -> deviceArgs[5].ifBlank { "Huawei" }
                }
                val serial = deviceArgs[1].takeIf { it.isNotBlank() }?.let {
                    if (it.length > 6) "••••••${it.takeLast(4)}" else it
                } ?: "Unavailable"

                // WAN page data is collected independently; WAN failure must not
                // discard valid device identity information.
                // The HAR shows that waninfo.asp loads its WAN records from
                // the common WAN list script. The actual IPWanList/WanIP record
                // is present in wan_list.asp, not reliably in waninfo.asp.
                val wanInfo = (getNetworkSettings() as? RouterResult.Success)?.data?.wan
                val wanIp = wanInfo?.publicIp?.takeIf { it.isNotBlank() && it != "Unavailable" && it != "0.0.0.0" }
                val wanStatus = wanInfo?.statusLabel.orEmpty()
                val cpu = Regex("""var\s+cpuUsed\s*=\s*['"]?(\d+)""")
                    .find(deviceHtml)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                val memory = Regex("""var\s+memUsed\s*=\s*['"]?(\d+)""")
                    .find(deviceHtml)?.groupValues?.get(1)?.toIntOrNull() ?: 0
                val uptime = Regex("""dev_uptime\s*=\s*['"]?(\d+)""")
                    .find(deviceHtml)?.groupValues?.get(1)?.toLongOrNull() ?: 0L

                RouterResult.Success(
                    RouterInfo(
                        manufacturer = manufacturer,
                        model = model,
                        firmwareVersion = deviceArgs[3].ifBlank { "Unavailable" },
                        hardwareRevision = deviceArgs[2].ifBlank { "Unavailable" },
                        routerIp = hostIp,
                        wanIp = wanIp,
                        internetConnected = wanStatus.equals("Connected", true) ||
                            wanStatus.equals("Up", true),
                        uptimeSeconds = uptime,
                        cpuLoadPercent = cpu,
                        memoryLoadPercent = memory,
                        serialMasked = serial,
                        connectionState = RouterConnectionState.CONNECTED,
                        adapterId = descriptor.id,
                        adapterName = descriptor.displayName
                    )
                )
            } catch (e: Exception) {
                val detail = e.message?.takeIf { it.isNotBlank() }
                    ?: e.cause?.message?.takeIf { it.isNotBlank() }
                    ?: "no exception message (${e::class.java.simpleName})"
                RouterResult.Failure("Huawei device/WAN information error: $detail")
            }
        }

    // ------------------------------------------------
    // WAN ADMINISTRATION (read-only fields grounded in wan_list.asp HAR)
    // ------------------------------------------------

    override suspend fun getNetworkSettings(): RouterResult<NetworkSettings> = withContext(Dispatchers.IO) {
        try {
            if (activeSessionToken == null) return@withContext RouterResult.NotConnected("Authenticate before requesting WAN information.")
            val wanPage = client.newCall(Request.Builder().url("$baseUrl/html/bbsp/wan/wan.asp").get().build())
                .execute().use { response ->
                    if (!response.isSuccessful) return@withContext RouterResult.Failure("Huawei WAN page failed: HTTP ${response.code}.")
                    response.body?.string().orEmpty()
                }
            val token = Regex("""id=['"]hwonttoken['"][^>]+value=['"]([^'"]+)['"]""", RegexOption.IGNORE_CASE)
                .find(wanPage)?.groupValues?.get(1)
                ?: return@withContext RouterResult.Failure("Huawei WAN page did not provide its dynamic token.")
            val wanScript = client.newCall(Request.Builder()
                .url("$baseUrl/html/bbsp/common/getwanlist.asp")
                .header("Referer", "$baseUrl/html/bbsp/wan/wan.asp")
                .post(FormBody.Builder().add("x.X_HW_Token", token).build())
                .build())
                .execute().use { response ->
                    if (!response.isSuccessful) return@withContext RouterResult.Failure("Huawei WAN list request failed: HTTP ${response.code}.")
                    response.body?.string().orEmpty()
                }
            val ppp = Regex("""new\s+WanPPP\s*\((.*?)\)""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                .find(wanScript)?.groupValues?.get(1)?.let(::parseJsArgs)
            val ip = Regex("""new\s+WanIP\s*\((.*?)\)""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                .find(wanScript)?.groupValues?.get(1)?.let(::parseJsArgs)
            val record = ppp ?: ip ?: return@withContext RouterResult.Failure("Huawei WAN list contained no PPPoE or IP WAN record.")
            val isPpp = ppp != null
            val status = record.getOrNull(3).orEmpty().ifBlank { "Unknown" }
            val publicIp = record.getOrNull(if (isPpp) 12 else 10).orEmpty()
            val gateway = record.getOrNull(if (isPpp) 13 else 11).orEmpty()
            val dns = record.getOrNull(if (isPpp) 16 else 14).orEmpty().split(',').map { it.trim() }.filter { it.isNotBlank() }
            val vlan = record.getOrNull(if (isPpp) 21 else 17)?.toIntOrNull()
            val mtu = record.getOrNull(if (isPpp) 35 else 24)?.toIntOrNull() ?: 0
            val name = record.getOrNull(6).orEmpty().ifBlank { "Primary WAN" }
            val service = record.getOrNull(if (isPpp) 25 else 26).orEmpty().ifBlank { "INTERNET" }
            val connType = if (isPpp) WanConnectionType.PPPOE else WanConnectionType.DHCP
            val wanInfo = WanInfo(
                statusLabel = status,
                connectionType = connType,
                publicIp = publicIp.ifBlank { "Unavailable" },
                subnetMask = "Unavailable",
                gatewayIp = gateway.ifBlank { "Unavailable" },
                primaryDns = dns.getOrNull(0) ?: "Unavailable",
                secondaryDns = dns.getOrNull(1) ?: "Unavailable",
                mtu = mtu,
                ispName = record.getOrNull(if (isPpp) 36 else 0).orEmpty().ifBlank { "Unavailable" }
            )
            val profile = WanConnectionProfile(
                id = record.getOrNull(0).orEmpty().ifBlank { "primary-wan" },
                name = name,
                serviceType = service,
                connectionType = connType,
                vlanId = vlan,
                isDefaultRoute = true,
                statusLabel = status,
                ipAddress = publicIp,
                enabled = record.getOrNull(7).equals("1")
            )
            RouterResult.Success(NetworkSettings(
                wan = wanInfo,
                wanConnections = listOf(profile),
                lan = LanConfig(routerIp = hostIp, subnetMask = "Unavailable", hostname = "Huawei ONT", igmpSnoopingEnabled = false),
                dhcp = DhcpConfig(enabled = false, startIp = "Unavailable", endIp = "Unavailable", leaseTimeMinutes = 0, activeLeasesCount = 0, staticReservationsCount = 0),
                dns = DnsConfig(mode = DnsMode.ISP_AUTO, primaryDns = wanInfo.primaryDns, secondaryDns = wanInfo.secondaryDns, dnsOverHttpsEnabled = false),
                portForwardingRules = emptyList(),
                firewall = FirewallConfig(level = FirewallLevel.CUSTOM, spiFirewallEnabled = false, dosProtectionEnabled = false, respondToWanPing = false, ipv6FirewallEnabled = false),
                upnpEnabled = false
            ))
        } catch (e: Exception) {
            RouterResult.Failure("Huawei WAN information error: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    // ------------------------------------------------
    // OPTICAL INFORMATION
    // ------------------------------------------------

    override suspend fun getOpticalInfo(): RouterResult<OpticalInfo> =
        withContext(Dispatchers.IO) {
            try {
                if (activeSessionToken == null) {
                    return@withContext RouterResult.NotConnected(
                        "Authenticate before requesting optical information."
                    )
                }

                // Confirmed in the supplied HS8346R HAR capture.
                val request = Request.Builder()
                    .url("$baseUrl/html/amp/opticinfo/opticinfo.asp")
                    .get()
                    .build()

                val html = client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext RouterResult.Failure(
                            "Optical request failed: HTTP ${response.code}."
                        )
                    }
                    response.body?.string().orEmpty()
                }

                val match = Regex(
                    """new\s+stOpticInfo\s*\(([^)]*)\)""",
                    RegexOption.IGNORE_CASE
                ).find(html) ?: return@withContext RouterResult.Failure(
                    "Optical telemetry record was not present in the router response."
                )

                val args = parseJsArgs(match.groupValues[1])
                if (args.size < 15) {
                    return@withContext RouterResult.Failure(
                        "Invalid optical telemetry: expected 15 fields, received ${args.size}."
                    )
                }

                // The HAR shows that the optical page embeds stOpticInfo directly in
                // opticinfo.asp. There is no separate getOpticInfo.cgi request in this firmware.
                // A literal '--' is a valid unavailable reading, not a parse failure.
                val txPower = args[1].toFloatOrNull() ?: Float.NaN
                val rxPower = args[2].toFloatOrNull() ?: Float.NaN
                val voltageMv = args[3].toFloatOrNull() ?: Float.NaN
                val temperature = args[4].toFloatOrNull() ?: Float.NaN
                val bias = args[5].toFloatOrNull() ?: Float.NaN
                val ponMode = Regex(
                    """ontPonMode\s*=\s*['"]([^'"]+)['"]""",
                    RegexOption.IGNORE_CASE
                ).find(html)?.groupValues?.get(1) ?: "Unknown"
                val losStatus = args[14]
                val vendor = args.getOrNull(8).orEmpty().trim()
                val serial = args.getOrNull(9).orEmpty().trim()
                RouterResult.Success(
                    OpticalInfo(
                        ponMode = ponMode,
                        linkState = when (losStatus) {
                            "0" -> "No LOS"
                            "1" -> "LOS"
                            else -> "Unknown"
                        },
                        rxPowerDbm = rxPower,
                        txPowerDbm = txPower,
                        temperatureC = temperature,
                        voltageV = if (voltageMv.isFinite()) voltageMv / 1000.0f else Float.NaN,
                        biasCurrentMa = bias,
                        vendorName = vendor.ifBlank { "Unavailable" },
                        vendorSerial = serial.ifBlank { "Unavailable" },
                        txWavelengthNm = args.getOrNull(11).orEmpty().ifBlank { "Unavailable" },
                        rxWavelengthNm = args.getOrNull(12).orEmpty().ifBlank { "Unavailable" },
                        maxDistanceKm = args.getOrNull(13).orEmpty().ifBlank { "Unavailable" }
                    )
                )
            } catch (e: Exception) {
                val detail = e.message?.takeIf { it.isNotBlank() }
                    ?: e.cause?.message?.takeIf { it.isNotBlank() }
                    ?: "no exception message (${e::class.java.simpleName})"
                RouterResult.Failure("Optical information error: $detail")
            }
        }

    // ------------------------------------------------

    // ------------------------------------------------
    // WI-FI CONFIGURATION (HAR-VERIFIED HS8346R)
    // ------------------------------------------------

    private data class HuaweiWifiSnapshot(
        val config: WifiConfig,
        val ssidDomain: String,
        val wpsDomain: String,
        val pskDomain: String,
        val standard: String,
        val groupRekey: String,
        val token: String
    )

    private suspend fun readHuaweiWifiSnapshot(): RouterResult<HuaweiWifiSnapshot> =
        withContext(Dispatchers.IO) {
            try {
                if (activeSessionToken == null) {
                    return@withContext RouterResult.NotConnected(
                        "Authenticate before reading Wi-Fi settings."
                    )
                }
                val request = Request.Builder()
                    .url("$baseUrl/html/amp/wlanbasic/WlanBasic.asp")
                    .get()
                    .build()
                val html = client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext RouterResult.Failure(
                            "Wi-Fi configuration page failed: HTTP ${response.code}."
                        )
                    }
                    response.body?.string().orEmpty()
                }

                val token = Regex(
                    """<input[^>]+id=['"]hwonttoken['"][^>]+value=['"]([^'"]+)['"]""",
                    RegexOption.IGNORE_CASE
                ).find(html)?.groupValues?.get(1)
                    ?: Regex(
                        """<input[^>]+name=['"]onttoken['"][^>]+value=['"]([^'"]+)['"]""",
                        RegexOption.IGNORE_CASE
                    ).find(html)?.groupValues?.get(1)
                    ?: return@withContext RouterResult.Failure(
                        "Huawei Wi-Fi page did not provide a dynamic X_HW_Token."
                    )

                val wlanArgs = Regex(
                    """new\s+stWlan\s*\((.*?)\)\s*,\s*null""",
                    setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
                ).find(html)?.groupValues?.get(1)?.let(::parseJsArgs)
                    ?: return@withContext RouterResult.Failure(
                        "Huawei Wi-Fi page did not contain a WLAN configuration record."
                    )
                val radioArgs = Regex(
                    """new\s+stWlanWifi\s*\((.*?)\)\s*,\s*null""",
                    setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
                ).find(html)?.groupValues?.get(1)?.let(::parseJsArgs)
                    ?: return@withContext RouterResult.Failure(
                        "Huawei Wi-Fi page did not contain a wireless radio record."
                    )
                val pskArgs = Regex(
                    """new\s+stPreSharedKey\s*\((.*?)\)\s*,\s*null""",
                    setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
                ).find(html)?.groupValues?.get(1)?.let(::parseJsArgs)
                    ?: return@withContext RouterResult.Failure(
                        "Huawei firmware did not expose the WPA pre-shared key in this page."
                    )

                if (wlanArgs.size < 19 || radioArgs.size < 10 || pskArgs.size < 2) {
                    return@withContext RouterResult.Failure(
                        "Huawei Wi-Fi response was incomplete (WLAN=${wlanArgs.size}, radio=${radioArgs.size}, key=${pskArgs.size})."
                    )
                }

                val enabled = wlanArgs[2] == "1" && radioArgs[2] == "1"
                val security = if (wlanArgs[7].contains("WPA", true)) {
                    WifiSecurityMode.WPA2_PSK
                } else {
                    WifiSecurityMode.OPEN
                }
                val config = WifiConfig(
                    masterWifiEnabled = enabled,
                    band24 = WifiBandConfig(
                        band = WifiBand.BAND_2_4_GHZ,
                        enabled = enabled,
                        ssid = wlanArgs[3],
                        securityMode = security,
                        password = pskArgs[1],
                        hiddenSsid = wlanArgs[4] != "1",
                        channel = radioArgs[5].ifBlank { "Auto" },
                        availableChannels = emptyList(),
                        bandwidthMhz = radioArgs[9].ifBlank { "Auto" },
                        availableBandwidthsMhz = emptyList(),
                        txPowerPercent = radioArgs[6].toIntOrNull()?.coerceIn(0, 100) ?: 100,
                        connectedClientsCount = wlanArgs[5].toIntOrNull() ?: 0
                    ),
                    band5 = null,
                    guestNetwork = null
                )
                RouterResult.Success(
                    HuaweiWifiSnapshot(
                        config = config,
                        ssidDomain = wlanArgs[0],
                        wpsDomain = "${wlanArgs[0]}.WPS",
                        pskDomain = pskArgs[0],
                        standard = radioArgs[4].ifBlank { "11bgn" },
                        groupRekey = wlanArgs[18].ifBlank { "3600" },
                        token = token
                    )
                )
            } catch (e: Exception) {
                val detail = e.message?.takeIf { it.isNotBlank() }
                    ?: "no exception message (${e::class.java.simpleName})"
                RouterResult.Failure("Huawei Wi-Fi read failed: $detail")
            }
        }

    override suspend fun getWifiConfig(): RouterResult<WifiConfig> =
        when (val result = readHuaweiWifiSnapshot()) {
            is RouterResult.Success -> RouterResult.Success(result.data.config)
            is RouterResult.Failure -> result
            is RouterResult.Unsupported -> result
            is RouterResult.NotConnected -> result
            is RouterResult.AuthRequired -> result
            is RouterResult.ValidationError -> result
        }

    private suspend fun saveHuaweiWifiConfig(
        ssid: String,
        password: String,
        enabled: Boolean,
        hiddenSsid: Boolean,
        securityMode: WifiSecurityMode
    ): RouterResult<WifiConfig> = withContext(Dispatchers.IO) {
        try {
            val read = readHuaweiWifiSnapshot()
            if (read !is RouterResult.Success) {
                return@withContext when (read) {
                    is RouterResult.Failure -> read
                    is RouterResult.NotConnected -> read
                    is RouterResult.Unsupported -> read
                    is RouterResult.AuthRequired -> read
                    is RouterResult.ValidationError -> read
                    else -> RouterResult.Failure("Unable to read current Huawei Wi-Fi settings.")
                }
            }
            val snap = read.data
            val isOpen = securityMode == WifiSecurityMode.OPEN
            val beacon = if (isOpen) "None" else "WPAand11i"
            val auth = if (isOpen) "None" else "PSKAuthentication"
            val encryption = if (isOpen) "None" else "TKIPandAESEncryption"
            val radioEnabled = if (enabled) "1" else "0"
            val advertise = if (hiddenSsid) "0" else "1"

            val url = "$baseUrl/html/amp/wlanbasic/set.cgi" +
                "?w=InternetGatewayDevice.X_HW_DEBUG.AMP.WifiCoverSetWlanBasic" +
                "&y=${snap.ssidDomain}&z=${snap.wpsDomain}&k=${snap.pskDomain}" +
                "&RequestFile=html/amp/wlanbasic/WlanBasic.asp"
            val body = FormBody.Builder()
                .add("y.Enable", radioEnabled)
                .add("y.SSIDAdvertisementEnabled", advertise)
                .add("y.SSID", ssid)
                .add("y.X_HW_AssociateNum", "32")
                .add("y.BeaconType", beacon)
                .add("y.X_HW_WPAand11iAuthenticationMode", auth)
                .add("y.X_HW_WPAand11iEncryptionModes", encryption)
                .add("k.PreSharedKey", if (isOpen) "" else password)
                .add("y.X_HW_GroupRekey", snap.groupRekey)
                .add("z.Enable", "0")
                .add("z.X_HW_ConfigMethod", "PushButton")
                .add("w.SsidInst", "1")
                .add("w.SSID", ssid)
                .add("w.Enable", radioEnabled)
                .add("w.Standard", snap.standard)
                .add("w.BasicAuthenticationMode", "None")
                .add("w.BasicEncryptionModes", "TKIPandAESEncryption")
                .add("w.WPAAuthenticationMode", "EAPAuthentication")
                .add("w.WPAEncryptionModes", "TKIPandAESEncryption")
                .add("w.IEEE11iAuthenticationMode", "EAPAuthentication")
                .add("w.IEEE11iEncryptionModes", "TKIPandAESEncryption")
                .add("w.MixAuthenticationMode", auth)
                .add("w.MixEncryptionModes", encryption)
                .add("w.BeaconType", beacon)
                .add("w.WEPEncryptionLevel", "104-bit")
                .add("w.WEPKeyIndex", "1")
                .add("w.Key", if (isOpen) "" else password)
                .add("x.X_HW_Token", snap.token)
                .build()
            val saveRequest = Request.Builder().url(url).post(body).build()
            client.newCall(saveRequest).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext RouterResult.Failure(
                        "Huawei rejected Wi-Fi update: HTTP ${response.code}."
                    )
                }
                response.body?.string().orEmpty()
            }

            val verify = readHuaweiWifiSnapshot()
            if (verify is RouterResult.Success) {
                val actual = verify.data.config.band24
                if (actual.ssid != ssid || actual.enabled != enabled ||
                    (!isOpen && actual.password != password)
                ) {
                    return@withContext RouterResult.Failure(
                        "Huawei accepted the request but read-back verification did not match the requested Wi-Fi settings."
                    )
                }
                RouterResult.Success(verify.data.config)
            } else {
                when (verify) {
                    is RouterResult.Failure -> verify
                    is RouterResult.NotConnected -> verify
                    is RouterResult.Unsupported -> verify
                    is RouterResult.AuthRequired -> verify
                    is RouterResult.ValidationError -> verify
                    else -> RouterResult.Failure("Wi-Fi settings were submitted but could not be verified.")
                }
            }
        } catch (e: Exception) {
            val detail = e.message?.takeIf { it.isNotBlank() }
                ?: "no exception message (${e::class.java.simpleName})"
            RouterResult.Failure("Huawei Wi-Fi update failed: $detail")
        }
    }

    override suspend fun setWifiEnabled(enabled: Boolean): RouterResult<WifiConfig> {
        val current = getWifiConfig()
        if (current !is RouterResult.Success) return current
        val cfg = current.data.band24
        return saveHuaweiWifiConfig(cfg.ssid, cfg.password, enabled, cfg.hiddenSsid, cfg.securityMode)
    }

    override suspend fun updateSsid(band: WifiBand, ssid: String): RouterResult<WifiConfig> {
        if (band != WifiBand.BAND_2_4_GHZ) {
            return RouterResult.Unsupported(
                featureName = "5 GHz Wi-Fi",
                reason = "The supplied HAR exposes only one 2.4 GHz WLAN record; 5 GHz support is not confirmed."
            )
        }
        val current = getWifiConfig()
        if (current !is RouterResult.Success) return current
        val cfg = current.data.band24
        return saveHuaweiWifiConfig(ssid, cfg.password, cfg.enabled, cfg.hiddenSsid, cfg.securityMode)
    }

    override suspend fun updateWifiPassword(band: WifiBand, password: String): RouterResult<WifiConfig> {
        if (band != WifiBand.BAND_2_4_GHZ) {
            return RouterResult.Unsupported(
                featureName = "5 GHz Wi-Fi",
                reason = "The supplied HAR exposes only one 2.4 GHz WLAN record; 5 GHz support is not confirmed."
            )
        }
        val current = getWifiConfig()
        if (current !is RouterResult.Success) return current
        val cfg = current.data.band24
        return saveHuaweiWifiConfig(cfg.ssid, password, cfg.enabled, cfg.hiddenSsid, cfg.securityMode)
    }

    override suspend fun updateWifiBandConfig(
        band: WifiBand,
        config: WifiBandConfig
    ): RouterResult<WifiConfig> {
        if (band != WifiBand.BAND_2_4_GHZ) {
            return RouterResult.Unsupported(
                featureName = "5 GHz Wi-Fi",
                reason = "The supplied HAR exposes only one 2.4 GHz WLAN record; 5 GHz support is not confirmed."
            )
        }
        return saveHuaweiWifiConfig(
            config.ssid, config.password, config.enabled, config.hiddenSsid, config.securityMode
        )
    }

    // CONNECTED DEVICES
    // ------------------------------------------------

    override suspend fun getConnectedDevices(): RouterResult<List<ConnectedDevice>> =
        withContext(Dispatchers.IO) {
            try {
                if (activeSessionToken == null) {
                    return@withContext RouterResult.NotConnected(
                        "Authenticate before discovering connected devices."
                    )
                }

                // HAR confirms this endpoint is requested with POST.
                val request = Request.Builder()
                    .url("$baseUrl/html/bbsp/common/GetLanUserDevInfo.asp")
                    .post(FormBody.Builder().build())
                    .build()

                val html = client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext RouterResult.Failure(
                            "Connected-device request failed: HTTP ${response.code}."
                        )
                    }
                    response.body?.string().orEmpty()
                }

                // The user-device page exposes the active WLAN MAC-filter entries.
                // These are the same entries managed by addajax.cgi / delajax.cgi.
                val userDevicePage = client.newCall(
                    Request.Builder()
                        .url("$baseUrl/html/bbsp/userdevinfo/userdevinfosmart.asp")
                        .get()
                        .build()
                ).execute().use { response ->
                    if (response.isSuccessful) response.body?.string().orEmpty() else ""
                }
                val blockedWifiMacs = Regex(
                    """new\s+stWlanMacFilter\s*\((.*?)\)""",
                    setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
                ).findAll(userDevicePage)
                    .mapNotNull { parseJsArgs(it.groupValues[1]).getOrNull(2)?.uppercase() }
                    .toSet()

                val internetBlockedIps = readHuaweiInternetBlockedIps()
                val deviceRegex = Regex(
                    """new\s+USERDevice\s*\(([^)]*)\)""",
                    RegexOption.IGNORE_CASE
                )

                val devices = deviceRegex.findAll(html).mapNotNull { match ->
                    val args = parseJsArgs(match.groupValues[1])
                    if (args.size < 10) return@mapNotNull null

                    val ip = args[1].takeIf { it.isNotBlank() && it != "--" }
                        ?: return@mapNotNull null
                    val mac = args[2].takeIf {
                        it.matches(Regex("(?i)([0-9a-f]{2}:){5}[0-9a-f]{2}"))
                    } ?: return@mapNotNull null

                    val portType = args[7]
                    val isWifi = portType.equals("WIFI", ignoreCase = true)
                    val connection = if (isWifi) {
                        // Firmware identifies Wi-Fi but this record does not expose its band.
                        ConnectionType.WIFI_2_4_GHZ
                    } else {
                        ConnectionType.ETHERNET
                    }

                    val rawName = args[9].takeIf { it.isNotBlank() && it != "--" }
                        ?: args[5].takeIf { it.isNotBlank() && it != "--" }
                        ?: "Unknown device"

                    val category = when {
                        rawName.contains("android", true) ||
                            rawName.contains("iphone", true) ||
                            rawName.contains("redmi", true) ||
                            rawName.contains("phone", true) -> DeviceCategory.PHONE
                        rawName.contains("desktop", true) ||
                            rawName.contains("windows", true) ||
                            rawName.startsWith("DESKTOP-", true) -> DeviceCategory.DESKTOP
                        rawName.contains("laptop", true) ||
                            rawName.contains("notebook", true) -> DeviceCategory.LAPTOP
                        rawName.contains("tv", true) -> DeviceCategory.TV_MEDIA
                        else -> DeviceCategory.UNKNOWN
                    }

                    ConnectedDevice(
                        macAddress = mac,
                        name = rawName,
                        ipAddress = ip,
                        manufacturer = args[5].takeIf { it.isNotBlank() } ?: "Unknown",
                        connectionType = connection,
                        category = category,
                        isOnline = args[6].equals("Online", ignoreCase = true),
                        isBlocked = mac.uppercase() in blockedWifiMacs,
                        isInternetBlocked = ip in internetBlockedIps,
                        isGuestBlocked = false,
                        isBand24Blocked = false,
                        isBand5Blocked = false,
                        staticIpReserved = args[4].equals("Static", ignoreCase = true),
                        frequencyBandLabel = if (isWifi) "Wi-Fi · ${args[3].ifBlank { "band not reported" }}" else "Ethernet",
                        signalStrengthDbm = null,
                        linkSpeedMbps = null,
                        rxRateMbps = 0f,
                        txRateMbps = 0f,
                        totalDownloadedBytes = 0L,
                        totalUploadedBytes = 0L,
                        connectedDurationSeconds = 0L,
                        dhcpType = args[4].ifBlank { "Unknown" },
                        lastSeenLabel = args[8].takeIf { it.isNotBlank() } ?: "Unknown"
                    )
                }.toList()

                RouterResult.Success(devices)
            } catch (e: Exception) {
                val detail = e.message?.takeIf { it.isNotBlank() }
                    ?: e.cause?.message?.takeIf { it.isNotBlank() }
                    ?: "no exception message (${e::class.java.simpleName})"
                RouterResult.Failure("Connected-device discovery failed: $detail")
            }
        }

    // ------------------------------------------------
    // ROUTER REBOOT
    // ------------------------------------------------

    /**
     * Adds a device to the Huawei WLAN MAC blacklist using the exact
     * userdevinfosmart.asp AJAX workflow captured from the router.
     */
    override suspend fun blockDevice(macAddress: String): RouterResult<Unit> =
        withContext(Dispatchers.IO) {
            val normalized = macAddress.trim().uppercase()
            if (!normalized.matches(Regex("""(?:[0-9A-F]{2}:){5}[0-9A-F]{2}"""))) {
                return@withContext RouterResult.ValidationError("macAddress", "Enter a valid MAC address.")
            }
            try {
                val page = client.newCall(
                    Request.Builder().url("$baseUrl/html/bbsp/userdevinfo/userdevinfosmart.asp").get().build()
                ).execute().use { response ->
                    if (!response.isSuccessful) return@withContext RouterResult.Failure("Huawei device-management page failed: HTTP ${response.code}.")
                    response.body?.string().orEmpty()
                }
                val token = Regex("""var\s+token\s*=\s*['\"]([^'\"]+)['\"]""", RegexOption.IGNORE_CASE)
                    .find(page)?.groupValues?.get(1)
                    ?: return@withContext RouterResult.Failure("Huawei device-management token was not found.")
                // The capture shows SSID-1 and SSID-2 filter entries for a device.
                // Add only missing entries to avoid duplicate MAC-filter records.
                val existingSsids = Regex("""new\s+stWlanMacFilter\s*\((.*?)\)""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                    .findAll(page).map { parseJsArgs(it.groupValues[1]) }
                    .filter { it.getOrNull(2)?.equals(normalized, true) == true }
                    .mapNotNull { it.getOrNull(1) }
                    .toSet()
                val ssids = listOf("SSID-1", "SSID-2").filterNot { it in existingSsids }
                for (ssid in ssids) {
                    val request = Request.Builder()
                        .url("$baseUrl/html/bbsp/userdevinfo/addajax.cgi?x=InternetGatewayDevice.X_HW_Security.WLANMacFilter&RequestFile=/html/bbsp/userdevinfo/userdevinfosmart.asp")
                        .post(FormBody.Builder()
                            .add("x.SSIDName", ssid)
                            .add("x.SourceMACAddress", normalized)
                            .add("x.Enable", "1")
                            .add("x.X_HW_Token", token)
                            .build())
                        .build()
                    val body = client.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) return@withContext RouterResult.Failure("Huawei Wi-Fi block request failed: HTTP ${response.code}.")
                        response.body?.string().orEmpty()
                    }
                    val result = Regex("""[\"']result[\"']\s*:\s*(\d+)""", RegexOption.IGNORE_CASE).find(decodeJsValue(body))?.groupValues?.get(1)?.toIntOrNull()
                    if (result != 0) return@withContext RouterResult.Failure("Huawei did not confirm Wi-Fi block for $ssid (result ${result ?: "unknown"}).")
                }
                RouterResult.Success(Unit)
            } catch (e: Exception) {
                RouterResult.Failure("Huawei Wi-Fi block failed: ${e.message ?: e.javaClass.simpleName}")
            }
        }

    /** Removes a device from the WLAN MAC blacklist using its captured object path. */
    override suspend fun unblockDevice(macAddress: String): RouterResult<Unit> =
        withContext(Dispatchers.IO) {
            val normalized = macAddress.trim().uppercase()
            if (!normalized.matches(Regex("""(?:[0-9A-F]{2}:){5}[0-9A-F]{2}"""))) {
                return@withContext RouterResult.ValidationError("macAddress", "Enter a valid MAC address.")
            }
            try {
                val page = client.newCall(
                    Request.Builder().url("$baseUrl/html/bbsp/userdevinfo/userdevinfosmart.asp").get().build()
                ).execute().use { response ->
                    if (!response.isSuccessful) return@withContext RouterResult.Failure("Huawei device-management page failed: HTTP ${response.code}.")
                    response.body?.string().orEmpty()
                }
                val token = Regex("""var\s+token\s*=\s*['\"]([^'\"]+)['\"]""", RegexOption.IGNORE_CASE)
                    .find(page)?.groupValues?.get(1)
                    ?: return@withContext RouterResult.Failure("Huawei device-management token was not found.")
                val domains = Regex("""new\s+stWlanMacFilter\s*\((.*?)\)""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                    .findAll(page).map { parseJsArgs(it.groupValues[1]) }
                    .filter { it.getOrNull(2)?.equals(normalized, true) == true }
                    .mapNotNull { it.getOrNull(0)?.takeIf(String::isNotBlank) }
                    .distinct().toList()
                if (domains.isEmpty()) return@withContext RouterResult.Success(Unit)
                for (domain in domains) {
                    val request = Request.Builder()
                        .url("$baseUrl/html/bbsp/userdevinfo/delajax.cgi?x=InternetGatewayDevice.X_HW_Security.WLANMacFilter&RequestFile=/html/bbsp/userdevinfo/userdevinfosmart.asp")
                        .post(FormBody.Builder().add(domain, "").add("x.X_HW_Token", token).build())
                        .build()
                    val body = client.newCall(request).execute().use { response ->
                        if (!response.isSuccessful) return@withContext RouterResult.Failure("Huawei Wi-Fi unblock request failed: HTTP ${response.code}.")
                        response.body?.string().orEmpty()
                    }
                    val result = Regex("""[\"']result[\"']\s*:\s*(\d+)""", RegexOption.IGNORE_CASE).find(decodeJsValue(body))?.groupValues?.get(1)?.toIntOrNull()
                    if (result != 0) return@withContext RouterResult.Failure("Huawei did not confirm Wi-Fi unblock (result ${result ?: "unknown"}).")
                }
                RouterResult.Success(Unit)
            } catch (e: Exception) {
                RouterResult.Failure("Huawei Wi-Fi unblock failed: ${e.message ?: e.javaClass.simpleName}")
            }
        }

    private suspend fun readHuaweiInternetBlockedIps(): Set<String> = withContext(Dispatchers.IO) {
        runCatching {
            val html = client.newCall(Request.Builder().url("$baseUrl/html/bbsp/ipincoming/ipincoming.asp").get().build())
                .execute().use { response -> if (response.isSuccessful) response.body?.string().orEmpty() else "" }
            Regex("""new\s+stFilterIn\s*\((.*?)\)""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                .findAll(html).mapNotNull { match ->
                    val args = parseJsArgs(match.groupValues[1])
                    val ip = args.getOrNull(4).orEmpty()
                    val action = args.getOrNull(8).orEmpty()
                    ip.takeIf { it.isNotBlank() && action.equals("Drop", true) }
                }.toSet()
        }.getOrDefault(emptySet())
    }

    override suspend fun setDeviceInternetBlocked(macAddress: String, blocked: Boolean): RouterResult<Unit> =
        withContext(Dispatchers.IO) {
            val normalized = macAddress.trim().uppercase()
            try {
                val devices = getConnectedDevices()
                val device = (devices as? RouterResult.Success)?.data?.firstOrNull { it.macAddress.equals(normalized, true) }
                    ?: return@withContext RouterResult.Failure("Device $normalized was not found in the current Huawei device list.")
                if (device.ipAddress.isBlank() || device.ipAddress == "--") return@withContext RouterResult.Failure("Huawei did not provide an IPv4 address for this device.")
                val page = client.newCall(Request.Builder().url("$baseUrl/html/bbsp/ipincoming/ipincoming.asp").get().build())
                    .execute().use { response ->
                        if (!response.isSuccessful) return@withContext RouterResult.Failure("Huawei IP-filter page failed: HTTP ${response.code}.")
                        response.body?.string().orEmpty()
                    }
                val token = Regex("""id=['"]hwonttoken['"][^>]+value=['"]([^'"]+)['"]""", RegexOption.IGNORE_CASE)
                    .find(page)?.groupValues?.get(1)
                    ?: return@withContext RouterResult.Failure("Huawei IP-filter token was not found.")
                val records = Regex("""new\s+stFilterIn\s*\((.*?)\)""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                    .findAll(page).map { match -> parseJsArgs(match.groupValues[1]) }.toList()
                val existing = records.firstOrNull { args -> args.getOrNull(4) == device.ipAddress && args.getOrNull(8).equals("Drop", true) }
                if (blocked && existing != null) return@withContext RouterResult.Success(Unit)
                if (!blocked) {
                    val matching = records.filter { args -> args.getOrNull(4) == device.ipAddress && args.getOrNull(8).equals("Drop", true) }
                    for (args in matching) {
                        val domain = args.getOrNull(0).orEmpty()
                        val body = client.newCall(Request.Builder()
                            .url("$baseUrl/html/bbsp/ipincoming/del.cgi?RequestFile=html/bbsp/ipincoming/ipincoming.asp")
                            .post(FormBody.Builder().add(domain, "").add("x.X_HW_Token", token).build()).build())
                            .execute().use { response -> if (!response.isSuccessful) return@withContext RouterResult.Failure("Huawei IP-filter removal failed: HTTP ${response.code}.") else response.body?.string().orEmpty() }
                    }
                    return@withContext RouterResult.Success(Unit)
                }
                // The firmware only exposes Action when custom policy mode (2) is enabled.
                // Switch to that mode, then create an explicit Drop rule for the selected host.
                val policy = Regex("""new\s+stPortFilter\s*\((.*?)\)""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                    .find(page)?.groupValues?.get(1)?.let(::parseJsArgs)?.getOrNull(2)?.toIntOrNull() ?: 0
                var activeToken = token
                if (policy != 2) {
                    val modeBody = FormBody.Builder().add("x.IpFilterInPolicy", "2").add("x.IpFilterInRight", "1").add("x.X_HW_Token", token).build()
                    client.newCall(Request.Builder().url("$baseUrl/html/bbsp/ipincoming/set.cgi?x=InternetGatewayDevice.X_HW_Security&RequestFile=html/bbsp/ipincoming/ipincoming.asp").post(modeBody).build())
                        .execute().use { response -> if (!response.isSuccessful) return@withContext RouterResult.Failure("Could not enable Huawei custom IP-filter mode: HTTP ${response.code}.") }
                    val refreshed = client.newCall(Request.Builder().url("$baseUrl/html/bbsp/ipincoming/ipincoming.asp").get().build())
                        .execute().use { response -> if (!response.isSuccessful) return@withContext RouterResult.Failure("Huawei IP-filter page refresh failed: HTTP ${response.code}.") else response.body?.string().orEmpty() }
                    activeToken = Regex("""id=['"]hwonttoken['"][^>]+value=['"]([^'"]+)['"]""", RegexOption.IGNORE_CASE)
                        .find(refreshed)?.groupValues?.get(1) ?: return@withContext RouterResult.Failure("Huawei did not provide a refreshed IP-filter token.")
                }
                val priority = (records.mapNotNull { it.getOrNull(1)?.toIntOrNull() }.maxOrNull() ?: 0) + 1
                val addBody = FormBody.Builder()
                    .add("x.Protocol", "ALL")
                    .add("x.Direction", "Bidirectional")
                    .add("x.Name", device.name.take(32))
                    .add("x.Priority", priority.toString())
                    .add("x.Action", "Drop")
                    .add("x.SourceIPStart", device.ipAddress)
                    .add("x.SourceIPEnd", device.ipAddress)
                    .add("x.DestIPStart", device.ipAddress)
                    .add("x.DestIPEnd", device.ipAddress)
                    .add("x.LanSideTcpPort", "")
                    .add("x.LanSideUdpPort", "")
                    .add("x.WanSideTcpPort", "")
                    .add("x.WanSideUdpPort", "")
                    .add("x.X_HW_Token", activeToken)
                    .build()
                client.newCall(Request.Builder().url("$baseUrl/html/bbsp/ipincoming/add.cgi?x=InternetGatewayDevice.X_HW_Security.IpFilterIn&RequestFile=html/bbsp/ipincoming/ipincoming.asp").post(addBody).build())
                    .execute().use { response -> if (!response.isSuccessful) return@withContext RouterResult.Failure("Huawei internet-block request failed: HTTP ${response.code}.") }
                val verified = readHuaweiInternetBlockedIps()
                if (device.ipAddress in verified) RouterResult.Success(Unit)
                else RouterResult.Failure("Huawei accepted the IP-filter request, but a Drop rule for ${device.ipAddress} was not visible on read-back.")
            } catch (e: Exception) {
                RouterResult.Failure("Huawei internet access rule failed: ${e.message ?: e.javaClass.simpleName}")
            }
        }

    override suspend fun rebootRouter(): RouterResult<Unit> {

        if (activeSessionToken == null) {
            return RouterResult.NotConnected(
                "Authenticate before attempting router operations."
            )
        }

        // The actual reboot CGI endpoint and parameters have
        // not yet been verified against captured router traffic.

        return RouterResult.Failure(
            "Reboot is not enabled. Verify the Huawei reboot endpoint first."
        )
    }

    // ------------------------------------------------
    // JAVASCRIPT ARGUMENT PARSER
    // ------------------------------------------------

    private fun parseJsArgs(rawArgs: String): List<String> {

        val result = mutableListOf<String>()
        val current = StringBuilder()

        var quote: Char? = null
        var escaped = false

        for (char in rawArgs) {

            if (escaped) {
                current.append(char)
                escaped = false
                continue
            }

            if (char == '\\') {
                current.append(char)
                escaped = true
                continue
            }

            if (quote != null) {

                if (char == quote) {
                    quote = null
                } else {
                    current.append(char)
                }

                continue
            }

            if (char == '"' || char == '\'') {
                quote = char
                continue
            }

            if (char == ',') {
                result.add(decodeJsValue(current.toString()))
                current.clear()
                continue
            }

            current.append(char)
        }

        result.add(decodeJsValue(current.toString()))

        return result
    }

    private fun decodeJsValue(value: String): String {

        val cleaned = value.trim()

        return Regex("""\\x([0-9A-Fa-f]{2})""")
            .replace(cleaned) { match ->

                match.groupValues[1]
                    .toInt(16)
                    .toChar()
                    .toString()
            }
    }
}
