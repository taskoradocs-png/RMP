# RouterManager Pro — Huawei Family Edition

Android application source focused on the Huawei web-management interface family represented by the supplied HAR captures.

## Dashboard

The dashboard is organized as a modem-status header followed by four full-width, vertically stacked bars:

1. **Wi-Fi Password Management** — read and update the wireless name/password.
2. **Devices Information** — connected Wi-Fi/Ethernet clients with per-device Wi-Fi and Internet access controls.
3. **Optical Information** — PON state, RX/TX power, temperature, voltage, bias, vendor, serial and wavelengths when the router reports them.
4. **WAN Admin Only** — active primary WAN status, PPPoE/IP information, public IP, gateway, DNS, MTU and VLAN where present.

The dashboard status header displays the modem model, current optical RX reading and online Wi-Fi client count. A floating Home control is available across the navigation stack and returns directly to the dashboard. Theme settings are available from the dashboard palette icon; light/dark mode, accent colour, theme style and corner style remain configurable.

## Huawei discovery and login

- Router discovery reads the Huawei `ProductName` JavaScript variable from the gateway login page.
- The `192.168.100.1` gateway match selects the Huawei adapter, HTTP port 80.
- For this exact gateway, the Connect action pre-fills the requested local credentials (`telecomadmin` / `admintelecom`) and starts authentication. These are device defaults requested for this local Huawei gateway; change them on the router if they are still active.
- The live session remains in the app's in-memory session manager while the app process is alive. The app does not disconnect merely because it is backgrounded. The top-right logout action explicitly clears the session. Android can still terminate a background process under memory pressure; this is not durable cookie persistence across process death.

## Captured Huawei mechanisms

- Login: GET `/` reads `ProductName` and `GetRandCnt()`; POST `/login.cgi` sends `UserName`, Base64 `PassWord`, and `x.X_HW_Token`.
- Connected clients: POST `/html/bbsp/common/GetLanUserDevInfo.asp`; device records are `USERDevice(...)` values.
- Wi-Fi block state: `stWlanMacFilter(...)`; add/remove uses `addajax.cgi` and `delajax.cgi` with the page token and router object path.
- Per-device Internet filtering: the supplied IP Incoming Filter page exposes `stFilterIn(...)`, `stPortFilter(...)`, `add.cgi`, `set.cgi` and `del.cgi`. The implementation uses custom policy mode and an explicit `Drop` rule, then reads the page back before reporting success. This changes the router's global IP-filter policy to Custom mode when needed; the UI warns about this.
- WAN: GET `/html/bbsp/wan/wan.asp` retrieves the dynamic `hwonttoken`; POST `/html/bbsp/common/getwanlist.asp` returns `WanPPP(...)` / `WanIP(...)` records. WAN administration is read-only in this edition; profile creation/deletion/modification is intentionally disabled.
- Optical: the supplied page embeds `stOpticInfo(...)` directly in `/html/amp/opticinfo/opticinfo.asp`. A `--` optical reading is displayed as unavailable rather than treated as a parser failure.

## Scope and safety

Only the Huawei adapter is exposed in the live adapter selector. Other vendor adapter source files remain in the project but are not selectable. The Huawei adapter currently includes model variants `HS8346R` and `HG8145C`; router firmware variations still require physical-device verification. Use only routers you own or are authorized to administer. Do not share unredacted HAR files, credentials, session cookies or CSRF tokens.

## Build

This source archive does not contain the Gradle wrapper script/JAR and the editing environment did not have an Android SDK or system Gradle installed. Import into Android Studio or your existing GitHub Actions build workflow and run `:app:assembleDebug`. A successful build and physical-router operation test have not yet been verified in this environment.
